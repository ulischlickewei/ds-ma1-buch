var ptx_lunr_search_style = "textbook";
var ptx_lunr_docs = [
{
  "id": "front-colophon",
  "level": "1",
  "url": "front-colophon.html",
  "type": "Impressum",
  "number": "",
  "title": "Impressum",
  "body": "  "
},
{
  "id": "ma1-ds-3-4",
  "level": "1",
  "url": "ma1-ds-3-4.html",
  "type": "Einleitung",
  "number": "",
  "title": "Vorwort: Wie Sie dieses Buch nutzen",
  "body": " Vorwort: Wie Sie dieses Buch nutzen  Dieses Buch begleitet die Vorlesung Mathematik 1 in den Studiengängen Wirtschaftsingenieurwesen und Data Science in Technik und Wirtschaft. Es behandelt komplexe Zahlen, Folgen und Reihen, Funktionen und Differenzialrechnung, Integralrechnung sowie gewöhnliche Differenzialgleichungen — in zehn Abschnitten, einem pro Vorlesungswoche.   Die Vorlesung ist umgedreht. Sie lesen jede Woche vor der Vorlesung den zugehörigen Abschnitt zu Hause. In der Vorlesung selbst wird der Stoff nicht noch einmal vorgetragen, sondern an Aufgaben vertieft, diskutiert und auf Fragen hin abgeklopft. Das funktioniert nur, wenn Sie vorbereitet kommen — und dafür ist dieses Buch geschrieben. Planen Sie für die Vorbereitung eines Abschnitts etwa zwei bis drei Stunden konzentriertes Lesen ein.   So ist ein Abschnitt aufgebaut. Jeder Abschnitt beginnt mit Lernzielen : Diese Liste sagt Ihnen, was Sie am Ende können sollten — lesen Sie sie zuerst und am Ende noch einmal. Dann folgt der eigentliche Stoff: Definitionen legen Begriffe fest, Sätze halten die Rechenregeln und Zusammenhänge fest, und Beispiele zeigen, wie man damit rechnet. Die Beispiele sind das Herzstück: Rechenbeispiele führen ein Verfahren Schritt für Schritt vor, Anwendungsbeispiele zeigen, wo dasselbe Verfahren in Data Science, Wirtschaft oder Technik gebraucht wird — von der Wechselstromrechnung über Zinseszins, Grenzkosten und Wahrscheinlichkeitsdichten bis zum Gradientenabstieg. Beispiele mit dem Zusatz (zur Vertiefung) im Titel können Sie bei der ersten Vorbereitung überspringen: Der übrige Text kommt ohne sie aus, und die Kurztests in der Vorlesung setzen sie nicht voraus. Eine Zusammenfassung bündelt am Ende das Wichtigste auf einer Seite, und einige kurze Übungsaufgaben lassen Sie prüfen, ob Sie den Abschnitt verstanden haben.   Lesen Sie mit Stift und Papier. Mathematik liest man nicht wie einen Roman. Die Lösungen der Beispiele sind in der Online-Version zunächst eingeklappt: Versuchen Sie jedes Beispiel erst selbst, und klappen Sie die Lösung dann zum Vergleich auf. Wenn eine Rechnung im Text einen Schritt überspringt, rechnen Sie ihn nach. Und wenn etwas unklar bleibt, notieren Sie die Frage — genau dafür ist die Vorlesung da.  Ziel des Kurses ist es, typische Problemstrukturen zu erkennen, Standardverfahren sicher anzuwenden und ein belastbares Verständnis der mathematischen Werkzeuge zu entwickeln, die in Data Science und Ingenieurpraxis täglich gebraucht werden.   Zur Entstehung dieses Buches. Der Text wurde auf Grundlage der Vorlesungsfolien des Autors mithilfe künstlicher Intelligenz (KI) generiert. Der Autor hat ihn anschließend sorgfältig durchgesehen und kuratiert und trägt die Verantwortung für seine Qualität.  "
},
{
  "id": "ma1-ds-3-4-3",
  "level": "2",
  "url": "ma1-ds-3-4.html#ma1-ds-3-4-3",
  "type": "Absatz (with a defined term)",
  "number": "",
  "title": "",
  "body": "Die Vorlesung ist umgedreht. "
},
{
  "id": "ma1-ds-3-4-4",
  "level": "2",
  "url": "ma1-ds-3-4.html#ma1-ds-3-4-4",
  "type": "Absatz (with a defined term)",
  "number": "",
  "title": "",
  "body": "So ist ein Abschnitt aufgebaut. "
},
{
  "id": "ma1-ds-3-4-5",
  "level": "2",
  "url": "ma1-ds-3-4.html#ma1-ds-3-4-5",
  "type": "Absatz (with a defined term)",
  "number": "",
  "title": "",
  "body": "Lesen Sie mit Stift und Papier. "
},
{
  "id": "ma1-ds-3-4-7",
  "level": "2",
  "url": "ma1-ds-3-4.html#ma1-ds-3-4-7",
  "type": "Absatz (with a defined term)",
  "number": "",
  "title": "",
  "body": "Zur Entstehung dieses Buches. "
},
{
  "id": "sec-koerper-der-komplexen-zahlen",
  "level": "1",
  "url": "sec-koerper-der-komplexen-zahlen.html",
  "type": "Abschnitt",
  "number": "1.1",
  "title": "Der Körper der komplexen Zahlen: Darstellungsformen und Grundrechenarten",
  "body": " Der Körper der komplexen Zahlen: Darstellungsformen und Grundrechenarten    Nach diesem Abschnitt können Sie    komplexe Zahlen in algebraischer Form addieren, subtrahieren, multiplizieren und dividieren;  Realteil, Imaginärteil, Betrag und konjugierte Zahl bestimmen und in der Gaußschen Zahlenebene deuten — insbesondere den Betrag als Abstand zum Ursprung und als Abstand zweier Punkte;  zwischen algebraischer Form, Polarform und Exponentialform umrechnen — bei den Standardwinkeln durch Normieren und Ablesen am Einheitskreis;  Produkte, Quotienten und Potenzen über die Exponentialform berechnen und geometrisch als Drehstreckung deuten;  Impedanzen und Phasoren der Wechselstromtechnik als komplexe Zahlen lesen.     Komplexe Zahlen wirken auf den ersten Blick wie ein Kunstgriff: eine neue Zahl , deren Quadrat ist. Tatsächlich sind sie das natürliche Werkzeug für alles, was schwingt oder sich dreht — Wechselströme, Signale, periodische Zeitreihen —, weil sich Beträge und Winkel mit ihnen in einer einzigen Zahl bündeln lassen. Dieser Abschnitt stellt die komplexen Zahlen und ihre beiden Darstellungsformen vor: die algebraische Form  , in der man bequem addiert, und die Exponentialform  , in der man bequem multipliziert und potenziert. Am Ende sollten Sie zwischen beiden frei wechseln können und wissen, welche Form sich für welche Rechnung eignet.    Der Körper der komplexen Zahlen   Was ist die Wurzel aus ? In der Schule lautet die ehrliche Antwort: So etwas gibt es nicht. Für jede reelle Zahl ist , also hat die Gleichung keine reelle Lösung — und eine quadratische Gleichung mit negativer Diskriminante hat eben keine Lösung .  Die Mathematiker des 16. Jahrhunderts sahen das zunächst genauso. Beim Lösen kubischer Gleichungen stießen sie aber immer wieder auf Wurzeln aus negativen Zahlen — und stellten fest, dass man mit diesen unmöglichen Größen einfach weiterrechnen kann und am Ende korrekte, ganz gewöhnliche reelle Ergebnisse erhält. René Descartes nannte solche Zahlen etwas abschätzig imaginär , also eingebildet. Der Name ist geblieben, der Makel nicht: Heute sind komplexe Zahlen aus Elektrotechnik, Signalverarbeitung und Regelungstechnik nicht mehr wegzudenken.  Die Grundidee passt in eine Zeile: Wir führen eine neue Zahl mit ein und rechnen mit ihr nach den gewohnten Regeln. In diesem Unterabschnitt sehen Sie, welche Zahlen dabei entstehen, wie man sie als Punkte einer Ebene zeichnet, wie man ihre Größe misst, was es mit der konjugierten Zahl auf sich hat und wie man mit komplexen Zahlen rechnet. Sie werden feststellen: Vieles davon kennen Sie schon.    Die imaginäre Einheit und komplexe Zahlen  Wir erweitern die reellen Zahlen um eine neue Zahl, die imaginäre Einheit  , für die per Festlegung gilt. Mehr braucht es nicht: Mit darf man rechnen wie mit einer Variablen — addieren, ausmultiplizieren, Klammern auflösen —, nur dass man jederzeit durch ersetzen darf. (In der Elektrotechnik schreibt man übrigens statt , weil dort schon für die Stromstärke vergeben ist.)   Komplexe Zahlen   Eine komplexe Zahl ist eine Zahl der Form mit reellen Zahlen und . Die Menge aller komplexen Zahlen ist      Die Gleichung wird lösbar   Zeigen Sie, dass und die Gleichung lösen. Finden Sie ebenso zwei Lösungen von .    Wir rechnen mit wie mit einer Variablen und ersetzen am Ende durch : Genauso ist und ; die Gleichung hat also die beiden Lösungen und . Ebenso lösen und die Gleichung .  Die Zahlen und sind komplexe Zahlen im Sinne der Definition, jeweils mit . Gleichungen, an denen wir in gescheitert sind, haben in also plötzlich Lösungen — und zwar gleich zwei.    Eine komplexe Zahl besteht also aus zwei reellen Bausteinen: dem Anteil ohne und dem Faktor vor . Beide bekommen einen eigenen Namen.   Real- und Imaginärteil, Gleichheit   Für heißt der Realteil und der Imaginärteil von . Zwei komplexe Zahlen sind genau dann gleich , wenn ihre Realteile und ihre Imaginärteile übereinstimmen.    Vorsicht, beliebte Falle: Der Imaginärteil ist die reelle Zahl , nicht . Für ist und nicht .   Real- und Imaginärteil ablesen   Bestimmen Sie Real- und Imaginärteil von , , und .      , .  Wegen ist und — das Minuszeichen gehört zum Imaginärteil.  ist nicht in der Reihenfolge Realteil zuerst notiert. Umgeordnet ist , also und .  Wegen ist und .       Eine komplexe Gleichung enthält zwei reelle Gleichungen   Bestimmen Sie die reellen Zahlen und so, dass gilt.    Links steht eine komplexe Zahl mit Realteil und Imaginärteil , rechts eine mit Realteil und Imaginärteil . Gleich sind die beiden genau dann, wenn beide Teile übereinstimmen: Eine einzige Gleichung zwischen komplexen Zahlen liefert also zwei Gleichungen zwischen reellen Zahlen — einen solchen Vergleich von Real- und Imaginärteil werden Sie noch oft verwenden.     Reelle und rein imaginäre Zahlen  Jede reelle Zahl lässt sich als schreiben, also als komplexe Zahl mit Imaginärteil . In diesem Sinn ist : Die komplexen Zahlen erweitern die reellen Zahlen, sie ersetzen sie nicht. Das andere Extrem sind komplexe Zahlen mit Realteil , also der Form ; sie heißen (rein) imaginär — wie und aus den Beispielen oben.     Die Gaußsche Zahlenebene  Reelle Zahlen stellt man sich als Punkte auf einer Zahlengeraden vor. Eine komplexe Zahl hat aber zwei reelle Bestandteile, und zwei Koordinaten beschreiben einen Punkt in der Ebene. Bekannt gemacht hat diese Sichtweise vor allem Carl Friedrich Gauß, der in der ersten Hälfte des 19. Jahrhunderts auch den Begriff komplexe Zahl prägte; die Ebene trägt deshalb seinen Namen.   Gaußsche Zahlenebene   In der Gaußschen Zahlenebene wird die komplexe Zahl als Punkt mit den kartesischen Koordinaten dargestellt. Die horizontale Achse heißt reelle Achse , die vertikale Achse imaginäre Achse .     Die Gaußsche Zahlenebene: Die Zahl ist der Punkt mit den Koordinaten .    Ein Koordinatensystem mit horizontaler reeller Achse und vertikaler imaginärer Achse. Auf der reellen Achse ist die markiert, auf der imaginären Achse . Der Punkt liegt im ersten Quadranten; gepunktete Linien verbinden ihn mit auf der reellen Achse und mit auf der imaginären Achse.       Komplexe Zahlen einzeichnen (zur Vertiefung)   Zeichnen Sie , , , , und in die Gaußsche Zahlenebene ein. Wo liegen die reellen, wo die rein imaginären Zahlen?    Jede Zahl wird zum Punkt , also , , , , und , siehe . Das Vorzeichen des Realteils entscheidet über links oder rechts, das des Imaginärteils über oben oder unten.   Die Zahlen in der Gaußschen Zahlenebene.    Ein Koordinatengitter von bis in horizontaler und von bis in vertikaler Richtung. Markiert sind bei im ersten Quadranten, bei im zweiten, bei im dritten, bei im vierten Quadranten, bei auf der reellen Achse und bei auf der imaginären Achse.      Die reelle Zahl liegt auf der reellen Achse ( -Achse), die rein imaginäre Zahl auf der imaginären Achse ( -Achse). Die reelle Achse ist also die vertraute Zahlengerade — die Gaußsche Zahlenebene ergänzt sie um eine zweite Richtung.     Bedingungen an Real- und Imaginärteil als Bilder   Wo in der Gaußschen Zahlenebene liegen alle komplexen Zahlen mit  ,  ,  ,  ?        Alle Punkte mit beliebigem : die senkrechte Gerade durch , parallel zur imaginären Achse.  Alle Punkte : die waagerechte Gerade durch , parallel zur reellen Achse.  Alle Punkte oberhalb der reellen Achse: die obere Halbebene, ohne die reelle Achse selbst.  Alle Punkte : die Winkelhalbierende des ersten und dritten Quadranten, also die Zahlen mit .    Bedingungen an Real- und Imaginärteil beschreiben Geraden und Halbebenen. Mit dem Betrag, den wir als Nächstes einführen, kommen Kreise hinzu.      Der Betrag  Wie groß ist eine komplexe Zahl? Bei reellen Zahlen misst der Betrag den Abstand von zur Null auf der Zahlengeraden. In der Gaußschen Zahlenebene liegt es nahe, genauso vorzugehen: Wir messen den Abstand des Punktes vom Ursprung — und den liefert der Satz des Pythagoras.   Betrag einer komplexen Zahl   Der Betrag von ist      Der Betrag ist die Hypotenuse des rechtwinkligen Dreiecks mit den Katheten und , also der Abstand von zum Ursprung.    Ein rechtwinkliges Dreieck in der Gaußschen Zahlenebene mit den Ecken Ursprung, und . Die waagerechte Kathete auf der reellen Achse hat die Länge , die senkrechte Kathete die Länge , und die Hypotenuse vom Ursprung zu hat die Länge .      Geometrisch ist also der Abstand von zum Ursprung . Für eine reelle Zahl liefert die Formel , den vertrauten reellen Betrag — die neue Definition passt also zur alten.   Beträge berechnen   Bestimmen Sie , , , und .     Bei kommt wie erwartet der reelle Betrag heraus. Die letzte Zahl hat den Betrag , liegt also auf dem Kreis mit Radius um den Ursprung, dem Einheitskreis . Solche Zahlen spielen in eine Hauptrolle.     Alle Zahlen vom Betrag 5   Welche komplexen Zahlen mit ganzzahligem Real- und Imaginärteil haben den Betrag ? Wo liegen sie in der Gaußschen Zahlenebene?    Gesucht sind ganze Zahlen mit , also . Die Quadratzahlen bis sind , und genau zwei Kombinationen ergeben : und (jeweils in beiden Reihenfolgen). Mit allen Vorzeichen erhält man die zwölf Zahlen Sie alle haben den Abstand vom Ursprung und liegen deshalb auf dem Kreis mit Radius um , siehe .   Die zwölf Zahlen mit ganzzahligem Real- und Imaginärteil vom Betrag liegen auf dem Kreis mit Radius um den Ursprung.    Ein Kreis mit Radius um den Ursprung der Gaußschen Zahlenebene. Auf ihm sind zwölf Punkte markiert: die vier Achsenpunkte und sowie die acht Punkte und . Beschriftet sind , , und .      Allgemein gilt: Die Zahlen mit bilden den Kreis mit Radius um den Ursprung.     Anwendungsbeispiel: Positionen im Lager (zur Vertiefung)   In einem Logistiklager fahren autonome Transportroboter. Die Lagersteuerung beschreibt jede Position in Metern relativ zur Ladestation im Ursprung; die reelle Achse zeigt nach Osten, die imaginäre nach Norden. Eine Position ist dann einfach eine komplexe Zahl. Python etwa kennt dafür den eingebauten Datentyp complex , geschrieben wie in der Elektrotechnik mit j : -12+9j .  Roboter A steht bei , Roboter B bei ( ). Welcher der beiden ist näher an der Ladestation?   Positionen zweier Transportroboter relativ zur Ladestation (Angaben in Metern).    Eine Gaußsche Zahlenebene mit der Ladestation im Ursprung. Die reelle Achse ist mit Osten , die imaginäre mit Norden beschriftet. Roboter A liegt bei links oben, Roboter B bei rechts oben; gepunktete Linien zeigen ihre Koordinaten auf beiden Achsen.        Die Entfernung zur Ladestation ist der Abstand zum Ursprung, also der Betrag: Roboter A ist mit  m Luftlinie näher an der Ladestation als Roboter B mit  m. (In Python liefert abs(-12+9j) genau diesen Betrag, 15.0 .)    Eine Warnung zum Schluss: In kann man je zwei Zahlen der Größe nach vergleichen. In geht das nicht — es gibt keine Anordnung der komplexen Zahlen, die mit den Rechenregeln verträglich ist. Ein Ausdruck wie ist deshalb schlicht sinnlos. Vergleichen lassen sich aber die Beträge: .    Komplexe Konjugation  Eine weitere Operation hat kein Gegenstück bei den reellen Zahlen, ist aber ungemein nützlich: Man kehrt das Vorzeichen des Imaginärteils um. Geometrisch ist das eine Spiegelung an der reellen Achse.   Komplexe Konjugation   Zu heißt die Zahl die zu  komplex-konjugierte Zahl . In der Gaußschen Zahlenebene entsteht aus durch Spiegelung an der reellen Achse.    In der Technik schreibt man statt häufig auch .   Die Konjugierte ist das Spiegelbild von an der reellen Achse.    Ein Koordinatensystem mit horizontaler reeller Achse ( ) und vertikaler imaginärer Achse ( ). Der Punkt ist markiert, ebenso der Ursprung, eine gestrichelte Verbindungslinie vom Ursprung zu , und der an der reellen Achse gespiegelte Punkt , der ebenfalls gestrichelt mit dem Ursprung verbunden ist.       Konjugieren heißt Spiegeln (zur Vertiefung)   Bestimmen Sie die konjugierten Zahlen zu , , und , und beschreiben Sie, was dabei in der Gaußschen Zahlenebene passiert.    Nur das Vorzeichen des Imaginärteils ändert sich: Die Punkte und wandern auf die andere Seite der reellen Achse. Die rein imaginäre Zahl springt auf der imaginären Achse von nach . Die reelle Zahl liegt auf der Spiegelachse und bleibt deshalb, wo sie ist.     Konjugieren ändert den Betrag nicht (zur Vertiefung)   Rechnen Sie nach, dass für jede komplexe Zahl gilt: . Begründen Sie das auch geometrisch.    Mit ist , also Geometrisch: Der Ursprung liegt auf der Spiegelachse, und eine Spiegelung ändert keine Abstände — also haben und denselben Abstand zum Ursprung (siehe die beiden gleich langen gestrichelten Strecken in ).      Grundrechenarten in  Jetzt wird gerechnet. Die Spielregeln legen wir so fest, dass  für reelle Zahlen alles beim Alten bleibt ( Permanenzprinzip ),  die vertrauten Rechengesetze — Kommutativ-, Assoziativ- und Distributivgesetz — weiter gelten und  ist.    Praktisch heißt das: Rechnen Sie mit wie mit einer Variablen, und ersetzen Sie durch , wo immer es auftaucht. Die folgenden Formeln sind nichts anderes als die Ergebnisse dieses Vorgehens.   Addition und Subtraktion   Für und :  Real- und Imaginärteil werden also komponentenweise addiert bzw. subtrahiert.    Weil Real- und Imaginärteile getrennt addiert werden, ist die Addition in der Gaußschen Zahlenebene die vertraute Addition von Pfeilen: ist die vierte Ecke des Parallelogramms, das die Pfeile von nach und nach aufspannen.   Addition und Subtraktion — rechnerisch und geometrisch   Berechnen Sie für und die Summe und die Differenz , und deuten Sie beide in der Gaußschen Zahlenebene.     Die Summe ist die Diagonale des Parallelogramms mit den Seiten und . Die Differenz ist der Pfeil, der von nach führt (denn ), hier an den Ursprung verschoben, siehe .   Summe und Differenz von und : Die Summe ist die Diagonale des Parallelogramms, die Differenz der Pfeil von nach .    Pfeile vom Ursprung zu , zu und zu . Gestrichelte Linien von und zu vervollständigen das Parallelogramm. Ein gepunkteter Pfeil führt von nach ; ein gleich langer, paralleler gepunkteter Pfeil führt vom Ursprung zu .        Daraus ergibt sich eine der nützlichsten Beobachtungen dieses Abschnitts: Weil der Pfeil von nach ist, ist der Abstand der Punkte und in der Gaußschen Zahlenebene.   Anwendungsbeispiel: Wie weit liegen zwei Roboter auseinander? (zur Vertiefung)   Die beiden Roboter aus stehen bei und . Roboter A soll ein Paket zu Roboter B bringen. Wie weit liegen die beiden (Luftlinie) auseinander?    Der Abstand ist der Betrag der Differenz: Die Roboter stehen  m voneinander entfernt. Eine hübsche Kontrolle: . Das Dreieck aus Ladestation, A und B erfüllt also den Satz des Pythagoras — es hat an der Ladestation einen rechten Winkel.     Multiplikation   Aus Distributivgesetz und folgt     Die Formel muss man nicht auswendig lernen: Ausmultiplizieren und einsetzen führt immer zum Ziel. Wichtig ist aber, dass die Multiplikation nicht komponentenweise funktioniert — der Realteil des Produkts ist nicht einfach .   Die Potenzen von wiederholen sich   Berechnen Sie , , , und . Welches Muster erkennen Sie?     Wegen wiederholen sich die Potenzen im Viererrhythmus — für kommt es nur auf den Rest von bei Division durch an. In der Gaußschen Zahlenebene springt der Punkt dabei jeweils eine Vierteldrehung weiter: . Dass die Multiplikation mit tatsächlich eine Drehung um ist, zeigt .     Produkte ausmultiplizieren (zur Vertiefung)   Berechnen Sie und in algebraischer Form.    Ausmultiplizieren und einsetzen: Das erste Ergebnis zeigt, warum komponentenweises Multiplizieren falsch wäre: Es hätte geliefert. Tatsächlich hebt sich der Realteil vollständig weg: Das Produkt zweier Zahlen mit positivem Realteil ist hier rein imaginär.     Eine unlösbare quadratische Gleichung   Die Gleichung hat keine reelle Lösung: Die -Formel führt auf . Zeigen Sie, dass und Lösungen in sind.    Für ist , also Für ist , also Beide Zahlen sind Lösungen — und sie sind zueinander konjugiert. Das ist kein Zufall. Wie man solche Lösungen systematisch findet, statt sie nur zu überprüfen, ist Thema von .     Rechenbeispiel aus der Geschichte: Bombellis kubische Gleichung   Der italienische Ingenieur Rafael Bombelli untersuchte in seinem 1572 erschienenen Buch L'Algebra die Gleichung . Die damals neue Lösungsformel für kubische Gleichungen (die Cardanische Formel) liefert für eine Lösung den Ausdruck mit einer Wurzel aus einer negativen Zahl. In unserer Schreibweise ist , denn . Bombelli vermutete, dass eine Kubikwurzel von sein könnte.  Prüfen Sie nach, dass und gilt. Welchen Wert hat dann , und löst er wirklich die Gleichung?    Zuerst das Quadrat, dann noch einmal mit multiplizieren: Genauso ist und . Damit ergibt Bombellis Ansatz Probe: und . Die Imaginärteile heben sich auf, und übrig bleibt eine ganz gewöhnliche reelle Lösung. Genau diese Erfahrung — komplexe Zahlen als Umweg zu reellen Ergebnissen — hat den komplexen Zahlen den Weg in die Mathematik geebnet.    Bevor wir dividieren, brauchen wir noch eine Beobachtung über das Produkt einer Zahl mit ihrer Konjugierten.   Produkt mit der konjugierten Zahl   Für jedes gilt     Mit ist da .    Das Produkt einer Zahl mit ihrer Konjugierten ist also stets reell und nicht negativ, zum Beispiel . Genau diese Eigenschaft macht die Division einfach: Man erweitert einen Bruch so, dass im Nenner eine reelle Zahl steht.   Division   Für erweitert man den Bruch mit , um den Nenner reell zu machen: Mit ( ) gilt      Division durch Erweitern mit dem konjugierten Nenner   Berechnen Sie und in algebraischer Form, und machen Sie jeweils die Probe.    Im ersten Bruch erweitern wir mit : Probe durch Zurückmultiplizieren: .  Im zweiten Bruch erweitern wir mit : Probe: . Durch zu teilen heißt also, mit zu multiplizieren — ein Trick, der im folgenden Anwendungsbeispiel gleich gebraucht wird.     Anwendungsbeispiel: Impedanz einer RC-Reihenschaltung   In der Wechselstromrechnung tritt an die Stelle des ohmschen Widerstands die Impedanz  , der komplexe Wechselstromwiderstand: Wie beim Gleichstrom ist sie das Verhältnis von Spannung zu Stromstärke, nur eben eine komplexe Zahl, weil sie außer dem Verhältnis der Amplituden auch festhält, wie weit Spannung und Strom zeitlich gegeneinander verschoben sind ( zeigt, wie man beides abliest).  Einem ohmschen Widerstand ordnet man die (reelle) Impedanz zu, einem Kondensator mit Kapazität bei Kreisfrequenz die (rein imaginäre) Impedanz . Die Gesamtimpedanz einer Reihenschaltung ( ) ist die Summe der Einzelimpedanzen — genau wie bei reellen Widerständen, nur dass jetzt komplex addiert wird.   RC-Reihenschaltung: Die Wechselspannungsquelle treibt den Strom nacheinander durch den Widerstand und den Kondensator .    Schaltplan eines geschlossenen Stromkreises. Links eine Wechselspannungsquelle, gezeichnet als Kreis mit einer Sinuswelle und beschriftet mit . Die Leitung führt oben über einen Widerstand (Rechteck) und rechts über einen Kondensator (zwei parallele Platten) zurück zur Quelle. Alle Bauteile liegen hintereinander in einem einzigen Stromweg.      Für , und bestimmen Sie die Gesamtimpedanz in algebraischer Form sowie ihren Betrag .  Für die Einheiten brauchen Sie , also Ohm gleich Sekunde pro Farad: Ein Kondensator mit speichert bei die Ladung , also ist und damit     Zunächst formen wir in algebraische Form um, indem wir mit erweitern: Mit ergibt sich mit  Die Gesamtimpedanz ist damit eine einfache komplexe Addition. Ihr Betrag ist Der negative Imaginärteil zeigt an, dass die Schaltung kapazitiv wirkt: Der Strom eilt der Spannung phasenmäßig voraus (die Begriffe kapazitiv und induktiv erklärt ). Im nächsten Unterabschnitt sehen wir, wie sich dieser Phasenwinkel direkt aus der Polarform von ablesen lässt.    Damit ist alles beisammen: In kann man addieren, subtrahieren, multiplizieren und — außer durch — dividieren, und es gelten dieselben Rechengesetze wie in und . Eine Zahlenmenge mit diesen Eigenschaften heißt in der Mathematik ein Körper . Daher der Titel dieses Unterabschnitts: ist der Körper der komplexen Zahlen.     Darstellungsformen komplexer Zahlen   Addieren ist in der algebraischen Form ein Kinderspiel. Multiplizieren dagegen wird schnell mühsam: Wer durch fünfmaliges Multiplizieren berechnet, braucht Geduld und macht leicht einen Vorzeichenfehler. Und die geometrische Bedeutung der Multiplikation — wir haben in gesehen, dass die Potenzen von im Kreis laufen — bleibt in der Formel völlig verborgen.  Abhilfe schafft ein Wechsel der Perspektive. Statt einen Punkt durch so weit nach rechts, so weit nach oben zu beschreiben, sagt man so weit vom Ursprung entfernt, in diese Richtung — so, wie ein Radar es tut. Das führt zur Polarform und, mit der Eulerschen Formel, zur Exponentialform  . In dieser Form wird die Multiplikation überraschend einfach: Beträge multiplizieren, Winkel addieren.    Polarkoordinaten  Ein Punkt der Gaußschen Zahlenebene ist festgelegt, wenn man seinen Abstand zum Ursprung kennt und den Winkel , unter dem er vom Ursprung aus gesehen liegt, gemessen von der positiven reellen Achse aus gegen den Uhrzeigersinn ( ). Den Abstand kennen wir schon: Er ist der Betrag .   Polarkoordinaten einer komplexen Zahl   Jede komplexe Zahl lässt sich eindeutig durch zwei Polarkoordinaten beschreiben:  den Radius  , den Abstand von zum Ursprung;  den Winkel (das Argument ) , den Winkel des Ortsvektors zur positiven reellen Achse.    Für setzt man und . Für berechnet man aus      Polarkoordinaten: Der Punkt hat den Abstand zum Ursprung und liegt unter dem Winkel zur positiven reellen Achse.    Eine Gaußsche Zahlenebene mit einem Punkt im ersten Quadranten. Eine Strecke der Länge verbindet den Ursprung mit . Ein Kreisbogen am Ursprung markiert den Winkel zwischen der positiven reellen Achse und dieser Strecke. Gepunktete Linien zeigen die Koordinaten auf der reellen und auf der imaginären Achse.      Die Fallunterscheidung sieht abschreckend aus, drückt aber nur eine einfache Beobachtung aus: Der Arkustangens liefert stets Winkel zwischen und , also Richtungen in die rechte Halbebene. Liegt links der imaginären Achse, muss man um korrigieren.  Für die Zahlen, mit denen wir in diesem Kurs rechnen, geht es fast immer einfacher — ganz ohne Arkustangens. Teilt man durch seinen Betrag , erhält man die normierte Zahl Sie hat den Betrag , liegt also auf dem Einheitskreis, und zwar in derselben Richtung wie — unter demselben Winkel . Für die Standardwinkel, die Vielfachen von und , zeigt , welche Zahl auf dem Einheitskreis zu welchem Winkel gehört. Diese Abbildung ist Ihr wichtigstes Werkzeug für den Rest des Kapitels; schauen Sie sie sich einmal in Ruhe an. Die farbigen Punkte gleicher Farbe gehen durch Spiegelung an den Achsen auseinander hervor: Ihre Real- und Imaginärteile unterscheiden sich nur im Vorzeichen.   Der Einheitskreis mit den Standardwinkeln (innen) und der Zahl vom Betrag , die unter diesem Winkel liegt (außen). Ihr Realteil ist , ihr Imaginärteil .    Der Einheitskreis in der Gaußschen Zahlenebene mit sechzehn markierten Punkten, die mit dem Ursprung durch Strecken verbunden sind. Innen an jeder Strecke steht der Winkel, außen die Zahl in algebraischer Form. Schwarz: bei , bei , bei , bei . Blau: bei und bei . Orange: bei und bei . Grün: bei und bei . Dabei gehört jeweils das Pluszeichen des Winkels zum Pluszeichen des Imaginärteils.       Rezept: Polarkoordinaten am Einheitskreis ablesen    Den Betrag berechnen.  Normieren: bilden und vereinfachen, bis Real- und Imaginärteil so aussehen wie in . Häufig braucht man dafür .  Die normierte Zahl in suchen und den Winkel ablesen.  Ist keine der markierten Zahlen, bleibt der Arkustangens mit der Fallunterscheidung aus . Auch dann zeigt die Abbildung aber, zwischen welchen Standardwinkeln liegen muss — eine wertvolle Kontrolle.    Polarkoordinaten am Einheitskreis ablesen   Bestimmen Sie die Polarkoordinaten von mit dem Rezept aus .    Der Betrag ist . Normiert: Diese Zahl finden wir in im zweiten Quadranten beim Winkel . Die Polarkoordinaten sind also und .  Zur Kontrolle: Der Punkt liegt links oberhalb des Ursprungs, also muss zwischen und liegen. Die Fallunterscheidung hätte dasselbe geliefert, , nur mit mehr Aufwand und mehr Gelegenheit für Fehler.     Ein Winkel pro Quadrant — und eine Falle (zur Vertiefung)   Bestimmen Sie Betrag und Argument von , , , sowie von und . Was liefert der Taschenrechner-Ansatz für ?    Die ersten vier Zahlen haben alle den Betrag . Normiert, mit : Das sind die vier orangefarbenen Punkte in , und wir lesen ab: Die beiden Achsenpunkte gehen genauso, nur schneller: und , also ; und , also .  Die Falle: Für ist , und — derselbe Wert wie für . Der Quotient kann die gegenüberliegenden Punkte und nicht unterscheiden. Erst die Korrektur um (dritter Fall der Definition) liefert den richtigen Winkel .      Polarform und Eulersche Formel  Kennt man und , liest man Real- und Imaginärteil am rechtwinkligen Dreieck in ab: Ankathete und Gegenkathete sind und .   Trigonometrische Polarform   Aus und erhält man Real- und Imaginärteil zurück durch also Diese Darstellung heißt (trigonometrische) Polarform von .    Für die Standardwinkel brauchen Sie dabei weder Taschenrechner noch Wertetabelle: Die Zahl steht in außen neben dem Winkel . Man liest sie ab und multipliziert mit — das Rezept aus , rückwärts angewandt.   Von der Polarform zurück zur algebraischen Form (zur Vertiefung)   Eine komplexe Zahl hat den Betrag und das Argument . Wie lautet sie in algebraischer Form?    In steht beim Winkel die Zahl . Mit dem Betrag multipliziert: Plausibel: zeigt in den zweiten Quadranten, und tatsächlich ist der Realteil negativ, der Imaginärteil positiv. Diese Richtung der Umrechnung ist die einfachere — sie braucht keine Fallunterscheidung.    Der Ausdruck taucht so oft auf, dass er eine Abkürzung verdient. Leonhard Euler entdeckte 1748, dass er mit der Exponentialfunktion zusammenhängt — einer der erstaunlichsten Zusammenhänge der Mathematik.   Eulersche Formel   Die (reelle) Exponentialfunktion lässt sich auf komplexe Argumente fortsetzen. Für gilt die Eulersche Formel      Ein Beweis erfordert Potenzreihen und geht über diesen Kurs hinaus; wir verwenden die Formel als Rechenwerkzeug. Geometrisch ist der Punkt auf dem Einheitskreis, der unter dem Winkel liegt ( ), denn . Für die Standardwinkel lesen Sie also direkt in ab.   Die Zahl liegt auf dem Einheitskreis unter dem Winkel .    Der Einheitskreis in der Gaußschen Zahlenebene, auf dem die Punkte , , und markiert sind. Ein weiterer Punkt liegt im ersten Quadranten auf dem Kreis; ein Bogen markiert den Winkel , gepunktete Linien zeigen auf der reellen und auf der imaginären Achse.       Eine Runde um den Einheitskreis (zur Vertiefung)   Berechnen Sie für .    Die ersten vier Winkel liegen in , ihre Werte stehen in : Die Winkel und kommen in der Abbildung nicht vor. Eine volle Umdrehung um führt aber zum selben Punkt zurück, allgemein ist . Wir ziehen also ab: Die Zahl kennen Sie aus : Sie hat den Betrag , und jetzt wissen wir auch, in welcher Richtung sie liegt. Der Wert für ergibt die berühmte Eulersche Identität  , die die fünf wichtigsten Konstanten der Mathematik in einer Gleichung vereint.     Exponentialform   Mit der Eulerschen Formel lässt sich jede komplexe Zahl in Exponentialform  schreiben. Dabei sind und genau die Polarkoordinaten von .    Weil sich nach einer vollen Umdrehung wiederholt, ist auch eine gültige Schreibweise für dieselbe Zahl. Eindeutig wird die Exponentialform erst durch die Vereinbarung .  Die Exponentialform ist auch die natürliche Sprache der Wechselstromtechnik, denn dort kommt es bei jeder Schwingung auf genau zwei Angaben an: wie groß sie ist und wann sie ihr Maximum erreicht.   Phasoren  Eine sinusförmige Wechselspannung ist durch ihre Amplitude , ihre Kreisfrequenz und ihren Nullphasenwinkel festgelegt. In einem Wechselstromkreis schwingen alle Spannungen und Ströme mit der Kreisfrequenz der Quelle; sie unterscheiden sich nur in Amplitude und Phase. Diese beiden Angaben fasst man zu einer komplexen Zahl zusammen, dem Phasor (auch Zeiger oder komplexe Amplitude ) Sein Betrag ist die Amplitude, sein Argument die Phase. Die Schwingung selbst ist der Realteil : Anschaulich ist ein Zeiger der Länge , der mit der Winkelgeschwindigkeit gegen den Uhrzeigersinn rotiert, und ist sein Schatten auf der reellen Achse.  Für die Phasoren und von Spannung und Strom gilt das ohmsche Gesetz der Wechselstromrechnung mit der Impedanz aus . Wie wir in sehen werden, folgt daraus: ist das Verhältnis der Amplituden von Spannung und Strom, und das Argument von ist die Phase der Spannung minus die Phase des Stroms.    Anwendungsbeispiel: Der Phasenwinkel einer Impedanz   In hatten wir für eine RC-Reihenschaltung die Impedanz (in ) berechnet. Bestimmen Sie ihre Exponentialform. Was bedeutet das Argument physikalisch?  Für das Vorzeichen des Arguments gibt es in der Elektrotechnik zwei Fachbegriffe. Eine Schaltung heißt kapazitiv , wenn ihre Impedanz einen negativen Imaginärteil hat, also : Sie verhält sich wie ein Kondensator mit , und der Strom eilt der Spannung voraus. Sie heißt induktiv , wenn der Imaginärteil positiv ist, also : Sie verhält sich wie eine Spule mit Induktivität und Impedanz , und der Strom hinkt der Spannung hinterher. Eine alte Merkregel fasst das zusammen: Beim Kondensator eilt der Strom vor, bei Induktivitäten wird er sich verspäten. Ist die Schaltung aus kapazitiv oder induktiv?    Der Betrag ist . Normiert, mit : In gehört diese Zahl zum Winkel , also ist und Nach gibt der Betrag an, wie stark die Schaltung den Strom begrenzt: Er ist das Verhältnis der Amplituden von Spannung und Strom. Das Argument ist der Phasenwinkel zwischen Spannung und Strom: Die Phase der Spannung ist um kleiner als die des Stroms, der Strom eilt der Spannung also um voraus. Wegen ist die Schaltung kapazitiv — wie zu erwarten, denn außer dem ohmschen Widerstand enthält sie nur einen Kondensator. Beide Größen, die ein Elektrotechniker wissen will, stehen direkt in der Exponentialform — in der algebraischen Form sieht man sie nicht auf den ersten Blick.      Rechnen in Exponentialform  Jetzt zahlt sich die Exponentialform aus. Für die komplexe Exponentialfunktion gelten dieselben Potenzgesetze wie im Reellen, insbesondere . Damit werden Produkte und Quotienten fast trivial.   Multiplikation und Division in Exponentialform   Für und gilt Geometrisch bedeutet Multiplikation: Beträge multiplizieren, Winkel addieren ; Division: Beträge dividieren, Winkel subtrahieren .    Das folgt direkt aus den Potenzgesetzen der Exponentialfunktion: und .    Liegt die Winkelsumme außerhalb von , zieht man ab oder addiert — an der Zahl ändert das nichts.   Produkt und Quotient über die Exponentialform   Berechnen Sie und für und , und geben Sie beide Ergebnisse in algebraischer Form an.    Beträge multiplizieren bzw. dividieren, Winkel addieren bzw. subtrahieren; die Werte von und lesen wir in ab: Zum Vergleich: In algebraischer Form wäre (wieder mit ) und — das Ausmultiplizieren und das Erweitern mit dem konjugierten Nenner führen zum selben Ergebnis, aber mit deutlich mehr Rechenaufwand.    Wendet man die Multiplikationsregel -mal auf denselben Faktor an, erhält man eine Formel für Potenzen: Der Betrag wird potenziert, der Winkel vervielfacht.   Potenzen über die Exponentialform   Berechnen Sie und .    Zunächst die Exponentialform der Basis: , und normiert ist , nach also und . Damit wobei wir verwendet und abgelesen haben.  Für die zweite Zahl ist , normiert ; das ist in der Punkt beim Winkel . Damit Die sechste Potenz ist reell — zwei volle Umdrehungen bringen den Winkel zurück auf die positive reelle Achse. Das Ausmultiplizieren hätte das kaum erahnen lassen.     Konjugation in Exponentialform   Für gilt Geometrisch bleibt der Betrag erhalten, das Vorzeichen des Winkels kehrt sich um.    Das passt zur Spiegelung an der reellen Achse aus : Ein Punkt, der um über der reellen Achse liegt, landet um darunter. Auch bestätigt sich so auf einen Blick.   Anwendungsbeispiel: Datenpunkte drehen   Fasst man einen Punkt der Ebene als komplexe Zahl auf, so ist die Multiplikation mit (Betrag , Winkel ) nach genau eine Drehung um den Ursprung um den Winkel : Der Betrag bleibt, der Winkel wächst um . Solche Drehungen braucht man etwa, wenn man Bilddaten zur Erweiterung eines Trainingsdatensatzes rotiert oder Sensordaten in ein gedrehtes Koordinatensystem umrechnet. Drehen Sie den Punkt um und um gegen den Uhrzeigersinn.    Die Drehfaktoren lesen wir in ab. Für ist , also Für ist , also Probe: Beide Bildpunkte haben wie den Abstand vom Ursprung — eine Drehung ändert Beträge nicht ( ). Nebenbei ist damit auch geklärt, warum die Potenzen von in im Kreis laufen: Jede Multiplikation mit ist eine Vierteldrehung.   Der Punkt , um und um gedreht. Alle drei Punkte liegen auf dem Kreis mit Radius .    Ein Kreis mit Radius um den Ursprung. Auf ihm liegen der Punkt im ersten Quadranten, der um gedrehte Punkt und der um gedrehte Punkt im zweiten Quadranten. Pfeile vom Ursprung führen zu allen drei Punkten, gebogene Pfeile zeigen die Drehrichtung gegen den Uhrzeigersinn.         Anwendungsbeispiel: Der Strom im RC-Glied (zur Vertiefung)   An die RC-Reihenschaltung aus mit wird eine Wechselspannung mit dem Phasor (Amplitude , Phase ) gelegt. Nach dem ohmschen Gesetz der Wechselstromrechnung ( ) ist der Stromphasor . Bestimmen Sie Amplitude und Phase des Stroms.    Division in Exponentialform — Beträge dividieren, Winkel subtrahieren: Der Strom hat die Amplitude und die Phase : Er eilt der Spannung um eine Achtelperiode voraus, wie in abgelesen. In algebraischer Form hätten wir hier durch teilen und mit dem konjugierten Nenner erweitern müssen; in Exponentialform ist es eine Zeile.     Anwendungsbeispiel: Überlagerung von Wechselspannungen (Phasoren)   Schwingungen gleicher Frequenz überlagert man, indem man ihre Phasoren ( ) addiert. Denn der Realteil einer Summe ist die Summe der Realteile:   Gegeben seien und . Bestimmen Sie Amplitude und Phase der überlagerten Schwingung .    Die Phasoren sind und . Der Summenphasor ist Sein Betrag ist , normiert ist . Diese Zahl ist keiner der markierten Punkte in — hier hilft nur der Arkustangens: (erster Quadrant, also keine Korrektur), etwa . Die Abbildung taugt trotzdem zur Kontrolle: Der Imaginärteil liegt zwischen und , also muss der Winkel zwischen und liegen — passt. Also ist , und die überlagerte Schwingung ist Man sieht direkt: Die Amplitude der Summe ist nicht die Summe der Amplituden — Phasenunterschiede zählen, und die komplexe Addition erfasst das automatisch richtig.    Hier arbeiten beide Darstellungsformen Hand in Hand: Addiert wird in algebraischer Form, Amplitude und Phase liest man aus der Exponentialform ab. Als Faustregel für diesen ganzen Abschnitt gilt: Algebraische Form zum Addieren und Subtrahieren, Exponentialform zum Multiplizieren, Dividieren und Potenzieren. Wer sicher zwischen beiden wechseln kann, hat das wichtigste Handwerkszeug für komplexe Zahlen beisammen.     Zusammenfassung     Komplexe Zahl:  mit ; , (beide reell). In der Gaußschen Zahlenebene ist der Punkt ; reelle Zahlen liegen auf der reellen Achse, .   Betrag und Abstand:  ist der Abstand von zum Ursprung, der Abstand der Punkte und . Die Zahlen mit bilden den Kreis mit Radius um den Ursprung.   Konjugation:  ist das Spiegelbild von an der reellen Achse; und .   Rechnen in algebraischer Form: Addition und Subtraktion komponentenweise; Multiplikation durch Ausmultiplizieren mit ; Division durch Erweitern mit dem konjugierten Nenner.   Polar- und Exponentialform:  mit und . Umrechnen am Einheitskreis ( ): berechnen, bilden und den Winkel ablesen; zurück liest man beim Winkel ab und multipliziert mit . Nur bei anderen Winkeln braucht man samt Quadrantenkorrektur.   Rechnen in Exponentialform: Beträge multiplizieren, Winkel addieren — , , . Multiplikation mit ist eine Drehung um .   Merkregel: Algebraische Form zum Addieren, Exponentialform zum Multiplizieren, Dividieren und Potenzieren.   Anwendung: Impedanzen ( , , ) addieren sich in Reihe komplex; heißt kapazitiv (Strom eilt vor), induktiv (Strom hinkt hinterher). Der Phasor fasst Amplitude und Phase der Schwingung zusammen; Schwingungen gleicher Frequenz überlagert man durch Addition ihrer Phasoren.      Übungsaufgaben    Gegeben seien und . Berechnen Sie in algebraischer Form , , und .      Für die Division erweitern wir mit :       Bestimmen Sie für den Realteil, den Imaginärteil, die konjugierte Zahl und den Betrag .     , , , und       Zeichnen Sie und in die Gaußsche Zahlenebene ein. Bestimmen Sie , und den Abstand der beiden Punkte.     ist der Punkt im zweiten Quadranten, der Punkt im ersten Quadranten. Der Abstand ist der Betrag der Differenz:       Bestimmen Sie die Exponentialform von .     Normiert, mit : In gehört diese Zahl zum Winkel . Damit       Berechnen Sie über die Exponentialform.    Es ist , normiert , nach also und . Damit ist (mit aus derselben Abbildung) (Probe über die algebraische Form: , also .)     "
},
{
  "id": "sec-koerper-der-komplexen-zahlen-2",
  "level": "2",
  "url": "sec-koerper-der-komplexen-zahlen.html#sec-koerper-der-komplexen-zahlen-2",
  "type": "Lernziele",
  "number": "1.1",
  "title": "",
  "body": "  Nach diesem Abschnitt können Sie    komplexe Zahlen in algebraischer Form addieren, subtrahieren, multiplizieren und dividieren;  Realteil, Imaginärteil, Betrag und konjugierte Zahl bestimmen und in der Gaußschen Zahlenebene deuten — insbesondere den Betrag als Abstand zum Ursprung und als Abstand zweier Punkte;  zwischen algebraischer Form, Polarform und Exponentialform umrechnen — bei den Standardwinkeln durch Normieren und Ablesen am Einheitskreis;  Produkte, Quotienten und Potenzen über die Exponentialform berechnen und geometrisch als Drehstreckung deuten;  Impedanzen und Phasoren der Wechselstromtechnik als komplexe Zahlen lesen.   "
},
{
  "id": "ssub-imaginaere-einheit-2",
  "level": "2",
  "url": "sec-koerper-der-komplexen-zahlen.html#ssub-imaginaere-einheit-2",
  "type": "Absatz (with a defined term)",
  "number": "",
  "title": "",
  "body": "imaginäre Einheit "
},
{
  "id": "def-komplexe-zahlen",
  "level": "2",
  "url": "sec-koerper-der-komplexen-zahlen.html#def-komplexe-zahlen",
  "type": "Definition",
  "number": "1.1.1",
  "title": "Komplexe Zahlen.",
  "body": " Komplexe Zahlen   Eine komplexe Zahl ist eine Zahl der Form mit reellen Zahlen und . Die Menge aller komplexen Zahlen ist    "
},
{
  "id": "ex-quadratwurzeln-negativer-zahlen",
  "level": "2",
  "url": "sec-koerper-der-komplexen-zahlen.html#ex-quadratwurzeln-negativer-zahlen",
  "type": "Beispiel",
  "number": "1.1.2",
  "title": "Die Gleichung <span class=\"process-math\">\\(z^2=-9\\)<\/span> wird lösbar.",
  "body": " Die Gleichung wird lösbar   Zeigen Sie, dass und die Gleichung lösen. Finden Sie ebenso zwei Lösungen von .    Wir rechnen mit wie mit einer Variablen und ersetzen am Ende durch : Genauso ist und ; die Gleichung hat also die beiden Lösungen und . Ebenso lösen und die Gleichung .  Die Zahlen und sind komplexe Zahlen im Sinne der Definition, jeweils mit . Gleichungen, an denen wir in gescheitert sind, haben in also plötzlich Lösungen — und zwar gleich zwei.   "
},
{
  "id": "def-realteil-imaginaerteil",
  "level": "2",
  "url": "sec-koerper-der-komplexen-zahlen.html#def-realteil-imaginaerteil",
  "type": "Definition",
  "number": "1.1.3",
  "title": "Real- und Imaginärteil, Gleichheit.",
  "body": " Real- und Imaginärteil, Gleichheit   Für heißt der Realteil und der Imaginärteil von . Zwei komplexe Zahlen sind genau dann gleich , wenn ihre Realteile und ihre Imaginärteile übereinstimmen.   "
},
{
  "id": "ex-realteil-imaginaerteil",
  "level": "2",
  "url": "sec-koerper-der-komplexen-zahlen.html#ex-realteil-imaginaerteil",
  "type": "Beispiel",
  "number": "1.1.4",
  "title": "Real- und Imaginärteil ablesen.",
  "body": " Real- und Imaginärteil ablesen   Bestimmen Sie Real- und Imaginärteil von , , und .      , .  Wegen ist und — das Minuszeichen gehört zum Imaginärteil.  ist nicht in der Reihenfolge Realteil zuerst notiert. Umgeordnet ist , also und .  Wegen ist und .     "
},
{
  "id": "ex-gleichheit-komplexer-zahlen",
  "level": "2",
  "url": "sec-koerper-der-komplexen-zahlen.html#ex-gleichheit-komplexer-zahlen",
  "type": "Beispiel",
  "number": "1.1.5",
  "title": "Eine komplexe Gleichung enthält zwei reelle Gleichungen.",
  "body": " Eine komplexe Gleichung enthält zwei reelle Gleichungen   Bestimmen Sie die reellen Zahlen und so, dass gilt.    Links steht eine komplexe Zahl mit Realteil und Imaginärteil , rechts eine mit Realteil und Imaginärteil . Gleich sind die beiden genau dann, wenn beide Teile übereinstimmen: Eine einzige Gleichung zwischen komplexen Zahlen liefert also zwei Gleichungen zwischen reellen Zahlen — einen solchen Vergleich von Real- und Imaginärteil werden Sie noch oft verwenden.   "
},
{
  "id": "rem-reelle-und-imaginaere-zahlen",
  "level": "2",
  "url": "sec-koerper-der-komplexen-zahlen.html#rem-reelle-und-imaginaere-zahlen",
  "type": "Bemerkung",
  "number": "1.1.6",
  "title": "Reelle und rein imaginäre Zahlen.",
  "body": " Reelle und rein imaginäre Zahlen  Jede reelle Zahl lässt sich als schreiben, also als komplexe Zahl mit Imaginärteil . In diesem Sinn ist : Die komplexen Zahlen erweitern die reellen Zahlen, sie ersetzen sie nicht. Das andere Extrem sind komplexe Zahlen mit Realteil , also der Form ; sie heißen (rein) imaginär — wie und aus den Beispielen oben.  "
},
{
  "id": "def-gausssche-zahlenebene",
  "level": "2",
  "url": "sec-koerper-der-komplexen-zahlen.html#def-gausssche-zahlenebene",
  "type": "Definition",
  "number": "1.1.7",
  "title": "Gaußsche Zahlenebene.",
  "body": " Gaußsche Zahlenebene   In der Gaußschen Zahlenebene wird die komplexe Zahl als Punkt mit den kartesischen Koordinaten dargestellt. Die horizontale Achse heißt reelle Achse , die vertikale Achse imaginäre Achse .   "
},
{
  "id": "fig-gausssche-zahlenebene",
  "level": "2",
  "url": "sec-koerper-der-komplexen-zahlen.html#fig-gausssche-zahlenebene",
  "type": "Abbildung",
  "number": "1.1.8",
  "title": "",
  "body": " Die Gaußsche Zahlenebene: Die Zahl ist der Punkt mit den Koordinaten .    Ein Koordinatensystem mit horizontaler reeller Achse und vertikaler imaginärer Achse. Auf der reellen Achse ist die markiert, auf der imaginären Achse . Der Punkt liegt im ersten Quadranten; gepunktete Linien verbinden ihn mit auf der reellen Achse und mit auf der imaginären Achse.     "
},
{
  "id": "ex-punkte-zahlenebene",
  "level": "2",
  "url": "sec-koerper-der-komplexen-zahlen.html#ex-punkte-zahlenebene",
  "type": "Beispiel",
  "number": "1.1.9",
  "title": "Komplexe Zahlen einzeichnen (zur Vertiefung).",
  "body": " Komplexe Zahlen einzeichnen (zur Vertiefung)   Zeichnen Sie , , , , und in die Gaußsche Zahlenebene ein. Wo liegen die reellen, wo die rein imaginären Zahlen?    Jede Zahl wird zum Punkt , also , , , , und , siehe . Das Vorzeichen des Realteils entscheidet über links oder rechts, das des Imaginärteils über oben oder unten.   Die Zahlen in der Gaußschen Zahlenebene.    Ein Koordinatengitter von bis in horizontaler und von bis in vertikaler Richtung. Markiert sind bei im ersten Quadranten, bei im zweiten, bei im dritten, bei im vierten Quadranten, bei auf der reellen Achse und bei auf der imaginären Achse.      Die reelle Zahl liegt auf der reellen Achse ( -Achse), die rein imaginäre Zahl auf der imaginären Achse ( -Achse). Die reelle Achse ist also die vertraute Zahlengerade — die Gaußsche Zahlenebene ergänzt sie um eine zweite Richtung.   "
},
{
  "id": "ex-mengen-zahlenebene",
  "level": "2",
  "url": "sec-koerper-der-komplexen-zahlen.html#ex-mengen-zahlenebene",
  "type": "Beispiel",
  "number": "1.1.11",
  "title": "Bedingungen an Real- und Imaginärteil als Bilder.",
  "body": " Bedingungen an Real- und Imaginärteil als Bilder   Wo in der Gaußschen Zahlenebene liegen alle komplexen Zahlen mit  ,  ,  ,  ?        Alle Punkte mit beliebigem : die senkrechte Gerade durch , parallel zur imaginären Achse.  Alle Punkte : die waagerechte Gerade durch , parallel zur reellen Achse.  Alle Punkte oberhalb der reellen Achse: die obere Halbebene, ohne die reelle Achse selbst.  Alle Punkte : die Winkelhalbierende des ersten und dritten Quadranten, also die Zahlen mit .    Bedingungen an Real- und Imaginärteil beschreiben Geraden und Halbebenen. Mit dem Betrag, den wir als Nächstes einführen, kommen Kreise hinzu.   "
},
{
  "id": "def-betrag-komplex",
  "level": "2",
  "url": "sec-koerper-der-komplexen-zahlen.html#def-betrag-komplex",
  "type": "Definition",
  "number": "1.1.12",
  "title": "Betrag einer komplexen Zahl.",
  "body": " Betrag einer komplexen Zahl   Der Betrag von ist    "
},
{
  "id": "fig-betrag-pythagoras",
  "level": "2",
  "url": "sec-koerper-der-komplexen-zahlen.html#fig-betrag-pythagoras",
  "type": "Abbildung",
  "number": "1.1.13",
  "title": "",
  "body": " Der Betrag ist die Hypotenuse des rechtwinkligen Dreiecks mit den Katheten und , also der Abstand von zum Ursprung.    Ein rechtwinkliges Dreieck in der Gaußschen Zahlenebene mit den Ecken Ursprung, und . Die waagerechte Kathete auf der reellen Achse hat die Länge , die senkrechte Kathete die Länge , und die Hypotenuse vom Ursprung zu hat die Länge .     "
},
{
  "id": "ex-betrag-berechnen",
  "level": "2",
  "url": "sec-koerper-der-komplexen-zahlen.html#ex-betrag-berechnen",
  "type": "Beispiel",
  "number": "1.1.14",
  "title": "Beträge berechnen.",
  "body": " Beträge berechnen   Bestimmen Sie , , , und .     Bei kommt wie erwartet der reelle Betrag heraus. Die letzte Zahl hat den Betrag , liegt also auf dem Kreis mit Radius um den Ursprung, dem Einheitskreis . Solche Zahlen spielen in eine Hauptrolle.   "
},
{
  "id": "ex-kreis-betrag-fuenf",
  "level": "2",
  "url": "sec-koerper-der-komplexen-zahlen.html#ex-kreis-betrag-fuenf",
  "type": "Beispiel",
  "number": "1.1.15",
  "title": "Alle Zahlen vom Betrag 5.",
  "body": " Alle Zahlen vom Betrag 5   Welche komplexen Zahlen mit ganzzahligem Real- und Imaginärteil haben den Betrag ? Wo liegen sie in der Gaußschen Zahlenebene?    Gesucht sind ganze Zahlen mit , also . Die Quadratzahlen bis sind , und genau zwei Kombinationen ergeben : und (jeweils in beiden Reihenfolgen). Mit allen Vorzeichen erhält man die zwölf Zahlen Sie alle haben den Abstand vom Ursprung und liegen deshalb auf dem Kreis mit Radius um , siehe .   Die zwölf Zahlen mit ganzzahligem Real- und Imaginärteil vom Betrag liegen auf dem Kreis mit Radius um den Ursprung.    Ein Kreis mit Radius um den Ursprung der Gaußschen Zahlenebene. Auf ihm sind zwölf Punkte markiert: die vier Achsenpunkte und sowie die acht Punkte und . Beschriftet sind , , und .      Allgemein gilt: Die Zahlen mit bilden den Kreis mit Radius um den Ursprung.   "
},
{
  "id": "ex-anwendung-lagerroboter-betrag",
  "level": "2",
  "url": "sec-koerper-der-komplexen-zahlen.html#ex-anwendung-lagerroboter-betrag",
  "type": "Beispiel",
  "number": "1.1.17",
  "title": "Anwendungsbeispiel: Positionen im Lager (zur Vertiefung).",
  "body": " Anwendungsbeispiel: Positionen im Lager (zur Vertiefung)   In einem Logistiklager fahren autonome Transportroboter. Die Lagersteuerung beschreibt jede Position in Metern relativ zur Ladestation im Ursprung; die reelle Achse zeigt nach Osten, die imaginäre nach Norden. Eine Position ist dann einfach eine komplexe Zahl. Python etwa kennt dafür den eingebauten Datentyp complex , geschrieben wie in der Elektrotechnik mit j : -12+9j .  Roboter A steht bei , Roboter B bei ( ). Welcher der beiden ist näher an der Ladestation?   Positionen zweier Transportroboter relativ zur Ladestation (Angaben in Metern).    Eine Gaußsche Zahlenebene mit der Ladestation im Ursprung. Die reelle Achse ist mit Osten , die imaginäre mit Norden beschriftet. Roboter A liegt bei links oben, Roboter B bei rechts oben; gepunktete Linien zeigen ihre Koordinaten auf beiden Achsen.        Die Entfernung zur Ladestation ist der Abstand zum Ursprung, also der Betrag: Roboter A ist mit  m Luftlinie näher an der Ladestation als Roboter B mit  m. (In Python liefert abs(-12+9j) genau diesen Betrag, 15.0 .)   "
},
{
  "id": "def-komplexe-konjugation",
  "level": "2",
  "url": "sec-koerper-der-komplexen-zahlen.html#def-komplexe-konjugation",
  "type": "Definition",
  "number": "1.1.19",
  "title": "Komplexe Konjugation.",
  "body": " Komplexe Konjugation   Zu heißt die Zahl die zu  komplex-konjugierte Zahl . In der Gaußschen Zahlenebene entsteht aus durch Spiegelung an der reellen Achse.   "
},
{
  "id": "fig-komplexe-konjugation",
  "level": "2",
  "url": "sec-koerper-der-komplexen-zahlen.html#fig-komplexe-konjugation",
  "type": "Abbildung",
  "number": "1.1.20",
  "title": "",
  "body": " Die Konjugierte ist das Spiegelbild von an der reellen Achse.    Ein Koordinatensystem mit horizontaler reeller Achse ( ) und vertikaler imaginärer Achse ( ). Der Punkt ist markiert, ebenso der Ursprung, eine gestrichelte Verbindungslinie vom Ursprung zu , und der an der reellen Achse gespiegelte Punkt , der ebenfalls gestrichelt mit dem Ursprung verbunden ist.     "
},
{
  "id": "ex-konjugierte-bestimmen",
  "level": "2",
  "url": "sec-koerper-der-komplexen-zahlen.html#ex-konjugierte-bestimmen",
  "type": "Beispiel",
  "number": "1.1.21",
  "title": "Konjugieren heißt Spiegeln (zur Vertiefung).",
  "body": " Konjugieren heißt Spiegeln (zur Vertiefung)   Bestimmen Sie die konjugierten Zahlen zu , , und , und beschreiben Sie, was dabei in der Gaußschen Zahlenebene passiert.    Nur das Vorzeichen des Imaginärteils ändert sich: Die Punkte und wandern auf die andere Seite der reellen Achse. Die rein imaginäre Zahl springt auf der imaginären Achse von nach . Die reelle Zahl liegt auf der Spiegelachse und bleibt deshalb, wo sie ist.   "
},
{
  "id": "ex-betrag-konjugierte",
  "level": "2",
  "url": "sec-koerper-der-komplexen-zahlen.html#ex-betrag-konjugierte",
  "type": "Beispiel",
  "number": "1.1.22",
  "title": "Konjugieren ändert den Betrag nicht (zur Vertiefung).",
  "body": " Konjugieren ändert den Betrag nicht (zur Vertiefung)   Rechnen Sie nach, dass für jede komplexe Zahl gilt: . Begründen Sie das auch geometrisch.    Mit ist , also Geometrisch: Der Ursprung liegt auf der Spiegelachse, und eine Spiegelung ändert keine Abstände — also haben und denselben Abstand zum Ursprung (siehe die beiden gleich langen gestrichelten Strecken in ).   "
},
{
  "id": "ssub-grundrechenarten-2",
  "level": "2",
  "url": "sec-koerper-der-komplexen-zahlen.html#ssub-grundrechenarten-2",
  "type": "Absatz (with a defined term)",
  "number": "",
  "title": "",
  "body": "Permanenzprinzip "
},
{
  "id": "def-addition-subtraktion-komplex",
  "level": "2",
  "url": "sec-koerper-der-komplexen-zahlen.html#def-addition-subtraktion-komplex",
  "type": "Definition",
  "number": "1.1.23",
  "title": "Addition und Subtraktion.",
  "body": " Addition und Subtraktion   Für und :  Real- und Imaginärteil werden also komponentenweise addiert bzw. subtrahiert.   "
},
{
  "id": "ex-addition-subtraktion",
  "level": "2",
  "url": "sec-koerper-der-komplexen-zahlen.html#ex-addition-subtraktion",
  "type": "Beispiel",
  "number": "1.1.24",
  "title": "Addition und Subtraktion — rechnerisch und geometrisch.",
  "body": " Addition und Subtraktion — rechnerisch und geometrisch   Berechnen Sie für und die Summe und die Differenz , und deuten Sie beide in der Gaußschen Zahlenebene.     Die Summe ist die Diagonale des Parallelogramms mit den Seiten und . Die Differenz ist der Pfeil, der von nach führt (denn ), hier an den Ursprung verschoben, siehe .   Summe und Differenz von und : Die Summe ist die Diagonale des Parallelogramms, die Differenz der Pfeil von nach .    Pfeile vom Ursprung zu , zu und zu . Gestrichelte Linien von und zu vervollständigen das Parallelogramm. Ein gepunkteter Pfeil führt von nach ; ein gleich langer, paralleler gepunkteter Pfeil führt vom Ursprung zu .       "
},
{
  "id": "ssub-grundrechenarten-7",
  "level": "2",
  "url": "sec-koerper-der-komplexen-zahlen.html#ssub-grundrechenarten-7",
  "type": "Absatz (with a defined term)",
  "number": "",
  "title": "",
  "body": "Abstand "
},
{
  "id": "ex-anwendung-lagerroboter-abstand",
  "level": "2",
  "url": "sec-koerper-der-komplexen-zahlen.html#ex-anwendung-lagerroboter-abstand",
  "type": "Beispiel",
  "number": "1.1.26",
  "title": "Anwendungsbeispiel: Wie weit liegen zwei Roboter auseinander? (zur Vertiefung).",
  "body": " Anwendungsbeispiel: Wie weit liegen zwei Roboter auseinander? (zur Vertiefung)   Die beiden Roboter aus stehen bei und . Roboter A soll ein Paket zu Roboter B bringen. Wie weit liegen die beiden (Luftlinie) auseinander?    Der Abstand ist der Betrag der Differenz: Die Roboter stehen  m voneinander entfernt. Eine hübsche Kontrolle: . Das Dreieck aus Ladestation, A und B erfüllt also den Satz des Pythagoras — es hat an der Ladestation einen rechten Winkel.   "
},
{
  "id": "def-multiplikation-komplex",
  "level": "2",
  "url": "sec-koerper-der-komplexen-zahlen.html#def-multiplikation-komplex",
  "type": "Definition",
  "number": "1.1.27",
  "title": "Multiplikation.",
  "body": " Multiplikation   Aus Distributivgesetz und folgt    "
},
{
  "id": "ex-potenzen-imaginaere-einheit",
  "level": "2",
  "url": "sec-koerper-der-komplexen-zahlen.html#ex-potenzen-imaginaere-einheit",
  "type": "Beispiel",
  "number": "1.1.28",
  "title": "Die Potenzen von <span class=\"process-math\">\\(\\ii\\)<\/span> wiederholen sich.",
  "body": " Die Potenzen von wiederholen sich   Berechnen Sie , , , und . Welches Muster erkennen Sie?     Wegen wiederholen sich die Potenzen im Viererrhythmus — für kommt es nur auf den Rest von bei Division durch an. In der Gaußschen Zahlenebene springt der Punkt dabei jeweils eine Vierteldrehung weiter: . Dass die Multiplikation mit tatsächlich eine Drehung um ist, zeigt .   "
},
{
  "id": "ex-multiplikation",
  "level": "2",
  "url": "sec-koerper-der-komplexen-zahlen.html#ex-multiplikation",
  "type": "Beispiel",
  "number": "1.1.29",
  "title": "Produkte ausmultiplizieren (zur Vertiefung).",
  "body": " Produkte ausmultiplizieren (zur Vertiefung)   Berechnen Sie und in algebraischer Form.    Ausmultiplizieren und einsetzen: Das erste Ergebnis zeigt, warum komponentenweises Multiplizieren falsch wäre: Es hätte geliefert. Tatsächlich hebt sich der Realteil vollständig weg: Das Produkt zweier Zahlen mit positivem Realteil ist hier rein imaginär.   "
},
{
  "id": "ex-quadratische-gleichung-probe",
  "level": "2",
  "url": "sec-koerper-der-komplexen-zahlen.html#ex-quadratische-gleichung-probe",
  "type": "Beispiel",
  "number": "1.1.30",
  "title": "Eine „unlösbare“ quadratische Gleichung.",
  "body": " Eine unlösbare quadratische Gleichung   Die Gleichung hat keine reelle Lösung: Die -Formel führt auf . Zeigen Sie, dass und Lösungen in sind.    Für ist , also Für ist , also Beide Zahlen sind Lösungen — und sie sind zueinander konjugiert. Das ist kein Zufall. Wie man solche Lösungen systematisch findet, statt sie nur zu überprüfen, ist Thema von .   "
},
{
  "id": "ex-bombelli-kubische-gleichung",
  "level": "2",
  "url": "sec-koerper-der-komplexen-zahlen.html#ex-bombelli-kubische-gleichung",
  "type": "Beispiel",
  "number": "1.1.31",
  "title": "Rechenbeispiel aus der Geschichte: Bombellis kubische Gleichung.",
  "body": " Rechenbeispiel aus der Geschichte: Bombellis kubische Gleichung   Der italienische Ingenieur Rafael Bombelli untersuchte in seinem 1572 erschienenen Buch L'Algebra die Gleichung . Die damals neue Lösungsformel für kubische Gleichungen (die Cardanische Formel) liefert für eine Lösung den Ausdruck mit einer Wurzel aus einer negativen Zahl. In unserer Schreibweise ist , denn . Bombelli vermutete, dass eine Kubikwurzel von sein könnte.  Prüfen Sie nach, dass und gilt. Welchen Wert hat dann , und löst er wirklich die Gleichung?    Zuerst das Quadrat, dann noch einmal mit multiplizieren: Genauso ist und . Damit ergibt Bombellis Ansatz Probe: und . Die Imaginärteile heben sich auf, und übrig bleibt eine ganz gewöhnliche reelle Lösung. Genau diese Erfahrung — komplexe Zahlen als Umweg zu reellen Ergebnissen — hat den komplexen Zahlen den Weg in die Mathematik geebnet.   "
},
{
  "id": "thm-zzstern-betragsquadrat",
  "level": "2",
  "url": "sec-koerper-der-komplexen-zahlen.html#thm-zzstern-betragsquadrat",
  "type": "Satz",
  "number": "1.1.32",
  "title": "Produkt mit der konjugierten Zahl.",
  "body": " Produkt mit der konjugierten Zahl   Für jedes gilt     Mit ist da .   "
},
{
  "id": "def-division-komplex",
  "level": "2",
  "url": "sec-koerper-der-komplexen-zahlen.html#def-division-komplex",
  "type": "Definition",
  "number": "1.1.33",
  "title": "Division.",
  "body": " Division   Für erweitert man den Bruch mit , um den Nenner reell zu machen: Mit ( ) gilt    "
},
{
  "id": "ex-division-schrittweise",
  "level": "2",
  "url": "sec-koerper-der-komplexen-zahlen.html#ex-division-schrittweise",
  "type": "Beispiel",
  "number": "1.1.34",
  "title": "Division durch Erweitern mit dem konjugierten Nenner.",
  "body": " Division durch Erweitern mit dem konjugierten Nenner   Berechnen Sie und in algebraischer Form, und machen Sie jeweils die Probe.    Im ersten Bruch erweitern wir mit : Probe durch Zurückmultiplizieren: .  Im zweiten Bruch erweitern wir mit : Probe: . Durch zu teilen heißt also, mit zu multiplizieren — ein Trick, der im folgenden Anwendungsbeispiel gleich gebraucht wird.   "
},
{
  "id": "ex-anwendung-impedanz-rc-reihenschaltung",
  "level": "2",
  "url": "sec-koerper-der-komplexen-zahlen.html#ex-anwendung-impedanz-rc-reihenschaltung",
  "type": "Beispiel",
  "number": "1.1.35",
  "title": "Anwendungsbeispiel: Impedanz einer RC-Reihenschaltung.",
  "body": " Anwendungsbeispiel: Impedanz einer RC-Reihenschaltung   In der Wechselstromrechnung tritt an die Stelle des ohmschen Widerstands die Impedanz  , der komplexe Wechselstromwiderstand: Wie beim Gleichstrom ist sie das Verhältnis von Spannung zu Stromstärke, nur eben eine komplexe Zahl, weil sie außer dem Verhältnis der Amplituden auch festhält, wie weit Spannung und Strom zeitlich gegeneinander verschoben sind ( zeigt, wie man beides abliest).  Einem ohmschen Widerstand ordnet man die (reelle) Impedanz zu, einem Kondensator mit Kapazität bei Kreisfrequenz die (rein imaginäre) Impedanz . Die Gesamtimpedanz einer Reihenschaltung ( ) ist die Summe der Einzelimpedanzen — genau wie bei reellen Widerständen, nur dass jetzt komplex addiert wird.   RC-Reihenschaltung: Die Wechselspannungsquelle treibt den Strom nacheinander durch den Widerstand und den Kondensator .    Schaltplan eines geschlossenen Stromkreises. Links eine Wechselspannungsquelle, gezeichnet als Kreis mit einer Sinuswelle und beschriftet mit . Die Leitung führt oben über einen Widerstand (Rechteck) und rechts über einen Kondensator (zwei parallele Platten) zurück zur Quelle. Alle Bauteile liegen hintereinander in einem einzigen Stromweg.      Für , und bestimmen Sie die Gesamtimpedanz in algebraischer Form sowie ihren Betrag .  Für die Einheiten brauchen Sie , also Ohm gleich Sekunde pro Farad: Ein Kondensator mit speichert bei die Ladung , also ist und damit     Zunächst formen wir in algebraische Form um, indem wir mit erweitern: Mit ergibt sich mit  Die Gesamtimpedanz ist damit eine einfache komplexe Addition. Ihr Betrag ist Der negative Imaginärteil zeigt an, dass die Schaltung kapazitiv wirkt: Der Strom eilt der Spannung phasenmäßig voraus (die Begriffe kapazitiv und induktiv erklärt ). Im nächsten Unterabschnitt sehen wir, wie sich dieser Phasenwinkel direkt aus der Polarform von ablesen lässt.   "
},
{
  "id": "ssub-grundrechenarten-21",
  "level": "2",
  "url": "sec-koerper-der-komplexen-zahlen.html#ssub-grundrechenarten-21",
  "type": "Absatz (with a defined term)",
  "number": "",
  "title": "",
  "body": "Körper "
},
{
  "id": "sub-darstellungsformen-2-2",
  "level": "2",
  "url": "sec-koerper-der-komplexen-zahlen.html#sub-darstellungsformen-2-2",
  "type": "Absatz (with a defined term)",
  "number": "",
  "title": "",
  "body": "Polarform Exponentialform "
},
{
  "id": "def-polarform",
  "level": "2",
  "url": "sec-koerper-der-komplexen-zahlen.html#def-polarform",
  "type": "Definition",
  "number": "1.1.37",
  "title": "Polarkoordinaten einer komplexen Zahl.",
  "body": " Polarkoordinaten einer komplexen Zahl   Jede komplexe Zahl lässt sich eindeutig durch zwei Polarkoordinaten beschreiben:  den Radius  , den Abstand von zum Ursprung;  den Winkel (das Argument ) , den Winkel des Ortsvektors zur positiven reellen Achse.    Für setzt man und . Für berechnet man aus    "
},
{
  "id": "fig-polarkoordinaten",
  "level": "2",
  "url": "sec-koerper-der-komplexen-zahlen.html#fig-polarkoordinaten",
  "type": "Abbildung",
  "number": "1.1.38",
  "title": "",
  "body": " Polarkoordinaten: Der Punkt hat den Abstand zum Ursprung und liegt unter dem Winkel zur positiven reellen Achse.    Eine Gaußsche Zahlenebene mit einem Punkt im ersten Quadranten. Eine Strecke der Länge verbindet den Ursprung mit . Ein Kreisbogen am Ursprung markiert den Winkel zwischen der positiven reellen Achse und dieser Strecke. Gepunktete Linien zeigen die Koordinaten auf der reellen und auf der imaginären Achse.     "
},
{
  "id": "ssub-polarkoordinaten-6",
  "level": "2",
  "url": "sec-koerper-der-komplexen-zahlen.html#ssub-polarkoordinaten-6",
  "type": "Absatz (with a defined term)",
  "number": "",
  "title": "",
  "body": "normierte "
},
{
  "id": "fig-einheitskreis-standardwinkel",
  "level": "2",
  "url": "sec-koerper-der-komplexen-zahlen.html#fig-einheitskreis-standardwinkel",
  "type": "Abbildung",
  "number": "1.1.39",
  "title": "",
  "body": " Der Einheitskreis mit den Standardwinkeln (innen) und der Zahl vom Betrag , die unter diesem Winkel liegt (außen). Ihr Realteil ist , ihr Imaginärteil .    Der Einheitskreis in der Gaußschen Zahlenebene mit sechzehn markierten Punkten, die mit dem Ursprung durch Strecken verbunden sind. Innen an jeder Strecke steht der Winkel, außen die Zahl in algebraischer Form. Schwarz: bei , bei , bei , bei . Blau: bei und bei . Orange: bei und bei . Grün: bei und bei . Dabei gehört jeweils das Pluszeichen des Winkels zum Pluszeichen des Imaginärteils.     "
},
{
  "id": "rem-umrechnen-einheitskreis",
  "level": "2",
  "url": "sec-koerper-der-komplexen-zahlen.html#rem-umrechnen-einheitskreis",
  "type": "Bemerkung",
  "number": "1.1.40",
  "title": "Rezept: Polarkoordinaten am Einheitskreis ablesen.",
  "body": " Rezept: Polarkoordinaten am Einheitskreis ablesen    Den Betrag berechnen.  Normieren: bilden und vereinfachen, bis Real- und Imaginärteil so aussehen wie in . Häufig braucht man dafür .  Die normierte Zahl in suchen und den Winkel ablesen.  Ist keine der markierten Zahlen, bleibt der Arkustangens mit der Fallunterscheidung aus . Auch dann zeigt die Abbildung aber, zwischen welchen Standardwinkeln liegen muss — eine wertvolle Kontrolle.  "
},
{
  "id": "ex-algebraisch-zu-polar",
  "level": "2",
  "url": "sec-koerper-der-komplexen-zahlen.html#ex-algebraisch-zu-polar",
  "type": "Beispiel",
  "number": "1.1.41",
  "title": "Polarkoordinaten am Einheitskreis ablesen.",
  "body": " Polarkoordinaten am Einheitskreis ablesen   Bestimmen Sie die Polarkoordinaten von mit dem Rezept aus .    Der Betrag ist . Normiert: Diese Zahl finden wir in im zweiten Quadranten beim Winkel . Die Polarkoordinaten sind also und .  Zur Kontrolle: Der Punkt liegt links oberhalb des Ursprungs, also muss zwischen und liegen. Die Fallunterscheidung hätte dasselbe geliefert, , nur mit mehr Aufwand und mehr Gelegenheit für Fehler.   "
},
{
  "id": "ex-winkel-vier-quadranten",
  "level": "2",
  "url": "sec-koerper-der-komplexen-zahlen.html#ex-winkel-vier-quadranten",
  "type": "Beispiel",
  "number": "1.1.42",
  "title": "Ein Winkel pro Quadrant — und eine Falle (zur Vertiefung).",
  "body": " Ein Winkel pro Quadrant — und eine Falle (zur Vertiefung)   Bestimmen Sie Betrag und Argument von , , , sowie von und . Was liefert der Taschenrechner-Ansatz für ?    Die ersten vier Zahlen haben alle den Betrag . Normiert, mit : Das sind die vier orangefarbenen Punkte in , und wir lesen ab: Die beiden Achsenpunkte gehen genauso, nur schneller: und , also ; und , also .  Die Falle: Für ist , und — derselbe Wert wie für . Der Quotient kann die gegenüberliegenden Punkte und nicht unterscheiden. Erst die Korrektur um (dritter Fall der Definition) liefert den richtigen Winkel .   "
},
{
  "id": "def-trigonometrische-polarform",
  "level": "2",
  "url": "sec-koerper-der-komplexen-zahlen.html#def-trigonometrische-polarform",
  "type": "Definition",
  "number": "1.1.43",
  "title": "Trigonometrische Polarform.",
  "body": " Trigonometrische Polarform   Aus und erhält man Real- und Imaginärteil zurück durch also Diese Darstellung heißt (trigonometrische) Polarform von .   "
},
{
  "id": "ex-polar-zu-algebraisch",
  "level": "2",
  "url": "sec-koerper-der-komplexen-zahlen.html#ex-polar-zu-algebraisch",
  "type": "Beispiel",
  "number": "1.1.44",
  "title": "Von der Polarform zurück zur algebraischen Form (zur Vertiefung).",
  "body": " Von der Polarform zurück zur algebraischen Form (zur Vertiefung)   Eine komplexe Zahl hat den Betrag und das Argument . Wie lautet sie in algebraischer Form?    In steht beim Winkel die Zahl . Mit dem Betrag multipliziert: Plausibel: zeigt in den zweiten Quadranten, und tatsächlich ist der Realteil negativ, der Imaginärteil positiv. Diese Richtung der Umrechnung ist die einfachere — sie braucht keine Fallunterscheidung.   "
},
{
  "id": "thm-eulersche-formel",
  "level": "2",
  "url": "sec-koerper-der-komplexen-zahlen.html#thm-eulersche-formel",
  "type": "Satz",
  "number": "1.1.45",
  "title": "Eulersche Formel.",
  "body": " Eulersche Formel   Die (reelle) Exponentialfunktion lässt sich auf komplexe Argumente fortsetzen. Für gilt die Eulersche Formel     "
},
{
  "id": "fig-einheitskreis-euler",
  "level": "2",
  "url": "sec-koerper-der-komplexen-zahlen.html#fig-einheitskreis-euler",
  "type": "Abbildung",
  "number": "1.1.46",
  "title": "",
  "body": " Die Zahl liegt auf dem Einheitskreis unter dem Winkel .    Der Einheitskreis in der Gaußschen Zahlenebene, auf dem die Punkte , , und markiert sind. Ein weiterer Punkt liegt im ersten Quadranten auf dem Kreis; ein Bogen markiert den Winkel , gepunktete Linien zeigen auf der reellen und auf der imaginären Achse.     "
},
{
  "id": "ex-werte-euler-einheitskreis",
  "level": "2",
  "url": "sec-koerper-der-komplexen-zahlen.html#ex-werte-euler-einheitskreis",
  "type": "Beispiel",
  "number": "1.1.47",
  "title": "Eine Runde um den Einheitskreis (zur Vertiefung).",
  "body": " Eine Runde um den Einheitskreis (zur Vertiefung)   Berechnen Sie für .    Die ersten vier Winkel liegen in , ihre Werte stehen in : Die Winkel und kommen in der Abbildung nicht vor. Eine volle Umdrehung um führt aber zum selben Punkt zurück, allgemein ist . Wir ziehen also ab: Die Zahl kennen Sie aus : Sie hat den Betrag , und jetzt wissen wir auch, in welcher Richtung sie liegt. Der Wert für ergibt die berühmte Eulersche Identität  , die die fünf wichtigsten Konstanten der Mathematik in einer Gleichung vereint.   "
},
{
  "id": "def-exponentialform",
  "level": "2",
  "url": "sec-koerper-der-komplexen-zahlen.html#def-exponentialform",
  "type": "Definition",
  "number": "1.1.48",
  "title": "Exponentialform.",
  "body": " Exponentialform   Mit der Eulerschen Formel lässt sich jede komplexe Zahl in Exponentialform  schreiben. Dabei sind und genau die Polarkoordinaten von .   "
},
{
  "id": "rem-phasoren",
  "level": "2",
  "url": "sec-koerper-der-komplexen-zahlen.html#rem-phasoren",
  "type": "Bemerkung",
  "number": "1.1.49",
  "title": "Phasoren.",
  "body": " Phasoren  Eine sinusförmige Wechselspannung ist durch ihre Amplitude , ihre Kreisfrequenz und ihren Nullphasenwinkel festgelegt. In einem Wechselstromkreis schwingen alle Spannungen und Ströme mit der Kreisfrequenz der Quelle; sie unterscheiden sich nur in Amplitude und Phase. Diese beiden Angaben fasst man zu einer komplexen Zahl zusammen, dem Phasor (auch Zeiger oder komplexe Amplitude ) Sein Betrag ist die Amplitude, sein Argument die Phase. Die Schwingung selbst ist der Realteil : Anschaulich ist ein Zeiger der Länge , der mit der Winkelgeschwindigkeit gegen den Uhrzeigersinn rotiert, und ist sein Schatten auf der reellen Achse.  Für die Phasoren und von Spannung und Strom gilt das ohmsche Gesetz der Wechselstromrechnung mit der Impedanz aus . Wie wir in sehen werden, folgt daraus: ist das Verhältnis der Amplituden von Spannung und Strom, und das Argument von ist die Phase der Spannung minus die Phase des Stroms.  "
},
{
  "id": "ex-anwendung-impedanz-phasenwinkel",
  "level": "2",
  "url": "sec-koerper-der-komplexen-zahlen.html#ex-anwendung-impedanz-phasenwinkel",
  "type": "Beispiel",
  "number": "1.1.50",
  "title": "Anwendungsbeispiel: Der Phasenwinkel einer Impedanz.",
  "body": " Anwendungsbeispiel: Der Phasenwinkel einer Impedanz   In hatten wir für eine RC-Reihenschaltung die Impedanz (in ) berechnet. Bestimmen Sie ihre Exponentialform. Was bedeutet das Argument physikalisch?  Für das Vorzeichen des Arguments gibt es in der Elektrotechnik zwei Fachbegriffe. Eine Schaltung heißt kapazitiv , wenn ihre Impedanz einen negativen Imaginärteil hat, also : Sie verhält sich wie ein Kondensator mit , und der Strom eilt der Spannung voraus. Sie heißt induktiv , wenn der Imaginärteil positiv ist, also : Sie verhält sich wie eine Spule mit Induktivität und Impedanz , und der Strom hinkt der Spannung hinterher. Eine alte Merkregel fasst das zusammen: Beim Kondensator eilt der Strom vor, bei Induktivitäten wird er sich verspäten. Ist die Schaltung aus kapazitiv oder induktiv?    Der Betrag ist . Normiert, mit : In gehört diese Zahl zum Winkel , also ist und Nach gibt der Betrag an, wie stark die Schaltung den Strom begrenzt: Er ist das Verhältnis der Amplituden von Spannung und Strom. Das Argument ist der Phasenwinkel zwischen Spannung und Strom: Die Phase der Spannung ist um kleiner als die des Stroms, der Strom eilt der Spannung also um voraus. Wegen ist die Schaltung kapazitiv — wie zu erwarten, denn außer dem ohmschen Widerstand enthält sie nur einen Kondensator. Beide Größen, die ein Elektrotechniker wissen will, stehen direkt in der Exponentialform — in der algebraischen Form sieht man sie nicht auf den ersten Blick.   "
},
{
  "id": "thm-multiplikation-division-exponentialform",
  "level": "2",
  "url": "sec-koerper-der-komplexen-zahlen.html#thm-multiplikation-division-exponentialform",
  "type": "Satz",
  "number": "1.1.51",
  "title": "Multiplikation und Division in Exponentialform.",
  "body": " Multiplikation und Division in Exponentialform   Für und gilt Geometrisch bedeutet Multiplikation: Beträge multiplizieren, Winkel addieren ; Division: Beträge dividieren, Winkel subtrahieren .    Das folgt direkt aus den Potenzgesetzen der Exponentialfunktion: und .   "
},
{
  "id": "ex-multiplikation-exponentialform",
  "level": "2",
  "url": "sec-koerper-der-komplexen-zahlen.html#ex-multiplikation-exponentialform",
  "type": "Beispiel",
  "number": "1.1.52",
  "title": "Produkt und Quotient über die Exponentialform.",
  "body": " Produkt und Quotient über die Exponentialform   Berechnen Sie und für und , und geben Sie beide Ergebnisse in algebraischer Form an.    Beträge multiplizieren bzw. dividieren, Winkel addieren bzw. subtrahieren; die Werte von und lesen wir in ab: Zum Vergleich: In algebraischer Form wäre (wieder mit ) und — das Ausmultiplizieren und das Erweitern mit dem konjugierten Nenner führen zum selben Ergebnis, aber mit deutlich mehr Rechenaufwand.   "
},
{
  "id": "ex-potenz-exponentialform",
  "level": "2",
  "url": "sec-koerper-der-komplexen-zahlen.html#ex-potenz-exponentialform",
  "type": "Beispiel",
  "number": "1.1.53",
  "title": "Potenzen über die Exponentialform.",
  "body": " Potenzen über die Exponentialform   Berechnen Sie und .    Zunächst die Exponentialform der Basis: , und normiert ist , nach also und . Damit wobei wir verwendet und abgelesen haben.  Für die zweite Zahl ist , normiert ; das ist in der Punkt beim Winkel . Damit Die sechste Potenz ist reell — zwei volle Umdrehungen bringen den Winkel zurück auf die positive reelle Achse. Das Ausmultiplizieren hätte das kaum erahnen lassen.   "
},
{
  "id": "prop-konjugation-exponentialform",
  "level": "2",
  "url": "sec-koerper-der-komplexen-zahlen.html#prop-konjugation-exponentialform",
  "type": "Proposition",
  "number": "1.1.54",
  "title": "Konjugation in Exponentialform.",
  "body": " Konjugation in Exponentialform   Für gilt Geometrisch bleibt der Betrag erhalten, das Vorzeichen des Winkels kehrt sich um.   "
},
{
  "id": "ex-anwendung-drehung-datenpunkte",
  "level": "2",
  "url": "sec-koerper-der-komplexen-zahlen.html#ex-anwendung-drehung-datenpunkte",
  "type": "Beispiel",
  "number": "1.1.55",
  "title": "Anwendungsbeispiel: Datenpunkte drehen.",
  "body": " Anwendungsbeispiel: Datenpunkte drehen   Fasst man einen Punkt der Ebene als komplexe Zahl auf, so ist die Multiplikation mit (Betrag , Winkel ) nach genau eine Drehung um den Ursprung um den Winkel : Der Betrag bleibt, der Winkel wächst um . Solche Drehungen braucht man etwa, wenn man Bilddaten zur Erweiterung eines Trainingsdatensatzes rotiert oder Sensordaten in ein gedrehtes Koordinatensystem umrechnet. Drehen Sie den Punkt um und um gegen den Uhrzeigersinn.    Die Drehfaktoren lesen wir in ab. Für ist , also Für ist , also Probe: Beide Bildpunkte haben wie den Abstand vom Ursprung — eine Drehung ändert Beträge nicht ( ). Nebenbei ist damit auch geklärt, warum die Potenzen von in im Kreis laufen: Jede Multiplikation mit ist eine Vierteldrehung.   Der Punkt , um und um gedreht. Alle drei Punkte liegen auf dem Kreis mit Radius .    Ein Kreis mit Radius um den Ursprung. Auf ihm liegen der Punkt im ersten Quadranten, der um gedrehte Punkt und der um gedrehte Punkt im zweiten Quadranten. Pfeile vom Ursprung führen zu allen drei Punkten, gebogene Pfeile zeigen die Drehrichtung gegen den Uhrzeigersinn.       "
},
{
  "id": "ex-anwendung-strom-rc-glied",
  "level": "2",
  "url": "sec-koerper-der-komplexen-zahlen.html#ex-anwendung-strom-rc-glied",
  "type": "Beispiel",
  "number": "1.1.57",
  "title": "Anwendungsbeispiel: Der Strom im RC-Glied (zur Vertiefung).",
  "body": " Anwendungsbeispiel: Der Strom im RC-Glied (zur Vertiefung)   An die RC-Reihenschaltung aus mit wird eine Wechselspannung mit dem Phasor (Amplitude , Phase ) gelegt. Nach dem ohmschen Gesetz der Wechselstromrechnung ( ) ist der Stromphasor . Bestimmen Sie Amplitude und Phase des Stroms.    Division in Exponentialform — Beträge dividieren, Winkel subtrahieren: Der Strom hat die Amplitude und die Phase : Er eilt der Spannung um eine Achtelperiode voraus, wie in abgelesen. In algebraischer Form hätten wir hier durch teilen und mit dem konjugierten Nenner erweitern müssen; in Exponentialform ist es eine Zeile.   "
},
{
  "id": "ex-anwendung-phasor-additionstheorem",
  "level": "2",
  "url": "sec-koerper-der-komplexen-zahlen.html#ex-anwendung-phasor-additionstheorem",
  "type": "Beispiel",
  "number": "1.1.58",
  "title": "Anwendungsbeispiel: Überlagerung von Wechselspannungen (Phasoren).",
  "body": " Anwendungsbeispiel: Überlagerung von Wechselspannungen (Phasoren)   Schwingungen gleicher Frequenz überlagert man, indem man ihre Phasoren ( ) addiert. Denn der Realteil einer Summe ist die Summe der Realteile:   Gegeben seien und . Bestimmen Sie Amplitude und Phase der überlagerten Schwingung .    Die Phasoren sind und . Der Summenphasor ist Sein Betrag ist , normiert ist . Diese Zahl ist keiner der markierten Punkte in — hier hilft nur der Arkustangens: (erster Quadrant, also keine Korrektur), etwa . Die Abbildung taugt trotzdem zur Kontrolle: Der Imaginärteil liegt zwischen und , also muss der Winkel zwischen und liegen — passt. Also ist , und die überlagerte Schwingung ist Man sieht direkt: Die Amplitude der Summe ist nicht die Summe der Amplituden — Phasenunterschiede zählen, und die komplexe Addition erfasst das automatisch richtig.   "
},
{
  "id": "sub-zusammenfassung-1-1-2",
  "level": "2",
  "url": "sec-koerper-der-komplexen-zahlen.html#sub-zusammenfassung-1-1-2",
  "type": "Absatz (with a defined term)",
  "number": "",
  "title": "",
  "body": "Komplexe Zahl: Betrag und Abstand: Konjugation: Rechnen in algebraischer Form: Polar- und Exponentialform: Rechnen in Exponentialform: Merkregel: Anwendung: "
},
{
  "id": "exercise-buch-grundrechenarten",
  "level": "2",
  "url": "sec-koerper-der-komplexen-zahlen.html#exercise-buch-grundrechenarten",
  "type": "Übung",
  "number": "1.1.4.1",
  "title": "",
  "body": "  Gegeben seien und . Berechnen Sie in algebraischer Form , , und .      Für die Division erweitern wir mit :    "
},
{
  "id": "exercise-buch-betrag-konjugierte",
  "level": "2",
  "url": "sec-koerper-der-komplexen-zahlen.html#exercise-buch-betrag-konjugierte",
  "type": "Übung",
  "number": "1.1.4.2",
  "title": "",
  "body": "  Bestimmen Sie für den Realteil, den Imaginärteil, die konjugierte Zahl und den Betrag .     , , , und    "
},
{
  "id": "exercise-buch-abstand-zahlenebene",
  "level": "2",
  "url": "sec-koerper-der-komplexen-zahlen.html#exercise-buch-abstand-zahlenebene",
  "type": "Übung",
  "number": "1.1.4.3",
  "title": "",
  "body": "  Zeichnen Sie und in die Gaußsche Zahlenebene ein. Bestimmen Sie , und den Abstand der beiden Punkte.     ist der Punkt im zweiten Quadranten, der Punkt im ersten Quadranten. Der Abstand ist der Betrag der Differenz:    "
},
{
  "id": "exercise-buch-exponentialform-umrechnen",
  "level": "2",
  "url": "sec-koerper-der-komplexen-zahlen.html#exercise-buch-exponentialform-umrechnen",
  "type": "Übung",
  "number": "1.1.4.4",
  "title": "",
  "body": "  Bestimmen Sie die Exponentialform von .     Normiert, mit : In gehört diese Zahl zum Winkel . Damit    "
},
{
  "id": "exercise-buch-potenz-exponentialform",
  "level": "2",
  "url": "sec-koerper-der-komplexen-zahlen.html#exercise-buch-potenz-exponentialform",
  "type": "Übung",
  "number": "1.1.4.5",
  "title": "",
  "body": "  Berechnen Sie über die Exponentialform.    Es ist , normiert , nach also und . Damit ist (mit aus derselben Abbildung) (Probe über die algebraische Form: , also .)   "
},
{
  "id": "sec-algebraische-gleichungen-anwendungen",
  "level": "1",
  "url": "sec-algebraische-gleichungen-anwendungen.html",
  "type": "Abschnitt",
  "number": "1.2",
  "title": "Algebraische Gleichungen und Anwendungen komplexer Zahlen",
  "body": " Algebraische Gleichungen und Anwendungen komplexer Zahlen    Nach diesem Abschnitt können Sie    alle Lösungen einer reinen Gleichung bestimmen und als regelmäßiges -Eck in der Zahlenebene deuten;  die -ten Einheitswurzeln angeben und ihre Rolle in der diskreten Fourier-Transformation erklären;  quadratische Gleichungen in lösen — mit negativer Diskriminante, mit komplexen Koeffizienten und, per Substitution, auch biquadratische Gleichungen;  den Fundamentalsatz der Algebra wiedergeben und ein Polynom bei bekannter Nullstelle in Linearfaktoren zerlegen;  reelle Polynome in irreduzible reelle Faktoren zerlegen, indem Sie konjugiert komplexe Nullstellenpaare zusammenfassen;  eine technische Bedingung an eine Impedanz oder einen Filter in eine reelle algebraische Gleichung übersetzen und lösen.     Fragen Sie Python nach den Nullstellen des Polynoms — mit numpy.roots([1, -1, 1, -1]) —, so bekommen Sie nicht nur die erwartete zurück, sondern auch die beiden Zahlen 1j und -1j (bis auf winzige Rundungsfehler). Das j ist die Ingenieursschreibweise für , und ein Programmierfehler ist das nicht: numpy.roots sucht Nullstellen von vornherein in — und das mit gutem Grund, denn nur dort hat die Frage immer eine vollständige Antwort. Ein Polynom vom Grad hat in genau Nullstellen (mit Vielfachheit gezählt), und selbst wer am Ende nur reelle Ergebnisse braucht — etwa die reelle Zerlegung —, kommt über die komplexen Nullstellen am schnellsten ans Ziel.  Wir beginnen mit den reinen Gleichungen  , deren Lösungen ein regelmäßiges -Eck bilden und die den Kern der diskreten Fourier-Transformation ausmachen. Mit ihnen wird die Mitternachtsformel in uneingeschränkt brauchbar. Dann folgt der Fundamentalsatz der Algebra mit der Linearfaktorzerlegung, und zum Schluss sehen Sie an Beispielen aus der Wechselstromtechnik, wie eine komplexe Impedanz oder ein Filter auf eine ganz gewöhnliche reelle Gleichung führt. Die Exponentialform aus sollten Sie dafür griffbereit haben — sie ist das wichtigste Werkzeug dieses Abschnitts.    Algebraische Gleichungen über   Der Ausgangspunkt dieses Kapitels war die Gleichung , die in keine Lösung hat. Mit der imaginären Einheit ist diese Gleichung in lösbar — und zwar gleich zweifach, durch und . In haben wir außerdem nachgeprüft, dass die Gleichung lösen. Ehrlicherweise war das aber ein bisschen geschummelt: Die Lösungen fielen vom Himmel, wir haben sie nur eingesetzt. Gefunden haben wir sie nicht. Das holen wir jetzt systematisch nach — und beginnen mit den einfachsten Gleichungen überhaupt, bei denen die Exponentialform ihre ganze Stärke ausspielt.    Reine Gleichungen -ten Grades  Wie viele Lösungen hat die Gleichung ? In findet man und . In kommen zwei weitere hinzu, denn auch und . Die vier Lösungen liegen auf dem Kreis mit Radius und bilden ein Quadrat. Das ist kein Zufall, sondern ein allgemeines Muster.   Reine Gleichung -ten Grades, Wurzeln   Für und heißt die reine Gleichung -ten Grades . Ihre Lösungen heißen auch Wurzeln von .    Vorsicht, beliebte Falle: In bezeichnet für genau eine Zahl, nämlich die nicht negative Lösung von . In gibt es keine solche natürliche Wahl — beide Lösungen von , also und , haben gleich viel Anspruch auf den Namen Wurzel aus . Wer das vergisst und die vertrauten Wurzelgesetze trotzdem anwendet, kann Erstaunliches beweisen : Der Fehler steckt im Gleichheitszeichen mit dem Fragezeichen: Die Regel gilt nur für . Wir verwenden das Wurzelzeichen deshalb nur für nicht negative reelle Zahlen und sprechen sonst von den Lösungen von . (Bombelli — und wir mit ihm in — hat noch unbekümmert als gelesen. Das ist eine bequeme Abkürzung für eine der beiden Lösungen von , aber streng genommen nicht eindeutig: hätte denselben Anspruch.)   Lösungsformel für reine Gleichungen   Sei . Die Gleichung hat genau verschiedene Lösungen in , nämlich In der Gaußschen Zahlenebene liegen diese Zahlen auf einem Kreis vom Radius um den Ursprung und bilden dort ein regelmäßiges -Eck. Man nennt deshalb auch eine Kreisteilungsgleichung .    Ansatz mit . Dann ist , und bedeutet: Beträge und Winkel beider Seiten stimmen überein, wobei Winkel nur bis auf Vielfache von bestimmt sind. Also , d. h. , und für ein , d. h. . Für ergeben diese Winkel verschiedene Zahlen, denn zwei von ihnen unterscheiden sich um mit , und das ist kein Vielfaches von ; liefert wieder den Winkel von (plus ), also nichts Neues.    Die Formel sieht technisch aus, das Rezept dahinter ist einfach:  in Exponentialform bringen, am besten mit dem Rezept aus ;  die -te (reelle) Wurzel aus dem Betrag ziehen und den Winkel durch teilen — das ergibt die erste Lösung ;  die übrigen Lösungen entstehen, indem man den Winkel -mal um weiterdreht.  Warum gerade ? Dreht man eine Lösung um diesen Winkel weiter, so dreht sich ihre -te Potenz um , also um eine volle Umdrehung — und landet wieder bei .   Fünf Lösungen, ein Fünfeck   Bestimmen Sie alle Lösungen von .     Schritt 1:  , normiert ; nach ist also und .   Schritt 2:  und , also .   Schritt 3: Weiterdrehen um jeweils : mit den Winkeln . Die Lösung zu ist — die einzige reelle Lösung, die man auch ohne komplexe Zahlen gefunden hätte. Die fünf Lösungen bilden ein regelmäßiges Fünfeck ( ).     Die fünf Lösungen von bilden ein regelmäßiges Fünfeck auf dem Kreis mit Radius um den Ursprung.    Ein Koordinatensystem mit reeller und imaginärer Achse und einem Kreis vom Radius 2 um den Ursprung. Auf diesem Kreis sind fünf gleichmäßig verteilte Punkte markiert (im Winkelabstand von , bei den Winkeln ), die ein regelmäßiges Fünfeck bilden; einer der Punkte liegt auf der negativen reellen Achse.       Die dritten Einheitswurzeln   Bestimmen Sie alle Lösungen von .    Mit ist , . Nach mit : also , und (wir haben abgezogen, um in zu landen). In algebraischer Form, abgelesen in : Man nennt die dritten Einheitswurzeln ; allgemein heißen die Lösungen von die -ten Einheitswurzeln . Sie bilden ein gleichseitiges Dreieck auf dem Einheitskreis, mit einer Ecke bei . Probe für : Nach dem Potenzgesetz ist . Wer der Exponentialform noch nicht traut, kann auch in algebraischer Form nachrechnen: und , denn ist die Konjugierte von .    Hinter den Einheitswurzeln steckt übrigens eine berühmte Geschichte. Die Griechen der Antike konnten das regelmäßige Drei-, Vier-, Fünf- und Fünfzehneck mit Zirkel und Lineal konstruieren. Ob weitere regelmäßige Vielecke hinzukommen (abgesehen vom bloßen Verdoppeln der Eckenzahl), blieb rund zweitausend Jahre lang offen — bis der 18-jährige Carl Friedrich Gauß im März 1796 zeigte, dass auch das regelmäßige Siebzehneck konstruierbar ist. Sein Werkzeug: die Gleichung , also genau die Kreisteilungsgleichung, um die es hier geht. Die Entdeckung soll ihn bewogen haben, Mathematik statt Sprachen zu studieren. (Die vollständige Antwort, welche -Ecke genau konstruierbar sind, gaben Gauß 1801 und Pierre Wantzel 1837.)   Wurzeln aus einer nicht-reellen Zahl   Bestimmen Sie alle Lösungen von in algebraischer Form, und machen Sie die Probe.     hat den Betrag und liegt nach beim Winkel , also . Die erste Lösung hat den Winkel , die zweite ist um weitergedreht, auf bzw. (nach Abziehen von ) . Abgelesen in der Abbildung: Probe: . Wie im Reellen unterscheiden sich die beiden Quadratwurzeln nur im Vorzeichen — sie liegen einander gegenüber auf dem Kreis.    Die Einheitswurzeln (der Fall ) sind nicht nur Stoff für Geometrie und Geschichte: Sie tauchen überall auf, wo periodische Vorgänge digital analysiert werden.   Anwendungsbeispiel: -te Einheitswurzeln und die diskrete Fourier-Transformation   Die -ten Einheitswurzeln aus sind mehr als eine hübsche geometrische Figur: Sie bilden die Grundlage der diskreten Fourier-Transformation (DFT) , eines der wichtigsten Werkzeuge der digitalen Signalverarbeitung und damit auch der Data Science (Spektralanalyse von Zeitreihen, Bild- und Audiokompression, schnelle Faltung in neuronalen Netzen). Die DFT zerlegt ein abgetastetes Signal, also in gleichen Zeitabständen gemessene Werte, in Beiträge unterschiedlicher Frequenz: Der Betrag gibt an, wie stark eine Schwingung mit genau Perioden pro Messfenster in den Daten steckt. Für eine Folge von Messwerten definiert man die DFT als wobei genau die -te Einheitswurzel mit dem kleinsten positiven Winkel ist — jede andere -te Einheitswurzel ist eine Potenz von ihr.  Bestimmen Sie für alle vierten Einheitswurzeln und geben Sie sie als Potenzen von an. Berechnen Sie dann die DFT der vier Messwerte .    Mit , , , liefert die Winkel , also (abgelesen in , mit ) Die vier Einheitswurzeln sind also genau — alle Potenzen der einen Zahl . Diese Struktur (jede -te Einheitswurzel als Potenz einer einzigen erzeugenden Wurzel) ist genau das, was die schnelle Fourier-Transformation (FFT) algorithmisch ausnutzt, um die DFT nicht in , sondern in Rechenschritten auszuwerten.  Für die DFT brauchen wir . Da nur und von null verschieden sind, bleiben jeweils zwei Summanden: Die Messwerte sind eine Abtastung von , also einer Schwingung, die genau einmal in vier Messpunkten durchläuft. Die DFT zeigt genau das: ein Ausschlag bei (eine Periode pro Messfenster) und sein Spiegelbild bei , sonst nichts. So erkennt man in echten Zeitreihen — Stromverbrauch, Verkaufszahlen, Vibrationsdaten — versteckte Periodizitäten. Die Bibliotheksfunktion numpy.fft.fft([2, 0, -2, 0]) liefert übrigens genau diese vier Werte (als komplexe Gleitkommazahlen).      Quadratische Gleichungen in  Die Mitternachtsformel bzw. ihre normierte Form, die -Formel, kennen Sie seit der Schule. Ihre Herleitung benutzt nur quadratische Ergänzung, also Addieren, Multiplizieren und Umstellen — und das alles funktioniert in genauso wie in . Der einzige Schritt, an dem es im Reellen hakt, ist das Wurzelziehen aus der Diskriminante. Genau dieses Problem haben wir aber gerade gelöst: Jede komplexe Zahl hat nach genau zwei Quadratwurzeln, und die beiden unterscheiden sich nur um ein Vorzeichen. Das in der Formel sorgt dafür, dass beide verwendet werden.   -Formel in   Seien . Ist eine Lösung von , so hat die Gleichung die Lösungen Die Lösungen fallen genau dann zusammen, wenn ist.    Quadratische Ergänzung liefert (dritte binomische Formel). Ein Produkt ist genau dann null, wenn einer der Faktoren null ist.    Für reelle mit negativer Diskriminante ist das besonders bequem: Dann ist rein imaginär, denn .   Quadratische Gleichungen mit negativer Diskriminante   Lösen Sie und in .    Für ist und , also . Eine Lösung von ist , und die -Formel liefert Das sind genau die Lösungen, die wir in nur nachgeprüft hatten — jetzt haben wir sie wirklich gefunden. Ebenso ist für die zweite Gleichung , also In beiden Fällen sind die Lösungen zueinander konjugiert. Das liegt am vor der rein imaginären Wurzel — und hat, wie wir später in diesem Abschnitt sehen, einen tieferen Grund.    Sind die Koeffizienten selbst komplex, ist die Diskriminante meist weder positiv noch negativ, sondern irgendeine komplexe Zahl. Dann bestimmt man ihre Quadratwurzeln mit der Lösungsformel für — oder, wenn der Winkel unhandlich ist, durch einen Vergleich von Real- und Imaginärteil wie in .   Eine quadratische Gleichung mit komplexen Koeffizienten   Lösen Sie .    Hier ist und . Die Diskriminante ist Wir suchen eine Zahl mit . Weg 1, Exponentialform:  hat den Betrag , normiert ist es , nach also . Damit ist (wieder mit der Abbildung) eine Lösung. Weg 2, Koeffizientenvergleich: Mit ist . Vergleich mit liefert und . Wegen ist , und dann , also . Mit , erhalten wir dasselbe Ergebnis (die andere Wahl , liefert die zweite Wurzel ).  Damit ist Probe über die Linearfaktoren: . Die beiden Lösungen sind diesmal nicht konjugiert — kein Widerspruch, denn die Koeffizienten sind nicht reell.    Ein letzter Trick gehört noch in den Werkzeugkasten. Enthält eine Gleichung vierten Grades nur die Potenzen , und eine Konstante, so heißt sie biquadratisch . Mit der Substitution wird daraus eine quadratische Gleichung in , und jede ihrer Lösungen liefert über zwei Werte für .   Biquadratisch: vier Lösungen auf einen Streich (zur Vertiefung)   Bestimmen Sie alle Lösungen von in .    Mit lautet die Gleichung , also Aus folgt , aus folgt . Die vier Lösungen sind In hätte man nur die Hälfte gefunden; die Lösung der Hilfsgleichung wäre einfach verworfen worden.     Wenn schon die Hilfsgleichung komplex wird   Bestimmen Sie alle Lösungen von in algebraischer Form.    Mit : . Hier ist , also und . In Exponentialform: Es ist , normiert ; das sind in die Punkte bei den Winkeln , also .  Jetzt lösen wir zweimal eine reine Gleichung zweiten Grades. Aus folgt (mit dem Wert bei aus der Abbildung) und aus ebenso . Die vier Lösungen liegen auf dem Kreis mit Radius bei den Winkeln und — und bilden zwei konjugierte Paare, wie es sich für eine Gleichung mit reellen Koeffizienten gehört.      Fundamentalsatz der Algebra und Linearfaktorzerlegung  Blicken Sie kurz zurück auf den Aufbau der Zahlbereiche. Die Gleichung ist in nicht lösbar — also nimmt man die negativen Zahlen hinzu und kommt zu . Für braucht man Brüche, also ; für die irrationalen Zahlen, also ; für schließlich . Jedes Mal hat eine harmlose Gleichung einen neuen Zahlbereich erzwungen. Geht das ewig so weiter? Für haben wir schon gesehen, dass die Lösungen in liegen. Aber braucht man vielleicht für eine so unübersichtliche Gleichung wie wieder neue Zahlen?  Die überraschende Antwort lautet: nein. Mit ist das Spiel vorbei, zumindest für Polynomgleichungen. Das ist die Aussage eines der zentralen Sätze der Mathematik.   Fundamentalsatz der Algebra   Jedes nicht-konstante Polynom mit Koeffizienten , , , hat mindestens eine Nullstelle in .    Der Satz wurde 1799 von Carl Friedrich Gauß in seiner Dissertation bewiesen — drei Jahre nach dem Siebzehneck; der Beweis erfordert tiefere Methoden und wird hier nicht geführt. Bemerkenswert ist, dass der Satz nur die Existenz einer Nullstelle sichert, nicht aber, wie man sie findet. Für Grad gibt es die Mitternachtsformel, für Grad und gibt es ähnliche (sehr unhandliche) Formeln, aber für Polynome vom Grad gibt es, wie Niels Henrik Abel 1826 zeigte, keine allgemeine Lösungsformel mit Wurzelausdrücken mehr. In der Praxis rät man eine Nullstelle (oder sie ist gegeben), spaltet sie ab und arbeitet mit dem Restpolynom weiter — oder man überlässt die Arbeit einem numerischen Verfahren wie numpy.roots . Von Hand gehen wir so vor wie in den folgenden Beispielen.   Linearfaktorzerlegung   Ist eine Nullstelle von (Grad ), so lässt sich der Linearfaktor  abspalten: Es gibt ein Polynom vom Grad mit Wendet man dies wiederholt an (der Fundamentalsatz garantiert bei jedem Schritt eine neue Nullstelle, solange der Grad bleibt), erhält man die vollständige Linearfaktorisierung  eindeutig bis auf die Reihenfolge der Faktoren. Eine Nullstelle kann dabei mehrfach auftreten; wie oft, heißt ihre Vielfachheit . Ein Polynom vom Grad hat also, mit Vielfachheit gezählt, stets genau Nullstellen in .     Nullstellen richtig zählen   Wie viele Nullstellen hat in , wie viele in ? Geben Sie die Linearfaktorisierung an.    Die erste binomische Formel liefert . In ist , also hat dort überhaupt keine Nullstelle. In ist , also Es gibt zwei verschiedene Nullstellen, und , jede mit Vielfachheit . Mit Vielfachheit gezählt sind das Nullstellen — genau so viele, wie der Grad verspricht. Ohne die Vielfachheit ginge die schöne Bilanz Grad Anzahl der Nullstellen nicht auf.     Ein kubisches Polynom in Linearfaktoren zerlegen   Bestimmen Sie die Linearfaktorisierung von . Nutzen Sie, dass eine Nullstelle ist.    Probe: . Wir spalten ab: Mit dem Ansatz liefert Ausmultiplizieren und der Koeffizientenvergleich mit ergibt , , , also und : Die -Formel gibt die Nullstellen dieses Faktors: Es ist , also und Die vollständige Linearfaktorisierung ist also Statt mit Ansatz und Koeffizientenvergleich können Sie den Faktor natürlich auch per Polynomdivision bestimmen — beide Wege sind gleichwertig. (Die drei Koeffizientengleichungen für nur zwei Unbekannte sind übrigens eine eingebaute Probe: Wäre keine Nullstelle, würden sie sich widersprechen.)    Wieder sind die beiden nicht-reellen Nullstellen konjugiert, genau wie in und . Dreimal ist kein Zufall mehr: Bei Polynomen mit reellen Koeffizienten ist das immer so.   Faktorisierung reeller Polynome   Hat ein Polynom nur reelle Koeffizienten, so gilt: Ist eine Nullstelle, so ist auch eine Nullstelle (nicht-reelle Nullstellen treten also stets in konjugiert komplexen Paaren auf). Jedes reelle Polynom lässt sich daher faktorisieren in ein Produkt aus reellen Linearfaktoren und quadratischen Polynomen mit reellen Koeffizienten, die selbst keine reelle Nullstelle haben (sie stammen von je einem Paar konjugiert komplexer Nullstellen). Man spricht von der Zerlegung in irreduzible reelle Faktoren .    Sei mit und . Konjugation dieser Gleichung liefert, da die Konjugation mit Summen und Produkten verträglich ist und für reelle Koeffizienten gilt, also ist auch Nullstelle. Für nicht-reelles sind und verschieden, und der Faktor hat reelle Koeffizienten (nachrechnen mit : ), aber keine reelle Nullstelle.    Eine hübsche Folgerung zum Nachdenken: Ein reelles Polynom ungeraden Grades hat immer mindestens eine reelle Nullstelle. Denn die quadratischen Faktoren der reellen Zerlegung tragen zusammen nur einen geraden Grad bei — bei ungeradem Gesamtgrad muss also mindestens ein reeller Linearfaktor dabei sein, und der liefert eine reelle Nullstelle.   Zerlegung in irreduzible reelle Faktoren   Bestimmen Sie die Zerlegung von in irreduzible reelle Faktoren. Nutzen Sie, dass eine Nullstelle ist.    Probe: . Da reelle Koeffizienten hat, ist nach auch Nullstelle. Der zugehörige reelle Faktor ist . Division von durch ergibt den Linearfaktor (Ansatz , Koeffizientenvergleich liefert ). Da keine reelle Nullstelle hat, ist die Zerlegung in irreduzible reelle Faktoren bereits erreicht: Wer genau hinsieht, findet die Zerlegung auch ohne jede komplexe Zahl: . Solche Glücksfälle sind aber die Ausnahme — der Weg über das konjugierte Paar funktioniert immer.    Man kann den Spieß auch umdrehen: Statt ein Polynom zu zerlegen, baut man es aus vorgegebenen Nullstellen zusammen. Das ist nützlicher, als es klingt — in der Regelungstechnik etwa legt man die Nullstellen eines charakteristischen Polynoms fest, um ein gewünschtes Systemverhalten zu erzwingen, und rechnet daraus die Koeffizienten zurück.   Rückwärts: Ein reelles Polynom zu vorgegebenen Nullstellen   Gesucht ist ein Polynom mit reellen Koeffizienten und Leitkoeffizient , das die Nullstellen und hat. Welchen Grad muss mindestens haben? Bestimmen Sie für diesen kleinsten Grad.    Weil reelle Koeffizienten haben soll, muss mit auch Nullstelle sein ( ). Also hat mindestens drei Nullstellen und damit mindestens Grad . Das konjugierte Paar liefert den reellen Faktor und damit Probe: . Ein Polynom vom Grad mit den beiden Nullstellen und gibt es natürlich auch, nämlich — aber dessen Koeffizienten sind nicht reell.    Damit schließt sich der Kreis, der mit begonnen hat. Die imaginäre Einheit wurde eingeführt, um eine unlösbare Gleichung zu retten. Herausgekommen ist ein Zahlbereich, in dem jede Polynomgleichung vollständig lösbar ist — und in dem sogar die Frage, wie sich ein reelles Polynom reell zerlegen lässt, erst ihre einfache Antwort findet. Solche Zerlegungen in reelle Faktoren sind übrigens der Ausgangspunkt der Partialbruchzerlegung , die einen Bruch aus zwei Polynomen in eine Summe einfacherer Brüche zerlegt. Sie wird in diesem Buch nur an einzelnen Stellen verwendet (bei Reihen und Differenzialgleichungen), aber weder vorausgesetzt noch in der Vorlesung behandelt: Wo sie vorkommt, ist die Zerlegung angegeben und lässt sich durch Zusammenfassen auf den Hauptnenner nachprüfen. Und die Ausgabe von numpy.roots aus der Einleitung ist jetzt keine Überraschung mehr: hat die reelle Nullstelle und das konjugierte Paar , das den reellen Faktor liefert — drei Nullstellen für Grad , wie es der Fundamentalsatz verspricht.     Anwendungen: Wechselstromtechnik  In der Praxis stellt selten jemand die Aufgabe Lösen Sie . Häufiger ist eine technische Größe komplex — eine Impedanz, ein Phasor —, und gesucht ist ein ganz handfestes, reelles Ergebnis: eine Amplitude, ein Bauteilwert, eine Frequenz. Genau dort treffen die Rechentechniken aus auf die algebraischen Gleichungen dieses Abschnitts.  Die vier folgenden Beispiele stammen aus der Wechselstromtechnik, die Sie schon aus und kennen. Es geht um die Überlagerung zweier Spannungen, um einen Widerstandswert, der eine Betragsbedingung erfüllen soll, um einen Filter, der Messrauschen unterdrückt, und um die Resonanz eines Schwingkreises. Achten Sie darauf, wie jedes Mal eine komplexe Rechnung zu einem reellen Ergebnis führt — in den drei letzten Beispielen über eine reelle algebraische Gleichung.   Anwendungsbeispiel: Überlagerung zweier Wechselspannungen   Eine sinusförmige Wechselspannung wird durch ihren Phasor dargestellt ( ); Spannungen gleicher Frequenz überlagert man, indem man ihre Phasoren addiert ( ). Gegeben seien Bestimmen Sie die überlagerte Spannung in komplexer und in reeller Form.    Die erste Spannung ist als Sinus gegeben, die Phasor-Schreibweise verlangt aber einen Kosinus. Mit (der Sinus hinkt dem Kosinus um eine Viertelperiode hinterher) ist . Die Phasoren sind also, mit den Werten von und aus , Der Summenphasor ist Amplitude: eine bemerkenswert glatte exakte Form. Sie ist kein Zufall: Es ist , und die beiden Phasoren schließen den Winkel ein, sodass der Kosinussatz liefert. Der normierte Phasor ist keiner der Standardpunkte in , also brauchen wir den Arkustangens. Da , (4. Quadrant), ist keine Korrektur nötig: Kontrolle an der Abbildung: Der Imaginärteil ist kleiner als , also muss zwischen und liegen — passt. Damit ist die komplexe Spannung (der Unterstrich kennzeichnet in der Elektrotechnik komplexe Größen), und in reeller Form Zur Plausibilität: Die Amplitude liegt zwischen und Volt, wie es bei einer Überlagerung sein muss. Am oberen Rand läge sie nur, wenn beide Schwingungen im Gleichtakt wären.    Die Überlagerung war eine direkte Rechnung. In den nächsten beiden Beispielen ist die Richtung umgekehrt: Das Ergebnis ist vorgegeben, und ein Bauteilwert oder eine Frequenz ist gesucht. Dabei hilft eine Regel, die aus der Exponentialform sofort folgt ( ): Der Betrag eines Produkts ist das Produkt der Beträge, der Betrag eines Quotienten der Quotient der Beträge, Man muss einen komplizierten Bruch also gar nicht erst in algebraische Form bringen, wenn man nur seinen Betrag braucht.  Außerdem müssen wir wissen, wie sich die Impedanzen mehrerer Bauteile zu einer Gesamtimpedanz verbinden. Es gelten dieselben Regeln wie für ohmsche Widerstände, nur eben mit komplexen Zahlen, und beide folgen aus dem ohmschen Gesetz der Wechselstromrechnung ( ):  In einer Reihenschaltung fließt durch alle Bauteile derselbe Strom , und ihre Spannungen addieren sich. Also addieren sich die Impedanzen, — so wie in .  In einer Parallelschaltung liegt an allen Bauteilen dieselbe Spannung , und ihre Ströme addieren sich. Also addieren sich die Kehrwerte der Impedanzen, bei zwei Bauteilen ist .     Anwendungsbeispiel: Bauteilwert aus einer Impedanzbedingung   Ein Kondensator hat die rein imaginäre Impedanz ; die positive Größe heißt sein Blindwiderstand (allgemein nennt man den Imaginärteil einer Impedanz so; beim Kondensator gibt man meist den Betrag an). Blind heißt er, weil der Kondensator den Strom zwar hemmt, die Energie dabei aber nicht wie ein ohmscher Widerstand in Wärme umwandelt, sondern nur speichert und wieder abgibt.  Ein ohmscher Widerstand und ein Kondensator mit Blindwiderstand sind parallel geschaltet ( ). Für die Gesamtimpedanz einer Parallelschaltung aus und gilt Für welchen Wert von hat die Schaltung den Betrag ?   RC-Parallelschaltung: Der Strom der Quelle teilt sich auf den Widerstand und den Kondensator mit Blindwiderstand auf.    Schaltplan: Links eine Wechselspannungsquelle (Kreis mit Sinuswelle). Von ihr führen zwei Leitungen nach rechts, zwischen denen nebeneinander zwei Zweige liegen: ein Widerstand (Rechteck) und ein Kondensator (zwei parallele Platten) mit der Beschriftung . Beide Bauteile liegen also an derselben Spannung.        Mit der Quotientenregel für Beträge ist Setzen wir und ein, erhalten wir eine algebraische Gleichung für : Multiplizieren mit dem Nenner und Quadrieren (erlaubt, da beide Seiten für positiv sind) macht daraus eine quadratische Gleichung für (ohne linearen Term): Die positive Lösung ist Probe: . Auch wenn die Ausgangsgröße (die Impedanz ) komplex ist, führt eine Bedingung an ihren Betrag auf eine rein reelle algebraische Gleichung — genau die Art von Gleichung, die in diesem Abschnitt im Zentrum steht. Nebenbei: Die Parallelschaltung hat einen kleineren Betrag als jedes ihrer beiden Bauteile ( und ) — wie bei zwei parallelen ohmschen Widerständen, bei denen der Strom sich zwei Wege teilen kann. Für und parallel ist das stets so; für Spule und Kondensator parallel dagegen nicht, wie zeigen wird.     Anwendungsbeispiel: Die Grenzfrequenz eines Tiefpassfilters (zur Vertiefung)   Ein Messsignal — etwa die Spannung eines Temperatursensors — ist fast immer von hochfrequentem Rauschen überlagert. Ein einfacher Weg, es zu glätten, ist ein RC-Tiefpass : Die Eingangsspannung wird an eine Reihenschaltung aus Widerstand und Kondensator gelegt, abgegriffen wird die Ausgangsspannung am Kondensator ( ).   RC-Tiefpass: Die Eingangsspannung liegt an der Reihenschaltung aus und , die Ausgangsspannung wird am Kondensator abgegriffen.    Schaltplan mit zwei Eingangsklemmen links und zwei Ausgangsklemmen rechts. Von der oberen Eingangsklemme führt die Leitung über einen Widerstand (Rechteck) zur oberen Ausgangsklemme; die untere Leitung verbindet die beiden unteren Klemmen direkt. Zwischen oberer und unterer Leitung liegt hinter dem Widerstand ein Kondensator . Spannungspfeile kennzeichnen die Eingangsspannung zwischen den linken und die Ausgangsspannung zwischen den rechten Klemmen, also am Kondensator.      Für eine sinusförmige Eingangsspannung der Kreisfrequenz beschreibt man Ein- und Ausgangsspannung durch ihre Phasoren und ( ). Ihr Quotient heißt Übertragungsfunktion (auch Frequenzgang ) des Filters: Ihr Betrag gibt an, welcher Anteil der Amplitude einer Schwingung mit Kreisfrequenz durch den Filter kommt, ihr Argument, um welchen Winkel die Ausgangsspannung gegenüber der Eingangsspannung phasenverschoben ist. Weil durch und derselbe Strom fließt, ist und ( Spannungsteilerregel ), also   Es sei und , also .  Bei welcher Kreisfrequenz ist ? (Diese Frequenz heißt Grenzfrequenz des Filters.)  Ab welcher Kreisfrequenz kommen höchstens noch der Amplitude durch?  Welche Phasenverschiebung erfährt eine Schwingung mit der Grenzfrequenz?      Wieder hilft die Quotientenregel für Beträge:   genau dann, wenn , also (für ):  genau dann, wenn , also . Ab etwa , also knapp dem Zehnfachen der Grenzfrequenz, wird die Amplitude auf höchstens ein Zehntel gedrückt.  Bei ist mit ; normiert ist , nach also : Die Ausgangsspannung hinkt der Eingangsspannung um hinterher.    Langsame Änderungen des Messsignals (kleines , also ) passieren den Filter praktisch unverändert, schnelles Rauschen wird unterdrückt. Das ist das analoge Gegenstück zum exponentiell gewichteten gleitenden Durchschnitt (EMA), mit dem man in der Zeitreihenanalyse verrauschte Daten glättet. Und noch eine Beobachtung zum Schmunzeln: Die Werte , und sind genau die aus . Die dort untersuchte Schaltung lief also exakt bei ihrer Grenzfrequenz — und deshalb ergab sich in ein Phasenwinkel von genau .    Im letzten Beispiel rechnen wir mit Buchstaben statt Zahlen. Das ist in der Technik der Normalfall: Man möchte wissen, wie ein Ergebnis von den Bauteilwerten abhängt, nicht nur, was bei einer bestimmten Wahl herauskommt. Die Grenzfrequenz eben war schon ein Beispiel für so eine Formel.   Anwendungsbeispiel: Resonanzbedingung eines Parallelschwingkreises (zur Vertiefung)   Eine Spule der Induktivität und ein Kondensator der Kapazität werden parallel geschaltet ( ). Der komplexe Gesamtwiderstand ergibt sich aus    Parallelschwingkreis: Spule und Kondensator liegen parallel an der Wechselspannungsquelle .    Schaltplan: Links eine Wechselspannungsquelle (Kreis mit Sinuswelle). Von ihr führen zwei Leitungen nach rechts, zwischen denen nebeneinander zwei Zweige liegen: eine Spule (gefülltes Rechteck, Schaltzeichen nach DIN) und ein Kondensator (zwei parallele Platten). Beide Bauteile liegen also an derselben Spannung.      Beim Entwurf einer Schaltung gibt man häufig vor, welchen Blindwiderstand (den Imaginärteil von ) sie bei der Betriebsfrequenz haben soll, etwa um den Blindwiderstand eines anderen Bauteils auszugleichen, und sucht dann die passende Frequenz oder die passenden Bauteilwerte. Der Wert (in Ohm, wenn , und in SI-Einheiten gemessen werden) steht hier stellvertretend für einen solchen Sollwert; mit jedem anderen Wert verläuft die Rechnung genauso. Für welche Kreisfrequenz hat der Blindwiderstand den Wert  ?    Bilden wir den Kehrwert (Erweitern mit , um den Nenner reell zu machen), erhalten wir also . Die Bedingung liefert nach Multiplikation mit dem Nenner die quadratische Gleichung in  mit der (für relevanten) Lösung der Mitternachtsformel Für einen beliebigen Sollwert statt führt dieselbe Rechnung auf . Interessant ist auch der Nenner von : Für , also , wird unbeschränkt — das ist die Resonanzfrequenz des Schwingkreises, bei der er den Strom vollständig sperrt. Dieselbe Größe begegnet uns in als Eigenfrequenz des RLC-Schwingkreises wieder.    Alle vier Beispiele folgen demselben Muster: Mit komplexen Zahlen wird die Schaltung kompakt beschrieben, und mit Betrag, Real- oder Imaginärteil gewinnt man daraus reelle Größen — in den letzten drei Fällen über eine gewöhnliche, hier quadratische Gleichung. Komplexe Zahlen sind hier kein Selbstzweck, sondern der kürzeste Weg zu einem reellen Ergebnis. Ein Bonmot des französischen Mathematikers Paul Painlevé, bekannt geworden durch seinen Kollegen Jacques Hadamard, bringt es auf den Punkt: Der kürzeste Weg zwischen zwei Wahrheiten über reelle Zahlen führt oft durch die komplexen Zahlen.    Zusammenfassung     Reine Gleichung  : genau Lösungen die Ecken eines regelmäßigen -Ecks auf dem Kreis mit Radius .   -te Einheitswurzeln: die Lösungen von ; alle sind Potenzen von . Sie bilden die Grundlage der diskreten Fourier-Transformation (DFT).   Quadratische Gleichungen:  hat für alle die Lösungen , wobei eine Lösung von ist; bei reellen und negativer Diskriminante ist rein imaginär, z. B. hat die Lösungen . Biquadratische Gleichungen löst man mit der Substitution . Vorsicht: Das Wurzelzeichen nur für verwenden — nur dort ist es eindeutig, und nur dort gilt .   Fundamentalsatz der Algebra: Jedes Polynom vom Grad hat in mindestens eine, mit Vielfachheit gezählt genau Nullstellen, also die Linearfaktorisierung .   Reelle Koeffizienten: Nicht-reelle Nullstellen treten als konjugierte Paare auf; jedes Paar liefert den reellen quadratischen Faktor ohne reelle Nullstelle. Ein reelles Polynom ungeraden Grades hat daher stets eine reelle Nullstelle.   Praktisches Vorgehen: Nullstelle raten oder aus der Aufgabe entnehmen, Linearfaktor (bzw. reellen quadratischen Faktor) per Ansatz und Koeffizientenvergleich abspalten, Restpolynom mit der Mitternachtsformel behandeln.   Anwendung: In Reihe addieren sich Impedanzen, parallel ihre Kehrwerte. Bedingungen an Betrag oder Imaginärteil einer komplexen Impedanz führen auf reelle algebraische Gleichungen für Bauteilwerte oder Frequenzen; dabei hilft .      Übungsaufgaben    Bestimmen Sie alle Lösungen von .    Es ist , normiert , nach also und . Mit und liefert die Lösungsformel für reine Gleichungen die Winkel , , also , , und . Die letzten beiden liegen nicht in ; nach Abziehen von sind es und . Mit den Werten aus der Abbildung:       Lösen Sie die Gleichung in , und machen Sie die Probe für eine der beiden Lösungen.    Mit und ist . Die Zahl hat den Betrag , normiert ist sie , nach also . Damit ist (Wert bei aus derselben Abbildung) eine Lösung von (Kontrolle: ). Die -Formel liefert Probe für : . Die beiden Lösungen sind nicht konjugiert zueinander — die Koeffizienten sind ja auch nicht reell.      Bestimmen Sie die Linearfaktorisierung von . Nutzen Sie, dass eine Nullstelle ist.    Probe: . Ansatz ; Ausmultiplizieren und Koeffizientenvergleich liefert Die Mitternachtsformel (bzw. direktes Wurzelziehen) gibt . Die vollständige Linearfaktorisierung ist also       Bestimmen Sie die Zerlegung von in irreduzible reelle Faktoren. Nutzen Sie, dass eine Nullstelle ist.    Probe: . Da reelle Koeffizienten hat, ist auch Nullstelle, und der zugehörige reelle Faktor ist . Division von durch (Ansatz , Koeffizientenvergleich liefert ) ergibt Da keine reelle Nullstelle hat, ist dies bereits die Zerlegung in irreduzible reelle Faktoren.      Bestimmen Sie alle sechsten Einheitswurzeln (die Lösungen von ), und zeigen Sie, dass ihre Summe gleich ist.    Mit , , , sind die Lösungen , . Die Winkel und entsprechen nach Abziehen von den Winkeln und ; in liest man ab: Summiert man Realteile und Imaginärteile getrennt, heben sich beide jeweils paarweise auf:      "
},
{
  "id": "sec-algebraische-gleichungen-anwendungen-2",
  "level": "2",
  "url": "sec-algebraische-gleichungen-anwendungen.html#sec-algebraische-gleichungen-anwendungen-2",
  "type": "Lernziele",
  "number": "1.2",
  "title": "",
  "body": "  Nach diesem Abschnitt können Sie    alle Lösungen einer reinen Gleichung bestimmen und als regelmäßiges -Eck in der Zahlenebene deuten;  die -ten Einheitswurzeln angeben und ihre Rolle in der diskreten Fourier-Transformation erklären;  quadratische Gleichungen in lösen — mit negativer Diskriminante, mit komplexen Koeffizienten und, per Substitution, auch biquadratische Gleichungen;  den Fundamentalsatz der Algebra wiedergeben und ein Polynom bei bekannter Nullstelle in Linearfaktoren zerlegen;  reelle Polynome in irreduzible reelle Faktoren zerlegen, indem Sie konjugiert komplexe Nullstellenpaare zusammenfassen;  eine technische Bedingung an eine Impedanz oder einen Filter in eine reelle algebraische Gleichung übersetzen und lösen.   "
},
{
  "id": "def-reine-gleichung-nten-grades",
  "level": "2",
  "url": "sec-algebraische-gleichungen-anwendungen.html#def-reine-gleichung-nten-grades",
  "type": "Definition",
  "number": "1.2.1",
  "title": "Reine Gleichung <span class=\"process-math\">\\(n\\)<\/span>-ten Grades, Wurzeln.",
  "body": " Reine Gleichung -ten Grades, Wurzeln   Für und heißt die reine Gleichung -ten Grades . Ihre Lösungen heißen auch Wurzeln von .   "
},
{
  "id": "thm-loesungen-reine-gleichung",
  "level": "2",
  "url": "sec-algebraische-gleichungen-anwendungen.html#thm-loesungen-reine-gleichung",
  "type": "Satz",
  "number": "1.2.2",
  "title": "Lösungsformel für reine Gleichungen.",
  "body": " Lösungsformel für reine Gleichungen   Sei . Die Gleichung hat genau verschiedene Lösungen in , nämlich In der Gaußschen Zahlenebene liegen diese Zahlen auf einem Kreis vom Radius um den Ursprung und bilden dort ein regelmäßiges -Eck. Man nennt deshalb auch eine Kreisteilungsgleichung .    Ansatz mit . Dann ist , und bedeutet: Beträge und Winkel beider Seiten stimmen überein, wobei Winkel nur bis auf Vielfache von bestimmt sind. Also , d. h. , und für ein , d. h. . Für ergeben diese Winkel verschiedene Zahlen, denn zwei von ihnen unterscheiden sich um mit , und das ist kein Vielfaches von ; liefert wieder den Winkel von (plus ), also nichts Neues.   "
},
{
  "id": "ex-reine-gleichung-fuenften-grades",
  "level": "2",
  "url": "sec-algebraische-gleichungen-anwendungen.html#ex-reine-gleichung-fuenften-grades",
  "type": "Beispiel",
  "number": "1.2.3",
  "title": "Fünf Lösungen, ein Fünfeck.",
  "body": " Fünf Lösungen, ein Fünfeck   Bestimmen Sie alle Lösungen von .     Schritt 1:  , normiert ; nach ist also und .   Schritt 2:  und , also .   Schritt 3: Weiterdrehen um jeweils : mit den Winkeln . Die Lösung zu ist — die einzige reelle Lösung, die man auch ohne komplexe Zahlen gefunden hätte. Die fünf Lösungen bilden ein regelmäßiges Fünfeck ( ).   "
},
{
  "id": "fig-nte-wurzeln-fuenfeck",
  "level": "2",
  "url": "sec-algebraische-gleichungen-anwendungen.html#fig-nte-wurzeln-fuenfeck",
  "type": "Abbildung",
  "number": "1.2.4",
  "title": "",
  "body": " Die fünf Lösungen von bilden ein regelmäßiges Fünfeck auf dem Kreis mit Radius um den Ursprung.    Ein Koordinatensystem mit reeller und imaginärer Achse und einem Kreis vom Radius 2 um den Ursprung. Auf diesem Kreis sind fünf gleichmäßig verteilte Punkte markiert (im Winkelabstand von , bei den Winkeln ), die ein regelmäßiges Fünfeck bilden; einer der Punkte liegt auf der negativen reellen Achse.     "
},
{
  "id": "ex-kubikwurzeln-einheit",
  "level": "2",
  "url": "sec-algebraische-gleichungen-anwendungen.html#ex-kubikwurzeln-einheit",
  "type": "Beispiel",
  "number": "1.2.5",
  "title": "Die dritten Einheitswurzeln.",
  "body": " Die dritten Einheitswurzeln   Bestimmen Sie alle Lösungen von .    Mit ist , . Nach mit : also , und (wir haben abgezogen, um in zu landen). In algebraischer Form, abgelesen in : Man nennt die dritten Einheitswurzeln ; allgemein heißen die Lösungen von die -ten Einheitswurzeln . Sie bilden ein gleichseitiges Dreieck auf dem Einheitskreis, mit einer Ecke bei . Probe für : Nach dem Potenzgesetz ist . Wer der Exponentialform noch nicht traut, kann auch in algebraischer Form nachrechnen: und , denn ist die Konjugierte von .   "
},
{
  "id": "ex-quadratwurzeln-aus-i",
  "level": "2",
  "url": "sec-algebraische-gleichungen-anwendungen.html#ex-quadratwurzeln-aus-i",
  "type": "Beispiel",
  "number": "1.2.6",
  "title": "Wurzeln aus einer nicht-reellen Zahl.",
  "body": " Wurzeln aus einer nicht-reellen Zahl   Bestimmen Sie alle Lösungen von in algebraischer Form, und machen Sie die Probe.     hat den Betrag und liegt nach beim Winkel , also . Die erste Lösung hat den Winkel , die zweite ist um weitergedreht, auf bzw. (nach Abziehen von ) . Abgelesen in der Abbildung: Probe: . Wie im Reellen unterscheiden sich die beiden Quadratwurzeln nur im Vorzeichen — sie liegen einander gegenüber auf dem Kreis.   "
},
{
  "id": "ex-anwendung-einheitswurzeln-dft",
  "level": "2",
  "url": "sec-algebraische-gleichungen-anwendungen.html#ex-anwendung-einheitswurzeln-dft",
  "type": "Beispiel",
  "number": "1.2.7",
  "title": "Anwendungsbeispiel: <span class=\"process-math\">\\(n\\)<\/span>-te Einheitswurzeln und die diskrete Fourier-Transformation.",
  "body": " Anwendungsbeispiel: -te Einheitswurzeln und die diskrete Fourier-Transformation   Die -ten Einheitswurzeln aus sind mehr als eine hübsche geometrische Figur: Sie bilden die Grundlage der diskreten Fourier-Transformation (DFT) , eines der wichtigsten Werkzeuge der digitalen Signalverarbeitung und damit auch der Data Science (Spektralanalyse von Zeitreihen, Bild- und Audiokompression, schnelle Faltung in neuronalen Netzen). Die DFT zerlegt ein abgetastetes Signal, also in gleichen Zeitabständen gemessene Werte, in Beiträge unterschiedlicher Frequenz: Der Betrag gibt an, wie stark eine Schwingung mit genau Perioden pro Messfenster in den Daten steckt. Für eine Folge von Messwerten definiert man die DFT als wobei genau die -te Einheitswurzel mit dem kleinsten positiven Winkel ist — jede andere -te Einheitswurzel ist eine Potenz von ihr.  Bestimmen Sie für alle vierten Einheitswurzeln und geben Sie sie als Potenzen von an. Berechnen Sie dann die DFT der vier Messwerte .    Mit , , , liefert die Winkel , also (abgelesen in , mit ) Die vier Einheitswurzeln sind also genau — alle Potenzen der einen Zahl . Diese Struktur (jede -te Einheitswurzel als Potenz einer einzigen erzeugenden Wurzel) ist genau das, was die schnelle Fourier-Transformation (FFT) algorithmisch ausnutzt, um die DFT nicht in , sondern in Rechenschritten auszuwerten.  Für die DFT brauchen wir . Da nur und von null verschieden sind, bleiben jeweils zwei Summanden: Die Messwerte sind eine Abtastung von , also einer Schwingung, die genau einmal in vier Messpunkten durchläuft. Die DFT zeigt genau das: ein Ausschlag bei (eine Periode pro Messfenster) und sein Spiegelbild bei , sonst nichts. So erkennt man in echten Zeitreihen — Stromverbrauch, Verkaufszahlen, Vibrationsdaten — versteckte Periodizitäten. Die Bibliotheksfunktion numpy.fft.fft([2, 0, -2, 0]) liefert übrigens genau diese vier Werte (als komplexe Gleitkommazahlen).   "
},
{
  "id": "thm-pq-formel-komplex",
  "level": "2",
  "url": "sec-algebraische-gleichungen-anwendungen.html#thm-pq-formel-komplex",
  "type": "Satz",
  "number": "1.2.8",
  "title": "<span class=\"process-math\">\\(pq\\)<\/span>-Formel in <span class=\"process-math\">\\(\\C\\)<\/span>.",
  "body": " -Formel in   Seien . Ist eine Lösung von , so hat die Gleichung die Lösungen Die Lösungen fallen genau dann zusammen, wenn ist.    Quadratische Ergänzung liefert (dritte binomische Formel). Ein Produkt ist genau dann null, wenn einer der Faktoren null ist.   "
},
{
  "id": "ex-quadratische-gleichung-komplex",
  "level": "2",
  "url": "sec-algebraische-gleichungen-anwendungen.html#ex-quadratische-gleichung-komplex",
  "type": "Beispiel",
  "number": "1.2.9",
  "title": "Quadratische Gleichungen mit negativer Diskriminante.",
  "body": " Quadratische Gleichungen mit negativer Diskriminante   Lösen Sie und in .    Für ist und , also . Eine Lösung von ist , und die -Formel liefert Das sind genau die Lösungen, die wir in nur nachgeprüft hatten — jetzt haben wir sie wirklich gefunden. Ebenso ist für die zweite Gleichung , also In beiden Fällen sind die Lösungen zueinander konjugiert. Das liegt am vor der rein imaginären Wurzel — und hat, wie wir später in diesem Abschnitt sehen, einen tieferen Grund.   "
},
{
  "id": "ex-quadratische-gleichung-komplexe-koeffizienten",
  "level": "2",
  "url": "sec-algebraische-gleichungen-anwendungen.html#ex-quadratische-gleichung-komplexe-koeffizienten",
  "type": "Beispiel",
  "number": "1.2.10",
  "title": "Eine quadratische Gleichung mit komplexen Koeffizienten.",
  "body": " Eine quadratische Gleichung mit komplexen Koeffizienten   Lösen Sie .    Hier ist und . Die Diskriminante ist Wir suchen eine Zahl mit . Weg 1, Exponentialform:  hat den Betrag , normiert ist es , nach also . Damit ist (wieder mit der Abbildung) eine Lösung. Weg 2, Koeffizientenvergleich: Mit ist . Vergleich mit liefert und . Wegen ist , und dann , also . Mit , erhalten wir dasselbe Ergebnis (die andere Wahl , liefert die zweite Wurzel ).  Damit ist Probe über die Linearfaktoren: . Die beiden Lösungen sind diesmal nicht konjugiert — kein Widerspruch, denn die Koeffizienten sind nicht reell.   "
},
{
  "id": "ssub-quadratische-gleichungen-komplex-8",
  "level": "2",
  "url": "sec-algebraische-gleichungen-anwendungen.html#ssub-quadratische-gleichungen-komplex-8",
  "type": "Absatz (with a defined term)",
  "number": "",
  "title": "",
  "body": "biquadratisch "
},
{
  "id": "ex-biquadratische-gleichung",
  "level": "2",
  "url": "sec-algebraische-gleichungen-anwendungen.html#ex-biquadratische-gleichung",
  "type": "Beispiel",
  "number": "1.2.11",
  "title": "Biquadratisch: vier Lösungen auf einen Streich (zur Vertiefung).",
  "body": " Biquadratisch: vier Lösungen auf einen Streich (zur Vertiefung)   Bestimmen Sie alle Lösungen von in .    Mit lautet die Gleichung , also Aus folgt , aus folgt . Die vier Lösungen sind In hätte man nur die Hälfte gefunden; die Lösung der Hilfsgleichung wäre einfach verworfen worden.   "
},
{
  "id": "ex-biquadratisch-komplexe-substitution",
  "level": "2",
  "url": "sec-algebraische-gleichungen-anwendungen.html#ex-biquadratisch-komplexe-substitution",
  "type": "Beispiel",
  "number": "1.2.12",
  "title": "Wenn schon die Hilfsgleichung komplex wird.",
  "body": " Wenn schon die Hilfsgleichung komplex wird   Bestimmen Sie alle Lösungen von in algebraischer Form.    Mit : . Hier ist , also und . In Exponentialform: Es ist , normiert ; das sind in die Punkte bei den Winkeln , also .  Jetzt lösen wir zweimal eine reine Gleichung zweiten Grades. Aus folgt (mit dem Wert bei aus der Abbildung) und aus ebenso . Die vier Lösungen liegen auf dem Kreis mit Radius bei den Winkeln und — und bilden zwei konjugierte Paare, wie es sich für eine Gleichung mit reellen Koeffizienten gehört.   "
},
{
  "id": "thm-fundamentalsatz-algebra",
  "level": "2",
  "url": "sec-algebraische-gleichungen-anwendungen.html#thm-fundamentalsatz-algebra",
  "type": "Satz",
  "number": "1.2.13",
  "title": "Fundamentalsatz der Algebra.",
  "body": " Fundamentalsatz der Algebra   Jedes nicht-konstante Polynom mit Koeffizienten , , , hat mindestens eine Nullstelle in .   "
},
{
  "id": "thm-linearfaktorisierung",
  "level": "2",
  "url": "sec-algebraische-gleichungen-anwendungen.html#thm-linearfaktorisierung",
  "type": "Satz",
  "number": "1.2.14",
  "title": "Linearfaktorzerlegung.",
  "body": " Linearfaktorzerlegung   Ist eine Nullstelle von (Grad ), so lässt sich der Linearfaktor  abspalten: Es gibt ein Polynom vom Grad mit Wendet man dies wiederholt an (der Fundamentalsatz garantiert bei jedem Schritt eine neue Nullstelle, solange der Grad bleibt), erhält man die vollständige Linearfaktorisierung  eindeutig bis auf die Reihenfolge der Faktoren. Eine Nullstelle kann dabei mehrfach auftreten; wie oft, heißt ihre Vielfachheit . Ein Polynom vom Grad hat also, mit Vielfachheit gezählt, stets genau Nullstellen in .   "
},
{
  "id": "ex-nullstellen-vielfachheit",
  "level": "2",
  "url": "sec-algebraische-gleichungen-anwendungen.html#ex-nullstellen-vielfachheit",
  "type": "Beispiel",
  "number": "1.2.15",
  "title": "Nullstellen richtig zählen.",
  "body": " Nullstellen richtig zählen   Wie viele Nullstellen hat in , wie viele in ? Geben Sie die Linearfaktorisierung an.    Die erste binomische Formel liefert . In ist , also hat dort überhaupt keine Nullstelle. In ist , also Es gibt zwei verschiedene Nullstellen, und , jede mit Vielfachheit . Mit Vielfachheit gezählt sind das Nullstellen — genau so viele, wie der Grad verspricht. Ohne die Vielfachheit ginge die schöne Bilanz Grad Anzahl der Nullstellen nicht auf.   "
},
{
  "id": "ex-linearfaktorisierung-kubisch",
  "level": "2",
  "url": "sec-algebraische-gleichungen-anwendungen.html#ex-linearfaktorisierung-kubisch",
  "type": "Beispiel",
  "number": "1.2.16",
  "title": "Ein kubisches Polynom in Linearfaktoren zerlegen.",
  "body": " Ein kubisches Polynom in Linearfaktoren zerlegen   Bestimmen Sie die Linearfaktorisierung von . Nutzen Sie, dass eine Nullstelle ist.    Probe: . Wir spalten ab: Mit dem Ansatz liefert Ausmultiplizieren und der Koeffizientenvergleich mit ergibt , , , also und : Die -Formel gibt die Nullstellen dieses Faktors: Es ist , also und Die vollständige Linearfaktorisierung ist also Statt mit Ansatz und Koeffizientenvergleich können Sie den Faktor natürlich auch per Polynomdivision bestimmen — beide Wege sind gleichwertig. (Die drei Koeffizientengleichungen für nur zwei Unbekannte sind übrigens eine eingebaute Probe: Wäre keine Nullstelle, würden sie sich widersprechen.)   "
},
{
  "id": "thm-reelle-faktorisierung",
  "level": "2",
  "url": "sec-algebraische-gleichungen-anwendungen.html#thm-reelle-faktorisierung",
  "type": "Satz",
  "number": "1.2.17",
  "title": "Faktorisierung reeller Polynome.",
  "body": " Faktorisierung reeller Polynome   Hat ein Polynom nur reelle Koeffizienten, so gilt: Ist eine Nullstelle, so ist auch eine Nullstelle (nicht-reelle Nullstellen treten also stets in konjugiert komplexen Paaren auf). Jedes reelle Polynom lässt sich daher faktorisieren in ein Produkt aus reellen Linearfaktoren und quadratischen Polynomen mit reellen Koeffizienten, die selbst keine reelle Nullstelle haben (sie stammen von je einem Paar konjugiert komplexer Nullstellen). Man spricht von der Zerlegung in irreduzible reelle Faktoren .    Sei mit und . Konjugation dieser Gleichung liefert, da die Konjugation mit Summen und Produkten verträglich ist und für reelle Koeffizienten gilt, also ist auch Nullstelle. Für nicht-reelles sind und verschieden, und der Faktor hat reelle Koeffizienten (nachrechnen mit : ), aber keine reelle Nullstelle.   "
},
{
  "id": "ex-reelle-faktorisierung-kubisch",
  "level": "2",
  "url": "sec-algebraische-gleichungen-anwendungen.html#ex-reelle-faktorisierung-kubisch",
  "type": "Beispiel",
  "number": "1.2.18",
  "title": "Zerlegung in irreduzible reelle Faktoren.",
  "body": " Zerlegung in irreduzible reelle Faktoren   Bestimmen Sie die Zerlegung von in irreduzible reelle Faktoren. Nutzen Sie, dass eine Nullstelle ist.    Probe: . Da reelle Koeffizienten hat, ist nach auch Nullstelle. Der zugehörige reelle Faktor ist . Division von durch ergibt den Linearfaktor (Ansatz , Koeffizientenvergleich liefert ). Da keine reelle Nullstelle hat, ist die Zerlegung in irreduzible reelle Faktoren bereits erreicht: Wer genau hinsieht, findet die Zerlegung auch ohne jede komplexe Zahl: . Solche Glücksfälle sind aber die Ausnahme — der Weg über das konjugierte Paar funktioniert immer.   "
},
{
  "id": "ex-polynom-aus-nullstellen",
  "level": "2",
  "url": "sec-algebraische-gleichungen-anwendungen.html#ex-polynom-aus-nullstellen",
  "type": "Beispiel",
  "number": "1.2.19",
  "title": "Rückwärts: Ein reelles Polynom zu vorgegebenen Nullstellen.",
  "body": " Rückwärts: Ein reelles Polynom zu vorgegebenen Nullstellen   Gesucht ist ein Polynom mit reellen Koeffizienten und Leitkoeffizient , das die Nullstellen und hat. Welchen Grad muss mindestens haben? Bestimmen Sie für diesen kleinsten Grad.    Weil reelle Koeffizienten haben soll, muss mit auch Nullstelle sein ( ). Also hat mindestens drei Nullstellen und damit mindestens Grad . Das konjugierte Paar liefert den reellen Faktor und damit Probe: . Ein Polynom vom Grad mit den beiden Nullstellen und gibt es natürlich auch, nämlich — aber dessen Koeffizienten sind nicht reell.   "
},
{
  "id": "ssub-fundamentalsatz-linearfaktorisierung-15",
  "level": "2",
  "url": "sec-algebraische-gleichungen-anwendungen.html#ssub-fundamentalsatz-linearfaktorisierung-15",
  "type": "Absatz (with a defined term)",
  "number": "",
  "title": "",
  "body": "Partialbruchzerlegung "
},
{
  "id": "ex-anwendung-ueberlagerung-zwei-spannungen",
  "level": "2",
  "url": "sec-algebraische-gleichungen-anwendungen.html#ex-anwendung-ueberlagerung-zwei-spannungen",
  "type": "Beispiel",
  "number": "1.2.20",
  "title": "Anwendungsbeispiel: Überlagerung zweier Wechselspannungen.",
  "body": " Anwendungsbeispiel: Überlagerung zweier Wechselspannungen   Eine sinusförmige Wechselspannung wird durch ihren Phasor dargestellt ( ); Spannungen gleicher Frequenz überlagert man, indem man ihre Phasoren addiert ( ). Gegeben seien Bestimmen Sie die überlagerte Spannung in komplexer und in reeller Form.    Die erste Spannung ist als Sinus gegeben, die Phasor-Schreibweise verlangt aber einen Kosinus. Mit (der Sinus hinkt dem Kosinus um eine Viertelperiode hinterher) ist . Die Phasoren sind also, mit den Werten von und aus , Der Summenphasor ist Amplitude: eine bemerkenswert glatte exakte Form. Sie ist kein Zufall: Es ist , und die beiden Phasoren schließen den Winkel ein, sodass der Kosinussatz liefert. Der normierte Phasor ist keiner der Standardpunkte in , also brauchen wir den Arkustangens. Da , (4. Quadrant), ist keine Korrektur nötig: Kontrolle an der Abbildung: Der Imaginärteil ist kleiner als , also muss zwischen und liegen — passt. Damit ist die komplexe Spannung (der Unterstrich kennzeichnet in der Elektrotechnik komplexe Größen), und in reeller Form Zur Plausibilität: Die Amplitude liegt zwischen und Volt, wie es bei einer Überlagerung sein muss. Am oberen Rand läge sie nur, wenn beide Schwingungen im Gleichtakt wären.   "
},
{
  "id": "sub-anwendungen-komplexer-zahlen-6",
  "level": "2",
  "url": "sec-algebraische-gleichungen-anwendungen.html#sub-anwendungen-komplexer-zahlen-6",
  "type": "Absatz (with a defined term)",
  "number": "",
  "title": "",
  "body": "Reihenschaltung Parallelschaltung "
},
{
  "id": "ex-anwendung-bauteilwert-aus-impedanz",
  "level": "2",
  "url": "sec-algebraische-gleichungen-anwendungen.html#ex-anwendung-bauteilwert-aus-impedanz",
  "type": "Beispiel",
  "number": "1.2.21",
  "title": "Anwendungsbeispiel: Bauteilwert aus einer Impedanzbedingung.",
  "body": " Anwendungsbeispiel: Bauteilwert aus einer Impedanzbedingung   Ein Kondensator hat die rein imaginäre Impedanz ; die positive Größe heißt sein Blindwiderstand (allgemein nennt man den Imaginärteil einer Impedanz so; beim Kondensator gibt man meist den Betrag an). Blind heißt er, weil der Kondensator den Strom zwar hemmt, die Energie dabei aber nicht wie ein ohmscher Widerstand in Wärme umwandelt, sondern nur speichert und wieder abgibt.  Ein ohmscher Widerstand und ein Kondensator mit Blindwiderstand sind parallel geschaltet ( ). Für die Gesamtimpedanz einer Parallelschaltung aus und gilt Für welchen Wert von hat die Schaltung den Betrag ?   RC-Parallelschaltung: Der Strom der Quelle teilt sich auf den Widerstand und den Kondensator mit Blindwiderstand auf.    Schaltplan: Links eine Wechselspannungsquelle (Kreis mit Sinuswelle). Von ihr führen zwei Leitungen nach rechts, zwischen denen nebeneinander zwei Zweige liegen: ein Widerstand (Rechteck) und ein Kondensator (zwei parallele Platten) mit der Beschriftung . Beide Bauteile liegen also an derselben Spannung.        Mit der Quotientenregel für Beträge ist Setzen wir und ein, erhalten wir eine algebraische Gleichung für : Multiplizieren mit dem Nenner und Quadrieren (erlaubt, da beide Seiten für positiv sind) macht daraus eine quadratische Gleichung für (ohne linearen Term): Die positive Lösung ist Probe: . Auch wenn die Ausgangsgröße (die Impedanz ) komplex ist, führt eine Bedingung an ihren Betrag auf eine rein reelle algebraische Gleichung — genau die Art von Gleichung, die in diesem Abschnitt im Zentrum steht. Nebenbei: Die Parallelschaltung hat einen kleineren Betrag als jedes ihrer beiden Bauteile ( und ) — wie bei zwei parallelen ohmschen Widerständen, bei denen der Strom sich zwei Wege teilen kann. Für und parallel ist das stets so; für Spule und Kondensator parallel dagegen nicht, wie zeigen wird.   "
},
{
  "id": "ex-anwendung-tiefpass-grenzfrequenz",
  "level": "2",
  "url": "sec-algebraische-gleichungen-anwendungen.html#ex-anwendung-tiefpass-grenzfrequenz",
  "type": "Beispiel",
  "number": "1.2.23",
  "title": "Anwendungsbeispiel: Die Grenzfrequenz eines Tiefpassfilters (zur Vertiefung).",
  "body": " Anwendungsbeispiel: Die Grenzfrequenz eines Tiefpassfilters (zur Vertiefung)   Ein Messsignal — etwa die Spannung eines Temperatursensors — ist fast immer von hochfrequentem Rauschen überlagert. Ein einfacher Weg, es zu glätten, ist ein RC-Tiefpass : Die Eingangsspannung wird an eine Reihenschaltung aus Widerstand und Kondensator gelegt, abgegriffen wird die Ausgangsspannung am Kondensator ( ).   RC-Tiefpass: Die Eingangsspannung liegt an der Reihenschaltung aus und , die Ausgangsspannung wird am Kondensator abgegriffen.    Schaltplan mit zwei Eingangsklemmen links und zwei Ausgangsklemmen rechts. Von der oberen Eingangsklemme führt die Leitung über einen Widerstand (Rechteck) zur oberen Ausgangsklemme; die untere Leitung verbindet die beiden unteren Klemmen direkt. Zwischen oberer und unterer Leitung liegt hinter dem Widerstand ein Kondensator . Spannungspfeile kennzeichnen die Eingangsspannung zwischen den linken und die Ausgangsspannung zwischen den rechten Klemmen, also am Kondensator.      Für eine sinusförmige Eingangsspannung der Kreisfrequenz beschreibt man Ein- und Ausgangsspannung durch ihre Phasoren und ( ). Ihr Quotient heißt Übertragungsfunktion (auch Frequenzgang ) des Filters: Ihr Betrag gibt an, welcher Anteil der Amplitude einer Schwingung mit Kreisfrequenz durch den Filter kommt, ihr Argument, um welchen Winkel die Ausgangsspannung gegenüber der Eingangsspannung phasenverschoben ist. Weil durch und derselbe Strom fließt, ist und ( Spannungsteilerregel ), also   Es sei und , also .  Bei welcher Kreisfrequenz ist ? (Diese Frequenz heißt Grenzfrequenz des Filters.)  Ab welcher Kreisfrequenz kommen höchstens noch der Amplitude durch?  Welche Phasenverschiebung erfährt eine Schwingung mit der Grenzfrequenz?      Wieder hilft die Quotientenregel für Beträge:   genau dann, wenn , also (für ):  genau dann, wenn , also . Ab etwa , also knapp dem Zehnfachen der Grenzfrequenz, wird die Amplitude auf höchstens ein Zehntel gedrückt.  Bei ist mit ; normiert ist , nach also : Die Ausgangsspannung hinkt der Eingangsspannung um hinterher.    Langsame Änderungen des Messsignals (kleines , also ) passieren den Filter praktisch unverändert, schnelles Rauschen wird unterdrückt. Das ist das analoge Gegenstück zum exponentiell gewichteten gleitenden Durchschnitt (EMA), mit dem man in der Zeitreihenanalyse verrauschte Daten glättet. Und noch eine Beobachtung zum Schmunzeln: Die Werte , und sind genau die aus . Die dort untersuchte Schaltung lief also exakt bei ihrer Grenzfrequenz — und deshalb ergab sich in ein Phasenwinkel von genau .   "
},
{
  "id": "ex-anwendung-schwingkreis-symbolisch",
  "level": "2",
  "url": "sec-algebraische-gleichungen-anwendungen.html#ex-anwendung-schwingkreis-symbolisch",
  "type": "Beispiel",
  "number": "1.2.25",
  "title": "Anwendungsbeispiel: Resonanzbedingung eines Parallelschwingkreises (zur Vertiefung).",
  "body": " Anwendungsbeispiel: Resonanzbedingung eines Parallelschwingkreises (zur Vertiefung)   Eine Spule der Induktivität und ein Kondensator der Kapazität werden parallel geschaltet ( ). Der komplexe Gesamtwiderstand ergibt sich aus    Parallelschwingkreis: Spule und Kondensator liegen parallel an der Wechselspannungsquelle .    Schaltplan: Links eine Wechselspannungsquelle (Kreis mit Sinuswelle). Von ihr führen zwei Leitungen nach rechts, zwischen denen nebeneinander zwei Zweige liegen: eine Spule (gefülltes Rechteck, Schaltzeichen nach DIN) und ein Kondensator (zwei parallele Platten). Beide Bauteile liegen also an derselben Spannung.      Beim Entwurf einer Schaltung gibt man häufig vor, welchen Blindwiderstand (den Imaginärteil von ) sie bei der Betriebsfrequenz haben soll, etwa um den Blindwiderstand eines anderen Bauteils auszugleichen, und sucht dann die passende Frequenz oder die passenden Bauteilwerte. Der Wert (in Ohm, wenn , und in SI-Einheiten gemessen werden) steht hier stellvertretend für einen solchen Sollwert; mit jedem anderen Wert verläuft die Rechnung genauso. Für welche Kreisfrequenz hat der Blindwiderstand den Wert  ?    Bilden wir den Kehrwert (Erweitern mit , um den Nenner reell zu machen), erhalten wir also . Die Bedingung liefert nach Multiplikation mit dem Nenner die quadratische Gleichung in  mit der (für relevanten) Lösung der Mitternachtsformel Für einen beliebigen Sollwert statt führt dieselbe Rechnung auf . Interessant ist auch der Nenner von : Für , also , wird unbeschränkt — das ist die Resonanzfrequenz des Schwingkreises, bei der er den Strom vollständig sperrt. Dieselbe Größe begegnet uns in als Eigenfrequenz des RLC-Schwingkreises wieder.   "
},
{
  "id": "sub-zusammenfassung-1-2-2",
  "level": "2",
  "url": "sec-algebraische-gleichungen-anwendungen.html#sub-zusammenfassung-1-2-2",
  "type": "Absatz (with a defined term)",
  "number": "",
  "title": "",
  "body": "Reine Gleichung -te Einheitswurzeln: Quadratische Gleichungen: Fundamentalsatz der Algebra: Reelle Koeffizienten: Praktisches Vorgehen: Anwendung: "
},
{
  "id": "exercise-buch-reine-gleichung-vierten-grades",
  "level": "2",
  "url": "sec-algebraische-gleichungen-anwendungen.html#exercise-buch-reine-gleichung-vierten-grades",
  "type": "Übung",
  "number": "1.2.4.1",
  "title": "",
  "body": "  Bestimmen Sie alle Lösungen von .    Es ist , normiert , nach also und . Mit und liefert die Lösungsformel für reine Gleichungen die Winkel , , also , , und . Die letzten beiden liegen nicht in ; nach Abziehen von sind es und . Mit den Werten aus der Abbildung:    "
},
{
  "id": "exercise-buch-quadratische-gleichung-komplexe-koeffizienten",
  "level": "2",
  "url": "sec-algebraische-gleichungen-anwendungen.html#exercise-buch-quadratische-gleichung-komplexe-koeffizienten",
  "type": "Übung",
  "number": "1.2.4.2",
  "title": "",
  "body": "  Lösen Sie die Gleichung in , und machen Sie die Probe für eine der beiden Lösungen.    Mit und ist . Die Zahl hat den Betrag , normiert ist sie , nach also . Damit ist (Wert bei aus derselben Abbildung) eine Lösung von (Kontrolle: ). Die -Formel liefert Probe für : . Die beiden Lösungen sind nicht konjugiert zueinander — die Koeffizienten sind ja auch nicht reell.   "
},
{
  "id": "exercise-buch-linearfaktorzerlegung-kubisch",
  "level": "2",
  "url": "sec-algebraische-gleichungen-anwendungen.html#exercise-buch-linearfaktorzerlegung-kubisch",
  "type": "Übung",
  "number": "1.2.4.3",
  "title": "",
  "body": "  Bestimmen Sie die Linearfaktorisierung von . Nutzen Sie, dass eine Nullstelle ist.    Probe: . Ansatz ; Ausmultiplizieren und Koeffizientenvergleich liefert Die Mitternachtsformel (bzw. direktes Wurzelziehen) gibt . Die vollständige Linearfaktorisierung ist also    "
},
{
  "id": "exercise-buch-reelle-faktorisierung-kubisch",
  "level": "2",
  "url": "sec-algebraische-gleichungen-anwendungen.html#exercise-buch-reelle-faktorisierung-kubisch",
  "type": "Übung",
  "number": "1.2.4.4",
  "title": "",
  "body": "  Bestimmen Sie die Zerlegung von in irreduzible reelle Faktoren. Nutzen Sie, dass eine Nullstelle ist.    Probe: . Da reelle Koeffizienten hat, ist auch Nullstelle, und der zugehörige reelle Faktor ist . Division von durch (Ansatz , Koeffizientenvergleich liefert ) ergibt Da keine reelle Nullstelle hat, ist dies bereits die Zerlegung in irreduzible reelle Faktoren.   "
},
{
  "id": "exercise-buch-einheitswurzeln-summe",
  "level": "2",
  "url": "sec-algebraische-gleichungen-anwendungen.html#exercise-buch-einheitswurzeln-summe",
  "type": "Übung",
  "number": "1.2.4.5",
  "title": "",
  "body": "  Bestimmen Sie alle sechsten Einheitswurzeln (die Lösungen von ), und zeigen Sie, dass ihre Summe gleich ist.    Mit , , , sind die Lösungen , . Die Winkel und entsprechen nach Abziehen von den Winkeln und ; in liest man ab: Summiert man Realteile und Imaginärteile getrennt, heben sich beide jeweils paarweise auf:    "
},
{
  "id": "sec-folgen",
  "level": "1",
  "url": "sec-folgen.html",
  "type": "Abschnitt",
  "number": "2.1",
  "title": "Folgen",
  "body": " Folgen    Nach diesem Abschnitt können Sie    Folgen explizit und rekursiv angeben, ihre ersten Glieder berechnen und arithmetische von geometrischen Folgen unterscheiden;  Beschränktheit und Monotonie einer Folge nachweisen;  die -Definition der Konvergenz in eigenen Worten erklären und an einfachen Beispielen anwenden;  Grenzwerte mit den Rechenregeln, durch Vergleich von Wachstumsraten und mit dem Sandwich-Satz bestimmen;  den Satz über monotone, beschränkte Folgen einsetzen und den Grenzwert einer rekursiven Folge über ihre Fixpunktgleichung bestimmen;  Abschreibung, Zinseszins, Kundenbestände und Gradientenabstieg als Folgen lesen und ihr Langzeitverhalten beurteilen.     Ein Lernverfahren meldet nach jeder Trainingsepoche seinen Fehler: ; ; ; ; ; ; Lohnt es sich, weiterzutrainieren? Wird der Fehler irgendwann null, oder pendelt er sich bei etwa ein? Und woran erkennt man das, ohne unendlich lange zu warten? Genau diese Fragen stellt die Mathematik an eine Folge : eine unendliche Liste von Zahlen — der Kontostand nach jedem weiteren Jahr, die Näherung nach jedem weiteren Iterationsschritt, der Trainingsfehler nach jeder Epoche. Am Ende dieses Abschnitts können Sie die Frage beantworten — und wissen, wo die Antwort an ihre Grenzen stößt.  Um die Frage stabilisiert sich die Liste? beantworten zu können, brauchen wir zuerst eine präzise Fassung von stabilisiert sich — den Grenzwert — und dann Werkzeuge, mit denen man Grenzwerte tatsächlich ausrechnet, ohne jedes Mal auf die Definition zurückzugehen. Genau in dieser Reihenfolge geht dieser Abschnitt vor. Unterwegs begegnen Ihnen Kaninchen, Abschreibungen, Kredite, Kundenbestände, ein zweitausend Jahre altes Verfahren zum Wurzelziehen und der Gradientenabstieg aus dem maschinellen Lernen. Einiges davon — Zinseszins, Grenzwerte gebrochen-rationaler Ausdrücke — kennen Sie vielleicht schon aus der Schule; neu ist vor allem die Präzision, mit der wir jetzt über das Unendliche sprechen.    Begriff einer Folge   Wie geht es weiter: ? Die Antwort liegt auf der Hand — jede Zahl ist das Doppelte der vorigen. Nun ein kleines Experiment: Markieren Sie Punkte auf einem Kreis, verbinden Sie jeden mit jedem durch eine gerade Strecke, und zählen Sie, in wie viele Stücke die Kreisfläche dabei zerfällt (die Punkte so gewählt, dass sich nie drei Strecken in einem Punkt schneiden). Für Punkte erhalten Sie Stücke. Für Punkte aber sind es und nicht .  Die Moral: Ein paar Anfangswerte legen eine unendliche Zahlenliste nicht fest. Man braucht eine Vorschrift , die sagt, wie jedes Glied zustande kommt. Solche Listen mit Vorschrift heißen Folgen .  In diesem Unterabschnitt legen wir fest, wie man Folgen aufschreibt, lernen die beiden wichtigsten Grundtypen kennen und sammeln zwei Eigenschaften, die für das Langzeitverhalten entscheidend sind: Bleibt die Folge in einem festen Bereich ( Beschränktheit ), und bewegt sie sich stets in dieselbe Richtung ( Monotonie )? Im nächsten Unterabschnitt werden wir sehen, dass beides zusammen schon Konvergenz garantiert.    Explizite und rekursive Folgen   Folge   Eine reelle Folge  ist eine Abbildung (oder ), welche jeder natürlichen Zahl eine reelle (oder komplexe) Zahl zuordnet. Man nennt das -te Folgenglied .  Eine Folge kann explizit angegeben werden, indem man eine Formel für in Abhängigkeit von angibt (z. B. ), oder rekursiv , indem man ein oder mehrere Anfangsglieder festlegt und jedes weitere Glied aus den vorherigen berechnet (z. B. , ).    Eine explizite Formel ist bequem: Man kann jedes Glied direkt ausrechnen, etwa , ohne die 999 Glieder davor zu kennen. Eine rekursive Vorschrift ist dagegen oft die natürliche Beschreibung eines Vorgangs — sie sagt, wie man vom heutigen Zustand zum morgigen kommt. Genau so arbeiten auch Computerprogramme: in einer Schleife, die aus dem alten Wert den neuen berechnet.   Explizite und rekursive Darstellung   Geben Sie die ersten vier Glieder der Folge an. Geben Sie außerdem die ersten vier Glieder der rekursiv definierten Folge , an.    Einsetzen liefert , , , . Für die rekursive Folge ist , , , — hier ergibt sich sogar die explizite Formel , was aber nicht bei jeder rekursiven Folge so einfach möglich ist.    Eine Rekursion darf auch auf mehrere Vorgänger zurückgreifen. Die berühmteste Folge dieser Art stammt aus einem Rechenbuch, das Leonardo von Pisa, heute bekannt als Fibonacci, im Jahr 1202 veröffentlichte. Er fragte, wie sich ein Kaninchenbestand entwickelt, wenn jedes Paar ab dem zweiten Lebensmonat jeden Monat ein neues Paar zur Welt bringt. Die Anzahl der Paare im -ten Monat ist also : Jedes Glied ist die Summe der beiden vorigen. Die Kaninchen sind biologisch nicht sehr realistisch, die Folge aber taucht bis heute an erstaunlich vielen Stellen auf, von Sonnenblumenkernen bis zur Laufzeitanalyse von Algorithmen.  Zwei einfache Bauarten von Folgen kommen so oft vor, dass sie eigene Namen haben: Entweder kommt in jedem Schritt derselbe Betrag hinzu, oder es wird in jedem Schritt mit demselben Faktor multipliziert.   Arithmetische und geometrische Folge   Eine Folge mit für eine feste Zahl heißt arithmetische Folge ; explizit ist . Eine Folge mit für eine feste Zahl heißt geometrische Folge ; explizit ist .    Die Folge aus ist arithmetisch mit , die Rekursion aus der Definition geometrisch mit . Arithmetische Folgen wachsen (oder fallen) gleichmäßig wie eine Treppe mit gleich hohen Stufen, geometrische Folgen beschleunigen sich oder bremsen sich ab — ein Unterschied, der auf lange Sicht alles entscheidet.   Anwendungsbeispiel: Lineare und degressive Abschreibung   Ein Unternehmen kauft eine Maschine für  €. In der Buchhaltung verliert sie jedes Jahr an Wert. Bei linearer Abschreibung werden jedes Jahr  € abgezogen, bei geometrisch-degressiver Abschreibung jedes Jahr des aktuellen Buchwerts. Geben Sie die Buchwerte und nach Jahren explizit an. In welchem Jahr ist der Buchwert bei degressiver Abschreibung erstmals höher als bei linearer?    Die lineare Abschreibung ist eine arithmetische Folge mit , die degressive eine geometrische mit : Eine kleine Wertetabelle (in €):                               Anfangs schreibt die degressive Methode schneller ab — im ersten Jahr  € statt  €. Weil sie aber immer nur vom Rest abzieht, werden ihre Stufen kleiner und kleiner, während die lineare Treppe gleichmäßig weiterläuft. Nach neun Jahren ist der degressive Buchwert (  €) erstmals höher als der lineare (  €) — für die Jahre, die in der Tabelle fehlen, prüft man leicht nach, dass er vorher stets darunter liegt, etwa  € gegenüber  €. Nach zehn Jahren schließlich ist die Maschine linear vollständig abgeschrieben, degressiv dagegen nie: wird zwar beliebig klein, aber niemals null. In der Praxis wechseln Unternehmen deshalb irgendwann von der degressiven zur linearen Abschreibung.     Anwendungsbeispiel: Einen Kredit tilgen   Ein Unternehmen nimmt einen Kredit über  € zu Zinsen pro Jahr auf. Am Ende jedes Jahres werden die Zinsen fällig, und das Unternehmen zahlt eine Rate von  €. Stellen Sie eine Rekursion für die Restschuld nach Jahren auf, und bestimmen Sie, in welchem Jahr der Kredit getilgt ist.    In jedem Jahr wächst die Schuld um und sinkt dann um die Rate: Schritt für Schritt: Am Ende des vierten Jahres sind nur noch  € offen; die letzte Zahlung ist also kleiner als eine volle Rate, und nach vier Jahren ist der Kredit getilgt. Die Rekursion beschreibt den Vorgang genau so, wie ihn eine Tabellenkalkulation Zeile für Zeile berechnen würde. Sie ist weder arithmetisch noch geometrisch, sondern eine Mischung aus beidem: erst mit multiplizieren, dann abziehen. Eine explizite Formel für gibt es trotzdem; man erhält sie mit der geometrischen Summenformel aus .    Ob eine Folge bei oder bei beginnt, ist Konvention und ändert nichts an ihrem Langzeitverhalten. Beim Kreditbeispiel ist natürlich, weil den Stand nach Jahren angibt und nach null Jahren der Anfangsbetrag ist. Achten Sie in Aufgaben einfach darauf, womit gezählt wird.    Beschränktheit und Monotonie  Um das Langzeitverhalten einer Folge einzuschätzen, fragt man zuerst: Bleibt sie in einem festen Bereich, oder kann sie beliebig groß werden? Der degressive Buchwert aus bleibt zwischen und , der Kaninchenbestand von Fibonacci dagegen sprengt jeden Stall.   Beschränkte und unbeschränkte Folge   Eine (reelle oder komplexe) Folge heißt beschränkt , falls es eine reelle Zahl gibt, so dass Ist dies nicht der Fall, so heißt  unbeschränkt .    Bei reellen Folgen interessiert oft nur eine Richtung: Gilt für alle , heißt die Folge nach oben beschränkt , gilt für alle , heißt sie nach unten beschränkt . Beschränkt ist sie genau dann, wenn beides gilt. Achten Sie auf die Reihenfolge der Quantoren in der Definition: Eine Schranke muss für alle Glieder gleichzeitig funktionieren. Dass jedes einzelne Glied endlich ist, reicht nicht — das ist bei jeder reellen Folge so.   Beschränktheit nachweisen   Zeigen Sie, dass beschränkt ist, und dass unbeschränkt ist.    Für alle ist (Zähler ist stets kleiner als der Nenner), also : Die Folge ist beschränkt mit . Für gibt es dagegen zu jeder Schranke ein mit (z. B. ) — es gibt also keine gemeinsame obere Schranke für alle Folgenglieder, und ist unbeschränkt. Nach unten ist allerdings beschränkt, etwa durch .    Die zweite Frage lautet: Geht es stets in dieselbe Richtung?   Monotone Folge   Eine reelle Folge heißt monoton wachsend , falls und streng monoton wachsend , falls sogar für alle gilt. Analog heißt  (streng) monoton fallend , falls (bzw. ) für alle .    Ein paar berechnete Glieder zeigen, welche Monotonie man erwarten kann — ein Nachweis sind sie nicht, denn eine Folge kann anfangs steigen und später fallen (und das Kreis-Experiment vom Anfang dieses Unterabschnitts hat gezeigt, wie trügerisch die ersten Glieder sein können). Für den Nachweis gibt es zwei Standardwege: Man zeigt, dass die Differenz  stets dasselbe Vorzeichen hat, oder — bei Folgen mit positiven Gliedern — dass der Quotient  stets größer oder stets kleiner als ist.   Monotonie über die Differenz nachweisen   Zeigen Sie, dass streng monoton wachsend ist.    Wir betrachten die Differenz zweier aufeinanderfolgender Glieder: Da für alle , ist diese Differenz stets positiv, also für alle : Die Folge ist streng monoton wachsend. Zusammen mit wissen wir: Die Glieder steigen ständig, kommen aber nie über hinaus ( ). Ein schnellerer Weg zum selben Ziel: , und von wird ein immer kleinerer Betrag abgezogen.     Die ersten zehn Glieder von : Die Folge wächst streng monoton und bleibt unter der Schranke .    Ein Koordinatensystem mit von bis auf der horizontalen und von bis auf der vertikalen Achse. Zehn Punkte steigen von bei an und nähern sich immer flacher der gestrichelten waagerechten Linie auf Höhe , ohne sie zu erreichen.       Monotonie über den Quotienten nachweisen   Berechnen Sie die ersten vier Glieder von und zeigen Sie, dass die Folge monoton fallend ist.     , , , . Die ersten beiden Glieder sind gleich, danach fällt die Folge. Da alle Glieder positiv sind, untersuchen wir den Quotienten: Also gilt für alle : Die Folge ist monoton fallend, aber wegen nicht streng monoton fallend. Der Quotient ist hier bequemer als die Differenz, weil sich die Zweierpotenzen wegkürzen.     Anwendungsbeispiel: Zinseszins als monotone, unbeschränkte Folge   Ein Kapital wird jährlich mit einem festen Zinssatz verzinst, ohne dass Geld abgehoben oder eingezahlt wird. Das Kapital nach Jahren ist dann . Zeigen Sie, dass streng monoton wachsend und unbeschränkt ist.    Wegen ist , also und da für alle , folgt : Die Folge ist streng monoton wachsend. Da mit wachsender Basis über jede Schranke hinauswächst, gibt es zu jedem ein mit — die Folge ist also unbeschränkt. Bei verdoppelt sich das Kapital etwa alle Jahre ( ), nach Jahren ist es auf mehr als das -Fache angewachsen. Was ein Urgroßvater angelegt hat, wäre für die Urenkel also ein hübsches Sümmchen — sofern Bank und Währung so lange durchhalten, was in Deutschland im 20. Jahrhundert mindestens zweimal nicht der Fall war. In untersuchen wir, was passiert, wenn man stattdessen die Verzinsungsperiode immer feiner unterteilt, den Zinssatz dabei aber proportional verkleinert.       Konvergenz von Folgen   Die Folge aus kommt der Zahl immer näher, andere Folgen wachsen über alle Grenzen oder springen ohne Ziel hin und her. Immer näher ist allerdings zu ungenau, um damit zu rechnen: Auch die Folge kommt der mit jedem Schritt näher — strebt aber in Wahrheit gegen (wenn sich die Zuwächse weiter halbieren).  Wer schon einmal ein iteratives Verfahren programmiert hat, kennt die praktische Version dieser Frage: Nach wie vielen Schritten ist das Ergebnis genau genug? Genau so fassen wir den Grenzwert: Zu jeder noch so kleinen Toleranz gibt es einen Index , ab dem die Folge innerhalb dieser Toleranz bleibt. Danach lernen wir Werkzeuge kennen, mit denen man Grenzwerte ausrechnet, ohne jedes Mal auf diese Definition zurückzugehen, und schließlich einen Satz, der die Konvergenz rekursiver Folgen sichert.    Was heißt Konvergenz?   Konvergente Folge, Grenzwert   Eine reelle oder komplexe Folge heißt konvergent mit Grenzwert  , geschrieben oder , falls gilt: Für alle existiert ein , so dass für alle  Mit anderen Worten: Für jedes müssen fast alle Folgenglieder (d. h. alle bis auf endlich viele) innerhalb des -Streifens um liegen. Eine Folge, die nicht konvergiert, heißt divergent .    Lesen Sie die Definition als Spiel zwischen zwei Personen: Die eine gibt eine Toleranz vor, die andere muss einen Index nennen, ab dem alle Folgenglieder näher als an liegen. Konvergenz heißt: Die zweite Person gewinnt immer, egal wie klein die Toleranz ist. Je kleiner , desto größer wird in der Regel ( ).   Konvergenz von gegen : Für liegen ab alle Folgenglieder im -Streifen (blau); liegt genau auf dem Rand und zählt wegen des strikten noch nicht. Verkleinert man , wird größer — aber es gibt immer ein solches .    Ein Koordinatensystem mit auf der horizontalen und auf der vertikalen Achse. Zwölf Punkte springen abwechselnd über und unter die waagerechte Linie und nähern sich ihr dabei an. Ein blau eingefärbter Streifen zwischen und umgibt die Linie; die ersten drei Punkte liegen außerhalb, der vierte genau auf dem oberen Rand, alle Punkte ab innerhalb des Streifens. Eine gepunktete Linie markiert .       Beschränkt, aber divergent   Zeigen Sie, dass die Folge beschränkt, aber nicht konvergent ist.    Wegen für alle ist die Folge beschränkt (mit ). Angenommen, sie konvergiert gegen ein . Dann müssten für ab einem alle Glieder im Intervall liegen, das die Länge hat. Aber zwei aufeinanderfolgende Glieder sind stets und , haben also den Abstand — sie passen nicht gemeinsam in ein offenes Intervall der Länge . Widerspruch: Die Folge divergiert. Sie springt für immer zwischen und hin und her, ohne sich festzulegen. Beschränktheit allein garantiert also keine Konvergenz; wir werden gleich sehen, welche Zusatzbedingung das leistet.    Ähnliche Überlegungen zeigen zweierlei, was man stillschweigend immer voraussetzt. Erstens hat eine Folge höchstens einen Grenzwert: Lägen zwei verschiedene Kandidaten und vor, so wählt man als halben Abstand — dann überlappen die beiden -Streifen nicht, und fast alle Glieder können nicht gleichzeitig in beiden liegen. Zweitens ist jede konvergente Folge beschränkt : Ab liegen alle Glieder im Streifen um , und die endlich vielen Glieder davor kann man mit einer genügend großen Schranke ebenfalls einfangen. Eine unbeschränkte Folge kann also niemals konvergieren — das erspart oft jede weitere Rechnung.   Konvergenz direkt anhand der Definition nachweisen   Bestimmen Sie für und ein passendes für die Toleranzen und . Zeigen Sie dann direkt anhand der -Definition, dass .    Für gilt Für brauchen wir , also , d. h. : reicht. Für brauchen wir , also . Zehnmal genauer kostet hier zehnmal so viele Folgenglieder.  Nun allgemein: Sei beliebig vorgegeben. Die Ungleichung ist äquivalent zu . Wir wählen also . Dabei bezeichnet die kleinste ganze Zahl, die größer oder gleich ist: Man rundet auf ( obere Gaußklammer ), zum Beispiel ist und . Für alle gilt dann und damit . Da beliebig war, folgt .     Bestimmt divergente Folge   Eine reelle Folge heißt bestimmt divergent gegen (bzw. gegen ), falls für jedes ein existiert, so dass Man schreibt dann (bzw. ), obwohl die Folge im strengen Sinn nicht konvergiert — ist keine reelle Zahl.     Bestimmt divergent oder nicht?   Welche der Folgen , und sind bestimmt divergent?    Zu jedem ist für alle ; also , wenn auch sehr langsam (für braucht man ). Ebenso ist für , also . Die Folge mit den Gliedern ist zwar unbeschränkt, aber nicht bestimmt divergent — jedes zweite Glied ist negativ, sie bleibt also ab keinem Index dauerhaft oberhalb von , und ebenso wenig unterhalb von .      Grenzwerte berechnen  Die -Definition ist das Fundament, aber kein Rechenwerkzeug. In der Praxis zerlegt man eine Folge in einfache Bausteine, deren Grenzwerte man kennt, und setzt diese mit den folgenden Regeln wieder zusammen.   Rechenregeln für Grenzwerte   Seien und konvergente Folgen in mit und , und sei . Dann gilt:        , falls  für (sofern definiert)  Ist stetig ( ; anschaulich: ohne Sprünge) und reell, so ist    Außerdem gilt der Sandwich-Satz : Sind , , Folgen mit für fast alle und , so konvergiert auch gegen .     Wichtige Grenzwerte  Mit den Rechenregeln führt man Grenzwerte auf wenige Grundbausteine zurück, die man kennen sollte:    für jedes , insbesondere und ;  für , für , und divergiert (springend) für ;  für jedes und sogar ;  — dazu gleich mehr beim Zinseszins.      Grenzwerte gebrochen-rationaler Folgen   Bestimmen Sie mithilfe der Rechenregeln die Grenzwerte von , und .    Für konvergieren alle drei Summanden einzeln ( , , ), also nach der Summenregel . Für konvergiert der Nenner , also . Für dividieren wir Zähler und Nenner durch die höchste auftretende Potenz : Übrig bleibt nur das Verhältnis der Leitkoeffizienten; alle niedrigeren Potenzen verschwinden im Grenzübergang.    Aus dem Trick durch die höchste Potenz kürzen ergibt sich eine Faustregel für gebrochen-rationale Folgen, die man nach kurzer Übung auf einen Blick anwendet. Ist der Zählergrad kleiner als der Nennergrad, geht die Folge gegen (wie bei ); sind die Grade gleich, ist der Grenzwert der Quotient der Leitkoeffizienten (wie bei ); ist der Zählergrad größer, divergiert die Folge bestimmt gegen , etwa . Eine Kontrolle mit einem großen schadet trotzdem nie: Für ist , schon recht nahe an .  Vorsicht: Die Rechenregeln setzen voraus, dass die einzelnen Grenzwerte existieren . Streben zwei Summanden gegen und , sagt die Summenregel nichts — kann alles Mögliche ergeben. Dann muss man die Folge zuerst geschickt umformen.   Ein Grenzwert der Form   Bestimmen Sie den Grenzwert von .    Beide Terme wachsen über alle Grenzen, die Regeln sind also nicht direkt anwendbar. Der Trick: Erweitern mit der Summe , sodass die dritte binomische Formel die Wurzel beseitigt: Jetzt kürzen wir durch (unter der Wurzel durch ): wobei wir die Stetigkeit der Wurzel benutzt haben. Probe mit : . Die naive Vermutung beide Terme sind etwa , also ist der Grenzwert wäre falsch gewesen.    Lässt sich eine Folge nicht direkt umformen, hilft oft der Sandwich-Satz: Man schätzt sie nach oben und unten durch zwei einfachere Folgen mit demselben Grenzwert ab.   Einklemmen mit dem Sandwich-Satz   Bestimmen Sie den Grenzwert von .    Unter der Wurzel dominiert der größere Summand . Das nutzen wir für eine Abschätzung nach beiden Seiten: Ziehen der -ten Wurzel erhält die Ungleichungen: Links steht die konstante Folge , rechts wegen ( ) eine Folge mit Grenzwert . Nach dem Sandwich-Satz gilt also : Auf lange Sicht zählt nur der größte Summand.     Nullfolgen durch Vergleich von Wachstumsraten   Zeigen Sie, dass eine Nullfolge ist.    Für gilt nach der allgemeinen binomischen Formel, dem binomischen Lehrsatz (er wird in dieser Vorlesung weder behandelt noch vorausgesetzt; siehe etwa Binomischer Lehrsatz ), Benutzt wird davon nur: Alle Summanden sind , also ist die Summe mindestens so groß wie ihr Summand für . Damit ist Nach dem Sandwich-Satz (eingeschlossen zwischen der Nullfolge und der Nullfolge ) folgt . Mit dem gleichen Prinzip zeigt man allgemeiner, dass jede Potenz von langsamer wächst als jede Exponentialfunktion mit , und dass jede Exponentialfunktion wiederum langsamer wächst als die Fakultät . Diese Wachstumshierarchie  ist beim Bestimmen von Grenzwerten sehr nützlich: Ein Quotient aus zwei solchen Termen geht gegen , wenn der Nenner weiter rechts in der Hierarchie steht.      Monotone Folgen und Iterationsverfahren  Bei rekursiven Folgen versagen die bisherigen Werkzeuge oft, weil keine explizite Formel für vorliegt. Hier hilft ein Satz, der ohne jede Formel auskommt. Die Idee ist anschaulich: Eine Folge, die ständig steigt, aber eine Decke nicht durchstoßen kann, muss sich irgendwo unterhalb der Decke stauen — sie kann nicht ewig in großen Schritten weiterklettern.   Konvergenz monotoner, beschränkter Folgen   Jede reelle Folge , die monoton und beschränkt ist, ist konvergent.     Anwendungsbeispiel: Wurzelziehen mit dem Heron-Verfahren   Für definiert man rekursiv , — das Heron-Verfahren , ein Spezialfall des Newton-Verfahrens zur numerischen Nullstellenbestimmung, hier angewandt auf . Zeigen Sie, dass konvergiert, und bestimmen Sie den Grenzwert.    Zuerst: Alle Folgenglieder sind positiv. Denn , und jedes weitere Glied ist der Mittelwert der beiden positiven Zahlen und , also wieder positiv.  Für jedes gilt , also nach Ausmultiplizieren und Umstellen wobei wir im letzten Schritt durch geteilt haben. Insbesondere ist (mit ) für alle , also für und, da beide Seiten positiv sind, . Division durch ergibt für , und es folgt Die Folge ist ab monoton fallend und durch nach unten beschränkt, nach also konvergent, etwa gegen . Da beide Seiten der Rekursion für gegen bzw. konvergieren, erfüllt die Fixpunktgleichung . Multiplizieren mit , Abziehen von und Multiplizieren mit ergibt nacheinander und wegen folgt schließlich .  Wie schnell das geht, zeigt . Die ersten Schritte von Hand: und gerundet verglichen mit . Die Anzahl korrekter Stellen verdoppelt sich ungefähr mit jedem Schritt — schon nach vier Iterationen stimmen mehr als zehn Nachkommastellen. Ähnliche Iterationsverfahren werden in Taschenrechnern und Programmbibliotheken eingesetzt.  Dieses Prinzip — eine Näherung durch wiederholtes Anwenden einer Vorschrift schrittweise verbessern, bis sich die Folge der Näherungen stabilisiert — liegt nicht nur dem Newton-Verfahren zugrunde, sondern auch den iterativen Optimierungsverfahren, mit denen in der Data Science die Parameter von Lernmodellen bestimmt werden. Das einfachste davon sehen wir uns jetzt an.     Anwendungsbeispiel: Gradientenabstieg als geometrische Folge   Der Gradientenabstieg sucht das Minimum einer Verlustfunktion, indem er von einem Startwert aus wiederholt ein Stück bergab geht — bei einer Funktion einer Variablen gegen das Vorzeichen der Steigung. Für die einfachste Verlustfunktion (Minimum bei , Steigung ) lautet die Vorschrift mit Lernrate  : Für die Spielzeugfunktion braucht man das Verfahren natürlich nicht — ihr Minimum sieht man sofort. Es geht um die Idee: Dasselbe Vorgehen funktioniert genauso, wenn die Verlustfunktion wie beim Deep Learning von Milliarden von Parametern abhängt und niemand ihr Minimum mehr sehen kann.  Bestimmen Sie eine explizite Formel für , und entscheiden Sie, für welche Lernraten die Folge gegen das Minimum konvergiert. Was passiert konkret für , und ?    Jeder Schritt multipliziert mit demselben Faktor , also ist — eine geometrische Folge. Nach gilt genau dann, wenn , d. h. . Wir ziehen überall ab und teilen dann durch . Dabei gilt die Regel: Multipliziert man eine Ungleichung mit einer negativen Zahl oder teilt man sie durch eine negative Zahl, so kehren sich die Ungleichheitszeichen um. also .    : , also — langsame, monotone Annäherung.  : , also — das Minimum wird in einem einzigen Schritt getroffen.  : , also — die Folge springt mit wachsendem Betrag um das Minimum herum und divergiert.     Gradientenabstieg für mit Startwert : die Punkte auf der Parabel für drei Lernraten. Für rücken sie monoton zum Minimum, für landet schon genau im Minimum, für springen sie mit wachsendem Betrag hin und her (rechts ein größerer Ausschnitt).    Drei kleine Bilder nebeneinander, jedes mit der Parabel und farbig markierten Iterierten, die durch Pfeile verbunden sind. Links, blau, : Die Punkte starten bei und rücken auf dem rechten Ast der Parabel in immer kleineren Schritten zum Tiefpunkt, ohne die Seite zu wechseln ( , , , und weiter). Mitte, grün, : ein einziger Pfeil von direkt in den Tiefpunkt . Rechts, orange, , mit größerem Ausschnitt von bis : Die Pfeile springen abwechselnd auf den linken und rechten Ast und steigen dabei immer höher ( , , , , ).      Schon bei der einfachsten Verlustfunktion entscheidet also allein die Lernrate darüber, ob das Verfahren konvergiert, wie schnell es das tut oder ob es explodiert . In lernen wir die Steigung als Ableitung kennen und führen den Gradientenabstieg für allgemeinere Funktionen von Hand aus.    Der Heron-Trick lässt sich als Rezept festhalten: Konvergiert eine rekursive Folge mit stetigem , so muss ihr Grenzwert die Fixpunktgleichung  erfüllen. Aber Achtung: Die Fixpunktgleichung liefert nur einen Kandidaten ; Grenzwert ist er erst, wenn die Konvergenz gesichert ist. Die Folge mit hat die Fixpunktgleichung mit der Lösung — und divergiert trotzdem gegen . Die Fixpunktgleichung sagt also nur, wo die Folge landen würde , wenn sie überhaupt irgendwo landet.   Anwendungsbeispiel: Kundenstamm mit Abwanderung   Ein Streamingdienst hat zu Jahresbeginn Abonnenten. Jedes Jahr kündigen der Kunden (die Churn-Rate , eine der wichtigsten Kennzahlen der Kundenanalyse), und neue kommen hinzu. Für den Bestand nach Jahren gilt also Zeigen Sie, dass konvergiert, und bestimmen Sie den langfristigen Kundenbestand.    Die ersten Glieder , , legen nahe, dass der Bestand wächst — aber immer langsamer. Den Kandidaten für den Grenzwert liefert die Fixpunktgleichung , also . Bevor wir als Grenzwert akzeptieren, sichern wir die Konvergenz — der Kandidat liefert dafür gleich die passende Schranke.   Beschränkt: Ist , so ist . Da , bleibt die Folge also Schritt für Schritt unter . Monoton:  , und das ist positiv, solange — also immer. Nach konvergiert , und der Grenzwert ist der Fixpunkt .  Man kann sogar genauer hinsehen: Zieht man die Fixpunktgleichung von der Rekursion ab, also die zweite Zeile von der ersten, so fällt die weg, und man erhält Der Abstand zum Gleichgewicht ist also eine geometrische Folge. Wendet man diese Beziehung immer wieder an, so folgt also Probe: , wie oben. Wegen ist nach etwa sieben Jahren die Hälfte des Weges zum Gleichgewicht geschafft. Wirtschaftlich interessant: Der Endbestand hängt gar nicht vom Startwert ab, sondern nur vom Verhältnis Neukunden pro Jahr durch Kündigungsquote . Wer ihn erhöhen will, muss an einer der beiden Stellschrauben drehen.  Zum Vergleich der Kredit aus : Auch hat einen Fixpunkt, nämlich — bei dieser Restschuld würde die Rate gerade die Zinsen decken, und die Schuld bliebe ewig gleich. Dort ist der Faktor aber , der Abstand zum Fixpunkt wächst also von Jahr zu Jahr: Wer mit weniger Schulden startet, ist irgendwann schuldenfrei, wer mit mehr startet, versinkt immer tiefer. Ob ein Fixpunkt anzieht oder abstößt, entscheidet der Faktor vor .    Der Trick mit dem Abstand zum Gleichgewicht funktioniert für jede Rekursion der Form mit . Ihr Fixpunkt ist , und zieht man von der Rekursion ab, so bleibt Der Abstand zum Fixpunkt ist eine geometrische Folge: Für schrumpft er, und (bei negativem springt die Folge dabei abwechselnd über und unter den Fixpunkt); für wächst er, und die Folge entfernt sich vom Fixpunkt — außer sie startet genau dort.  Eine letzte Warnung, bevor wir zur stetigen Verzinsung kommen, denn dort lauert eine beliebte Falle. Für könnte man argumentieren: , und hoch irgendwas ist , also . Die Zahlen sagen etwas anderes: Der Fehler: Basis und Exponent ändern sich gleichzeitig . Die Basis rückt zwar an heran, aber der Exponent wächst so schnell, dass sich beide Effekte die Waage halten. ist deshalb genau wie eine unbestimmte Form, kein Rechenergebnis.   Anwendungsbeispiel: Vom Zinseszins zur stetigen Verzinsung   Ein Kapital wird über ein Jahr mit Zinssatz verzinst. Statt der Verzinsung einmal am Jahresende zerlegen wir das Jahr in gleich lange Perioden und verzinsen in jeder Periode mit dem anteiligen Satz , wobei die Zinsen jeweils sofort mitverzinst werden (Zinseszins). Das Endkapital nach einem Jahr ist dann Was passiert mit , wenn man die Verzinsungsperiode immer feiner unterteilt, also gehen lässt?    Die Folge ist monoton wachsend und beschränkt (das lässt sich mit der allgemeinen binomischen Formel, dem binomischen Lehrsatz, nachrechnen; wie in gilt: In der Vorlesung wird er weder behandelt noch vorausgesetzt, siehe Binomischer Lehrsatz ), nach also konvergent. Ihr Grenzwert ist gerade die Exponentialfunktion an der Stelle : (Für ist das eine der üblichen Definitionen der Eulerschen Zahl .) Damit konvergiert die Folge der Endkapitale gegen den Grenzfall der stetigen Verzinsung . Anders als man vielleicht vermuten würde, führt beliebig feine Unterteilung der Verzinsungsperiode also nicht zu unbegrenztem Wachstum, sondern zu einem endlichen Grenzwert — ein Effekt, der in der Finanzmathematik zur Modellierung kontinuierlicher Verzinsung verwendet wird, und dieselbe Exponentialfunktion , die uns bei Wachstums- und Zerfallsprozessen in wiederbegegnen wird.  Zahlenbeispiel: Bei  € und ergibt jährliche Verzinsung  €, monatliche  € und stetige  €. Der Unterschied zwischen monatlicher und stetiger Verzinsung beträgt also nur elf Cent.    Und der Trainingsfehler vom Anfang dieses Abschnitts? Als Vertiefung folgt hier für alle, die es interessiert, eine mögliche Auflösung.   Anwendungsbeispiel: Der Trainingsfehler vom Anfang (zur Vertiefung)   Ein Lernverfahren meldet nach den Trainingsepochen die Fehler . Gegen welchen Wert strebt der Fehler vermutlich, wenn man weitertrainiert, und lohnt sich das?     Die Daten. Wir bezeichnen mit den Fehler nach Epoche und mit die Abnahme von Epoche zu Epoche . Die Tabelle zeigt beide und den Quotienten aufeinanderfolgender Abnahmen:                                         Die Abnahmen. Von Epoche zu Epoche sinkt der Fehler um , dann um , dann um , und . Die Quotienten , und zeigen: Jede Abnahme ist ungefähr ein Drittel der vorigen, zuletzt mit eher knapp die Hälfte.   Die Brücke zum Modell. Als Modell nehmen wir die Rekursion aus dem Absatz nach , mit unbekannten Konstanten und . Sie beschreibt den Fehler selbst, nicht seine Abnahme. Schreibt man sie für zwei aufeinanderfolgende Epochen hin, und zieht die zweite Gleichung von der ersten ab, so fällt weg: (für die zweite Form beide Seiten mit multiplizieren). Die Abnahmen bilden also eine geometrische Folge mit demselben Faktor wie die Rekursion — genau das beobachten wir in den Daten, mit . Nach demselben Absatz schrumpft mit dem Faktor auch der Abstand des Fehlers zum Grenzwert . Es sind also drei Größen im Spiel: Der Fehler strebt gegen ; seine Abnahmen und sein Abstand zum Grenzwert schrumpfen in jeder Epoche auf etwa ein Drittel.   Die Reihe. Um wie viel sinkt der Fehler nach der letzten Messung insgesamt noch? Mit der letzten Abnahme sind die künftigen Abnahmen , , und so fort, die gesamte noch ausstehende Abnahme ist also eine unendliche Summe der Glieder einer geometrischen Folge. Ihre ersten Teilsummen für sind , dann , dann gerundet Sie wachsen, aber immer langsamer, und scheinen sich bei einzupendeln. Wann eine solche unendliche Summe einen endlichen Wert hat und wie man ihn ausrechnet, ist genau das Thema des nächsten Abschnitts, .   Der Grenzwert. Als Vorgriff benutzen wir die Formel aus : Für ist (mit dem ersten Glied ) Mit ergibt sich , also Mit dem zuletzt beobachteten Quotienten wäre die ausstehende Abnahme und — ebenfalls rund . Der Fehler strebt also gegen rund , nicht gegen , und langes Weitertrainieren bringt kaum noch etwas.   Der Vorbehalt. Aber denken Sie an das Kreisexperiment vom Anfang von : Sechs Werte beweisen nichts. Die Prognose steht und fällt mit der Annahme, dass sich die Abnahmen weiter ungefähr dritteln — eine Modellannahme, keine Folgerung aus den Daten.       Zusammenfassung     Folge: Abbildung , ; explizit durch eine Formel für oder rekursiv durch Anfangsglied und Vorschrift . Arithmetisch: ; geometrisch: .   Beschränkt:  für alle . Monoton:  (wachsend) bzw. (fallend) für alle ; Nachweis über die Differenz oder den Quotienten .   Konvergenz  : Zu jedem liegen fast alle Glieder im Streifen . Sonst divergent; bestimmt divergent, wenn . Der Grenzwert ist eindeutig, und jede konvergente Folge ist beschränkt; beschränkt allein reicht aber nicht ( ).   Rechenregeln: Grenzwerte von Summen, Produkten und Quotienten sind Summen, Produkte und Quotienten der Grenzwerte. Gebrochen-rationale Folgen: durch die höchste Potenz kürzen (Zählergrad kleiner: Grenzwert ; gleich: Quotient der Leitkoeffizienten; größer: bestimmt divergent); bei den unbestimmten Formen und erst umformen (z. B. mit der dritten binomischen Formel erweitern). Sandwich-Satz:  und   .   Grundbausteine:  , für , , ; Wachstumshierarchie .   Monoton und beschränkt konvergent. Bei rekursiven Folgen liefert dann die Fixpunktgleichung (Rekursion mit ) den Grenzwert — so beim Heron-Verfahren . Die Fixpunktgleichung liefert nur einen Kandidaten; Grenzwert ist er erst, wenn die Konvergenz gesichert ist. Bei ( ) ist mit : Der Abstand zum Fixpunkt schrumpft für und wächst für .   Anwendungen: Lineare Abschreibung ist arithmetisch, degressive geometrisch; ein Kundenstamm mit Churn-Rate strebt gegen Neukunden durch Kündigungsquote ; Zinseszins wächst unbeschränkt, stetige Verzinsung liefert ; Gradientenabstieg für ist die geometrische Folge und konvergiert genau für .      Übungsaufgaben    Geben Sie die ersten vier Glieder der Folge an. Geben Sie außerdem die ersten vier Glieder der rekursiv definierten Folge , an, und finden Sie eine explizite Formel für .    Einsetzen liefert , , , . Für die rekursive Folge ist , , , — jedes weitere Glied ist um kleiner als das vorherige, also .      Zeigen Sie, dass monoton fallend und beschränkt ist, und bestimmen Sie den Grenzwert.    Wir schreiben um: Mit wachsendem wird kleiner, also streng monoton fallend; da für alle , ist , also durch nach unten beschränkt; nach oben ist sie wegen der Monotonie durch beschränkt. Nach dem Satz über monotone, beschränkte Folgen konvergiert , und wegen ist       Bestimmen Sie .    Division von Zähler und Nenner durch die höchste auftretende Potenz :       Eine Patientin nimmt jeden Morgen  mg eines Wirkstoffs ein; bis zum nächsten Morgen baut ihr Körper die Hälfte der jeweils vorhandenen Menge ab. Für die Wirkstoffmenge (in mg) direkt nach der -ten Einnahme gilt , .  Berechnen Sie , und .  Zeigen Sie, dass für alle gilt und dass die Folge monoton wachsend ist.  Bestimmen Sie den Grenzwert.        , , .  Ist , so ist ; wegen gilt die Schranke also für alle . Außerdem ist , weil .  Monoton und beschränkt, also konvergent. Der Grenzwert erfüllt die Fixpunktgleichung , also : Auf Dauer pendelt sich die Wirkstoffmenge nach der Einnahme bei  mg ein, dem Doppelten der Tagesdosis.        Zeigen Sie mit dem Sandwich-Satz, dass eine Nullfolge ist.    Da für alle , gilt Beide einschließenden Folgen und konvergieren gegen . Nach dem Sandwich-Satz konvergiert also auch gegen .     "
},
{
  "id": "sec-folgen-2",
  "level": "2",
  "url": "sec-folgen.html#sec-folgen-2",
  "type": "Lernziele",
  "number": "2.1",
  "title": "",
  "body": "  Nach diesem Abschnitt können Sie    Folgen explizit und rekursiv angeben, ihre ersten Glieder berechnen und arithmetische von geometrischen Folgen unterscheiden;  Beschränktheit und Monotonie einer Folge nachweisen;  die -Definition der Konvergenz in eigenen Worten erklären und an einfachen Beispielen anwenden;  Grenzwerte mit den Rechenregeln, durch Vergleich von Wachstumsraten und mit dem Sandwich-Satz bestimmen;  den Satz über monotone, beschränkte Folgen einsetzen und den Grenzwert einer rekursiven Folge über ihre Fixpunktgleichung bestimmen;  Abschreibung, Zinseszins, Kundenbestände und Gradientenabstieg als Folgen lesen und ihr Langzeitverhalten beurteilen.   "
},
{
  "id": "def-folge",
  "level": "2",
  "url": "sec-folgen.html#def-folge",
  "type": "Definition",
  "number": "2.1.1",
  "title": "Folge.",
  "body": " Folge   Eine reelle Folge  ist eine Abbildung (oder ), welche jeder natürlichen Zahl eine reelle (oder komplexe) Zahl zuordnet. Man nennt das -te Folgenglied .  Eine Folge kann explizit angegeben werden, indem man eine Formel für in Abhängigkeit von angibt (z. B. ), oder rekursiv , indem man ein oder mehrere Anfangsglieder festlegt und jedes weitere Glied aus den vorherigen berechnet (z. B. , ).   "
},
{
  "id": "ex-explizit-rekursiv-folge",
  "level": "2",
  "url": "sec-folgen.html#ex-explizit-rekursiv-folge",
  "type": "Beispiel",
  "number": "2.1.2",
  "title": "Explizite und rekursive Darstellung.",
  "body": " Explizite und rekursive Darstellung   Geben Sie die ersten vier Glieder der Folge an. Geben Sie außerdem die ersten vier Glieder der rekursiv definierten Folge , an.    Einsetzen liefert , , , . Für die rekursive Folge ist , , , — hier ergibt sich sogar die explizite Formel , was aber nicht bei jeder rekursiven Folge so einfach möglich ist.   "
},
{
  "id": "def-arithmetische-geometrische-folge",
  "level": "2",
  "url": "sec-folgen.html#def-arithmetische-geometrische-folge",
  "type": "Definition",
  "number": "2.1.3",
  "title": "Arithmetische und geometrische Folge.",
  "body": " Arithmetische und geometrische Folge   Eine Folge mit für eine feste Zahl heißt arithmetische Folge ; explizit ist . Eine Folge mit für eine feste Zahl heißt geometrische Folge ; explizit ist .   "
},
{
  "id": "ex-anwendung-abschreibung",
  "level": "2",
  "url": "sec-folgen.html#ex-anwendung-abschreibung",
  "type": "Beispiel",
  "number": "2.1.4",
  "title": "Anwendungsbeispiel: Lineare und degressive Abschreibung.",
  "body": " Anwendungsbeispiel: Lineare und degressive Abschreibung   Ein Unternehmen kauft eine Maschine für  €. In der Buchhaltung verliert sie jedes Jahr an Wert. Bei linearer Abschreibung werden jedes Jahr  € abgezogen, bei geometrisch-degressiver Abschreibung jedes Jahr des aktuellen Buchwerts. Geben Sie die Buchwerte und nach Jahren explizit an. In welchem Jahr ist der Buchwert bei degressiver Abschreibung erstmals höher als bei linearer?    Die lineare Abschreibung ist eine arithmetische Folge mit , die degressive eine geometrische mit : Eine kleine Wertetabelle (in €):                               Anfangs schreibt die degressive Methode schneller ab — im ersten Jahr  € statt  €. Weil sie aber immer nur vom Rest abzieht, werden ihre Stufen kleiner und kleiner, während die lineare Treppe gleichmäßig weiterläuft. Nach neun Jahren ist der degressive Buchwert (  €) erstmals höher als der lineare (  €) — für die Jahre, die in der Tabelle fehlen, prüft man leicht nach, dass er vorher stets darunter liegt, etwa  € gegenüber  €. Nach zehn Jahren schließlich ist die Maschine linear vollständig abgeschrieben, degressiv dagegen nie: wird zwar beliebig klein, aber niemals null. In der Praxis wechseln Unternehmen deshalb irgendwann von der degressiven zur linearen Abschreibung.   "
},
{
  "id": "ex-anwendung-kredit-rekursiv",
  "level": "2",
  "url": "sec-folgen.html#ex-anwendung-kredit-rekursiv",
  "type": "Beispiel",
  "number": "2.1.5",
  "title": "Anwendungsbeispiel: Einen Kredit tilgen.",
  "body": " Anwendungsbeispiel: Einen Kredit tilgen   Ein Unternehmen nimmt einen Kredit über  € zu Zinsen pro Jahr auf. Am Ende jedes Jahres werden die Zinsen fällig, und das Unternehmen zahlt eine Rate von  €. Stellen Sie eine Rekursion für die Restschuld nach Jahren auf, und bestimmen Sie, in welchem Jahr der Kredit getilgt ist.    In jedem Jahr wächst die Schuld um und sinkt dann um die Rate: Schritt für Schritt: Am Ende des vierten Jahres sind nur noch  € offen; die letzte Zahlung ist also kleiner als eine volle Rate, und nach vier Jahren ist der Kredit getilgt. Die Rekursion beschreibt den Vorgang genau so, wie ihn eine Tabellenkalkulation Zeile für Zeile berechnen würde. Sie ist weder arithmetisch noch geometrisch, sondern eine Mischung aus beidem: erst mit multiplizieren, dann abziehen. Eine explizite Formel für gibt es trotzdem; man erhält sie mit der geometrischen Summenformel aus .   "
},
{
  "id": "def-beschraenkte-folge",
  "level": "2",
  "url": "sec-folgen.html#def-beschraenkte-folge",
  "type": "Definition",
  "number": "2.1.6",
  "title": "Beschränkte und unbeschränkte Folge.",
  "body": " Beschränkte und unbeschränkte Folge   Eine (reelle oder komplexe) Folge heißt beschränkt , falls es eine reelle Zahl gibt, so dass Ist dies nicht der Fall, so heißt  unbeschränkt .   "
},
{
  "id": "ssub-beschraenktheit-monotonie-4",
  "level": "2",
  "url": "sec-folgen.html#ssub-beschraenktheit-monotonie-4",
  "type": "Absatz (with a defined term)",
  "number": "",
  "title": "",
  "body": "nach oben beschränkt nach unten beschränkt "
},
{
  "id": "ex-beschraenktheit-nachweis",
  "level": "2",
  "url": "sec-folgen.html#ex-beschraenktheit-nachweis",
  "type": "Beispiel",
  "number": "2.1.7",
  "title": "Beschränktheit nachweisen.",
  "body": " Beschränktheit nachweisen   Zeigen Sie, dass beschränkt ist, und dass unbeschränkt ist.    Für alle ist (Zähler ist stets kleiner als der Nenner), also : Die Folge ist beschränkt mit . Für gibt es dagegen zu jeder Schranke ein mit (z. B. ) — es gibt also keine gemeinsame obere Schranke für alle Folgenglieder, und ist unbeschränkt. Nach unten ist allerdings beschränkt, etwa durch .   "
},
{
  "id": "def-monotone-folge",
  "level": "2",
  "url": "sec-folgen.html#def-monotone-folge",
  "type": "Definition",
  "number": "2.1.8",
  "title": "Monotone Folge.",
  "body": " Monotone Folge   Eine reelle Folge heißt monoton wachsend , falls und streng monoton wachsend , falls sogar für alle gilt. Analog heißt  (streng) monoton fallend , falls (bzw. ) für alle .   "
},
{
  "id": "ex-monotonie-nachweis-differenz",
  "level": "2",
  "url": "sec-folgen.html#ex-monotonie-nachweis-differenz",
  "type": "Beispiel",
  "number": "2.1.9",
  "title": "Monotonie über die Differenz nachweisen.",
  "body": " Monotonie über die Differenz nachweisen   Zeigen Sie, dass streng monoton wachsend ist.    Wir betrachten die Differenz zweier aufeinanderfolgender Glieder: Da für alle , ist diese Differenz stets positiv, also für alle : Die Folge ist streng monoton wachsend. Zusammen mit wissen wir: Die Glieder steigen ständig, kommen aber nie über hinaus ( ). Ein schnellerer Weg zum selben Ziel: , und von wird ein immer kleinerer Betrag abgezogen.   "
},
{
  "id": "fig-folge-n-durch-n-plus-1",
  "level": "2",
  "url": "sec-folgen.html#fig-folge-n-durch-n-plus-1",
  "type": "Abbildung",
  "number": "2.1.10",
  "title": "",
  "body": " Die ersten zehn Glieder von : Die Folge wächst streng monoton und bleibt unter der Schranke .    Ein Koordinatensystem mit von bis auf der horizontalen und von bis auf der vertikalen Achse. Zehn Punkte steigen von bei an und nähern sich immer flacher der gestrichelten waagerechten Linie auf Höhe , ohne sie zu erreichen.     "
},
{
  "id": "ex-monotonie-nachweis-quotient",
  "level": "2",
  "url": "sec-folgen.html#ex-monotonie-nachweis-quotient",
  "type": "Beispiel",
  "number": "2.1.11",
  "title": "Monotonie über den Quotienten nachweisen.",
  "body": " Monotonie über den Quotienten nachweisen   Berechnen Sie die ersten vier Glieder von und zeigen Sie, dass die Folge monoton fallend ist.     , , , . Die ersten beiden Glieder sind gleich, danach fällt die Folge. Da alle Glieder positiv sind, untersuchen wir den Quotienten: Also gilt für alle : Die Folge ist monoton fallend, aber wegen nicht streng monoton fallend. Der Quotient ist hier bequemer als die Differenz, weil sich die Zweierpotenzen wegkürzen.   "
},
{
  "id": "ex-anwendung-zinseszins-monoton",
  "level": "2",
  "url": "sec-folgen.html#ex-anwendung-zinseszins-monoton",
  "type": "Beispiel",
  "number": "2.1.12",
  "title": "Anwendungsbeispiel: Zinseszins als monotone, unbeschränkte Folge.",
  "body": " Anwendungsbeispiel: Zinseszins als monotone, unbeschränkte Folge   Ein Kapital wird jährlich mit einem festen Zinssatz verzinst, ohne dass Geld abgehoben oder eingezahlt wird. Das Kapital nach Jahren ist dann . Zeigen Sie, dass streng monoton wachsend und unbeschränkt ist.    Wegen ist , also und da für alle , folgt : Die Folge ist streng monoton wachsend. Da mit wachsender Basis über jede Schranke hinauswächst, gibt es zu jedem ein mit — die Folge ist also unbeschränkt. Bei verdoppelt sich das Kapital etwa alle Jahre ( ), nach Jahren ist es auf mehr als das -Fache angewachsen. Was ein Urgroßvater angelegt hat, wäre für die Urenkel also ein hübsches Sümmchen — sofern Bank und Währung so lange durchhalten, was in Deutschland im 20. Jahrhundert mindestens zweimal nicht der Fall war. In untersuchen wir, was passiert, wenn man stattdessen die Verzinsungsperiode immer feiner unterteilt, den Zinssatz dabei aber proportional verkleinert.   "
},
{
  "id": "def-konvergente-folge",
  "level": "2",
  "url": "sec-folgen.html#def-konvergente-folge",
  "type": "Definition",
  "number": "2.1.13",
  "title": "Konvergente Folge, Grenzwert.",
  "body": " Konvergente Folge, Grenzwert   Eine reelle oder komplexe Folge heißt konvergent mit Grenzwert  , geschrieben oder , falls gilt: Für alle existiert ein , so dass für alle  Mit anderen Worten: Für jedes müssen fast alle Folgenglieder (d. h. alle bis auf endlich viele) innerhalb des -Streifens um liegen. Eine Folge, die nicht konvergiert, heißt divergent .   "
},
{
  "id": "fig-epsilon-streifen",
  "level": "2",
  "url": "sec-folgen.html#fig-epsilon-streifen",
  "type": "Abbildung",
  "number": "2.1.14",
  "title": "",
  "body": " Konvergenz von gegen : Für liegen ab alle Folgenglieder im -Streifen (blau); liegt genau auf dem Rand und zählt wegen des strikten noch nicht. Verkleinert man , wird größer — aber es gibt immer ein solches .    Ein Koordinatensystem mit auf der horizontalen und auf der vertikalen Achse. Zwölf Punkte springen abwechselnd über und unter die waagerechte Linie und nähern sich ihr dabei an. Ein blau eingefärbter Streifen zwischen und umgibt die Linie; die ersten drei Punkte liegen außerhalb, der vierte genau auf dem oberen Rand, alle Punkte ab innerhalb des Streifens. Eine gepunktete Linie markiert .     "
},
{
  "id": "ex-beschraenkt-aber-divergent",
  "level": "2",
  "url": "sec-folgen.html#ex-beschraenkt-aber-divergent",
  "type": "Beispiel",
  "number": "2.1.15",
  "title": "Beschränkt, aber divergent.",
  "body": " Beschränkt, aber divergent   Zeigen Sie, dass die Folge beschränkt, aber nicht konvergent ist.    Wegen für alle ist die Folge beschränkt (mit ). Angenommen, sie konvergiert gegen ein . Dann müssten für ab einem alle Glieder im Intervall liegen, das die Länge hat. Aber zwei aufeinanderfolgende Glieder sind stets und , haben also den Abstand — sie passen nicht gemeinsam in ein offenes Intervall der Länge . Widerspruch: Die Folge divergiert. Sie springt für immer zwischen und hin und her, ohne sich festzulegen. Beschränktheit allein garantiert also keine Konvergenz; wir werden gleich sehen, welche Zusatzbedingung das leistet.   "
},
{
  "id": "ex-epsilon-nachweis-buch",
  "level": "2",
  "url": "sec-folgen.html#ex-epsilon-nachweis-buch",
  "type": "Beispiel",
  "number": "2.1.16",
  "title": "Konvergenz direkt anhand der Definition nachweisen.",
  "body": " Konvergenz direkt anhand der Definition nachweisen   Bestimmen Sie für und ein passendes für die Toleranzen und . Zeigen Sie dann direkt anhand der -Definition, dass .    Für gilt Für brauchen wir , also , d. h. : reicht. Für brauchen wir , also . Zehnmal genauer kostet hier zehnmal so viele Folgenglieder.  Nun allgemein: Sei beliebig vorgegeben. Die Ungleichung ist äquivalent zu . Wir wählen also . Dabei bezeichnet die kleinste ganze Zahl, die größer oder gleich ist: Man rundet auf ( obere Gaußklammer ), zum Beispiel ist und . Für alle gilt dann und damit . Da beliebig war, folgt .   "
},
{
  "id": "def-bestimmt-divergent",
  "level": "2",
  "url": "sec-folgen.html#def-bestimmt-divergent",
  "type": "Definition",
  "number": "2.1.17",
  "title": "Bestimmt divergente Folge.",
  "body": " Bestimmt divergente Folge   Eine reelle Folge heißt bestimmt divergent gegen (bzw. gegen ), falls für jedes ein existiert, so dass Man schreibt dann (bzw. ), obwohl die Folge im strengen Sinn nicht konvergiert — ist keine reelle Zahl.   "
},
{
  "id": "ex-bestimmt-divergent",
  "level": "2",
  "url": "sec-folgen.html#ex-bestimmt-divergent",
  "type": "Beispiel",
  "number": "2.1.18",
  "title": "Bestimmt divergent oder nicht?",
  "body": " Bestimmt divergent oder nicht?   Welche der Folgen , und sind bestimmt divergent?    Zu jedem ist für alle ; also , wenn auch sehr langsam (für braucht man ). Ebenso ist für , also . Die Folge mit den Gliedern ist zwar unbeschränkt, aber nicht bestimmt divergent — jedes zweite Glied ist negativ, sie bleibt also ab keinem Index dauerhaft oberhalb von , und ebenso wenig unterhalb von .   "
},
{
  "id": "thm-rechenregeln-grenzwerte",
  "level": "2",
  "url": "sec-folgen.html#thm-rechenregeln-grenzwerte",
  "type": "Satz",
  "number": "2.1.19",
  "title": "Rechenregeln für Grenzwerte.",
  "body": " Rechenregeln für Grenzwerte   Seien und konvergente Folgen in mit und , und sei . Dann gilt:        , falls  für (sofern definiert)  Ist stetig ( ; anschaulich: ohne Sprünge) und reell, so ist    Außerdem gilt der Sandwich-Satz : Sind , , Folgen mit für fast alle und , so konvergiert auch gegen .   "
},
{
  "id": "rem-wichtige-grenzwerte",
  "level": "2",
  "url": "sec-folgen.html#rem-wichtige-grenzwerte",
  "type": "Bemerkung",
  "number": "2.1.20",
  "title": "Wichtige Grenzwerte.",
  "body": " Wichtige Grenzwerte  Mit den Rechenregeln führt man Grenzwerte auf wenige Grundbausteine zurück, die man kennen sollte:    für jedes , insbesondere und ;  für , für , und divergiert (springend) für ;  für jedes und sogar ;  — dazu gleich mehr beim Zinseszins.    "
},
{
  "id": "ex-grenzwertsaetze-gebrochen-rational",
  "level": "2",
  "url": "sec-folgen.html#ex-grenzwertsaetze-gebrochen-rational",
  "type": "Beispiel",
  "number": "2.1.21",
  "title": "Grenzwerte gebrochen-rationaler Folgen.",
  "body": " Grenzwerte gebrochen-rationaler Folgen   Bestimmen Sie mithilfe der Rechenregeln die Grenzwerte von , und .    Für konvergieren alle drei Summanden einzeln ( , , ), also nach der Summenregel . Für konvergiert der Nenner , also . Für dividieren wir Zähler und Nenner durch die höchste auftretende Potenz : Übrig bleibt nur das Verhältnis der Leitkoeffizienten; alle niedrigeren Potenzen verschwinden im Grenzübergang.   "
},
{
  "id": "ex-wurzeldifferenz-grenzwert",
  "level": "2",
  "url": "sec-folgen.html#ex-wurzeldifferenz-grenzwert",
  "type": "Beispiel",
  "number": "2.1.22",
  "title": "Ein Grenzwert der Form „<span class=\"process-math\">\\(\\infty-\\infty\\)<\/span>“.",
  "body": " Ein Grenzwert der Form   Bestimmen Sie den Grenzwert von .    Beide Terme wachsen über alle Grenzen, die Regeln sind also nicht direkt anwendbar. Der Trick: Erweitern mit der Summe , sodass die dritte binomische Formel die Wurzel beseitigt: Jetzt kürzen wir durch (unter der Wurzel durch ): wobei wir die Stetigkeit der Wurzel benutzt haben. Probe mit : . Die naive Vermutung beide Terme sind etwa , also ist der Grenzwert wäre falsch gewesen.   "
},
{
  "id": "ex-sandwich-n-te-wurzel",
  "level": "2",
  "url": "sec-folgen.html#ex-sandwich-n-te-wurzel",
  "type": "Beispiel",
  "number": "2.1.23",
  "title": "Einklemmen mit dem Sandwich-Satz.",
  "body": " Einklemmen mit dem Sandwich-Satz   Bestimmen Sie den Grenzwert von .    Unter der Wurzel dominiert der größere Summand . Das nutzen wir für eine Abschätzung nach beiden Seiten: Ziehen der -ten Wurzel erhält die Ungleichungen: Links steht die konstante Folge , rechts wegen ( ) eine Folge mit Grenzwert . Nach dem Sandwich-Satz gilt also : Auf lange Sicht zählt nur der größte Summand.   "
},
{
  "id": "ex-nullfolgen-wachstumsvergleich",
  "level": "2",
  "url": "sec-folgen.html#ex-nullfolgen-wachstumsvergleich",
  "type": "Beispiel",
  "number": "2.1.24",
  "title": "Nullfolgen durch Vergleich von Wachstumsraten.",
  "body": " Nullfolgen durch Vergleich von Wachstumsraten   Zeigen Sie, dass eine Nullfolge ist.    Für gilt nach der allgemeinen binomischen Formel, dem binomischen Lehrsatz (er wird in dieser Vorlesung weder behandelt noch vorausgesetzt; siehe etwa Binomischer Lehrsatz ), Benutzt wird davon nur: Alle Summanden sind , also ist die Summe mindestens so groß wie ihr Summand für . Damit ist Nach dem Sandwich-Satz (eingeschlossen zwischen der Nullfolge und der Nullfolge ) folgt . Mit dem gleichen Prinzip zeigt man allgemeiner, dass jede Potenz von langsamer wächst als jede Exponentialfunktion mit , und dass jede Exponentialfunktion wiederum langsamer wächst als die Fakultät . Diese Wachstumshierarchie  ist beim Bestimmen von Grenzwerten sehr nützlich: Ein Quotient aus zwei solchen Termen geht gegen , wenn der Nenner weiter rechts in der Hierarchie steht.   "
},
{
  "id": "thm-monotone-beschraenkte-folgen",
  "level": "2",
  "url": "sec-folgen.html#thm-monotone-beschraenkte-folgen",
  "type": "Satz",
  "number": "2.1.25",
  "title": "Konvergenz monotoner, beschränkter Folgen.",
  "body": " Konvergenz monotoner, beschränkter Folgen   Jede reelle Folge , die monoton und beschränkt ist, ist konvergent.   "
},
{
  "id": "ex-anwendung-heron-verfahren",
  "level": "2",
  "url": "sec-folgen.html#ex-anwendung-heron-verfahren",
  "type": "Beispiel",
  "number": "2.1.26",
  "title": "Anwendungsbeispiel: Wurzelziehen mit dem Heron-Verfahren.",
  "body": " Anwendungsbeispiel: Wurzelziehen mit dem Heron-Verfahren   Für definiert man rekursiv , — das Heron-Verfahren , ein Spezialfall des Newton-Verfahrens zur numerischen Nullstellenbestimmung, hier angewandt auf . Zeigen Sie, dass konvergiert, und bestimmen Sie den Grenzwert.    Zuerst: Alle Folgenglieder sind positiv. Denn , und jedes weitere Glied ist der Mittelwert der beiden positiven Zahlen und , also wieder positiv.  Für jedes gilt , also nach Ausmultiplizieren und Umstellen wobei wir im letzten Schritt durch geteilt haben. Insbesondere ist (mit ) für alle , also für und, da beide Seiten positiv sind, . Division durch ergibt für , und es folgt Die Folge ist ab monoton fallend und durch nach unten beschränkt, nach also konvergent, etwa gegen . Da beide Seiten der Rekursion für gegen bzw. konvergieren, erfüllt die Fixpunktgleichung . Multiplizieren mit , Abziehen von und Multiplizieren mit ergibt nacheinander und wegen folgt schließlich .  Wie schnell das geht, zeigt . Die ersten Schritte von Hand: und gerundet verglichen mit . Die Anzahl korrekter Stellen verdoppelt sich ungefähr mit jedem Schritt — schon nach vier Iterationen stimmen mehr als zehn Nachkommastellen. Ähnliche Iterationsverfahren werden in Taschenrechnern und Programmbibliotheken eingesetzt.  Dieses Prinzip — eine Näherung durch wiederholtes Anwenden einer Vorschrift schrittweise verbessern, bis sich die Folge der Näherungen stabilisiert — liegt nicht nur dem Newton-Verfahren zugrunde, sondern auch den iterativen Optimierungsverfahren, mit denen in der Data Science die Parameter von Lernmodellen bestimmt werden. Das einfachste davon sehen wir uns jetzt an.   "
},
{
  "id": "ex-anwendung-gradientenabstieg-folge",
  "level": "2",
  "url": "sec-folgen.html#ex-anwendung-gradientenabstieg-folge",
  "type": "Beispiel",
  "number": "2.1.27",
  "title": "Anwendungsbeispiel: Gradientenabstieg als geometrische Folge.",
  "body": " Anwendungsbeispiel: Gradientenabstieg als geometrische Folge   Der Gradientenabstieg sucht das Minimum einer Verlustfunktion, indem er von einem Startwert aus wiederholt ein Stück bergab geht — bei einer Funktion einer Variablen gegen das Vorzeichen der Steigung. Für die einfachste Verlustfunktion (Minimum bei , Steigung ) lautet die Vorschrift mit Lernrate  : Für die Spielzeugfunktion braucht man das Verfahren natürlich nicht — ihr Minimum sieht man sofort. Es geht um die Idee: Dasselbe Vorgehen funktioniert genauso, wenn die Verlustfunktion wie beim Deep Learning von Milliarden von Parametern abhängt und niemand ihr Minimum mehr sehen kann.  Bestimmen Sie eine explizite Formel für , und entscheiden Sie, für welche Lernraten die Folge gegen das Minimum konvergiert. Was passiert konkret für , und ?    Jeder Schritt multipliziert mit demselben Faktor , also ist — eine geometrische Folge. Nach gilt genau dann, wenn , d. h. . Wir ziehen überall ab und teilen dann durch . Dabei gilt die Regel: Multipliziert man eine Ungleichung mit einer negativen Zahl oder teilt man sie durch eine negative Zahl, so kehren sich die Ungleichheitszeichen um. also .    : , also — langsame, monotone Annäherung.  : , also — das Minimum wird in einem einzigen Schritt getroffen.  : , also — die Folge springt mit wachsendem Betrag um das Minimum herum und divergiert.     Gradientenabstieg für mit Startwert : die Punkte auf der Parabel für drei Lernraten. Für rücken sie monoton zum Minimum, für landet schon genau im Minimum, für springen sie mit wachsendem Betrag hin und her (rechts ein größerer Ausschnitt).    Drei kleine Bilder nebeneinander, jedes mit der Parabel und farbig markierten Iterierten, die durch Pfeile verbunden sind. Links, blau, : Die Punkte starten bei und rücken auf dem rechten Ast der Parabel in immer kleineren Schritten zum Tiefpunkt, ohne die Seite zu wechseln ( , , , und weiter). Mitte, grün, : ein einziger Pfeil von direkt in den Tiefpunkt . Rechts, orange, , mit größerem Ausschnitt von bis : Die Pfeile springen abwechselnd auf den linken und rechten Ast und steigen dabei immer höher ( , , , , ).      Schon bei der einfachsten Verlustfunktion entscheidet also allein die Lernrate darüber, ob das Verfahren konvergiert, wie schnell es das tut oder ob es explodiert . In lernen wir die Steigung als Ableitung kennen und führen den Gradientenabstieg für allgemeinere Funktionen von Hand aus.   "
},
{
  "id": "ssub-monotone-folgen-iterationen-6",
  "level": "2",
  "url": "sec-folgen.html#ssub-monotone-folgen-iterationen-6",
  "type": "Absatz (with a defined term)",
  "number": "",
  "title": "",
  "body": "Fixpunktgleichung "
},
{
  "id": "ex-anwendung-kundenstamm-fixpunkt",
  "level": "2",
  "url": "sec-folgen.html#ex-anwendung-kundenstamm-fixpunkt",
  "type": "Beispiel",
  "number": "2.1.29",
  "title": "Anwendungsbeispiel: Kundenstamm mit Abwanderung.",
  "body": " Anwendungsbeispiel: Kundenstamm mit Abwanderung   Ein Streamingdienst hat zu Jahresbeginn Abonnenten. Jedes Jahr kündigen der Kunden (die Churn-Rate , eine der wichtigsten Kennzahlen der Kundenanalyse), und neue kommen hinzu. Für den Bestand nach Jahren gilt also Zeigen Sie, dass konvergiert, und bestimmen Sie den langfristigen Kundenbestand.    Die ersten Glieder , , legen nahe, dass der Bestand wächst — aber immer langsamer. Den Kandidaten für den Grenzwert liefert die Fixpunktgleichung , also . Bevor wir als Grenzwert akzeptieren, sichern wir die Konvergenz — der Kandidat liefert dafür gleich die passende Schranke.   Beschränkt: Ist , so ist . Da , bleibt die Folge also Schritt für Schritt unter . Monoton:  , und das ist positiv, solange — also immer. Nach konvergiert , und der Grenzwert ist der Fixpunkt .  Man kann sogar genauer hinsehen: Zieht man die Fixpunktgleichung von der Rekursion ab, also die zweite Zeile von der ersten, so fällt die weg, und man erhält Der Abstand zum Gleichgewicht ist also eine geometrische Folge. Wendet man diese Beziehung immer wieder an, so folgt also Probe: , wie oben. Wegen ist nach etwa sieben Jahren die Hälfte des Weges zum Gleichgewicht geschafft. Wirtschaftlich interessant: Der Endbestand hängt gar nicht vom Startwert ab, sondern nur vom Verhältnis Neukunden pro Jahr durch Kündigungsquote . Wer ihn erhöhen will, muss an einer der beiden Stellschrauben drehen.  Zum Vergleich der Kredit aus : Auch hat einen Fixpunkt, nämlich — bei dieser Restschuld würde die Rate gerade die Zinsen decken, und die Schuld bliebe ewig gleich. Dort ist der Faktor aber , der Abstand zum Fixpunkt wächst also von Jahr zu Jahr: Wer mit weniger Schulden startet, ist irgendwann schuldenfrei, wer mit mehr startet, versinkt immer tiefer. Ob ein Fixpunkt anzieht oder abstößt, entscheidet der Faktor vor .   "
},
{
  "id": "ex-anwendung-stetige-verzinsung",
  "level": "2",
  "url": "sec-folgen.html#ex-anwendung-stetige-verzinsung",
  "type": "Beispiel",
  "number": "2.1.30",
  "title": "Anwendungsbeispiel: Vom Zinseszins zur stetigen Verzinsung.",
  "body": " Anwendungsbeispiel: Vom Zinseszins zur stetigen Verzinsung   Ein Kapital wird über ein Jahr mit Zinssatz verzinst. Statt der Verzinsung einmal am Jahresende zerlegen wir das Jahr in gleich lange Perioden und verzinsen in jeder Periode mit dem anteiligen Satz , wobei die Zinsen jeweils sofort mitverzinst werden (Zinseszins). Das Endkapital nach einem Jahr ist dann Was passiert mit , wenn man die Verzinsungsperiode immer feiner unterteilt, also gehen lässt?    Die Folge ist monoton wachsend und beschränkt (das lässt sich mit der allgemeinen binomischen Formel, dem binomischen Lehrsatz, nachrechnen; wie in gilt: In der Vorlesung wird er weder behandelt noch vorausgesetzt, siehe Binomischer Lehrsatz ), nach also konvergent. Ihr Grenzwert ist gerade die Exponentialfunktion an der Stelle : (Für ist das eine der üblichen Definitionen der Eulerschen Zahl .) Damit konvergiert die Folge der Endkapitale gegen den Grenzfall der stetigen Verzinsung . Anders als man vielleicht vermuten würde, führt beliebig feine Unterteilung der Verzinsungsperiode also nicht zu unbegrenztem Wachstum, sondern zu einem endlichen Grenzwert — ein Effekt, der in der Finanzmathematik zur Modellierung kontinuierlicher Verzinsung verwendet wird, und dieselbe Exponentialfunktion , die uns bei Wachstums- und Zerfallsprozessen in wiederbegegnen wird.  Zahlenbeispiel: Bei  € und ergibt jährliche Verzinsung  €, monatliche  € und stetige  €. Der Unterschied zwischen monatlicher und stetiger Verzinsung beträgt also nur elf Cent.   "
},
{
  "id": "ex-anwendung-trainingsfehler",
  "level": "2",
  "url": "sec-folgen.html#ex-anwendung-trainingsfehler",
  "type": "Beispiel",
  "number": "2.1.31",
  "title": "Anwendungsbeispiel: Der Trainingsfehler vom Anfang (zur Vertiefung).",
  "body": " Anwendungsbeispiel: Der Trainingsfehler vom Anfang (zur Vertiefung)   Ein Lernverfahren meldet nach den Trainingsepochen die Fehler . Gegen welchen Wert strebt der Fehler vermutlich, wenn man weitertrainiert, und lohnt sich das?     Die Daten. Wir bezeichnen mit den Fehler nach Epoche und mit die Abnahme von Epoche zu Epoche . Die Tabelle zeigt beide und den Quotienten aufeinanderfolgender Abnahmen:                                         Die Abnahmen. Von Epoche zu Epoche sinkt der Fehler um , dann um , dann um , und . Die Quotienten , und zeigen: Jede Abnahme ist ungefähr ein Drittel der vorigen, zuletzt mit eher knapp die Hälfte.   Die Brücke zum Modell. Als Modell nehmen wir die Rekursion aus dem Absatz nach , mit unbekannten Konstanten und . Sie beschreibt den Fehler selbst, nicht seine Abnahme. Schreibt man sie für zwei aufeinanderfolgende Epochen hin, und zieht die zweite Gleichung von der ersten ab, so fällt weg: (für die zweite Form beide Seiten mit multiplizieren). Die Abnahmen bilden also eine geometrische Folge mit demselben Faktor wie die Rekursion — genau das beobachten wir in den Daten, mit . Nach demselben Absatz schrumpft mit dem Faktor auch der Abstand des Fehlers zum Grenzwert . Es sind also drei Größen im Spiel: Der Fehler strebt gegen ; seine Abnahmen und sein Abstand zum Grenzwert schrumpfen in jeder Epoche auf etwa ein Drittel.   Die Reihe. Um wie viel sinkt der Fehler nach der letzten Messung insgesamt noch? Mit der letzten Abnahme sind die künftigen Abnahmen , , und so fort, die gesamte noch ausstehende Abnahme ist also eine unendliche Summe der Glieder einer geometrischen Folge. Ihre ersten Teilsummen für sind , dann , dann gerundet Sie wachsen, aber immer langsamer, und scheinen sich bei einzupendeln. Wann eine solche unendliche Summe einen endlichen Wert hat und wie man ihn ausrechnet, ist genau das Thema des nächsten Abschnitts, .   Der Grenzwert. Als Vorgriff benutzen wir die Formel aus : Für ist (mit dem ersten Glied ) Mit ergibt sich , also Mit dem zuletzt beobachteten Quotienten wäre die ausstehende Abnahme und — ebenfalls rund . Der Fehler strebt also gegen rund , nicht gegen , und langes Weitertrainieren bringt kaum noch etwas.   Der Vorbehalt. Aber denken Sie an das Kreisexperiment vom Anfang von : Sechs Werte beweisen nichts. Die Prognose steht und fällt mit der Annahme, dass sich die Abnahmen weiter ungefähr dritteln — eine Modellannahme, keine Folgerung aus den Daten.   "
},
{
  "id": "sub-zusammenfassung-2-1-2",
  "level": "2",
  "url": "sec-folgen.html#sub-zusammenfassung-2-1-2",
  "type": "Absatz (with a defined term)",
  "number": "",
  "title": "",
  "body": "Folge: Beschränkt: Monoton: Konvergenz Rechenregeln: Sandwich-Satz: Grundbausteine: Monoton und beschränkt konvergent. Anwendungen: "
},
{
  "id": "exercise-buch-explizit-rekursiv",
  "level": "2",
  "url": "sec-folgen.html#exercise-buch-explizit-rekursiv",
  "type": "Übung",
  "number": "2.1.4.1",
  "title": "",
  "body": "  Geben Sie die ersten vier Glieder der Folge an. Geben Sie außerdem die ersten vier Glieder der rekursiv definierten Folge , an, und finden Sie eine explizite Formel für .    Einsetzen liefert , , , . Für die rekursive Folge ist , , , — jedes weitere Glied ist um kleiner als das vorherige, also .   "
},
{
  "id": "exercise-buch-monotonie-grenzwert",
  "level": "2",
  "url": "sec-folgen.html#exercise-buch-monotonie-grenzwert",
  "type": "Übung",
  "number": "2.1.4.2",
  "title": "",
  "body": "  Zeigen Sie, dass monoton fallend und beschränkt ist, und bestimmen Sie den Grenzwert.    Wir schreiben um: Mit wachsendem wird kleiner, also streng monoton fallend; da für alle , ist , also durch nach unten beschränkt; nach oben ist sie wegen der Monotonie durch beschränkt. Nach dem Satz über monotone, beschränkte Folgen konvergiert , und wegen ist    "
},
{
  "id": "exercise-buch-grenzwertsaetze-rational",
  "level": "2",
  "url": "sec-folgen.html#exercise-buch-grenzwertsaetze-rational",
  "type": "Übung",
  "number": "2.1.4.3",
  "title": "",
  "body": "  Bestimmen Sie .    Division von Zähler und Nenner durch die höchste auftretende Potenz :    "
},
{
  "id": "exercise-buch-medikamentenspiegel",
  "level": "2",
  "url": "sec-folgen.html#exercise-buch-medikamentenspiegel",
  "type": "Übung",
  "number": "2.1.4.4",
  "title": "",
  "body": "  Eine Patientin nimmt jeden Morgen  mg eines Wirkstoffs ein; bis zum nächsten Morgen baut ihr Körper die Hälfte der jeweils vorhandenen Menge ab. Für die Wirkstoffmenge (in mg) direkt nach der -ten Einnahme gilt , .  Berechnen Sie , und .  Zeigen Sie, dass für alle gilt und dass die Folge monoton wachsend ist.  Bestimmen Sie den Grenzwert.        , , .  Ist , so ist ; wegen gilt die Schranke also für alle . Außerdem ist , weil .  Monoton und beschränkt, also konvergent. Der Grenzwert erfüllt die Fixpunktgleichung , also : Auf Dauer pendelt sich die Wirkstoffmenge nach der Einnahme bei  mg ein, dem Doppelten der Tagesdosis.     "
},
{
  "id": "exercise-buch-sandwich-sinus",
  "level": "2",
  "url": "sec-folgen.html#exercise-buch-sandwich-sinus",
  "type": "Übung",
  "number": "2.1.4.5",
  "title": "",
  "body": "  Zeigen Sie mit dem Sandwich-Satz, dass eine Nullfolge ist.    Da für alle , gilt Beide einschließenden Folgen und konvergieren gegen . Nach dem Sandwich-Satz konvergiert also auch gegen .   "
},
{
  "id": "sec-reihen",
  "level": "1",
  "url": "sec-reihen.html",
  "type": "Abschnitt",
  "number": "2.2",
  "title": "Reihen",
  "body": " Reihen    Nach diesem Abschnitt können Sie    eine Reihe als Folge ihrer Partialsummen erklären und sagen, was Konvergenz und absolute Konvergenz einer Reihe bedeuten;  geometrische Reihen summieren, auch mit verschobenem Startindex;  das notwendige Kriterium, Majoranten- und Minorantenkriterium, Quotienten-, Wurzel- und Leibniz-Kriterium anwenden — und das passende Kriterium für eine gegebene Reihe auswählen;  an der harmonischen und der alternierenden harmonischen Reihe erklären, warum Nullfolge nicht reicht und warum konvergent nicht absolut konvergent bedeutet;  Annuitäten, Barwerte, diskontierte Belohnungen und Lernraten-Bedingungen als Reihen lesen und den Abbruchfehler einer Reihe mit einer geometrischen Majorante abschätzen.     Kann eine Summe aus unendlich vielen positiven Zahlen endlich sein? sagt ja — die Summe ist . sagt nein — sie wächst über jede Grenze, obwohl die Summanden genauso gegen null gehen. Der Unterschied ist nicht offensichtlich, und genau deshalb braucht es einen präzisen Konvergenzbegriff für unendliche Summen und eine Handvoll Kriterien, mit denen man Konvergenz entscheidet, ohne die Summe zu kennen.  Der Abschnitt beginnt mit dem Begriff der Reihe und ihrem wichtigsten Vertreter, der geometrischen Reihe, mit der Sie Kredite, Renten und diskontierte Gesamterträge im Reinforcement Learning ausrechnen. Danach folgen die Konvergenzkriterien, jeweils mit Beispielen, die zeigen, was sie leisten und wo ihre Grenzen liegen. Unterwegs ragen Bücher über eine Tischkante hinaus, ein Computer berechnet , und eine Reihe ändert ihre Summe, nur weil man ihre Summanden umsortiert.    Begriff einer Reihe   Stellen Sie sich vor, Sie laufen auf eine Wand zu, die zwei Meter entfernt ist. Mit dem ersten Schritt legen Sie einen Meter zurück, mit jedem weiteren Schritt die Hälfte des vorigen: , dann , dann Meter und so fort. Kommen Sie je an der Wand an? Nach jedem Schritt fehlt noch genau so viel, wie Sie zuletzt gelaufen sind — Sie erreichen die Wand also nie, kommen ihr aber beliebig nahe. Der Weg, den Sie insgesamt zurücklegen, ist   Schon der griechische Philosoph Zenon von Elea (5. Jahrhundert v. Chr.) ersann solche Gedankenexperimente — allerdings, um zu beweisen , dass Bewegung unmöglich sei. Dahinter steckt genau die Frage vom Anfang dieses Abschnitts. Die Antwort liefert der Grenzwertbegriff aus . Man addiert schrittweise, betrachtet die Folge der Zwischenergebnisse und fragt, ob sie konvergiert. Eine Reihe ist also nichts anderes als eine Folge ganz besonderer Bauart, und alles, was wir über Folgen wissen, lässt sich auf unendliche Summen übertragen.    Reihen und Partialsummen   Reihe, Partialsumme, Konvergenz   Sei eine reelle oder komplexe Folge. Den formalen Ausdruck nennt man (unendliche) Reihe . Die Folge der Partialsummen (oder Teilsummen ) ist dabei selbst wieder eine gewöhnliche Folge. Konvergiert , so heißt die Reihe konvergent , und man nennt die Summe der Reihe , geschrieben . Eine nicht-konvergente Reihe heißt divergent . Die Reihe heißt absolut konvergent , wenn die Reihe der Beträge konvergiert. Jede absolut konvergente Reihe ist insbesondere auch konvergent — die Umkehrung gilt nicht, wie wir in diesem Abschnitt sehen werden.     Eine Reihe ist keine wirklich unendliche Summe  Es gibt in der Mathematik keine tatsächlich unendlichen Summen: Die Schreibweise ist eine rein symbolische Abkürzung. Für eine konvergente Reihe steht der Ausdruck exakt für den wohldefinierten Sachverhalt — nichts anderes. Diese Präzisierung ist mehr als Spitzfindigkeit: Rechenregeln, die für endliche Summen selbstverständlich sind (etwa beliebiges Umordnen der Summanden), gelten für unendliche Reihen im Allgemeinen nicht mehr ohne Weiteres. Wir werden zulässige Rechenregeln für konvergente Reihen weiter unten explizit festhalten.    Die Partialsummen des Leitbeispiels   Berechnen Sie für die Partialsummen , finden Sie eine Formel für , und bestimmen Sie die Summe der Reihe.    Schrittweise addieren: Der Abstand zur halbiert sich mit jedem Schritt: , , , …, allgemein Wegen konvergiert gegen , also ist ( ). Man beachte: Die Summe wird von keiner Partialsumme erreicht, sie ist der Grenzwert.   Die Partialsummen von auf dem Zahlenstrahl: Jeder Summand überbrückt die Hälfte des verbleibenden Abstands zur .    Ein Zahlenstrahl von bis . Markiert sind die Partialsummen , , , und . Bögen über dem Strahl zeigen die Summanden , , , , die immer kürzer werden und sich der annähern.        Dass eine Reihe konvergiert, ist keineswegs selbstverständlich. Die einfachste Reihe überhaupt zeigt das Gegenteil — und sie kommt mit einer berühmten Anekdote daher.   Der kleine Gauß und eine divergente Reihe (zur Vertiefung)   Carl Friedrich Gauß soll als Grundschüler von seinem Lehrer die Aufgabe bekommen haben, die Zahlen von bis zu addieren — in der Hoffnung auf eine ruhige Stunde. Gauß war nach wenigen Augenblicken fertig. Bestimmen Sie so geschickt wie er die Partialsummen der Reihe . Konvergiert die Reihe?    Der Trick: Man schreibt die Summe zweimal untereinander, einmal vorwärts und einmal rückwärts, und addiert spaltenweise. Also ist , für den kleinen Gauß . Die Folge der Partialsummen wächst über alle Grenzen, die Reihe divergiert also bestimmt gegen — wenig überraschend, denn die Summanden werden ja immer größer. Interessant wird es erst, wenn die Summanden gegen gehen. Dann kann alles passieren, wie Sie gleich sehen werden.      Die geometrische Reihe  Im Leitbeispiel entsteht jeder Summand aus dem vorigen durch Multiplikation mit demselben Faktor . Reihen dieser Bauart sind die wichtigsten überhaupt — in der Finanzmathematik ebenso wie beim Vergleich mit anderen Reihen —, und für sie gibt es eine geschlossene Formel.   Die geometrische Reihe   Für (oder ) und (oder ) heißt  geometrische Reihe — genau die Bauart, die auch unser Einstiegsbeispiel hat (dort ist , ). Leiten Sie eine geschlossene Formel für die Partialsumme her, und bestimmen Sie, für welche die Reihe konvergiert.    Für ist , was für nicht konvergiert. Sei also . Der Trick ist, mit zu multiplizieren — dabei teleskopiert die Summe. Wir schreiben und aus, und zwar so untereinander, dass gleiche Terme übereinander stehen: Zieht man die zweite Zeile von der ersten ab, heben sich alle Terme von bis weg, und es bleibt In Summenschreibweise lautet dieselbe Rechnung kurz da sich alle mittleren Terme gegenseitig aufheben. Division durch liefert die geschlossene Formel Für gilt ( ), also konvergiert gegen Für und ist keine Nullfolge, die Reihe divergiert also (das notwendige Konvergenzkriterium liefert dies sofort; für sieht man es auch direkt an der Formel für ).     Grenzwerte geometrischer Reihen berechnen   Bestimmen Sie sowie (beachten Sie, dass die zweite Summe erst bei beginnt).    Mit der Formel aus und , (also ): Bei der zweiten Reihe beginnt der Summationsindex erst bei statt bei . Wir ziehen den gemeinsamen Faktor heraus und führen die Summe auf eine bei beginnende geometrische Reihe zurück: (Alternativ hätte man auch die vollständige Summe ab berechnen und die fehlenden Anfangsglieder wieder abziehen können: — beide Wege sind bei Reihen mit verschobenem Startindex gleichermaßen üblich.)     Periodische Dezimalzahlen als geometrische Reihen   Schreiben Sie und als Brüche.    Eine periodische Dezimalzahl ist eine geometrische Reihe: Jeder Block ist hundertmal kleiner als der vorige. Ebenso ist Das überrascht viele: ist nicht knapp unter , sondern genau  . Nach der Definition ist der Grenzwert der Partialsummen , und dieser Grenzwert ist — auch wenn keine der Partialsummen selbst ist.    Auch die endliche Summenformel aus ist für sich genommen nützlich, etwa für Ratenzahlungen.   Anwendungsbeispiel: Die Restschuld eines Kredits explizit   In hatten wir die Restschuld rekursiv berechnet: , . Leiten Sie mit der geometrischen Summenformel eine explizite Formel für her, und prüfen Sie sie für .    Mit und rollen wir die Rekursion auf: und allgemein . Die Klammer ist eine endliche geometrische Summe, also Probe für : , also derselbe Wert wie bei der schrittweisen Rechnung. Mit der expliziten Formel kann man nun auch umgekehrt fragen, welche Rate nötig ist, damit der Kredit nach genau Jahren getilgt ist: Man setzt und löst nach auf. Das ist die Annuitätenformel der Finanzmathematik — und die rechnen wir gleich aus.     Anwendungsbeispiel: Die Annuitätenformel   Bei einem Annuitätendarlehen zahlt man jedes Jahr denselben Betrag (die Annuität ), und zwar so, dass der Kredit nach genau Jahren getilgt ist. Leiten Sie aus der expliziten Formel in eine Formel für her. Wie hoch ist die Annuität für den Kredit über  € bei Zinsen, wenn er in genau vier Jahren getilgt sein soll? Wie viel Zinsen zahlt man insgesamt?    Aus folgt Mit , , und ist (in €) Insgesamt zahlt man  € zurück, davon  € Zinsen. Zum Vergleich: Mit der Rate von  € aus war man ebenfalls nach vier Jahren fertig, die letzte Zahlung war aber krumm. Die Annuität verteilt die Last gleichmäßig — genau so rechnen Banken Ihre monatliche Rate für einen Autokredit oder eine Baufinanzierung aus, nur mit Monaten statt Jahren.     Anwendungsbeispiel: Barwert einer ewigen Rente   In der Investitionsrechnung fragt man häufig nach dem Barwert einer zukünftigen Zahlungsreihe: Wie viel ist eine Serie zukünftiger Zahlungen heute wert, wenn man mit einem periodischen Zinssatz abzinst? Eine ewige Rente zahlt am Ende jeder Periode einen festen Betrag , unbegrenzt oft. Der Barwert einer Zahlung , die erst in Perioden erfolgt, ist (das ist gerade die Umkehrung der Zinseszinsformel aus ). Der Barwert der gesamten ewigen Rente ist daher Zeigen Sie , und berechnen Sie konkret für  € pro Jahr und .    Mit gilt wegen stets , und die Reihe ist geometrisch, nur beginnt sie bei statt : Einsetzen von liefert also , wie behauptet. Für und ergibt sich Eine ewige jährliche Zahlung von  € ist bei Zins heute  € wert — obwohl über die gesamte (unendliche) Laufzeit unbegrenzt viel Geld fließt, ist ihr heutiger Wert endlich, weil spätere Zahlungen immer stärker abgezinst werden.     Anwendungsbeispiel: Diskontierte Belohnung im Reinforcement Learning   Beim Reinforcement Learning lernt ein Agent (etwa ein Lagerroboter oder ein Spielprogramm) durch Belohnungen , die er in aufeinanderfolgenden Zeitschritten erhält. Bewertet wird nicht die nächste Belohnung allein, sondern der diskontierte Gesamtertrag  mit einem Diskontfaktor  , der spätere Belohnungen schwächer gewichtet. Angenommen, der Agent erhält in jedem Schritt dieselbe Belohnung . Bestimmen Sie für und für , und interpretieren Sie den Unterschied.    Für konstante Belohnung ist eine geometrische Reihe mit und , also Für ergibt das , für dagegen . Der Wert ist so etwas wie der Planungshorizont des Agenten: Bei zählen im Wesentlichen die nächsten zehn Schritte, bei die nächsten hundert. Der Diskontfaktor spielt also genau die Rolle des Abzinsungsfaktors aus — Finanzmathematik und Reinforcement Learning rechnen hier mit derselben Reihe.    Die geometrische Reihe ist damit so etwas wie das Schweizer Taschenmesser dieses Abschnitts: Sie verwandelt periodische Dezimalzahlen in Brüche, rechnet Kredite und Renten aus, bewertet Belohnungen im maschinellen Lernen — und im nächsten Unterabschnitt dient sie als Maßstab, an dem wir andere Reihen messen.     Konvergenzkriterien für Reihen   Bei der geometrischen Reihe hatten wir Glück: Für ihre Partialsummen gibt es eine geschlossene Formel. Das ist die Ausnahme. Schon für eine so harmlos aussehende Reihe wie findet man keine einfache Formel für — und trotzdem möchte man wissen, ob sie konvergiert. In der Praxis ist das oft sogar die wichtigere Frage: Ob ein Algorithmus, eine Näherungsformel oder ein Finanzmodell überhaupt einen endlichen Wert liefert, muss geklärt sein, bevor man ihn numerisch ausrechnet.  Dafür gibt es Konvergenzkriterien : Tests, die allein an den Summanden ablesen, ob die Reihe konvergiert. Wir beginnen mit einem Test, der nur Divergenz nachweisen kann, vergleichen dann Reihen miteinander, lernen zwei automatische Kriterien und ein Kriterium für Reihen mit wechselndem Vorzeichen kennen. Am Ende steht eine Strategie, welches Kriterium man wann ausprobiert.    Das notwendige Kriterium und die harmonische Reihe   Notwendiges Konvergenzkriterium   Ist die Reihe konvergent, so ist eine Nullfolge: (Grund: Mit gilt ; konvergiert gegen ein , so auch , also .) Diese Bedingung ist notwendig, aber nicht hinreichend — das folgende Beispiel zeigt eine Reihe, deren Glieder eine Nullfolge bilden, die aber trotzdem divergiert.     Die harmonische Reihe divergiert   Zeigen Sie, dass die harmonische Reihe  divergiert, obwohl eine Nullfolge ist.    Wir schätzen die Partialsumme nach unten ab, indem wir die Summanden in Blöcke der Länge gruppieren: Der -te Block (für ) enthält Summanden, von denen jeder mindestens so groß ist wie der letzte, kleinste Summand des Blocks. Also ist jeder Block mindestens groß. Da es solche Blöcke gibt, folgt Für wächst diese untere Schranke über alle Grenzen, also ist und damit auch unbeschränkt und somit divergent. Die harmonische Reihe ist damit das Standardbeispiel dafür, dass das notwendige Kriterium nicht hinreichend ist — wir werden sie im Rest dieses Abschnitts noch mehrfach als Vergleichsreihe verwenden.  Wie tückisch diese Divergenz ist, zeigen ein paar Zahlen: Die Summe der ersten tausend Glieder ist erst , und um die zu überschreiten, braucht man Summanden. Wer nur auf eine Computerausgabe der ersten Partialsummen schaut, würde leicht auf Konvergenz tippen.    Dass die harmonische Reihe so extrem langsam, aber eben doch über jede Grenze wächst, hat handfeste und manchmal verblüffende Folgen. Zwei davon sehen Sie jetzt: eine zum Ausprobieren auf dem Schreibtisch und eine aus der Textanalyse.   Anwendungsbeispiel: Ein Bücherstapel über der Tischkante   Sie stapeln gleiche Bücher der Länge an einer Tischkante übereinander, jedes Buch auf dem vorigen, und schieben sie so weit wie möglich nach rechts hinaus, ohne dass der Stapel kippt. Ein Stapel ist stabil, solange für jedes Buch gilt: Der gemeinsame Schwerpunkt aller Bücher darüber liegt nicht rechts von seiner rechten Kante; ebenso darf der Schwerpunkt des ganzen Stapels nicht rechts der Tischkante liegen. Man kann zeigen, dass der Überhang am größten wird, wenn das -te Buch von oben genau um über das Buch darunter (bzw. über die Tischkante) hinausragt. Wie weit ragt der oberste Buchrand dann insgesamt über die Tischkante? Geht mehr als eine ganze Buchlänge?    Der gesamte Überhang ist die Summe der einzelnen Überstände: also die halbe -te Partialsumme der harmonischen Reihe. Schon bei vier Büchern ist das : Das oberste Buch liegt komplett jenseits der Tischkante, kein Stück davon ist mehr über dem Tisch ( ). Weil die harmonische Reihe divergiert, lässt sich der Überhang mit genügend Büchern sogar beliebig groß machen. Allerdings braucht man für zwei Buchlängen Überhang schon Bücher, für drei und für zehn rund Millionen — die Divergenz ist real, aber quälend langsam.  Woher die Überstände kommen, lässt sich mit dem Schwerpunkt als Mittelwert begründen: Liegt der gemeinsame Schwerpunkt der oberen Bücher genau über der rechten Kante von Buch , und hat Buch seinen eigenen Schwerpunkt weiter links, so liegt der Schwerpunkt aller Bücher beim gewichteten Mittel , also genau links der Kante. Dort muss die Kante des nächsten Buches liegen.   Vier Bücher der Länge , optimal gestapelt: Die Überstände betragen von oben nach unten , , und ; das oberste Buch ragt insgesamt über die Tischkante.    Ein Tisch links, dessen rechte Kante durch eine senkrechte gestrichelte Linie markiert ist. Darauf liegen vier gleich lange Bücher als flache Rechtecke übereinander, jedes gegenüber dem darunterliegenden nach rechts verschoben. Das unterste Buch ragt um ein Achtel über die Tischkante, das oberste liegt vollständig rechts der Tischkante; sein rechter Rand ist um Buchlängen von der Kante entfernt.         Anwendungsbeispiel: Das Zipfsche Gesetz in der Textanalyse   Zählt man in einem großen Textkorpus, wie oft jedes Wort vorkommt, und sortiert die Wörter nach Häufigkeit, so beobachtet man erstaunlich genau das Zipfsche Gesetz : Das -häufigste Wort kommt ungefähr -mal so oft vor wie das häufigste. Bei einem Wortschatz von Wörtern ist der Anteil der häufigsten Wörter am gesamten Text dann Welchen Anteil eines Textes decken die häufigsten Wörter ab, wenn der Wortschatz Wörter umfasst? Verwenden Sie , und die Näherung für große (die Zahl heißt Euler-Mascheroni-Konstante).    Mit ist der Anteil Die häufigsten Wörter — der , die , und , in , … — machen also fast die Hälfte eines typischen Textes aus, obwohl sie nur des Wortschatzes sind. Das ist der Grund, warum man in der Textanalyse solche Stoppwörter oft herausfiltert, bevor man nach inhaltlich interessanten Begriffen sucht. Und die langsame Divergenz der harmonischen Reihe zeigt sich hier von ihrer praktischen Seite: Weil nur logarithmisch mit dem Wortschatz wächst, ändert auch ein doppelt so großer Wortschatz an diesem Bild wenig.      Vergleichskriterien  Die Idee des nächsten Kriteriums kennt jeder aus dem Alltag: Wer weniger ausgibt als jemand, dessen Ausgaben begrenzt sind, hat selbst begrenzte Ausgaben. Bei Reihen mit nichtnegativen Gliedern sind die Partialsummen monoton wachsend; bleiben sie unter einer Schranke, konvergieren sie nach .   Majorantenkriterium   Die Reihe soll auf Konvergenz untersucht werden.    Gibt es eine konvergente Reihe mit , so dass für alle ab einem Index , so konvergiert (sogar absolut). Man nennt eine konvergente Majorante .  Gibt es eine divergente Reihe mit , so dass für alle ab einem Index , so divergiert . Man nennt eine divergente Minorante . (Hier müssen die selbst — nicht nur ihre Beträge — über liegen: Mit folgt nur, dass nicht absolut konvergiert; die alternierende harmonische Reihe weiter unten zeigt, dass sie trotzdem konvergieren kann.)       Majorantenkriterium anwenden   Untersuchen Sie und auf Konvergenz.    Für die erste Reihe gilt für alle , also Die geometrische Reihe konvergiert ( ), ist also eine konvergente Majorante: konvergiert.  Für die zweite Reihe gilt für alle , also . Die harmonische Reihe divergiert ( ), ist also eine divergente Minorante: divergiert ebenfalls.     Anwendungsbeispiel: Schrittweiten beim stochastischen Gradientenabstieg   Beim stochastischen Gradientenabstieg (SGD), mit dem in der Data Science die Parameter vieler Modelle trainiert werden, verwendet man in jedem Schritt eine Schrittweite (Lernrate) . Damit das Verfahren garantiert konvergiert, fordert man klassischerweise die Robbins–Monro-Bedingungen  Die erste Bedingung stellt sicher, dass die Summe der Schritte groß genug ist, um von jedem Startpunkt aus jeden Punkt erreichen zu können; die zweite, dass die Schritte schnell genug schrumpfen, damit sich das Rauschen der stochastischen Gradienten im Mittel herausmittelt. Zeigen Sie, dass die klassische Wahl beide Bedingungen erfüllt.    Die erste Bedingung ist genau die Divergenz der harmonischen Reihe , die wir in gezeigt haben.  Für die zweite Bedingung zeigen wir konvergiert, mit dem Majorantenkriterium. Für gilt die Partialbruchzerlegung (eine Technik, die in diesem Kurs weder vorausgesetzt noch behandelt wird — die Gleichung prüft man durch Zusammenfassen der rechten Seite auf den Hauptnenner), und wegen folgt Die rechte Seite ist eine Teleskopreihe: Ihre Partialsumme ist für jedes (alle mittleren Terme heben sich auf), insbesondere ist diese Teleskopreihe konvergent (Grenzwert ) und damit eine konvergente Majorante für . Mit dem -Term dazu ist also auch konvergent (mit Summe kleiner als ). Die Schrittweite erfüllt damit beide Robbins–Monro-Bedingungen — einer der Gründe, warum -artige Zerfallsschemata für die Lernrate in der Optimierung so verbreitet sind.    Eine Majorante leistet oft mehr als den bloßen Konvergenznachweis: Ist sie geometrisch, kann man mit ihr auch abschätzen, wie viel beim Abbruch nach endlich vielen Gliedern noch fehlt. Genau das braucht man, wenn ein Computer eine Reihe tatsächlich auswerten soll.   Anwendungsbeispiel: Wie berechnet ein Computer ?   Man kann zeigen, dass gilt. Abgebrochene Potenzreihen dieser Art stecken — nach geschickter Verkleinerung des Arguments und mit leicht optimierten Koeffizienten — hinter der Funktion exp in vielen Programmbibliotheken.  Zeigen Sie mit dem Majorantenkriterium, dass die Reihe konvergiert, und folgern Sie .  Berechnen Sie die Partialsumme , und schätzen Sie den Fehler mit einer geometrischen Reihe ab.        Für ist , also . Die geometrische Reihe ist eine konvergente Majorante, und .  . Für den Rest ziehen wir vor die Klammer; jeder weitere Faktor im Nenner ist mindestens : Tatsächlich ist , der Fehler also — die Schranke ist fast exakt.    Sieben Summanden liefern also schon drei korrekte Nachkommastellen, und die Fehlerschranke sagt vorab, wann man aufhören darf. Weil die Fakultät im Nenner so schnell wächst, reichen für die volle Rechengenauigkeit eines Computers (etwa Stellen) knapp zwanzig Summanden.      Quotienten- und Wurzelkriterium  Für Vergleichskriterien braucht man eine passende Vergleichsreihe, und die zu finden erfordert Erfahrung. Die folgenden beiden Kriterien arbeiten dagegen automatisch : Man berechnet einen Grenzwert und liest das Ergebnis ab. Beide beruhen auf einem Vergleich mit der geometrischen Reihe — wenn die Glieder auf lange Sicht mindestens so schnell schrumpfen wie mit , konvergiert die Reihe.   Quotientenkriterium   Sei eine Reihe mit für alle ab einem Index, und die Folge konvergiere.    Falls , so ist absolut konvergent.  Falls , so ist divergent.    Im Grenzfall liefert das Kriterium keine Aussage: Sowohl die divergente harmonische Reihe als auch die konvergente Reihe haben Quotientengrenzwert . Dann muss ein anderes Kriterium herangezogen werden, etwa ein Vergleich mit einer bekannten Reihe.     Quotientenkriterium: einmal Konvergenz, einmal Divergenz   Untersuchen Sie und auf Konvergenz.    Für kürzen sich die Dreierpotenzen fast vollständig: Die erste Reihe konvergiert also (absolut). Für ist die zweite Reihe divergiert. Das passt zur Wachstumshierarchie aus : Die Exponentialfunktion setzt sich gegen jede Potenz von durch — im Nenner sorgt sie für Konvergenz, im Zähler für Divergenz.     Quotientenkriterium anwenden (zur Vertiefung)   Untersuchen Sie auf Konvergenz.    Mit gilt Aus wissen wir bereits , also Nach dem Quotientenkriterium konvergiert die Reihe (absolut).     Wurzelkriterium   Sei eine Reihe, und die Folge konvergiere.    Falls , so ist absolut konvergent.  Falls , so ist divergent.       Wurzelkriterium anwenden   Untersuchen Sie auf Konvergenz.    Hier zieht die -te Wurzel die -te Potenz glatt zurück, ohne dass — wie beim Quotientenkriterium — erst gekürzt werden müsste: Nach dem Wurzelkriterium konvergiert die Reihe (absolut). Dieses Beispiel zeigt, warum es sich lohnt, bei Reihen mit einer Potenz zuerst das Wurzelkriterium zu probieren: Es vermeidet hier die etwas unhandlichere Quotientenbildung ganz.      Alternierende Reihen  Alle bisherigen Kriterien liefern, wenn sie Konvergenz zeigen, sogar absolute Konvergenz. Wechseln die Vorzeichen der Summanden ab, können sich positive und negative Glieder aber gegenseitig ausgleichen, und die Reihe kann konvergieren, obwohl die Reihe der Beträge divergiert.   Leibniz-Kriterium für alternierende Reihen   Sei eine monoton fallende, reelle Nullfolge mit . Dann konvergiert die alternierende Reihe  .     Fehlerabschätzung beim Leibniz-Kriterium  Unter den Voraussetzungen des Leibniz-Kriteriums oszillieren die Partialsummen mit stetig kleiner werdender Amplitude um den Grenzwert : Aufeinanderfolgende Partialsummen liegen abwechselnd über und unter und schließen so immer enger ein. Daraus folgt die nützliche Fehlerabschätzung — der Fehler beim Abbruch nach dem -ten Glied ist höchstens so groß wie der Betrag des ersten weggelassenen Gliedes. Das erlaubt es, vorab abzuschätzen, wie viele Glieder für eine gewünschte Genauigkeit nötig sind, ohne den (oft unbekannten) Grenzwert selbst zu kennen — ein Prinzip, das auch bei der Fehlerabschätzung abgebrochener Reihenapproximationen (etwa von Taylorreihen) verwendet wird.    Die alternierende harmonische Reihe: konvergent, aber nicht absolut   Zeigen Sie, dass konvergiert, aber nicht absolut konvergiert.    Die Folge ist eine monoton fallende Nullfolge, also konvergiert die Reihe nach dem Leibniz-Kriterium. Die Reihe der Beträge ist aber also genau die harmonische Reihe, die nach divergiert. Die Reihe konvergiert also, aber nicht absolut — man nennt eine solche Reihe bedingt konvergent . (Man kann zeigen, dass ihre Summe ist; das würde hier aber zu weit führen.) Dieses Beispiel zeigt insbesondere, dass die Umkehrung der Aussage absolut konvergent konvergent aus tatsächlich falsch ist.    Bedingt konvergente Reihen sind empfindliche Gebilde. Bei endlichen Summen darf man die Summanden beliebig umsortieren — bei einer bedingt konvergenten Reihe nicht, wie das nächste, zunächst unglaublich wirkende Beispiel zeigt. Es ist genau die Warnung aus , jetzt mit Zahlen.   Umordnen verändert die Summe   Sei die Summe der alternierenden harmonischen Reihe. Wir ordnen dieselben Summanden um: jeweils ein positiver, dann zwei negative, Überzeugen Sie sich, dass jeder Summand von genau einmal vorkommt, und zeigen Sie .    Die positiven Summanden kommen in der alten Reihenfolge vor, und die negativen und durchlaufen zusammen alle geraden Nenner — jeder Summand wird also genau einmal verwendet. Jetzt fassen wir in Dreiergruppen zusammen und vereinfachen jeweils die ersten beiden Glieder, wobei ist: Für ergibt das (Weil die Summanden gegen gehen, ändert das Zusammenfassen zu Dreiergruppen nichts am Grenzwert.) Dieselben Zahlen, anders sortiert, ergeben also die halbe Summe — mit ist . Bernhard Riemann hat sogar gezeigt, dass man eine bedingt konvergente Reihe durch geschicktes Umordnen gegen jede beliebige Zahl konvergieren lassen kann. Bei absolut konvergenten Reihen passiert so etwas nie; dort ist Umordnen erlaubt.     Wie viele Glieder braucht man?   Um 1735 bewies Leonhard Euler zur Verblüffung seiner Zeitgenossen, dass ist — das Basler Problem , an dem sich zuvor unter anderem Jakob Bernoulli vergeblich versucht hatte. Daraus folgt auch (den Beweis führen wir hier nicht). Wie viele Glieder muss man addieren, damit die Fehlerabschätzung des Leibniz-Kriteriums einen Fehler kleiner als garantiert? Vergleichen Sie mit der Reihe für aus und mit der alternierenden harmonischen Reihe.    Die Beträge bilden eine monoton fallende Nullfolge, also gilt die Fehlerabschätzung . Wir brauchen ; wegen und ist das ab , also der Fall. Die Abschätzung garantiert die gewünschte Genauigkeit also spätestens nach Summanden ( ). Tatsächlich reichen schon — die Schranke ist vorsichtig, aber sie ist garantiert.  Zum Vergleich: Bei der Reihe für genügten sieben Summanden. Bei der alternierenden harmonischen Reihe liefert die Abschätzung , und die garantiert einen Fehler unter erst nach rund tausend Gliedern. Entscheidend ist, wie schnell die Summanden klein werden: fällt rasant, ordentlich, nur zäh. Die Fehlerabschätzung garantiert also Konvergenz, sagt aber auch ehrlich, wie langsam sie sein kann.      Rechenregeln und Überblick  Zum Schluss halten wir fest, welche Rechenregeln für konvergente Reihen tatsächlich gelten, und fassen zusammen, wie man bei einer unbekannten Reihe am besten vorgeht.   Welches Kriterium wann?  Die Kriterien greifen jeweils für typische Bauarten von Reihen. Eine bewährte Reihenfolge beim Untersuchen einer Reihe :    Nullfolge? Geht nicht gegen , ist man fertig: Die Reihe divergiert.  Potenz im Glied? Wurzelkriterium. Fakultäten oder -te Potenzen fester Zahlen ( , )? Quotientenkriterium.  Wechselndes Vorzeichen mit monoton fallenden Beträgen? Leibniz-Kriterium (und die Fehlerabschätzung gratis dazu).  Sonst — insbesondere bei gebrochen-rationalen Gliedern wie — Vergleich mit einer bekannten Reihe: geometrische Reihe und als konvergente Majoranten, und als divergente Minoranten.    Liefert Quotienten- oder Wurzelkriterium den Grenzwert , hilft — sofern Schritt 1 nicht schon entschieden hat — nur noch Schritt 3 oder 4.    Das passende Kriterium auswählen   Entscheiden Sie mit der Strategie aus , ob die folgenden Reihen konvergieren:       Die Potenz lädt zum Wurzelkriterium ein — aber , keine Aussage. Schritt 1 hilft: . Keine Nullfolge, also divergiert die Reihe.  Fakultät: Quotientenkriterium. . Die Reihe konvergiert. Bemerkenswert: Die Summanden wachsen zunächst sogar, bis auf über bei und . Das Kriterium schaut aber nur auf das Langzeitverhalten; endlich viele große Anfangsglieder ändern nichts an der Konvergenz.  Wechselndes Vorzeichen, und ist eine monoton fallende Nullfolge: Nach Leibniz konvergiert die Reihe. Absolut konvergiert sie nicht, denn divergiert ( ).  Gebrochen-rational: Für große ist , also vermuten wir Divergenz. Wegen gilt , und divergiert als halbe harmonische Reihe. Die divergente Minorante zeigt: Die Reihe divergiert.    Bei (a) zeigt sich, warum Schritt 1 immer zuerst kommt: Er hätte den Umweg über das Wurzelkriterium erspart.     Rechenregeln für konvergente Reihen   Seien und konvergente Reihen und (oder ). Dann gelten:    ( Multiplikation mit einer Konstanten ) Die Reihe ist konvergent, und .  ( Summenregel ) Die Reihe ist konvergent, und .  ( Cauchy-Produkt ) Sind und sogar absolut konvergent, so konvergiert auch das Cauchy-Produkt  der beiden Reihen mit , und Die Voraussetzung der absoluten Konvergenz ist hier wesentlich: Für nur bedingt konvergente Reihen kann das Cauchy-Produkt divergieren.       Cauchy-Produkt einer geometrischen Reihe mit sich selbst (zur Vertiefung)   Sei . Bilden Sie das Cauchy-Produkt der geometrischen Reihe mit sich selbst, und überprüfen Sie das Ergebnis numerisch für .    Mit ist der -te Koeffizient des Cauchy-Produkts da jeder der Summanden gleich ist. Die geometrische Reihe ist für absolut konvergent, denn ist selbst eine konvergente geometrische Reihe. Die Regel über das Cauchy-Produkt aus ist also anwendbar, und wir erhalten die Identität Für liefert die rechte Seite . Die linke Seite ist , mit den Partialsummen die sich tatsächlich der nähern. Nebenbei haben wir eine Reihe summiert, ohne eine Formel für ihre Partialsummen zu brauchen — allein durch Multiplizieren zweier geometrischer Reihen.    Damit haben Sie das Handwerkszeug beisammen, um die Frage vom Anfang dieses Abschnitts zu beantworten: Eine unendliche Summe positiver Zahlen ist endlich, wenn ihre Summanden schnell genug klein werden — so schnell wie bei einer geometrischen Reihe oder wie bei . Das bloße gegen null gehen reicht nicht, wie die harmonische Reihe mit ihrem Bücherstapel eindrucksvoll zeigt. Und wechselnde Vorzeichen können eine Reihe retten, machen sie aber empfindlich: Bei bedingter Konvergenz kommt es sogar auf die Reihenfolge der Summanden an.     Zusammenfassung     Reihe  : konvergent, wenn die Partialsummen konvergieren; die Summe ist . Absolut konvergent , wenn konvergiert — das ist stärker als konvergent. Nur bei absolut konvergenten Reihen darf man beliebig umordnen.   Geometrische Reihe:  für , divergent für ; endliche Summe . Verschobener Startindex: Faktor ausklammern oder die fehlenden Glieder abziehen.   Notwendig:  . Nicht hinreichend — die harmonische Reihe divergiert, wenn auch extrem langsam (Bücherstapel, Zipfsches Gesetz).   Majorante\/Minorante:  mit konvergent  absolut konvergent; mit divergent  divergent. Vergleichsreihen: geometrische Reihe, (konvergent), (divergent).   Quotienten- und Wurzelkriterium: Grenzwert von bzw. kleiner  absolut konvergent, größer  divergent, gleich : keine Aussage.   Leibniz:  mit monoton fallender Nullfolge konvergiert; Abbruchfehler . Die alternierende harmonische Reihe ist konvergent, aber nicht absolut konvergent.   Rechenregeln: Reihen dürfen gliedweise mit Konstanten multipliziert und addiert werden; das Cauchy-Produkt zweier absolut konvergenter Reihen konvergiert gegen das Produkt der Summen.   Anwendungen: Annuität , Barwert einer ewigen Rente und diskontierter Gesamtertrag kommen aus der geometrischen Reihe; eine geometrische Majorante liefert auch Fehlerschranken, etwa für ; Robbins–Monro: , , erfüllt für .      Übungsaufgaben    Bestimmen Sie .    Mit , (also ):       Ein Kredit über  € soll bei Zinsen pro Jahr in zwei gleich hohen Jahresraten (Annuitäten) getilgt werden, jeweils fällig am Jahresende. Bestimmen Sie , und machen Sie die Probe mit der Rekursion .    Mit , und der Annuitätenformel ist (in €) Probe: und (bis auf Rundung auf Cent).      Was sagt das notwendige Konvergenzkriterium über die Reihe aus?     Da keine Nullfolge ist, divergiert die Reihe nach dem notwendigen Konvergenzkriterium.      Untersuchen Sie mit dem Wurzelkriterium auf Konvergenz.     Nach dem Wurzelkriterium konvergiert die Reihe (absolut).      Zeigen Sie, dass die Reihe konvergiert.    Die Folge ist positiv, streng monoton fallend (der Nenner wächst mit ) und eine Nullfolge. Nach dem Leibniz-Kriterium konvergiert also .     "
},
{
  "id": "sec-reihen-2",
  "level": "2",
  "url": "sec-reihen.html#sec-reihen-2",
  "type": "Lernziele",
  "number": "2.2",
  "title": "",
  "body": "  Nach diesem Abschnitt können Sie    eine Reihe als Folge ihrer Partialsummen erklären und sagen, was Konvergenz und absolute Konvergenz einer Reihe bedeuten;  geometrische Reihen summieren, auch mit verschobenem Startindex;  das notwendige Kriterium, Majoranten- und Minorantenkriterium, Quotienten-, Wurzel- und Leibniz-Kriterium anwenden — und das passende Kriterium für eine gegebene Reihe auswählen;  an der harmonischen und der alternierenden harmonischen Reihe erklären, warum Nullfolge nicht reicht und warum konvergent nicht absolut konvergent bedeutet;  Annuitäten, Barwerte, diskontierte Belohnungen und Lernraten-Bedingungen als Reihen lesen und den Abbruchfehler einer Reihe mit einer geometrischen Majorante abschätzen.   "
},
{
  "id": "sub-begriff-einer-reihe-2-2",
  "level": "2",
  "url": "sec-reihen.html#sub-begriff-einer-reihe-2-2",
  "type": "Absatz (with a defined term)",
  "number": "",
  "title": "",
  "body": "Reihe "
},
{
  "id": "def-reihe",
  "level": "2",
  "url": "sec-reihen.html#def-reihe",
  "type": "Definition",
  "number": "2.2.1",
  "title": "Reihe, Partialsumme, Konvergenz.",
  "body": " Reihe, Partialsumme, Konvergenz   Sei eine reelle oder komplexe Folge. Den formalen Ausdruck nennt man (unendliche) Reihe . Die Folge der Partialsummen (oder Teilsummen ) ist dabei selbst wieder eine gewöhnliche Folge. Konvergiert , so heißt die Reihe konvergent , und man nennt die Summe der Reihe , geschrieben . Eine nicht-konvergente Reihe heißt divergent . Die Reihe heißt absolut konvergent , wenn die Reihe der Beträge konvergiert. Jede absolut konvergente Reihe ist insbesondere auch konvergent — die Umkehrung gilt nicht, wie wir in diesem Abschnitt sehen werden.   "
},
{
  "id": "rem-reihe-symbolische-schreibweise",
  "level": "2",
  "url": "sec-reihen.html#rem-reihe-symbolische-schreibweise",
  "type": "Bemerkung",
  "number": "2.2.2",
  "title": "Eine Reihe ist keine wirklich unendliche Summe.",
  "body": " Eine Reihe ist keine wirklich unendliche Summe  Es gibt in der Mathematik keine tatsächlich unendlichen Summen: Die Schreibweise ist eine rein symbolische Abkürzung. Für eine konvergente Reihe steht der Ausdruck exakt für den wohldefinierten Sachverhalt — nichts anderes. Diese Präzisierung ist mehr als Spitzfindigkeit: Rechenregeln, die für endliche Summen selbstverständlich sind (etwa beliebiges Umordnen der Summanden), gelten für unendliche Reihen im Allgemeinen nicht mehr ohne Weiteres. Wir werden zulässige Rechenregeln für konvergente Reihen weiter unten explizit festhalten.  "
},
{
  "id": "ex-partialsummen-leitbeispiel",
  "level": "2",
  "url": "sec-reihen.html#ex-partialsummen-leitbeispiel",
  "type": "Beispiel",
  "number": "2.2.3",
  "title": "Die Partialsummen des Leitbeispiels.",
  "body": " Die Partialsummen des Leitbeispiels   Berechnen Sie für die Partialsummen , finden Sie eine Formel für , und bestimmen Sie die Summe der Reihe.    Schrittweise addieren: Der Abstand zur halbiert sich mit jedem Schritt: , , , …, allgemein Wegen konvergiert gegen , also ist ( ). Man beachte: Die Summe wird von keiner Partialsumme erreicht, sie ist der Grenzwert.   Die Partialsummen von auf dem Zahlenstrahl: Jeder Summand überbrückt die Hälfte des verbleibenden Abstands zur .    Ein Zahlenstrahl von bis . Markiert sind die Partialsummen , , , und . Bögen über dem Strahl zeigen die Summanden , , , , die immer kürzer werden und sich der annähern.       "
},
{
  "id": "ex-kleiner-gauss",
  "level": "2",
  "url": "sec-reihen.html#ex-kleiner-gauss",
  "type": "Beispiel",
  "number": "2.2.5",
  "title": "Der kleine Gauß und eine divergente Reihe (zur Vertiefung).",
  "body": " Der kleine Gauß und eine divergente Reihe (zur Vertiefung)   Carl Friedrich Gauß soll als Grundschüler von seinem Lehrer die Aufgabe bekommen haben, die Zahlen von bis zu addieren — in der Hoffnung auf eine ruhige Stunde. Gauß war nach wenigen Augenblicken fertig. Bestimmen Sie so geschickt wie er die Partialsummen der Reihe . Konvergiert die Reihe?    Der Trick: Man schreibt die Summe zweimal untereinander, einmal vorwärts und einmal rückwärts, und addiert spaltenweise. Also ist , für den kleinen Gauß . Die Folge der Partialsummen wächst über alle Grenzen, die Reihe divergiert also bestimmt gegen — wenig überraschend, denn die Summanden werden ja immer größer. Interessant wird es erst, wenn die Summanden gegen gehen. Dann kann alles passieren, wie Sie gleich sehen werden.   "
},
{
  "id": "ex-geometrische-reihe-herleitung",
  "level": "2",
  "url": "sec-reihen.html#ex-geometrische-reihe-herleitung",
  "type": "Beispiel",
  "number": "2.2.6",
  "title": "Die geometrische Reihe.",
  "body": " Die geometrische Reihe   Für (oder ) und (oder ) heißt  geometrische Reihe — genau die Bauart, die auch unser Einstiegsbeispiel hat (dort ist , ). Leiten Sie eine geschlossene Formel für die Partialsumme her, und bestimmen Sie, für welche die Reihe konvergiert.    Für ist , was für nicht konvergiert. Sei also . Der Trick ist, mit zu multiplizieren — dabei teleskopiert die Summe. Wir schreiben und aus, und zwar so untereinander, dass gleiche Terme übereinander stehen: Zieht man die zweite Zeile von der ersten ab, heben sich alle Terme von bis weg, und es bleibt In Summenschreibweise lautet dieselbe Rechnung kurz da sich alle mittleren Terme gegenseitig aufheben. Division durch liefert die geschlossene Formel Für gilt ( ), also konvergiert gegen Für und ist keine Nullfolge, die Reihe divergiert also (das notwendige Konvergenzkriterium liefert dies sofort; für sieht man es auch direkt an der Formel für ).   "
},
{
  "id": "ex-geometrische-reihe-berechnung",
  "level": "2",
  "url": "sec-reihen.html#ex-geometrische-reihe-berechnung",
  "type": "Beispiel",
  "number": "2.2.7",
  "title": "Grenzwerte geometrischer Reihen berechnen.",
  "body": " Grenzwerte geometrischer Reihen berechnen   Bestimmen Sie sowie (beachten Sie, dass die zweite Summe erst bei beginnt).    Mit der Formel aus und , (also ): Bei der zweiten Reihe beginnt der Summationsindex erst bei statt bei . Wir ziehen den gemeinsamen Faktor heraus und führen die Summe auf eine bei beginnende geometrische Reihe zurück: (Alternativ hätte man auch die vollständige Summe ab berechnen und die fehlenden Anfangsglieder wieder abziehen können: — beide Wege sind bei Reihen mit verschobenem Startindex gleichermaßen üblich.)   "
},
{
  "id": "ex-periodische-dezimalzahl",
  "level": "2",
  "url": "sec-reihen.html#ex-periodische-dezimalzahl",
  "type": "Beispiel",
  "number": "2.2.8",
  "title": "Periodische Dezimalzahlen als geometrische Reihen.",
  "body": " Periodische Dezimalzahlen als geometrische Reihen   Schreiben Sie und als Brüche.    Eine periodische Dezimalzahl ist eine geometrische Reihe: Jeder Block ist hundertmal kleiner als der vorige. Ebenso ist Das überrascht viele: ist nicht knapp unter , sondern genau  . Nach der Definition ist der Grenzwert der Partialsummen , und dieser Grenzwert ist — auch wenn keine der Partialsummen selbst ist.   "
},
{
  "id": "ex-anwendung-restschuld-explizit",
  "level": "2",
  "url": "sec-reihen.html#ex-anwendung-restschuld-explizit",
  "type": "Beispiel",
  "number": "2.2.9",
  "title": "Anwendungsbeispiel: Die Restschuld eines Kredits explizit.",
  "body": " Anwendungsbeispiel: Die Restschuld eines Kredits explizit   In hatten wir die Restschuld rekursiv berechnet: , . Leiten Sie mit der geometrischen Summenformel eine explizite Formel für her, und prüfen Sie sie für .    Mit und rollen wir die Rekursion auf: und allgemein . Die Klammer ist eine endliche geometrische Summe, also Probe für : , also derselbe Wert wie bei der schrittweisen Rechnung. Mit der expliziten Formel kann man nun auch umgekehrt fragen, welche Rate nötig ist, damit der Kredit nach genau Jahren getilgt ist: Man setzt und löst nach auf. Das ist die Annuitätenformel der Finanzmathematik — und die rechnen wir gleich aus.   "
},
{
  "id": "ex-anwendung-annuitaet",
  "level": "2",
  "url": "sec-reihen.html#ex-anwendung-annuitaet",
  "type": "Beispiel",
  "number": "2.2.10",
  "title": "Anwendungsbeispiel: Die Annuitätenformel.",
  "body": " Anwendungsbeispiel: Die Annuitätenformel   Bei einem Annuitätendarlehen zahlt man jedes Jahr denselben Betrag (die Annuität ), und zwar so, dass der Kredit nach genau Jahren getilgt ist. Leiten Sie aus der expliziten Formel in eine Formel für her. Wie hoch ist die Annuität für den Kredit über  € bei Zinsen, wenn er in genau vier Jahren getilgt sein soll? Wie viel Zinsen zahlt man insgesamt?    Aus folgt Mit , , und ist (in €) Insgesamt zahlt man  € zurück, davon  € Zinsen. Zum Vergleich: Mit der Rate von  € aus war man ebenfalls nach vier Jahren fertig, die letzte Zahlung war aber krumm. Die Annuität verteilt die Last gleichmäßig — genau so rechnen Banken Ihre monatliche Rate für einen Autokredit oder eine Baufinanzierung aus, nur mit Monaten statt Jahren.   "
},
{
  "id": "ex-anwendung-rentenbarwert",
  "level": "2",
  "url": "sec-reihen.html#ex-anwendung-rentenbarwert",
  "type": "Beispiel",
  "number": "2.2.11",
  "title": "Anwendungsbeispiel: Barwert einer ewigen Rente.",
  "body": " Anwendungsbeispiel: Barwert einer ewigen Rente   In der Investitionsrechnung fragt man häufig nach dem Barwert einer zukünftigen Zahlungsreihe: Wie viel ist eine Serie zukünftiger Zahlungen heute wert, wenn man mit einem periodischen Zinssatz abzinst? Eine ewige Rente zahlt am Ende jeder Periode einen festen Betrag , unbegrenzt oft. Der Barwert einer Zahlung , die erst in Perioden erfolgt, ist (das ist gerade die Umkehrung der Zinseszinsformel aus ). Der Barwert der gesamten ewigen Rente ist daher Zeigen Sie , und berechnen Sie konkret für  € pro Jahr und .    Mit gilt wegen stets , und die Reihe ist geometrisch, nur beginnt sie bei statt : Einsetzen von liefert also , wie behauptet. Für und ergibt sich Eine ewige jährliche Zahlung von  € ist bei Zins heute  € wert — obwohl über die gesamte (unendliche) Laufzeit unbegrenzt viel Geld fließt, ist ihr heutiger Wert endlich, weil spätere Zahlungen immer stärker abgezinst werden.   "
},
{
  "id": "ex-anwendung-diskontierte-belohnung",
  "level": "2",
  "url": "sec-reihen.html#ex-anwendung-diskontierte-belohnung",
  "type": "Beispiel",
  "number": "2.2.12",
  "title": "Anwendungsbeispiel: Diskontierte Belohnung im Reinforcement Learning.",
  "body": " Anwendungsbeispiel: Diskontierte Belohnung im Reinforcement Learning   Beim Reinforcement Learning lernt ein Agent (etwa ein Lagerroboter oder ein Spielprogramm) durch Belohnungen , die er in aufeinanderfolgenden Zeitschritten erhält. Bewertet wird nicht die nächste Belohnung allein, sondern der diskontierte Gesamtertrag  mit einem Diskontfaktor  , der spätere Belohnungen schwächer gewichtet. Angenommen, der Agent erhält in jedem Schritt dieselbe Belohnung . Bestimmen Sie für und für , und interpretieren Sie den Unterschied.    Für konstante Belohnung ist eine geometrische Reihe mit und , also Für ergibt das , für dagegen . Der Wert ist so etwas wie der Planungshorizont des Agenten: Bei zählen im Wesentlichen die nächsten zehn Schritte, bei die nächsten hundert. Der Diskontfaktor spielt also genau die Rolle des Abzinsungsfaktors aus — Finanzmathematik und Reinforcement Learning rechnen hier mit derselben Reihe.   "
},
{
  "id": "sub-konvergenzkriterien-reihen-2-2",
  "level": "2",
  "url": "sec-reihen.html#sub-konvergenzkriterien-reihen-2-2",
  "type": "Absatz (with a defined term)",
  "number": "",
  "title": "",
  "body": "Konvergenzkriterien "
},
{
  "id": "thm-notwendiges-kriterium",
  "level": "2",
  "url": "sec-reihen.html#thm-notwendiges-kriterium",
  "type": "Satz",
  "number": "2.2.13",
  "title": "Notwendiges Konvergenzkriterium.",
  "body": " Notwendiges Konvergenzkriterium   Ist die Reihe konvergent, so ist eine Nullfolge: (Grund: Mit gilt ; konvergiert gegen ein , so auch , also .) Diese Bedingung ist notwendig, aber nicht hinreichend — das folgende Beispiel zeigt eine Reihe, deren Glieder eine Nullfolge bilden, die aber trotzdem divergiert.   "
},
{
  "id": "ex-harmonische-reihe-divergent",
  "level": "2",
  "url": "sec-reihen.html#ex-harmonische-reihe-divergent",
  "type": "Beispiel",
  "number": "2.2.14",
  "title": "Die harmonische Reihe divergiert.",
  "body": " Die harmonische Reihe divergiert   Zeigen Sie, dass die harmonische Reihe  divergiert, obwohl eine Nullfolge ist.    Wir schätzen die Partialsumme nach unten ab, indem wir die Summanden in Blöcke der Länge gruppieren: Der -te Block (für ) enthält Summanden, von denen jeder mindestens so groß ist wie der letzte, kleinste Summand des Blocks. Also ist jeder Block mindestens groß. Da es solche Blöcke gibt, folgt Für wächst diese untere Schranke über alle Grenzen, also ist und damit auch unbeschränkt und somit divergent. Die harmonische Reihe ist damit das Standardbeispiel dafür, dass das notwendige Kriterium nicht hinreichend ist — wir werden sie im Rest dieses Abschnitts noch mehrfach als Vergleichsreihe verwenden.  Wie tückisch diese Divergenz ist, zeigen ein paar Zahlen: Die Summe der ersten tausend Glieder ist erst , und um die zu überschreiten, braucht man Summanden. Wer nur auf eine Computerausgabe der ersten Partialsummen schaut, würde leicht auf Konvergenz tippen.   "
},
{
  "id": "ex-anwendung-buecherstapel",
  "level": "2",
  "url": "sec-reihen.html#ex-anwendung-buecherstapel",
  "type": "Beispiel",
  "number": "2.2.15",
  "title": "Anwendungsbeispiel: Ein Bücherstapel über der Tischkante.",
  "body": " Anwendungsbeispiel: Ein Bücherstapel über der Tischkante   Sie stapeln gleiche Bücher der Länge an einer Tischkante übereinander, jedes Buch auf dem vorigen, und schieben sie so weit wie möglich nach rechts hinaus, ohne dass der Stapel kippt. Ein Stapel ist stabil, solange für jedes Buch gilt: Der gemeinsame Schwerpunkt aller Bücher darüber liegt nicht rechts von seiner rechten Kante; ebenso darf der Schwerpunkt des ganzen Stapels nicht rechts der Tischkante liegen. Man kann zeigen, dass der Überhang am größten wird, wenn das -te Buch von oben genau um über das Buch darunter (bzw. über die Tischkante) hinausragt. Wie weit ragt der oberste Buchrand dann insgesamt über die Tischkante? Geht mehr als eine ganze Buchlänge?    Der gesamte Überhang ist die Summe der einzelnen Überstände: also die halbe -te Partialsumme der harmonischen Reihe. Schon bei vier Büchern ist das : Das oberste Buch liegt komplett jenseits der Tischkante, kein Stück davon ist mehr über dem Tisch ( ). Weil die harmonische Reihe divergiert, lässt sich der Überhang mit genügend Büchern sogar beliebig groß machen. Allerdings braucht man für zwei Buchlängen Überhang schon Bücher, für drei und für zehn rund Millionen — die Divergenz ist real, aber quälend langsam.  Woher die Überstände kommen, lässt sich mit dem Schwerpunkt als Mittelwert begründen: Liegt der gemeinsame Schwerpunkt der oberen Bücher genau über der rechten Kante von Buch , und hat Buch seinen eigenen Schwerpunkt weiter links, so liegt der Schwerpunkt aller Bücher beim gewichteten Mittel , also genau links der Kante. Dort muss die Kante des nächsten Buches liegen.   Vier Bücher der Länge , optimal gestapelt: Die Überstände betragen von oben nach unten , , und ; das oberste Buch ragt insgesamt über die Tischkante.    Ein Tisch links, dessen rechte Kante durch eine senkrechte gestrichelte Linie markiert ist. Darauf liegen vier gleich lange Bücher als flache Rechtecke übereinander, jedes gegenüber dem darunterliegenden nach rechts verschoben. Das unterste Buch ragt um ein Achtel über die Tischkante, das oberste liegt vollständig rechts der Tischkante; sein rechter Rand ist um Buchlängen von der Kante entfernt.       "
},
{
  "id": "ex-anwendung-zipf",
  "level": "2",
  "url": "sec-reihen.html#ex-anwendung-zipf",
  "type": "Beispiel",
  "number": "2.2.17",
  "title": "Anwendungsbeispiel: Das Zipfsche Gesetz in der Textanalyse.",
  "body": " Anwendungsbeispiel: Das Zipfsche Gesetz in der Textanalyse   Zählt man in einem großen Textkorpus, wie oft jedes Wort vorkommt, und sortiert die Wörter nach Häufigkeit, so beobachtet man erstaunlich genau das Zipfsche Gesetz : Das -häufigste Wort kommt ungefähr -mal so oft vor wie das häufigste. Bei einem Wortschatz von Wörtern ist der Anteil der häufigsten Wörter am gesamten Text dann Welchen Anteil eines Textes decken die häufigsten Wörter ab, wenn der Wortschatz Wörter umfasst? Verwenden Sie , und die Näherung für große (die Zahl heißt Euler-Mascheroni-Konstante).    Mit ist der Anteil Die häufigsten Wörter — der , die , und , in , … — machen also fast die Hälfte eines typischen Textes aus, obwohl sie nur des Wortschatzes sind. Das ist der Grund, warum man in der Textanalyse solche Stoppwörter oft herausfiltert, bevor man nach inhaltlich interessanten Begriffen sucht. Und die langsame Divergenz der harmonischen Reihe zeigt sich hier von ihrer praktischen Seite: Weil nur logarithmisch mit dem Wortschatz wächst, ändert auch ein doppelt so großer Wortschatz an diesem Bild wenig.   "
},
{
  "id": "thm-majorantenkriterium",
  "level": "2",
  "url": "sec-reihen.html#thm-majorantenkriterium",
  "type": "Satz",
  "number": "2.2.18",
  "title": "Majorantenkriterium.",
  "body": " Majorantenkriterium   Die Reihe soll auf Konvergenz untersucht werden.    Gibt es eine konvergente Reihe mit , so dass für alle ab einem Index , so konvergiert (sogar absolut). Man nennt eine konvergente Majorante .  Gibt es eine divergente Reihe mit , so dass für alle ab einem Index , so divergiert . Man nennt eine divergente Minorante . (Hier müssen die selbst — nicht nur ihre Beträge — über liegen: Mit folgt nur, dass nicht absolut konvergiert; die alternierende harmonische Reihe weiter unten zeigt, dass sie trotzdem konvergieren kann.)     "
},
{
  "id": "ex-majorantenkriterium-anwendung",
  "level": "2",
  "url": "sec-reihen.html#ex-majorantenkriterium-anwendung",
  "type": "Beispiel",
  "number": "2.2.19",
  "title": "Majorantenkriterium anwenden.",
  "body": " Majorantenkriterium anwenden   Untersuchen Sie und auf Konvergenz.    Für die erste Reihe gilt für alle , also Die geometrische Reihe konvergiert ( ), ist also eine konvergente Majorante: konvergiert.  Für die zweite Reihe gilt für alle , also . Die harmonische Reihe divergiert ( ), ist also eine divergente Minorante: divergiert ebenfalls.   "
},
{
  "id": "ex-anwendung-sgd-schrittweiten",
  "level": "2",
  "url": "sec-reihen.html#ex-anwendung-sgd-schrittweiten",
  "type": "Beispiel",
  "number": "2.2.20",
  "title": "Anwendungsbeispiel: Schrittweiten beim stochastischen Gradientenabstieg.",
  "body": " Anwendungsbeispiel: Schrittweiten beim stochastischen Gradientenabstieg   Beim stochastischen Gradientenabstieg (SGD), mit dem in der Data Science die Parameter vieler Modelle trainiert werden, verwendet man in jedem Schritt eine Schrittweite (Lernrate) . Damit das Verfahren garantiert konvergiert, fordert man klassischerweise die Robbins–Monro-Bedingungen  Die erste Bedingung stellt sicher, dass die Summe der Schritte groß genug ist, um von jedem Startpunkt aus jeden Punkt erreichen zu können; die zweite, dass die Schritte schnell genug schrumpfen, damit sich das Rauschen der stochastischen Gradienten im Mittel herausmittelt. Zeigen Sie, dass die klassische Wahl beide Bedingungen erfüllt.    Die erste Bedingung ist genau die Divergenz der harmonischen Reihe , die wir in gezeigt haben.  Für die zweite Bedingung zeigen wir konvergiert, mit dem Majorantenkriterium. Für gilt die Partialbruchzerlegung (eine Technik, die in diesem Kurs weder vorausgesetzt noch behandelt wird — die Gleichung prüft man durch Zusammenfassen der rechten Seite auf den Hauptnenner), und wegen folgt Die rechte Seite ist eine Teleskopreihe: Ihre Partialsumme ist für jedes (alle mittleren Terme heben sich auf), insbesondere ist diese Teleskopreihe konvergent (Grenzwert ) und damit eine konvergente Majorante für . Mit dem -Term dazu ist also auch konvergent (mit Summe kleiner als ). Die Schrittweite erfüllt damit beide Robbins–Monro-Bedingungen — einer der Gründe, warum -artige Zerfallsschemata für die Lernrate in der Optimierung so verbreitet sind.   "
},
{
  "id": "ex-anwendung-e-berechnen",
  "level": "2",
  "url": "sec-reihen.html#ex-anwendung-e-berechnen",
  "type": "Beispiel",
  "number": "2.2.21",
  "title": "Anwendungsbeispiel: Wie berechnet ein Computer <span class=\"process-math\">\\(\\euler\\text{?}\\)<\/span>",
  "body": " Anwendungsbeispiel: Wie berechnet ein Computer ?   Man kann zeigen, dass gilt. Abgebrochene Potenzreihen dieser Art stecken — nach geschickter Verkleinerung des Arguments und mit leicht optimierten Koeffizienten — hinter der Funktion exp in vielen Programmbibliotheken.  Zeigen Sie mit dem Majorantenkriterium, dass die Reihe konvergiert, und folgern Sie .  Berechnen Sie die Partialsumme , und schätzen Sie den Fehler mit einer geometrischen Reihe ab.        Für ist , also . Die geometrische Reihe ist eine konvergente Majorante, und .  . Für den Rest ziehen wir vor die Klammer; jeder weitere Faktor im Nenner ist mindestens : Tatsächlich ist , der Fehler also — die Schranke ist fast exakt.    Sieben Summanden liefern also schon drei korrekte Nachkommastellen, und die Fehlerschranke sagt vorab, wann man aufhören darf. Weil die Fakultät im Nenner so schnell wächst, reichen für die volle Rechengenauigkeit eines Computers (etwa Stellen) knapp zwanzig Summanden.   "
},
{
  "id": "thm-quotientenkriterium",
  "level": "2",
  "url": "sec-reihen.html#thm-quotientenkriterium",
  "type": "Satz",
  "number": "2.2.22",
  "title": "Quotientenkriterium.",
  "body": " Quotientenkriterium   Sei eine Reihe mit für alle ab einem Index, und die Folge konvergiere.    Falls , so ist absolut konvergent.  Falls , so ist divergent.    Im Grenzfall liefert das Kriterium keine Aussage: Sowohl die divergente harmonische Reihe als auch die konvergente Reihe haben Quotientengrenzwert . Dann muss ein anderes Kriterium herangezogen werden, etwa ein Vergleich mit einer bekannten Reihe.   "
},
{
  "id": "ex-quotientenkriterium-zwei-faelle",
  "level": "2",
  "url": "sec-reihen.html#ex-quotientenkriterium-zwei-faelle",
  "type": "Beispiel",
  "number": "2.2.23",
  "title": "Quotientenkriterium: einmal Konvergenz, einmal Divergenz.",
  "body": " Quotientenkriterium: einmal Konvergenz, einmal Divergenz   Untersuchen Sie und auf Konvergenz.    Für kürzen sich die Dreierpotenzen fast vollständig: Die erste Reihe konvergiert also (absolut). Für ist die zweite Reihe divergiert. Das passt zur Wachstumshierarchie aus : Die Exponentialfunktion setzt sich gegen jede Potenz von durch — im Nenner sorgt sie für Konvergenz, im Zähler für Divergenz.   "
},
{
  "id": "ex-quotientenkriterium-anwendung",
  "level": "2",
  "url": "sec-reihen.html#ex-quotientenkriterium-anwendung",
  "type": "Beispiel",
  "number": "2.2.24",
  "title": "Quotientenkriterium anwenden (zur Vertiefung).",
  "body": " Quotientenkriterium anwenden (zur Vertiefung)   Untersuchen Sie auf Konvergenz.    Mit gilt Aus wissen wir bereits , also Nach dem Quotientenkriterium konvergiert die Reihe (absolut).   "
},
{
  "id": "thm-wurzelkriterium",
  "level": "2",
  "url": "sec-reihen.html#thm-wurzelkriterium",
  "type": "Satz",
  "number": "2.2.25",
  "title": "Wurzelkriterium.",
  "body": " Wurzelkriterium   Sei eine Reihe, und die Folge konvergiere.    Falls , so ist absolut konvergent.  Falls , so ist divergent.     "
},
{
  "id": "ex-wurzelkriterium-anwendung",
  "level": "2",
  "url": "sec-reihen.html#ex-wurzelkriterium-anwendung",
  "type": "Beispiel",
  "number": "2.2.26",
  "title": "Wurzelkriterium anwenden.",
  "body": " Wurzelkriterium anwenden   Untersuchen Sie auf Konvergenz.    Hier zieht die -te Wurzel die -te Potenz glatt zurück, ohne dass — wie beim Quotientenkriterium — erst gekürzt werden müsste: Nach dem Wurzelkriterium konvergiert die Reihe (absolut). Dieses Beispiel zeigt, warum es sich lohnt, bei Reihen mit einer Potenz zuerst das Wurzelkriterium zu probieren: Es vermeidet hier die etwas unhandlichere Quotientenbildung ganz.   "
},
{
  "id": "thm-leibniz-kriterium",
  "level": "2",
  "url": "sec-reihen.html#thm-leibniz-kriterium",
  "type": "Satz",
  "number": "2.2.27",
  "title": "Leibniz-Kriterium für alternierende Reihen.",
  "body": " Leibniz-Kriterium für alternierende Reihen   Sei eine monoton fallende, reelle Nullfolge mit . Dann konvergiert die alternierende Reihe  .   "
},
{
  "id": "rem-leibniz-fehlerabschaetzung",
  "level": "2",
  "url": "sec-reihen.html#rem-leibniz-fehlerabschaetzung",
  "type": "Bemerkung",
  "number": "2.2.28",
  "title": "Fehlerabschätzung beim Leibniz-Kriterium.",
  "body": " Fehlerabschätzung beim Leibniz-Kriterium  Unter den Voraussetzungen des Leibniz-Kriteriums oszillieren die Partialsummen mit stetig kleiner werdender Amplitude um den Grenzwert : Aufeinanderfolgende Partialsummen liegen abwechselnd über und unter und schließen so immer enger ein. Daraus folgt die nützliche Fehlerabschätzung — der Fehler beim Abbruch nach dem -ten Glied ist höchstens so groß wie der Betrag des ersten weggelassenen Gliedes. Das erlaubt es, vorab abzuschätzen, wie viele Glieder für eine gewünschte Genauigkeit nötig sind, ohne den (oft unbekannten) Grenzwert selbst zu kennen — ein Prinzip, das auch bei der Fehlerabschätzung abgebrochener Reihenapproximationen (etwa von Taylorreihen) verwendet wird.  "
},
{
  "id": "ex-leibniz-alternierende-harmonische-reihe",
  "level": "2",
  "url": "sec-reihen.html#ex-leibniz-alternierende-harmonische-reihe",
  "type": "Beispiel",
  "number": "2.2.29",
  "title": "Die alternierende harmonische Reihe: konvergent, aber nicht absolut.",
  "body": " Die alternierende harmonische Reihe: konvergent, aber nicht absolut   Zeigen Sie, dass konvergiert, aber nicht absolut konvergiert.    Die Folge ist eine monoton fallende Nullfolge, also konvergiert die Reihe nach dem Leibniz-Kriterium. Die Reihe der Beträge ist aber also genau die harmonische Reihe, die nach divergiert. Die Reihe konvergiert also, aber nicht absolut — man nennt eine solche Reihe bedingt konvergent . (Man kann zeigen, dass ihre Summe ist; das würde hier aber zu weit führen.) Dieses Beispiel zeigt insbesondere, dass die Umkehrung der Aussage absolut konvergent konvergent aus tatsächlich falsch ist.   "
},
{
  "id": "ex-umordnung-alternierende-harmonische-reihe",
  "level": "2",
  "url": "sec-reihen.html#ex-umordnung-alternierende-harmonische-reihe",
  "type": "Beispiel",
  "number": "2.2.30",
  "title": "Umordnen verändert die Summe.",
  "body": " Umordnen verändert die Summe   Sei die Summe der alternierenden harmonischen Reihe. Wir ordnen dieselben Summanden um: jeweils ein positiver, dann zwei negative, Überzeugen Sie sich, dass jeder Summand von genau einmal vorkommt, und zeigen Sie .    Die positiven Summanden kommen in der alten Reihenfolge vor, und die negativen und durchlaufen zusammen alle geraden Nenner — jeder Summand wird also genau einmal verwendet. Jetzt fassen wir in Dreiergruppen zusammen und vereinfachen jeweils die ersten beiden Glieder, wobei ist: Für ergibt das (Weil die Summanden gegen gehen, ändert das Zusammenfassen zu Dreiergruppen nichts am Grenzwert.) Dieselben Zahlen, anders sortiert, ergeben also die halbe Summe — mit ist . Bernhard Riemann hat sogar gezeigt, dass man eine bedingt konvergente Reihe durch geschicktes Umordnen gegen jede beliebige Zahl konvergieren lassen kann. Bei absolut konvergenten Reihen passiert so etwas nie; dort ist Umordnen erlaubt.   "
},
{
  "id": "ex-leibniz-fehlerabschaetzung-anwendung",
  "level": "2",
  "url": "sec-reihen.html#ex-leibniz-fehlerabschaetzung-anwendung",
  "type": "Beispiel",
  "number": "2.2.31",
  "title": "Wie viele Glieder braucht man?",
  "body": " Wie viele Glieder braucht man?   Um 1735 bewies Leonhard Euler zur Verblüffung seiner Zeitgenossen, dass ist — das Basler Problem , an dem sich zuvor unter anderem Jakob Bernoulli vergeblich versucht hatte. Daraus folgt auch (den Beweis führen wir hier nicht). Wie viele Glieder muss man addieren, damit die Fehlerabschätzung des Leibniz-Kriteriums einen Fehler kleiner als garantiert? Vergleichen Sie mit der Reihe für aus und mit der alternierenden harmonischen Reihe.    Die Beträge bilden eine monoton fallende Nullfolge, also gilt die Fehlerabschätzung . Wir brauchen ; wegen und ist das ab , also der Fall. Die Abschätzung garantiert die gewünschte Genauigkeit also spätestens nach Summanden ( ). Tatsächlich reichen schon — die Schranke ist vorsichtig, aber sie ist garantiert.  Zum Vergleich: Bei der Reihe für genügten sieben Summanden. Bei der alternierenden harmonischen Reihe liefert die Abschätzung , und die garantiert einen Fehler unter erst nach rund tausend Gliedern. Entscheidend ist, wie schnell die Summanden klein werden: fällt rasant, ordentlich, nur zäh. Die Fehlerabschätzung garantiert also Konvergenz, sagt aber auch ehrlich, wie langsam sie sein kann.   "
},
{
  "id": "rem-welches-kriterium",
  "level": "2",
  "url": "sec-reihen.html#rem-welches-kriterium",
  "type": "Bemerkung",
  "number": "2.2.32",
  "title": "Welches Kriterium wann?",
  "body": " Welches Kriterium wann?  Die Kriterien greifen jeweils für typische Bauarten von Reihen. Eine bewährte Reihenfolge beim Untersuchen einer Reihe :    Nullfolge? Geht nicht gegen , ist man fertig: Die Reihe divergiert.  Potenz im Glied? Wurzelkriterium. Fakultäten oder -te Potenzen fester Zahlen ( , )? Quotientenkriterium.  Wechselndes Vorzeichen mit monoton fallenden Beträgen? Leibniz-Kriterium (und die Fehlerabschätzung gratis dazu).  Sonst — insbesondere bei gebrochen-rationalen Gliedern wie — Vergleich mit einer bekannten Reihe: geometrische Reihe und als konvergente Majoranten, und als divergente Minoranten.    Liefert Quotienten- oder Wurzelkriterium den Grenzwert , hilft — sofern Schritt 1 nicht schon entschieden hat — nur noch Schritt 3 oder 4.  "
},
{
  "id": "ex-kriterium-auswaehlen",
  "level": "2",
  "url": "sec-reihen.html#ex-kriterium-auswaehlen",
  "type": "Beispiel",
  "number": "2.2.33",
  "title": "Das passende Kriterium auswählen.",
  "body": " Das passende Kriterium auswählen   Entscheiden Sie mit der Strategie aus , ob die folgenden Reihen konvergieren:       Die Potenz lädt zum Wurzelkriterium ein — aber , keine Aussage. Schritt 1 hilft: . Keine Nullfolge, also divergiert die Reihe.  Fakultät: Quotientenkriterium. . Die Reihe konvergiert. Bemerkenswert: Die Summanden wachsen zunächst sogar, bis auf über bei und . Das Kriterium schaut aber nur auf das Langzeitverhalten; endlich viele große Anfangsglieder ändern nichts an der Konvergenz.  Wechselndes Vorzeichen, und ist eine monoton fallende Nullfolge: Nach Leibniz konvergiert die Reihe. Absolut konvergiert sie nicht, denn divergiert ( ).  Gebrochen-rational: Für große ist , also vermuten wir Divergenz. Wegen gilt , und divergiert als halbe harmonische Reihe. Die divergente Minorante zeigt: Die Reihe divergiert.    Bei (a) zeigt sich, warum Schritt 1 immer zuerst kommt: Er hätte den Umweg über das Wurzelkriterium erspart.   "
},
{
  "id": "thm-rechenregeln-reihen",
  "level": "2",
  "url": "sec-reihen.html#thm-rechenregeln-reihen",
  "type": "Satz",
  "number": "2.2.34",
  "title": "Rechenregeln für konvergente Reihen.",
  "body": " Rechenregeln für konvergente Reihen   Seien und konvergente Reihen und (oder ). Dann gelten:    ( Multiplikation mit einer Konstanten ) Die Reihe ist konvergent, und .  ( Summenregel ) Die Reihe ist konvergent, und .  ( Cauchy-Produkt ) Sind und sogar absolut konvergent, so konvergiert auch das Cauchy-Produkt  der beiden Reihen mit , und Die Voraussetzung der absoluten Konvergenz ist hier wesentlich: Für nur bedingt konvergente Reihen kann das Cauchy-Produkt divergieren.     "
},
{
  "id": "ex-cauchy-produkt-geometrische-reihe",
  "level": "2",
  "url": "sec-reihen.html#ex-cauchy-produkt-geometrische-reihe",
  "type": "Beispiel",
  "number": "2.2.35",
  "title": "Cauchy-Produkt einer geometrischen Reihe mit sich selbst (zur Vertiefung).",
  "body": " Cauchy-Produkt einer geometrischen Reihe mit sich selbst (zur Vertiefung)   Sei . Bilden Sie das Cauchy-Produkt der geometrischen Reihe mit sich selbst, und überprüfen Sie das Ergebnis numerisch für .    Mit ist der -te Koeffizient des Cauchy-Produkts da jeder der Summanden gleich ist. Die geometrische Reihe ist für absolut konvergent, denn ist selbst eine konvergente geometrische Reihe. Die Regel über das Cauchy-Produkt aus ist also anwendbar, und wir erhalten die Identität Für liefert die rechte Seite . Die linke Seite ist , mit den Partialsummen die sich tatsächlich der nähern. Nebenbei haben wir eine Reihe summiert, ohne eine Formel für ihre Partialsummen zu brauchen — allein durch Multiplizieren zweier geometrischer Reihen.   "
},
{
  "id": "sub-zusammenfassung-2-2-2",
  "level": "2",
  "url": "sec-reihen.html#sub-zusammenfassung-2-2-2",
  "type": "Absatz (with a defined term)",
  "number": "",
  "title": "",
  "body": "Reihe Absolut konvergent Geometrische Reihe: Notwendig: Majorante\/Minorante: Quotienten- und Wurzelkriterium: Leibniz: Rechenregeln: Anwendungen: "
},
{
  "id": "exercise-buch-geometrische-reihe",
  "level": "2",
  "url": "sec-reihen.html#exercise-buch-geometrische-reihe",
  "type": "Übung",
  "number": "2.2.4.1",
  "title": "",
  "body": "  Bestimmen Sie .    Mit , (also ):    "
},
{
  "id": "exercise-buch-annuitaet",
  "level": "2",
  "url": "sec-reihen.html#exercise-buch-annuitaet",
  "type": "Übung",
  "number": "2.2.4.2",
  "title": "",
  "body": "  Ein Kredit über  € soll bei Zinsen pro Jahr in zwei gleich hohen Jahresraten (Annuitäten) getilgt werden, jeweils fällig am Jahresende. Bestimmen Sie , und machen Sie die Probe mit der Rekursion .    Mit , und der Annuitätenformel ist (in €) Probe: und (bis auf Rundung auf Cent).   "
},
{
  "id": "exercise-buch-notwendiges-kriterium",
  "level": "2",
  "url": "sec-reihen.html#exercise-buch-notwendiges-kriterium",
  "type": "Übung",
  "number": "2.2.4.3",
  "title": "",
  "body": "  Was sagt das notwendige Konvergenzkriterium über die Reihe aus?     Da keine Nullfolge ist, divergiert die Reihe nach dem notwendigen Konvergenzkriterium.   "
},
{
  "id": "exercise-buch-wurzelkriterium",
  "level": "2",
  "url": "sec-reihen.html#exercise-buch-wurzelkriterium",
  "type": "Übung",
  "number": "2.2.4.4",
  "title": "",
  "body": "  Untersuchen Sie mit dem Wurzelkriterium auf Konvergenz.     Nach dem Wurzelkriterium konvergiert die Reihe (absolut).   "
},
{
  "id": "exercise-buch-leibniz",
  "level": "2",
  "url": "sec-reihen.html#exercise-buch-leibniz",
  "type": "Übung",
  "number": "2.2.4.5",
  "title": "",
  "body": "  Zeigen Sie, dass die Reihe konvergiert.    Die Folge ist positiv, streng monoton fallend (der Nenner wächst mit ) und eine Nullfolge. Nach dem Leibniz-Kriterium konvergiert also .   "
},
{
  "id": "sec-funktionen-stetigkeit",
  "level": "1",
  "url": "sec-funktionen-stetigkeit.html",
  "type": "Abschnitt",
  "number": "3.1",
  "title": "Funktionen: Grundbegriffe, elementare Funktionen und Stetigkeit",
  "body": " Funktionen: Grundbegriffe, elementare Funktionen und Stetigkeit    Nach diesem Abschnitt können Sie    Abbildungen mit Definitions-, Ziel- und Bildmenge beschreiben, auf Injektivität, Surjektivität und Bijektivität prüfen sowie Verkettungen und Umkehrabbildungen bilden;  reelle Funktionen auf maximale Definitionsmenge, Symmetrie, Periodizität und Monotonie untersuchen und Umkehrfunktionen bestimmen;  mit Exponential-, Logarithmus-, trigonometrischen und Hyperbelfunktionen rechnen und zugehörige Gleichungen lösen;  Grenzwerte von Funktionen durch Faktorisieren, Rationalisieren, einseitige Betrachtung und den Sandwich-Satz berechnen;  Stetigkeit nachweisen, Parameter abschnittsweise definierter Funktionen so wählen, dass sie stetig werden, den Zwischenwertsatz anwenden und Definitionslücken stetig fortsetzen;  ReLU und Sigmoid — die Standardfunktionen neuronaler Netze — mit diesen Begriffen einordnen.     Dieser Abschnitt ist der umfangreichste des Kurses, weil er das Vokabular für alles Weitere liefert. Ein Teil davon ist Ihnen aus der Schule vertraut — Potenzen, Logarithmen, Sinus und Kosinus. Lesen Sie diese Teile zügig und als Auffrischung. Konzentrieren Sie sich auf die Begriffe, die wirklich neu sind: die präzise Sprechweise über Abbildungen (wann ist eine Zuordnung umkehrbar?), die Grenzwerte von Funktionen (was passiert nahe einer Stelle, an der die Funktion gar nicht definiert ist?) und die Stetigkeit . Als roten Faden verfolgen wir zwei Funktionen aus dem maschinellen Lernen: die ReLU-Funktion mit ihrem Knick und die Sigmoid-Funktion mit ihrer Sättigung — beide werden uns im nächsten Abschnitt beim Ableiten wiederbegegnen.  Unterwegs erfahren Sie, warum jede Prüfsummenfunktion Kollisionen haben muss, warum Data Scientists so gern logarithmieren, warum man in der Analysis im Bogenmaß rechnet, wie eine Wertetabelle lügen kann und warum eine Bergwanderin an zwei Tagen zur selben Uhrzeit an derselben Stelle sein muss.    Abbildungen   Bisher haben wir mit einzelnen Zahlen (komplex, reell) und mit Folgen gerechnet. Ab jetzt steht der Begriff im Mittelpunkt, der Abhängigkeiten zwischen Größen beschreibt: ein Modell sagt einen Hauspreis aus der Wohnfläche voraus, eine Aktivierungsfunktion wandelt die gewichtete Summe der Eingänge eines Neurons in einen Ausgabewert um, ein Zinssatz bestimmt das Endkapital nach einer Laufzeit. In all diesen Fällen wird jedem Element einer Menge eindeutig ein Element einer anderen Menge zugeordnet — das ist der Begriff der Abbildung .  Die Sprechweise dieses Unterabschnitts wirkt zunächst formal. Sie beantwortet aber eine sehr praktische Frage: Wann lässt sich eine Zuordnung umkehren , wann kann man also aus dem Ergebnis eindeutig auf die Eingabe zurückschließen? Aus einer Temperatur in Fahrenheit kann man die Temperatur in Celsius zurückrechnen; aus einem gerundeten Messwert den exakten Wert nicht mehr.    Abbildungen und ihre Verkettung   Abbildung, Funktion   Eine Abbildung (auch Funktion genannt) von einer Menge auf eine Menge ist eine Zuordnung, die jedem   genau ein  zuordnet. Man schreibt oder kurz .    Entscheidend sind die beiden Wörter jedem und genau ein : Kein Element von darf ohne Bild bleiben, und keines darf zwei Bilder haben. Dagegen dürfen mehrere Elemente von dasselbe Bild haben, und nicht jedes Element von muss getroffen werden.   Abbildung oder nicht? (zur Vertiefung)   In einer Hochschuldatenbank gibt es eine Tabelle aller Studierenden. Welche der folgenden Zuordnungen sind Abbildungen?  Matrikelnummer Geburtsdatum der Person mit dieser Nummer;  Geburtsdatum Person mit diesem Geburtsdatum;  reelle Zahl  die Zahlen mit .        Ja: Jede Matrikelnummer gehört zu genau einer Person, und diese hat genau ein Geburtsdatum. Dass viele Nummern auf dasselbe Datum abgebildet werden, ist erlaubt.  Nein, gleich doppelt nicht: An manchen Daten sind mehrere Studierende geboren ( genau ein verletzt), an manchen niemand ( jedem verletzt).  Nein: Zu gehören und . Erst die Festlegung die nicht negative Lösung macht daraus die Wurzelfunktion .    Nebenbei: Dass die Matrikelnummer eine Person eindeutig festlegt, macht sie in der Datenbank zum Schlüssel . Die Zuordnung Person Matrikelnummer darf also nie zwei Personen dieselbe Nummer geben — genau diese Eigenschaft werden wir gleich injektiv nennen.    Für die einzelnen Bestandteile einer Abbildung gibt es feste Namen.   Definitionsmenge, Bildmenge, Urbild   Sei eine Abbildung. Dann heißt    die Definitionsmenge von ,  ein Argument von ,  die Zielmenge von ,   die Bildmenge (oder Wertemenge , das Bild ) von ,  für und das Element das Bild von und ein Urbild von ,  für die Menge die Urbildmenge von .    Der Name des Arguments spielt dabei keine Rolle: und beschreiben dieselbe Abbildung. Ebenso ist zwischen der Abbildung selbst und dem einzelnen Wert , der beim Einsetzen von entsteht, zu unterscheiden.     Bild- und Urbildmengen bestimmen   Sei , . Bestimmen Sie und .    Einsetzen liefert , , , , , also (Werte zählen nur einmal). Für die Urbildmenge suchen wir alle mit : Da keine Quadratzahl ist und , , folgt .    Vorsicht mit der Schreibweise : Die Urbildmenge ist für jede Abbildung definiert, auch für eine, die sich nicht umkehren lässt — im Beispiel gehören zum Bild die beiden Urbilder und . Für bijektive Abbildungen stimmt die Urbildmenge mit dem Bild unter der Umkehrabbildung überein, die wir weiter unten einführen; im Allgemeinen ist aber nur eine Menge von Urbildern.  Oft werden Abbildungen hintereinander ausgeführt: Ein Modell berechnet aus Merkmalen eine Zahl, eine zweite Funktion wandelt diese in eine Wahrscheinlichkeit um. Das Ergebnis ist wieder eine Abbildung.   Verkettung von Abbildungen   Seien und zwei Abbildungen, derart dass die Zielmenge von im Definitionsgebiet von enthalten ist. Dann ist die Verkettung ( Hintereinanderausführung ) von und die Abbildung Man liest als nach : Zuerst wird angewandt, dann .     Verkettung berechnen   Seien , , und , . Bestimmen Sie und und stellen Sie fest, ob gilt.    Es gilt und . Da bereits die Koeffizienten von verschieden sind ( gegen ), gilt : Die Verkettung von Abbildungen ist im Allgemeinen nicht kommutativ.      Injektiv, surjektiv, bijektiv — und die Umkehrabbildung  Eine Abbildung lässt sich genau dann umkehren, wenn zu jedem Element der Zielmenge genau ein Urbild gehört. Das zerlegt man in zwei Bedingungen: höchstens ein Urbild (injektiv) und mindestens ein Urbild (surjektiv).   Injektiv, surjektiv, bijektiv   Sei eine Abbildung.     heißt injektiv , falls für alle mit folgt, dass (verschiedene Elemente werden auf verschiedene Elemente abgebildet).   heißt surjektiv , falls für alle ein mit existiert (alle Elemente von haben mindestens ein Urbild).   heißt bijektiv , wenn injektiv und surjektiv ist.       Injektivität und Surjektivität nachweisen   Untersuchen Sie , , und , , jeweils auf Injektivität und Surjektivität.     ist nicht injektiv, denn mit . ist auch nicht surjektiv, denn hat kein Urbild in (keine ganze Zahl quadriert zu ).   dagegen ist injektiv: Sind mit , so folgt wegen bereits (Kontraposition der Injektivitätsbedingung). ist aber nicht surjektiv, da z. B. kein Urbild besitzt ( , , nichts liegt dazwischen). Das Beispiel zeigt: Injektivität und Surjektivität hängen nicht nur von der Rechenvorschrift, sondern auch von Definitions- und Zielmenge ab.    Manchmal weiß man ohne jede Rechnung, dass eine Abbildung nicht injektiv sein kann: nämlich dann, wenn die Definitionsmenge mehr Elemente hat als die Zielmenge. Wer Socken auf Schubladen verteilt, hat irgendwo zwei Socken in derselben Schublade. Dieses Schubfachprinzip klingt banal, hat aber handfeste Konsequenzen. Unter Menschen haben mit Sicherheit zwei am selben Tag Geburtstag. Und eine Hashfunktion , die beliebig lange Dateien auf Prüfsummen fester Länge abbildet (etwa Bit), kann niemals injektiv sein — es gibt unendlich viele mögliche Dateien, aber nur Prüfsummen. Kollisionen existieren also zwingend; die Kunst der Kryptographie besteht darin, dass niemand eine finden kann. Ebenso wenig injektiv ist das Runden von Messwerten auf eine feste Schrittweite, die Quantisierung : Rundet man auf eine Nachkommastelle, werden und beide zu , und aus dem gespeicherten Wert lässt sich der Messwert nicht mehr eindeutig zurückgewinnen.   Umkehrabbildung   Sei eine Abbildung. Ist bijektiv, so wird durch , mit , eine Abbildung definiert, die sogenannte Umkehrabbildung von . Sie wird mit bezeichnet. Es gilt und , wobei die identische Abbildung auf bezeichnet.     Anwendungsbeispiel: Temperaturen umrechnen   Ein Sensor liefert Temperaturen in Grad Celsius; ein US-amerikanisches Dashboard erwartet Grad Fahrenheit. Die Umrechnung ist , . Zeigen Sie, dass bijektiv ist, und bestimmen Sie die Umkehrabbildung. Welche Celsius-Temperatur entspricht  °F?    Wir lösen nach auf: Zu jedem gibt es also genau ein Urbild : ist surjektiv (es gibt eines) und injektiv (es gibt nur eines), also bijektiv, und Für ergibt sich — die normale Körpertemperatur. Probe: . Das Auflösen nach der Eingabe ist das Standardverfahren, um die Umkehrabbildung zu bestimmen: Gelingt es eindeutig, ist die Abbildung bijektiv.       Reelle Funktionen: Grundbegriffe   Ab jetzt beschränken wir uns auf reelle Funktionen , also Abbildungen zwischen Teilmengen von . Für diese übertragen wir die Begriffe aus und ergänzen sie um Eigenschaften, die speziell für reellwertige Funktionen sinnvoll sind: Symmetrie, Periodizität, Monotonie. Vieles davon kennen Sie aus der Schule unter dem Stichwort Kurvendiskussion ; neu ist vor allem, dass wir die Eigenschaften jetzt rechnerisch nachweisen , statt sie nur am Graphen abzulesen.    Definitionsmenge, Graph und abschnittsweise Funktionen   Reelle Funktion, Wertebereich, Nullstelle   Wir betrachten Funktionen mit (der Definitionsmenge ) und (der Zielmenge ). Werden und nicht explizit angegeben, so gilt stillschweigend: ist die maximale Definitionsmenge — die Menge aller reellen Zahlen, die in die Funktionsvorschrift eingesetzt werden dürfen — und .  Der Wertebereich von ist die Menge . Eine Nullstelle von ist ein mit .     Maximale Definitionsmenge bestimmen   Bestimmen Sie die maximale Definitionsmenge von .    Der Ausdruck unter der Wurzel muss nichtnegativ sein: . Außerdem darf der Nenner nicht sein: . Insgesamt     Der Graph einer reellen Funktion ist die Teilmenge . Er macht Eigenschaften wie Nullstellen, Monotonie oder Symmetrie visuell zugänglich.  Viele Funktionen aus der Praxis werden stückweise festgelegt: ein Steuertarif mit Stufen, ein Versandpreis, der ab einem Bestellwert entfällt, oder eine Aktivierungsfunktion, die negative Eingaben abschneidet.   Abschnittsweise definierte Funktion   Eine Funktion, deren Definitionsbereich aus endlich vielen Intervallen besteht, für die jeweils eine eigene Funktionsvorschrift gegeben ist, heißt abschnittsweise definiert .     Anwendungsbeispiel: Die ReLU-Aktivierungsfunktion   In künstlichen neuronalen Netzen wird häufig die ReLU-Funktion ( rectified linear unit ) als Aktivierungsfunktion verwendet: Geben Sie , und an, und bestimmen Sie den Wertebereich von .    Einsetzen liefert , , . Da negative Eingaben stets auf abgebildet werden und nichtnegative Eingaben unverändert bleiben, ist der Wertebereich . Wir kommen in auf die ReLU-Funktion zurück und untersuchen, ob der Knick bei ihre Stetigkeit beeinträchtigt.     Die ReLU-Funktion: links von konstant null, rechts die Identität — mit einem Knick bei .    Ein Koordinatensystem mit dem Graphen der ReLU-Funktion: Für negative verläuft der Graph auf der -Achse, für positive als Gerade mit Steigung durch den Ursprung. Am Ursprung hat der Graph einen Knick.        Symmetrie, Periodizität und Monotonie  Symmetrien sparen Arbeit: Kennt man den Graphen einer geraden oder ungeraden Funktion für , kennt man ihn überall.   Gerade und ungerade Funktion   Sei eine auf einem zum Ursprung symmetrischen Intervall definierte Funktion.     heißt gerade , wenn für alle . Der Graph ist dann achsensymmetrisch zur -Achse.   heißt ungerade , wenn für alle . Der Graph ist dann punktsymmetrisch zum Ursprung.      Für Polynome gibt es einen schnellen Test: Ein Polynom mit nur geraden Exponenten wie ist gerade, denn ; eines mit nur ungeraden Exponenten wie ist ungerade. Ein Polynom wie ist weder das eine noch das andere — die meisten Funktionen haben gar keine dieser Symmetrien.   Periodische Funktion   Sei eine auf einem Intervall definierte Funktion. heißt periodisch mit Periode  , wenn für alle mit  gilt. Ist periodisch mit Periode , so auch mit jeder Periode , ; die kleinste positive Periode heißt primitive Periode .     Anwendungsbeispiel: Perioden in Zeitreihen   Der Stromverbrauch eines Bürogebäudes (in kW) wird über den Tag durch modelliert, in Stunden ab Mitternacht. Bestimmen Sie die primitive Periode. Wann ist der Verbrauch am höchsten?    Der Kosinus hat die primitive Periode . Das Argument durchläuft eine volle Periode, wenn um mit wächst, also : Der Verbrauch wiederholt sich im Tagesrhythmus, . Am höchsten ist er, wenn ist, also bei , d. h. um Uhr mittags, mit  kW; nachts um Uhr liegt er bei  kW. Solche Tages-, Wochen- und Jahresperioden zu erkennen, ist ein Standardschritt bei der Analyse von Zeitreihen.    Monotonie kennen Sie schon von Folgen ( ). Bei Funktionen vergleicht man nicht aufeinanderfolgende Glieder, sondern zwei beliebige Stellen .   Monotone Funktion   Sei eine auf einem Intervall definierte Funktion. heißt     monoton wachsend , wenn für alle in : ; streng monoton wachsend , wenn sogar gilt;   monoton fallend , wenn für alle in : ; streng monoton fallend , wenn sogar gilt.       Monotonie über die Differenz nachweisen (zur Vertiefung)   Zeigen Sie, dass auf streng monoton wachsend ist.    Für in betrachten wir die Differenz: Da , sind und , also ist der Nenner positiv; der Zähler ist wegen ebenfalls positiv. Damit ist , also : ist streng monoton wachsend.      Umkehrfunktionen  Eine wichtige Beobachtung zur Umkehrbarkeit: Ist injektiv, so ist als Abbildung zwischen Definitionsmenge und Wertebereich bijektiv, und die Umkehrfunktion existiert ( ). Um ihre Abbildungsvorschrift zu bestimmen, löst man die Gleichung nach auf; der Graph von entsteht durch Spiegelung des Graphen von an der ersten Winkelhalbierenden . Jede streng monotone Funktion ist injektiv und damit umkehrbar — die Umkehrung gilt jedoch nicht: auf ist injektiv, aber nicht monoton (sie fällt links und rechts von jeweils streng, springt dazwischen aber von nach ).   Umkehrfunktion durch Einschränkung des Definitionsbereichs   Die Funktion , , ist auf ganz nicht injektiv. Finden Sie ein möglichst großes Intervall mit , auf dem die Einschränkung von injektiv ist, und bestimmen Sie die Umkehrfunktion dieser Einschränkung.     ist eine um nach rechts und nach oben verschobene Normalparabel; sie ist genau auf und auf jeweils streng monoton, also injektiv. Da , wählen wir .  Auflösen von nach (für , dem Wertebereich der Einschränkung): , und wegen folgt , also . Die Umkehrfunktion ist damit Probe: und . Hätten wir gewählt, wäre beim Wurzelziehen das negative Vorzeichen richtig gewesen: . Die Wahl des Intervalls entscheidet also mit über die Formel der Umkehrfunktion.       Elementare Funktionen   Eine Funktion wird elementar genannt, wenn sie sich durch Grundrechenarten und Verkettung aus einigen wenigen Grundtypen aufbauen lässt: Potenz- und Wurzelfunktionen, Polynome und gebrochenrationale Funktionen, trigonometrische Funktionen und ihre Umkehrfunktionen, Exponentialfunktionen und Logarithmen sowie hyperbolische Funktionen. Fast jede Formel, die Ihnen in Technik und Wirtschaft begegnet, ist aus diesen Bausteinen zusammengesetzt.  Potenzen, Polynome und Brüche kennen Sie aus der Schule und der Grundlagenwiederholung. Wir konzentrieren uns hier auf drei Familien: Exponentialfunktion und Logarithmus, die Wachstums- und Zerfallsprozesse beschreiben, die trigonometrischen Funktionen für alles Periodische und die weniger bekannten Hyperbelfunktionen. Vieles ist Wiederholung — lesen Sie diese Teile zügig und rechnen Sie die Beispiele trotzdem mit.    Exponentialfunktion und Logarithmus   Exponentialfunktion   Eine Funktion mit Abbildungsvorschrift für eine feste reelle Basis heißt Exponentialfunktion . Für ist streng monoton wachsend, für streng monoton fallend; in beiden Fällen ist bijektiv.     Rechenregeln für Exponentialfunktionen   Für und gilt:              Eulersche Zahl   Die Eulersche Zahl  ist die eindeutig bestimmte reelle Zahl, für die die Exponentialfunktion an der Stelle Steigung hat. Sie ist irrational, . Die Funktion heißt die Exponentialfunktion und wird auch als geschrieben.     Anwendungsbeispiel: Kapitalwert als Exponentialfunktion   Ein Kapital von wird mit einem festen Jahreszins von verzinst. Geben Sie den Kapitalwert als Funktion der Laufzeit (in Jahren) an, und berechnen Sie .    Mit und Wachstumsfaktor pro Jahr ist , eine Exponentialfunktion in . Es folgt . Anders als bei der linearen Verzinsung wächst hier mit fester relativer Rate — für ganzzahlige ist das genau die Zinseszinsfolge aus , jetzt als Funktion einer kontinuierlichen Laufzeit gelesen.    Beim Zinseszins kennt man Startkapital, Zinssatz und Laufzeit und berechnet das Endkapital. Oft ist die Frage aber umgekehrt: Wie lange dauert es, bis ein bestimmter Wert erreicht ist? Dann steht die Unbekannte im Exponenten, und man braucht die Umkehrfunktion der Exponentialfunktion.   Logarithmus zur Basis   Sei , . Die Umkehrfunktion der bijektiven Exponentialfunktion , , ist die Logarithmusfunktion  Da sie Umkehrfunktionen zueinander sind, gilt für alle und für alle .     Logarithmengesetze   Für , und gilt:           Der Logarithmus zur Basis heißt natürlicher Logarithmus und wird geschrieben. Für (mit im zweiten Fall) gelten die Basiswechselformeln  mit denen sich jede Exponential- bzw. Logarithmusfunktion auf die Basis zurückführen lässt. Der Logarithmus wächst streng monoton, aber deutlich langsamer als jede Wurzelfunktion.   Exponentialfunktion und natürlicher Logarithmus sind Umkehrfunktionen voneinander: Ihre Graphen gehen durch Spiegelung an der Winkelhalbierenden (gestrichelt) auseinander hervor.    Ein Koordinatensystem mit dem steil ansteigenden Graphen von , der die -Achse bei schneidet, und dem Graphen von , der die -Achse bei schneidet und nach links gegen die negative -Achse strebt. Beide Graphen sind spiegelbildlich zur gestrichelten Diagonalen .       Schulstoff zum Aufwärmen (zur Vertiefung)   (a) Schreiben Sie als eine einzige Potenz von . (b) Berechnen Sie ohne Taschenrechner. (c) Lösen Sie nach auf.    (a) Mit und ist der Ausdruck . (b) Quotientengesetz: . (c) Logarithmieren: , also .     Anwendungsbeispiel: Verdopplungszeit   Nach wie vielen Jahren hat sich das Kapital aus (Zinssatz ) verdoppelt?    Gesucht ist mit , also . Logarithmieren und das dritte Logarithmengesetz holen aus dem Exponenten: Nach knapp Jahren hat sich das Kapital verdoppelt — unabhängig vom Startkapital , das sich weggekürzt hat. Praktiker rechnen das mit einer Faustregel im Kopf, die wir in begründen.    Der Logarithmus hat noch eine zweite, sehr praktische Seite: Er macht aus Multiplikation Addition und damit aus exponentiellem Wachstum eine gerade Linie. Das nutzt man in der Datenanalyse ständig.   Anwendungsbeispiel: Exponentielles Wachstum auf der Log-Skala   Eine neue App hat nach Monaten jeweils , , und Nutzer. Zeigen Sie, dass die Daten zu passen, und dass eine lineare Funktion von ist. Wann wird die App bei gleichbleibendem Wachstum Nutzer haben? (Verwenden Sie und .)    Die Quotienten aufeinanderfolgender Werte sind alle gleich, , also . Logarithmieren mit den Logarithmengesetzen liefert eine Gerade in mit Steigung . Für brauchen wir , also Nach gut elf Monaten, also knapp einem Jahr, wäre die Marke erreicht. Genau deshalb zeichnet man Wachstumsdaten gern mit logarithmischer -Achse: Exponentielles Wachstum erscheint dort als Gerade, und jede Abweichung von der Geraden — etwa ein Abflachen, weil der Markt gesättigt ist — fällt sofort ins Auge. Aus einem verwandten Grund — Logarithmieren macht Multiplikatives additiv — logarithmiert man in der Statistik oft Einkommen, Preise oder Fallzahlen, bevor man eine Gerade an die Daten anpasst.     Anwendungsbeispiel: Die Sigmoid-Funktion   In der logistischen Regression und als Aktivierungsfunktion in neuronalen Netzen wird die Sigmoid-Funktion  verwendet, um einen beliebigen reellen Wert (z. B. eine gewichtete Summe von Merkmalen) auf eine Wahrscheinlichkeit im Intervall abzubilden. Berechnen Sie und zeigen Sie für alle .     — eine Eingabe von entspricht also maximaler Unsicherheit. Da für alle , ist der Nenner , also . Außerdem ist streng monoton wachsend: Wächst , so fällt , also fällt , also fällt der Nenner , und der Bruch wächst. Damit ist injektiv, also umkehrbar — ihre Umkehrfunktion ist die in der logistischen Regression verwendete Logit-Funktion  . Das Grenzverhalten von für untersuchen wir in .     Die Sigmoid-Funktion : streng monoton wachsend, Werte in , punktsymmetrisch zu , und für große nahezu konstant ( Sättigung ).    Ein Koordinatensystem mit dem S-förmigen Graphen der Sigmoid-Funktion, der von links nahe kommt, bei den Wert hat und nach rechts gegen die gestrichelte Asymptote strebt.        Trigonometrische Funktionen  Wir wiederholen die trigonometrischen Funktionen und , die am Einheitskreis definiert sind: Für einen Winkel (im Bogenmaß) ist der Punkt auf dem Einheitskreis, der durch Drehung von um den Winkel entsteht. Beide Funktionen sind -periodisch mit Wertebereich .  Warum eigentlich Bogenmaß und nicht Grad? Ein Winkel im Bogenmaß ist genau die Länge des zugehörigen Bogens auf dem Einheitskreis — eine Länge, keine willkürliche Einteilung in Teile, die auf die Babylonier zurückgeht. Diese Natürlichkeit zahlt sich aus: Nur im Bogenmaß gilt für kleine Winkel die bequeme Näherung ( ), und nur im Bogenmaß haben Sinus und Kosinus die einfachen Ableitungen, die Sie in kennenlernen. Achten Sie deshalb beim Taschenrechner und in Programmiersprachen darauf, dass Winkel in Radiant ( rad ) eingegeben werden — numpy.sin erwartet immer Bogenmaß.   Arkussinus und Arkuskosinus   Der Arkussinus ist die Umkehrfunktion der Einschränkung des Sinus auf : Der Arkuskosinus ist die Umkehrfunktion der Einschränkung des Kosinus auf :      Trigonometrische Gleichung lösen   Bestimmen Sie alle Lösungen der Gleichung .    Umformen liefert . Da , hat die Gleichung im Hauptbereich die Lösung . Wegen der Symmetrie des Sinus ( ) und der -Periodizität ergeben sich im Intervall die beiden Lösungen     Analog wird der Tangens  (definiert für ) auf eingeschränkt umgekehrt zum Arkustangens  , und der Kotangens  liefert entsprechend den Arkuskotangens . Für Sinus und Kosinus gelten die Additionstheoreme     Allgemeine Kosinusfunktion   Die allgemeine Kosinusfunktion hat die Form mit Amplitude  , Kreisfrequenz  und Phasenverschiebung  . Ihre primitive Periode ist .    Ein Beispiel aus der Steckdose: Die Netzspannung (in Volt, in Sekunden) hat die Amplitude  V und die Kreisfrequenz pro Sekunde, also die Periode  s  ms. Die ist die Netzfrequenz in Hertz: fünfzig volle Schwingungen pro Sekunde.    Hyperbelfunktionen  Addiert oder subtrahiert man und , entstehen Funktionen, die sich in vielem wie Kosinus und Sinus verhalten — nur ohne zu schwingen. Sie tauchen in der Statik, bei Freileitungen und als Aktivierungsfunktion in neuronalen Netzen auf.   Hyperbelfunktionen   Die Hyperbelfunktionen sind definiert als       Eine Hyperbelidentität nachweisen   Zeigen Sie für alle .    Einsetzen der Definitionen: Ausmultiplizieren beider Quadrate liefert und . Die Differenz der beiden Terme in Klammern ist also , so dass . Vergleichen Sie mit : Die Punkte liegen auf einem Kreis, die Punkte auf einer Hyperbel — daher der Name.     Anwendungsbeispiel: Die Kettenlinie (zur Vertiefung)   Eine frei zwischen zwei Aufhängepunkten hängende Kette (oder Freileitung) folgt der Kurve für eine Konstante , die von Kettenlänge und Eigengewicht abhängt. Für : Um wie viel liegt die Kette seitlich vom tiefsten Punkt höher als an diesem?    Der tiefste Punkt liegt bei mit . Bei ist Der Höhenunterschied beträgt also . Eine Parabel sieht ähnlich aus, ist aber nicht dasselbe: Wer eine Freileitung plant, rechnet mit . Stellt man die Kettenlinie auf den Kopf, erhält man übrigens die ideale Form eines Bogens, in dem nur Druck und keine Biegung auftritt. Der Architekt Antoni Gaudí hat deshalb seine Gewölbe mit Hängemodellen aus Schnüren und Gewichten entworfen, und der Gateway Arch in St. Louis folgt einer (leicht abgewandelten) umgedrehten Kettenlinie.       Grenzwerte von Funktionen  Was passiert mit einer Funktion in der Nähe einer Stelle, an der man sie gar nicht auswerten darf? Ein Beispiel: ist bei nicht definiert, denn dort steht . Setzt man Werte in der Nähe ein, zeigt sich aber ein klares Bild: Von beiden Seiten nähern sich die Funktionswerte der . Eine Wertetabelle ist allerdings kein Beweis — sie könnte eine Besonderheit zwischen den Stützstellen übersehen, und wir werden gleich ein Beispiel sehen, bei dem sie gründlich in die Irre führt.  Den präzisen Begriff liefert der Grenzwert von Folgen aus . Die Idee: Man nähert sich der Stelle auf jede erdenkliche Weise mit einer Folge und schaut, ob die Funktionswerte dann immer gegen denselben Wert streben. Mit der folgenden Definition und den Rechenregeln können wir den Grenzwert im Beispiel oben exakt bestimmen ( ).   Grenzwert einer Funktion, links-\/rechtsseitiger Grenzwert   Sei ein Intervall, , und sei eine Funktion.     hat den Grenzwert  an der Stelle , falls für jede Folge im Definitionsbereich von mit gilt: . Wir schreiben .   hat den linksseitigen (bzw. rechtsseitigen ) Grenzwert  an der Stelle , falls dies für jede Folge mit und (bzw. ) gilt. Wir schreiben bzw. .    Der beidseitige Grenzwert existiert genau dann, wenn beide einseitigen Grenzwerte existieren und übereinstimmen.    Das kleine Wort jede in der Definition ist wichtig. Es genügt nicht, sich der Stelle auf einem bequemen Weg zu nähern — wie trügerisch das sein kann, zeigt das folgende Beispiel.   Wenn die Wertetabelle lügt   Werten Sie an den Stellen aus. Was vermuten Sie über ? Untersuchen Sie dann die Folge .    Es ist , und . Allgemein ist für jedes — die Tabelle legt den Grenzwert nahe. Aber für ist für alle . Zwei Folgen, die beide gegen gehen, liefern verschiedene Grenzwerte der Funktionswerte. Also existiert nicht: Nahe schwingt die Funktion immer schneller zwischen und hin und her, und die Stützstellen haben zufällig immer die Nullstellen erwischt. Ein Computer, der ein paar Werte ausprobiert , wäre auf genau diese Falle hereingefallen.    Ganz analog definiert man Grenzwerte für (bzw. ): bedeutet, dass für jede Folge gilt. Solche Grenzwerte beschreiben das Langzeitverhalten, etwa die Kosten pro Stück bei sehr großen Produktionsmengen.   Rechenregeln für Grenzwerte   Es gelte und . Dann:       , falls   (Sandwich-Satz) Gilt und für alle in einer Umgebung von , so folgt .       Grenzwert durch Faktorisieren   Bestimmen Sie .    Einsetzen von ergibt den unbestimmten Ausdruck ; wir faktorisieren den Zähler. Die Nullstellen von sind und , also . Für kann gekürzt werden: Damit .     Grenzwert durch Rationalisieren   Bestimmen Sie .    Wir erweitern mit der dritten binomischen Formel, also mit : Für strebt dies gegen .     Einseitige Grenzwerte, die nicht übereinstimmen   Zeigen Sie, dass für keinen Grenzwert besitzt.    Für ist , also , somit . Für ist , also , somit . Da die beiden einseitigen Grenzwerte nicht übereinstimmen, existiert nicht.     Sandwich-Satz bei oszillierender Funktion   Bestimmen Sie .    Der Faktor oszilliert für und besitzt keinen Grenzwert, ist aber stets zwischen und beschränkt. Damit gilt für alle : Da , folgt mit dem Sandwich-Satz .    Der Sandwich-Satz liefert auch einen der wichtigsten Grenzwerte der Analysis überhaupt, den man mit keinem Kürzen und Erweitern herausbekommt.   Der Grenzwert   Bestimmen Sie ( im Bogenmaß). Vergleichen Sie zuerst mit einigen Werten und begründen Sie das Ergebnis dann am Einheitskreis ( ).   Am Einheitskreis gilt für : kleines Dreieck Kreissektor großes Dreieck, also .    Ein Viertel des Einheitskreises im ersten Quadranten. Vom Ursprung geht ein Strahl unter dem Winkel aus, der den Kreis im Punkt schneidet und die senkrechte Tangente bei in der Höhe . Drei ineinanderliegende Flächen sind unterschiedlich stark eingefärbt: das dunkle kleine Dreieck aus Ursprung, und dem Kreispunkt, der mittlere Kreissektor und das helle große Dreieck aus Ursprung, und .        Einsetzen von ergibt . Werte: , — der Grenzwert ist vermutlich .  Zur Begründung sei . In liegen drei Flächen ineinander: das kleine Dreieck mit Höhe , der Kreissektor mit Winkel und das große Dreieck mit Höhe . Ihre Flächeninhalte sind , (der Sektor ist der Anteil der Kreisfläche ) und , also Teilen durch und Übergang zu den Kehrwerten ergibt Da (der Kosinus ist stetig, siehe ), liefert der Sandwich-Satz für . Für negative gilt dasselbe, weil . Also   Praktisch heißt das: Für kleine Winkel ist . Ingenieure nutzen diese Kleinwinkelnäherung ständig, etwa beim Fadenpendel oder in der Optik.     Anwendungsbeispiel: Stückkosten bei großer Produktion (zur Vertiefung)   Ein Unternehmen hat Fixkosten von  € und variable Kosten von  € pro Stück. Durch Mengenrabatte beim Materialeinkauf sinken die variablen Kosten pro zusätzlichem Stück mit wachsender Stückzahl , sodass die Gesamtkosten betragen. Gegen welchen Wert streben die Stückkosten für ?    Wir teilen jeden Summanden durch : Für gilt und , also Die Fixkosten verteilen sich auf immer mehr Stück und verschwinden pro Stück ( Fixkostendegression ); übrig bleiben die variablen Kosten, durch den Rabatt auf  € pro Stück gesenkt. Die Technik ist dieselbe wie bei Folgen ( ): durch die höchste Potenz kürzen.     Anwendungsbeispiel: Sättigung der Sigmoid-Funktion   Bestimmen Sie und für die Sigmoid-Funktion aus .    Für geht , also , und damit . Für geht , also , und damit . Die Sigmoid-Funktion nähert sich also für große den horizontalen Asymptoten bzw. an — sie sättigt . Diese Sättigung ist beim Training neuronaler Netze relevant: Für sehr große wird der Funktionswert nahezu konstant, was (wie in gezeigt wird) zu sehr kleinen Gradienten führt.      Stetige Funktionen  Anschaulich ist eine Funktion stetig, wenn man ihren Graphen zeichnen kann, ohne den Stift abzusetzen. Der Grenzwertbegriff aus macht diese Anschauung präzise.  Stetigkeit klingt nach einer Selbstverständlichkeit, ist aber die Voraussetzung für zwei sehr praktische Dinge: Man darf Grenzwerte einfach durch Einsetzen berechnen, und man kann Nullstellen einkreisen, ohne die Gleichung lösen zu können. Beides sehen wir in diesem Unterabschnitt. Umgekehrt sind Unstetigkeiten in Anwendungen oft genau die Stellen, an denen etwas Interessantes passiert: ein Tarifsprung, ein Schaltvorgang.   Stetigkeit   Eine reelle Funktion ist stetig an der Stelle  , wenn Ist an jeder Stelle von stetig, so heißt  stetig .    In der Definition stecken drei Bedingungen: muss definiert sein, der Grenzwert muss existieren, und beide müssen übereinstimmen.   Anwendungsbeispiel: Ein Versandtarif mit Sprung   Ein Onlinehändler berechnet für Bestellungen mit Warenwert  € Versandkosten von  €, ab  € ist der Versand kostenlos. Der Rechnungsbetrag ist also Ist an der Stelle stetig?    Von links gilt , von rechts . Die einseitigen Grenzwerte stimmen nicht überein, der Grenzwert existiert nicht, und ist bei unstetig — der Graph springt um  € nach unten. Genau dieser Sprung ist gewollt: Wer für  € bestellt, zahlt  €; wer für  € mehr einkauft, zahlt nur  €. Unstetige Tarife setzen bewusst Anreize.    Nicht jeder Sprung ist erwünscht. Oft möchte man einen abschnittsweise definierten Tarif so festlegen, dass er an der Nahtstelle keinen Sprung macht. Dann bestimmt man einen freien Parameter so, dass links- und rechtsseitiger Grenzwert übereinstimmen.   Anwendungsbeispiel: Einen Stromtarif stetig machen   Ein Energieversorger berechnet bis zu einem Jahresverbrauch von  kWh einen Preis von  € pro kWh. Wer mehr verbraucht, zahlt für den gesamten Verbrauch einen Grundpreis plus  € pro kWh: Wie muss gewählt werden, damit stetig ist? Was passiert bei  €?    Beide Teilstücke sind als lineare Funktionen stetig; kritisch ist nur die Nahtstelle . Dort ist Stetig ist genau dann, wenn , also  €. Bei  € dagegen springt die Rechnung an der Grenze um  € nach unten : Ein Haushalt mit  kWh zahlt  €, einer mit  kWh nur  €. Wer knapp unter der Grenze liegt, würde also Geld sparen, indem er mehr Strom verbraucht — ein klassischer Schwelleneffekt , den ein stetiger Tarif vermeidet.    Zum Glück muss man Stetigkeit nur selten mit der Definition nachweisen. Die meisten Funktionen sind aus stetigen Bausteinen zusammengesetzt, und dabei bleibt die Stetigkeit erhalten.   Kombination und Verkettung stetiger Funktionen   Sind und an der Stelle stetig, so sind auch , und (falls ) an der Stelle stetig. Ist an der Stelle und an der Stelle stetig, so ist auch die Verkettung an der Stelle stetig. Alle elementaren Funktionen ( ) sind auf ihrem gesamten Definitionsbereich stetig.     Stetigkeit einer zusammengesetzten Funktion (zur Vertiefung)   Begründen Sie, warum auf ganz stetig ist.     ist als Polynom stetig und stets positiv, die Wurzelfunktion ist auf stetig, also ist die Verkettung auf ganz stetig. Ebenso sind und als elementare Funktionen stetig, also auch ihre Verkettung . Als Produkt zweier auf stetiger Funktionen ist damit auch auf ganz stetig.     Anwendungsbeispiel: Die ReLU-Funktion ist stetig   Zeigen Sie, dass die ReLU-Funktion aus , an der Stelle stetig ist.    Der linksseitige Grenzwert ist , der rechtsseitige . Beide stimmen überein und mit dem Funktionswert , also ist : ist an der Stelle stetig — trotz des Knicks im Graphen. Stetigkeit verlangt nur übereinstimmende Grenzwerte, keine Glattheit ; ob die Funktion an dieser Stelle auch differenzierbar ist, untersuchen wir in .     Zwischenwertsatz, Nullstellensatz   Sei eine auf stetige Funktion.    ( Zwischenwertsatz ) nimmt jeden Wert zwischen und mindestens einmal an.  ( Nullstellensatz ) Haben und unterschiedliche Vorzeichen, so besitzt mindestens eine Nullstelle in .      Der Nullstellensatz ist anschaulich klar — wer den Stift nicht absetzt, muss die -Achse kreuzen, um von unten nach oben zu gelangen. Er ist aber auch die Grundlage eines einfachen, robusten Algorithmus zur Nullstellensuche.   Rechenbeispiel: Nullstellen einkreisen durch Intervallhalbierung   Zeigen Sie, dass eine Nullstelle in hat, und schränken Sie sie durch viermaliges Halbieren des Intervalls ein.     ist als Polynom stetig, und , . Nach dem Nullstellensatz liegt in eine Nullstelle. Nun werten wir in der Intervallmitte aus und behalten die Hälfte, an deren Rändern das Vorzeichen wechselt: Die Nullstelle liegt also zwischen und (tatsächlich bei ). Jeder Schritt halbiert die Unsicherheit; nach Schritten ist das Intervall lang, nach Schritten also kürzer als ein Millionstel. Das Bisektionsverfahren ist langsamer als das Heron-Verfahren oder das später behandelte Newton-Verfahren ( ), funktioniert aber für jede stetige Funktion mit Vorzeichenwechsel.     Das Rätsel von der Bergwanderung   Eine Wanderin bricht um 6 Uhr morgens im Tal auf und erreicht um 18 Uhr die Berghütte. Am nächsten Morgen startet sie um 6 Uhr auf demselben Weg zum Abstieg und ist um 18 Uhr wieder im Tal. Unterwegs läuft sie an beiden Tagen ganz unterschiedlich schnell und macht Pausen, wo es ihr gefällt. Gibt es eine Stelle des Weges, an der sie an beiden Tagen zur selben Uhrzeit ist?    Die Antwort ist ja — und zwar ganz egal, wie sie läuft. Sei die Weglänge, ihre Position (Wegstrecke ab Tal) am ersten Tag und die am zweiten Tag, jeweils zur Uhrzeit . Beide Funktionen sind stetig, denn niemand springt. Die Differenz ist ebenfalls stetig, und Nach dem Nullstellensatz gibt es ein mit , also : Zur Uhrzeit ist sie an beiden Tagen an derselben Stelle.  Wer das nicht glaubt, stelle sich zwei Wanderinnen vor, die am selben Tag losgehen, eine von unten, eine von oben — sie müssen sich unterwegs begegnen. Bemerkenswert ist, was der Beweis nicht liefert: Wann und wo die Begegnung stattfindet, sagt er nicht. Der Nullstellensatz ist ein reiner Existenzsatz, genau wie der Fundamentalsatz der Algebra in .     Stetige Fortsetzung   Seien ein Intervall, , und eine auf definierte Funktion. Existiert der Grenzwert , so heißt  stetig fortsetzbar durch     Ein Beispiel kennen wir schon: Die Funktion aus ist bei nicht definiert, hat dort aber den Grenzwert . Mit dem Wert an der Stelle wird sie stetig fortgesetzt — die Fortsetzung ist einfach . Anders bei : Dort wachsen die Funktionswerte beim Annähern an über alle Grenzen (Polstelle), ein Grenzwert existiert nicht, und keine Wahl von macht die Funktion stetig.    Zusammenfassung     Abbildung  : jedem genau ein . Injektiv: verschiedene Argumente, verschiedene Werte. Surjektiv: jedes wird getroffen. Bijektiv: beides — dann existiert die Umkehrabbildung . Verkettung , im Allgemeinen nicht kommutativ. Schubfachprinzip: Hat mehr Elemente als , kann nicht injektiv sein.   Reelle Funktionen: maximale Definitionsmenge (Wurzeln , Nenner , Logarithmus ); gerade ( ) oder ungerade ( ); periodisch mit Periode ; (streng) monoton. Streng monoton injektiv umkehrbar; Umkehrfunktion durch Auflösen von nach , Graph gespiegelt an ; nötigenfalls Definitionsbereich einschränken.   Elementare Funktionen:  und sind Umkehrfunktionen voneinander; Potenz- und Logarithmengesetze; Basiswechsel , ; auf der Log-Skala wird exponentielles Wachstum zur Geraden, . , sind -periodisch; , , kehren eingeschränkte Zweige um; hat Periode . Hyperbelfunktionen: .   Grenzwert  : für jede Folge . Links- und rechtsseitige Grenzwerte müssen übereinstimmen. Techniken bei : Faktorisieren und Kürzen, Erweitern mit der dritten binomischen Formel, Sandwich-Satz bei beschränkten Faktoren. Wichtig: (im Bogenmaß), also für kleine . Wertetabellen können täuschen ( an den Stellen ).   Stetig in : . Elementare Funktionen sind stetig; Summen, Produkte, Quotienten und Verkettungen stetiger Funktionen bleiben stetig. Knicke sind erlaubt (ReLU), Sprünge nicht (Versandkostentarif). Bei abschnittsweise definierten Funktionen prüft man die Nahtstellen: links- und rechtsseitiger Grenzwert müssen mit dem Funktionswert übereinstimmen — so bestimmt man auch freie Parameter (stetiger Tarif).   Zwischenwertsatz: Eine auf stetige Funktion nimmt jeden Wert zwischen und an; bei Vorzeichenwechsel gibt es eine Nullstelle. Stetige Fortsetzung einer Definitionslücke durch den Grenzwert, falls er existiert.   Roter Faden: ReLU ist abschnittsweise definiert, hat Wertebereich und ist stetig; Sigmoid hat Werte in , und sättigt: für , für .      Übungsaufgaben    Untersuchen Sie , , und , , jeweils auf Injektivität und Surjektivität.     ist injektiv: Aus folgt . Sie ist aber nicht surjektiv, da z. B. kein Urbild besitzt (kein erfüllt ).   ist ebenfalls injektiv: Aus folgt . Sie ist nicht surjektiv, da kein Urbild besitzt ( für alle ).      Untersuchen Sie und auf Symmetrie (gerade, ungerade oder keines von beidem).    Es gilt , also ist gerade. Für : , also ist ungerade.      Bestimmen Sie .    Die Nullstellen von sind und , also . Für gilt Damit .      Untersuchen Sie, ob sich an der Stelle stetig fortsetzen lässt.    Mit der Faktorisierung (Formel für die Differenz dritter Potenzen, ) gilt für : Damit . Der Grenzwert existiert, also ist stetig fortsetzbar mit Funktionswert an der Stelle .      Lösen Sie die Gleichung nach auf.    Anwenden von auf beide Seiten liefert , also (Probe der Definitionsbedingung: ist erfüllt.)     "
},
{
  "id": "sec-funktionen-stetigkeit-2",
  "level": "2",
  "url": "sec-funktionen-stetigkeit.html#sec-funktionen-stetigkeit-2",
  "type": "Lernziele",
  "number": "3.1",
  "title": "",
  "body": "  Nach diesem Abschnitt können Sie    Abbildungen mit Definitions-, Ziel- und Bildmenge beschreiben, auf Injektivität, Surjektivität und Bijektivität prüfen sowie Verkettungen und Umkehrabbildungen bilden;  reelle Funktionen auf maximale Definitionsmenge, Symmetrie, Periodizität und Monotonie untersuchen und Umkehrfunktionen bestimmen;  mit Exponential-, Logarithmus-, trigonometrischen und Hyperbelfunktionen rechnen und zugehörige Gleichungen lösen;  Grenzwerte von Funktionen durch Faktorisieren, Rationalisieren, einseitige Betrachtung und den Sandwich-Satz berechnen;  Stetigkeit nachweisen, Parameter abschnittsweise definierter Funktionen so wählen, dass sie stetig werden, den Zwischenwertsatz anwenden und Definitionslücken stetig fortsetzen;  ReLU und Sigmoid — die Standardfunktionen neuronaler Netze — mit diesen Begriffen einordnen.   "
},
{
  "id": "sub-abbildungen-2-1",
  "level": "2",
  "url": "sec-funktionen-stetigkeit.html#sub-abbildungen-2-1",
  "type": "Absatz (with a defined term)",
  "number": "",
  "title": "",
  "body": "Abbildung "
},
{
  "id": "def-abbildung",
  "level": "2",
  "url": "sec-funktionen-stetigkeit.html#def-abbildung",
  "type": "Definition",
  "number": "3.1.1",
  "title": "Abbildung, Funktion.",
  "body": " Abbildung, Funktion   Eine Abbildung (auch Funktion genannt) von einer Menge auf eine Menge ist eine Zuordnung, die jedem   genau ein  zuordnet. Man schreibt oder kurz .   "
},
{
  "id": "ex-abbildung-oder-nicht",
  "level": "2",
  "url": "sec-funktionen-stetigkeit.html#ex-abbildung-oder-nicht",
  "type": "Beispiel",
  "number": "3.1.2",
  "title": "Abbildung oder nicht? (zur Vertiefung).",
  "body": " Abbildung oder nicht? (zur Vertiefung)   In einer Hochschuldatenbank gibt es eine Tabelle aller Studierenden. Welche der folgenden Zuordnungen sind Abbildungen?  Matrikelnummer Geburtsdatum der Person mit dieser Nummer;  Geburtsdatum Person mit diesem Geburtsdatum;  reelle Zahl  die Zahlen mit .        Ja: Jede Matrikelnummer gehört zu genau einer Person, und diese hat genau ein Geburtsdatum. Dass viele Nummern auf dasselbe Datum abgebildet werden, ist erlaubt.  Nein, gleich doppelt nicht: An manchen Daten sind mehrere Studierende geboren ( genau ein verletzt), an manchen niemand ( jedem verletzt).  Nein: Zu gehören und . Erst die Festlegung die nicht negative Lösung macht daraus die Wurzelfunktion .    Nebenbei: Dass die Matrikelnummer eine Person eindeutig festlegt, macht sie in der Datenbank zum Schlüssel . Die Zuordnung Person Matrikelnummer darf also nie zwei Personen dieselbe Nummer geben — genau diese Eigenschaft werden wir gleich injektiv nennen.   "
},
{
  "id": "def-grundbegriffe-abbildung",
  "level": "2",
  "url": "sec-funktionen-stetigkeit.html#def-grundbegriffe-abbildung",
  "type": "Definition",
  "number": "3.1.3",
  "title": "Definitionsmenge, Bildmenge, Urbild.",
  "body": " Definitionsmenge, Bildmenge, Urbild   Sei eine Abbildung. Dann heißt    die Definitionsmenge von ,  ein Argument von ,  die Zielmenge von ,   die Bildmenge (oder Wertemenge , das Bild ) von ,  für und das Element das Bild von und ein Urbild von ,  für die Menge die Urbildmenge von .    Der Name des Arguments spielt dabei keine Rolle: und beschreiben dieselbe Abbildung. Ebenso ist zwischen der Abbildung selbst und dem einzelnen Wert , der beim Einsetzen von entsteht, zu unterscheiden.   "
},
{
  "id": "ex-bild-urbild-quadrieren",
  "level": "2",
  "url": "sec-funktionen-stetigkeit.html#ex-bild-urbild-quadrieren",
  "type": "Beispiel",
  "number": "3.1.4",
  "title": "Bild- und Urbildmengen bestimmen.",
  "body": " Bild- und Urbildmengen bestimmen   Sei , . Bestimmen Sie und .    Einsetzen liefert , , , , , also (Werte zählen nur einmal). Für die Urbildmenge suchen wir alle mit : Da keine Quadratzahl ist und , , folgt .   "
},
{
  "id": "def-verkettung",
  "level": "2",
  "url": "sec-funktionen-stetigkeit.html#def-verkettung",
  "type": "Definition",
  "number": "3.1.5",
  "title": "Verkettung von Abbildungen.",
  "body": " Verkettung von Abbildungen   Seien und zwei Abbildungen, derart dass die Zielmenge von im Definitionsgebiet von enthalten ist. Dann ist die Verkettung ( Hintereinanderausführung ) von und die Abbildung Man liest als nach : Zuerst wird angewandt, dann .   "
},
{
  "id": "ex-verkettung-berechnen",
  "level": "2",
  "url": "sec-funktionen-stetigkeit.html#ex-verkettung-berechnen",
  "type": "Beispiel",
  "number": "3.1.6",
  "title": "Verkettung berechnen.",
  "body": " Verkettung berechnen   Seien , , und , . Bestimmen Sie und und stellen Sie fest, ob gilt.    Es gilt und . Da bereits die Koeffizienten von verschieden sind ( gegen ), gilt : Die Verkettung von Abbildungen ist im Allgemeinen nicht kommutativ.   "
},
{
  "id": "def-injektiv-surjektiv-bijektiv",
  "level": "2",
  "url": "sec-funktionen-stetigkeit.html#def-injektiv-surjektiv-bijektiv",
  "type": "Definition",
  "number": "3.1.7",
  "title": "Injektiv, surjektiv, bijektiv.",
  "body": " Injektiv, surjektiv, bijektiv   Sei eine Abbildung.     heißt injektiv , falls für alle mit folgt, dass (verschiedene Elemente werden auf verschiedene Elemente abgebildet).   heißt surjektiv , falls für alle ein mit existiert (alle Elemente von haben mindestens ein Urbild).   heißt bijektiv , wenn injektiv und surjektiv ist.     "
},
{
  "id": "ex-injektiv-surjektiv-pruefen",
  "level": "2",
  "url": "sec-funktionen-stetigkeit.html#ex-injektiv-surjektiv-pruefen",
  "type": "Beispiel",
  "number": "3.1.8",
  "title": "Injektivität und Surjektivität nachweisen.",
  "body": " Injektivität und Surjektivität nachweisen   Untersuchen Sie , , und , , jeweils auf Injektivität und Surjektivität.     ist nicht injektiv, denn mit . ist auch nicht surjektiv, denn hat kein Urbild in (keine ganze Zahl quadriert zu ).   dagegen ist injektiv: Sind mit , so folgt wegen bereits (Kontraposition der Injektivitätsbedingung). ist aber nicht surjektiv, da z. B. kein Urbild besitzt ( , , nichts liegt dazwischen). Das Beispiel zeigt: Injektivität und Surjektivität hängen nicht nur von der Rechenvorschrift, sondern auch von Definitions- und Zielmenge ab.   "
},
{
  "id": "ssub-injektiv-surjektiv-umkehrabbildung-5",
  "level": "2",
  "url": "sec-funktionen-stetigkeit.html#ssub-injektiv-surjektiv-umkehrabbildung-5",
  "type": "Absatz (with a defined term)",
  "number": "",
  "title": "",
  "body": "Schubfachprinzip Hashfunktion Quantisierung "
},
{
  "id": "def-umkehrabbildung",
  "level": "2",
  "url": "sec-funktionen-stetigkeit.html#def-umkehrabbildung",
  "type": "Definition",
  "number": "3.1.9",
  "title": "Umkehrabbildung.",
  "body": " Umkehrabbildung   Sei eine Abbildung. Ist bijektiv, so wird durch , mit , eine Abbildung definiert, die sogenannte Umkehrabbildung von . Sie wird mit bezeichnet. Es gilt und , wobei die identische Abbildung auf bezeichnet.   "
},
{
  "id": "ex-anwendung-temperatur-umrechnen",
  "level": "2",
  "url": "sec-funktionen-stetigkeit.html#ex-anwendung-temperatur-umrechnen",
  "type": "Beispiel",
  "number": "3.1.10",
  "title": "Anwendungsbeispiel: Temperaturen umrechnen.",
  "body": " Anwendungsbeispiel: Temperaturen umrechnen   Ein Sensor liefert Temperaturen in Grad Celsius; ein US-amerikanisches Dashboard erwartet Grad Fahrenheit. Die Umrechnung ist , . Zeigen Sie, dass bijektiv ist, und bestimmen Sie die Umkehrabbildung. Welche Celsius-Temperatur entspricht  °F?    Wir lösen nach auf: Zu jedem gibt es also genau ein Urbild : ist surjektiv (es gibt eines) und injektiv (es gibt nur eines), also bijektiv, und Für ergibt sich — die normale Körpertemperatur. Probe: . Das Auflösen nach der Eingabe ist das Standardverfahren, um die Umkehrabbildung zu bestimmen: Gelingt es eindeutig, ist die Abbildung bijektiv.   "
},
{
  "id": "sub-grundbegriffe-funktionen-2-1",
  "level": "2",
  "url": "sec-funktionen-stetigkeit.html#sub-grundbegriffe-funktionen-2-1",
  "type": "Absatz (with a defined term)",
  "number": "",
  "title": "",
  "body": "reelle Funktionen "
},
{
  "id": "def-reelle-funktion",
  "level": "2",
  "url": "sec-funktionen-stetigkeit.html#def-reelle-funktion",
  "type": "Definition",
  "number": "3.1.11",
  "title": "Reelle Funktion, Wertebereich, Nullstelle.",
  "body": " Reelle Funktion, Wertebereich, Nullstelle   Wir betrachten Funktionen mit (der Definitionsmenge ) und (der Zielmenge ). Werden und nicht explizit angegeben, so gilt stillschweigend: ist die maximale Definitionsmenge — die Menge aller reellen Zahlen, die in die Funktionsvorschrift eingesetzt werden dürfen — und .  Der Wertebereich von ist die Menge . Eine Nullstelle von ist ein mit .   "
},
{
  "id": "ex-maximale-definitionsmenge",
  "level": "2",
  "url": "sec-funktionen-stetigkeit.html#ex-maximale-definitionsmenge",
  "type": "Beispiel",
  "number": "3.1.12",
  "title": "Maximale Definitionsmenge bestimmen.",
  "body": " Maximale Definitionsmenge bestimmen   Bestimmen Sie die maximale Definitionsmenge von .    Der Ausdruck unter der Wurzel muss nichtnegativ sein: . Außerdem darf der Nenner nicht sein: . Insgesamt    "
},
{
  "id": "ssub-definitionsmenge-graph-4",
  "level": "2",
  "url": "sec-funktionen-stetigkeit.html#ssub-definitionsmenge-graph-4",
  "type": "Absatz (with a defined term)",
  "number": "",
  "title": "",
  "body": "Graph "
},
{
  "id": "def-abschnittsweise-funktion",
  "level": "2",
  "url": "sec-funktionen-stetigkeit.html#def-abschnittsweise-funktion",
  "type": "Definition",
  "number": "3.1.13",
  "title": "Abschnittsweise definierte Funktion.",
  "body": " Abschnittsweise definierte Funktion   Eine Funktion, deren Definitionsbereich aus endlich vielen Intervallen besteht, für die jeweils eine eigene Funktionsvorschrift gegeben ist, heißt abschnittsweise definiert .   "
},
{
  "id": "ex-anwendung-relu",
  "level": "2",
  "url": "sec-funktionen-stetigkeit.html#ex-anwendung-relu",
  "type": "Beispiel",
  "number": "3.1.14",
  "title": "Anwendungsbeispiel: Die ReLU-Aktivierungsfunktion.",
  "body": " Anwendungsbeispiel: Die ReLU-Aktivierungsfunktion   In künstlichen neuronalen Netzen wird häufig die ReLU-Funktion ( rectified linear unit ) als Aktivierungsfunktion verwendet: Geben Sie , und an, und bestimmen Sie den Wertebereich von .    Einsetzen liefert , , . Da negative Eingaben stets auf abgebildet werden und nichtnegative Eingaben unverändert bleiben, ist der Wertebereich . Wir kommen in auf die ReLU-Funktion zurück und untersuchen, ob der Knick bei ihre Stetigkeit beeinträchtigt.   "
},
{
  "id": "fig-relu",
  "level": "2",
  "url": "sec-funktionen-stetigkeit.html#fig-relu",
  "type": "Abbildung",
  "number": "3.1.15",
  "title": "",
  "body": " Die ReLU-Funktion: links von konstant null, rechts die Identität — mit einem Knick bei .    Ein Koordinatensystem mit dem Graphen der ReLU-Funktion: Für negative verläuft der Graph auf der -Achse, für positive als Gerade mit Steigung durch den Ursprung. Am Ursprung hat der Graph einen Knick.     "
},
{
  "id": "def-gerade-ungerade-funktion",
  "level": "2",
  "url": "sec-funktionen-stetigkeit.html#def-gerade-ungerade-funktion",
  "type": "Definition",
  "number": "3.1.16",
  "title": "Gerade und ungerade Funktion.",
  "body": " Gerade und ungerade Funktion   Sei eine auf einem zum Ursprung symmetrischen Intervall definierte Funktion.     heißt gerade , wenn für alle . Der Graph ist dann achsensymmetrisch zur -Achse.   heißt ungerade , wenn für alle . Der Graph ist dann punktsymmetrisch zum Ursprung.     "
},
{
  "id": "def-periodische-funktion",
  "level": "2",
  "url": "sec-funktionen-stetigkeit.html#def-periodische-funktion",
  "type": "Definition",
  "number": "3.1.17",
  "title": "Periodische Funktion.",
  "body": " Periodische Funktion   Sei eine auf einem Intervall definierte Funktion. heißt periodisch mit Periode  , wenn für alle mit  gilt. Ist periodisch mit Periode , so auch mit jeder Periode , ; die kleinste positive Periode heißt primitive Periode .   "
},
{
  "id": "ex-periode-bestimmen",
  "level": "2",
  "url": "sec-funktionen-stetigkeit.html#ex-periode-bestimmen",
  "type": "Beispiel",
  "number": "3.1.18",
  "title": "Anwendungsbeispiel: Perioden in Zeitreihen.",
  "body": " Anwendungsbeispiel: Perioden in Zeitreihen   Der Stromverbrauch eines Bürogebäudes (in kW) wird über den Tag durch modelliert, in Stunden ab Mitternacht. Bestimmen Sie die primitive Periode. Wann ist der Verbrauch am höchsten?    Der Kosinus hat die primitive Periode . Das Argument durchläuft eine volle Periode, wenn um mit wächst, also : Der Verbrauch wiederholt sich im Tagesrhythmus, . Am höchsten ist er, wenn ist, also bei , d. h. um Uhr mittags, mit  kW; nachts um Uhr liegt er bei  kW. Solche Tages-, Wochen- und Jahresperioden zu erkennen, ist ein Standardschritt bei der Analyse von Zeitreihen.   "
},
{
  "id": "def-monotone-funktion",
  "level": "2",
  "url": "sec-funktionen-stetigkeit.html#def-monotone-funktion",
  "type": "Definition",
  "number": "3.1.19",
  "title": "Monotone Funktion.",
  "body": " Monotone Funktion   Sei eine auf einem Intervall definierte Funktion. heißt     monoton wachsend , wenn für alle in : ; streng monoton wachsend , wenn sogar gilt;   monoton fallend , wenn für alle in : ; streng monoton fallend , wenn sogar gilt.     "
},
{
  "id": "ex-monotonie-differenz-funktion",
  "level": "2",
  "url": "sec-funktionen-stetigkeit.html#ex-monotonie-differenz-funktion",
  "type": "Beispiel",
  "number": "3.1.20",
  "title": "Monotonie über die Differenz nachweisen (zur Vertiefung).",
  "body": " Monotonie über die Differenz nachweisen (zur Vertiefung)   Zeigen Sie, dass auf streng monoton wachsend ist.    Für in betrachten wir die Differenz: Da , sind und , also ist der Nenner positiv; der Zähler ist wegen ebenfalls positiv. Damit ist , also : ist streng monoton wachsend.   "
},
{
  "id": "ex-umkehrfunktion-einschraenkung",
  "level": "2",
  "url": "sec-funktionen-stetigkeit.html#ex-umkehrfunktion-einschraenkung",
  "type": "Beispiel",
  "number": "3.1.21",
  "title": "Umkehrfunktion durch Einschränkung des Definitionsbereichs.",
  "body": " Umkehrfunktion durch Einschränkung des Definitionsbereichs   Die Funktion , , ist auf ganz nicht injektiv. Finden Sie ein möglichst großes Intervall mit , auf dem die Einschränkung von injektiv ist, und bestimmen Sie die Umkehrfunktion dieser Einschränkung.     ist eine um nach rechts und nach oben verschobene Normalparabel; sie ist genau auf und auf jeweils streng monoton, also injektiv. Da , wählen wir .  Auflösen von nach (für , dem Wertebereich der Einschränkung): , und wegen folgt , also . Die Umkehrfunktion ist damit Probe: und . Hätten wir gewählt, wäre beim Wurzelziehen das negative Vorzeichen richtig gewesen: . Die Wahl des Intervalls entscheidet also mit über die Formel der Umkehrfunktion.   "
},
{
  "id": "sub-elementare-funktionen-2-1",
  "level": "2",
  "url": "sec-funktionen-stetigkeit.html#sub-elementare-funktionen-2-1",
  "type": "Absatz (with a defined term)",
  "number": "",
  "title": "",
  "body": "elementar "
},
{
  "id": "def-exponentialfunktion",
  "level": "2",
  "url": "sec-funktionen-stetigkeit.html#def-exponentialfunktion",
  "type": "Definition",
  "number": "3.1.22",
  "title": "Exponentialfunktion.",
  "body": " Exponentialfunktion   Eine Funktion mit Abbildungsvorschrift für eine feste reelle Basis heißt Exponentialfunktion . Für ist streng monoton wachsend, für streng monoton fallend; in beiden Fällen ist bijektiv.   "
},
{
  "id": "thm-rechenregeln-exponential",
  "level": "2",
  "url": "sec-funktionen-stetigkeit.html#thm-rechenregeln-exponential",
  "type": "Satz",
  "number": "3.1.23",
  "title": "Rechenregeln für Exponentialfunktionen.",
  "body": " Rechenregeln für Exponentialfunktionen   Für und gilt:            "
},
{
  "id": "def-eulersche-zahl-funktion",
  "level": "2",
  "url": "sec-funktionen-stetigkeit.html#def-eulersche-zahl-funktion",
  "type": "Definition",
  "number": "3.1.24",
  "title": "Eulersche Zahl.",
  "body": " Eulersche Zahl   Die Eulersche Zahl  ist die eindeutig bestimmte reelle Zahl, für die die Exponentialfunktion an der Stelle Steigung hat. Sie ist irrational, . Die Funktion heißt die Exponentialfunktion und wird auch als geschrieben.   "
},
{
  "id": "ex-anwendung-verzinsung-exponentialfunktion",
  "level": "2",
  "url": "sec-funktionen-stetigkeit.html#ex-anwendung-verzinsung-exponentialfunktion",
  "type": "Beispiel",
  "number": "3.1.25",
  "title": "Anwendungsbeispiel: Kapitalwert als Exponentialfunktion.",
  "body": " Anwendungsbeispiel: Kapitalwert als Exponentialfunktion   Ein Kapital von wird mit einem festen Jahreszins von verzinst. Geben Sie den Kapitalwert als Funktion der Laufzeit (in Jahren) an, und berechnen Sie .    Mit und Wachstumsfaktor pro Jahr ist , eine Exponentialfunktion in . Es folgt . Anders als bei der linearen Verzinsung wächst hier mit fester relativer Rate — für ganzzahlige ist das genau die Zinseszinsfolge aus , jetzt als Funktion einer kontinuierlichen Laufzeit gelesen.   "
},
{
  "id": "def-logarithmus",
  "level": "2",
  "url": "sec-funktionen-stetigkeit.html#def-logarithmus",
  "type": "Definition",
  "number": "3.1.26",
  "title": "Logarithmus zur Basis <span class=\"process-math\">\\(b\\)<\/span>.",
  "body": " Logarithmus zur Basis   Sei , . Die Umkehrfunktion der bijektiven Exponentialfunktion , , ist die Logarithmusfunktion  Da sie Umkehrfunktionen zueinander sind, gilt für alle und für alle .   "
},
{
  "id": "thm-logarithmengesetze",
  "level": "2",
  "url": "sec-funktionen-stetigkeit.html#thm-logarithmengesetze",
  "type": "Satz",
  "number": "3.1.27",
  "title": "Logarithmengesetze.",
  "body": " Logarithmengesetze   Für , und gilt:          "
},
{
  "id": "ssub-exponential-logarithmus-9",
  "level": "2",
  "url": "sec-funktionen-stetigkeit.html#ssub-exponential-logarithmus-9",
  "type": "Absatz (with a defined term)",
  "number": "",
  "title": "",
  "body": "natürlicher Logarithmus Basiswechselformeln "
},
{
  "id": "fig-exp-ln",
  "level": "2",
  "url": "sec-funktionen-stetigkeit.html#fig-exp-ln",
  "type": "Abbildung",
  "number": "3.1.28",
  "title": "",
  "body": " Exponentialfunktion und natürlicher Logarithmus sind Umkehrfunktionen voneinander: Ihre Graphen gehen durch Spiegelung an der Winkelhalbierenden (gestrichelt) auseinander hervor.    Ein Koordinatensystem mit dem steil ansteigenden Graphen von , der die -Achse bei schneidet, und dem Graphen von , der die -Achse bei schneidet und nach links gegen die negative -Achse strebt. Beide Graphen sind spiegelbildlich zur gestrichelten Diagonalen .     "
},
{
  "id": "ex-exp-log-auffrischung",
  "level": "2",
  "url": "sec-funktionen-stetigkeit.html#ex-exp-log-auffrischung",
  "type": "Beispiel",
  "number": "3.1.29",
  "title": "Schulstoff zum Aufwärmen (zur Vertiefung).",
  "body": " Schulstoff zum Aufwärmen (zur Vertiefung)   (a) Schreiben Sie als eine einzige Potenz von . (b) Berechnen Sie ohne Taschenrechner. (c) Lösen Sie nach auf.    (a) Mit und ist der Ausdruck . (b) Quotientengesetz: . (c) Logarithmieren: , also .   "
},
{
  "id": "ex-anwendung-verdopplungszeit",
  "level": "2",
  "url": "sec-funktionen-stetigkeit.html#ex-anwendung-verdopplungszeit",
  "type": "Beispiel",
  "number": "3.1.30",
  "title": "Anwendungsbeispiel: Verdopplungszeit.",
  "body": " Anwendungsbeispiel: Verdopplungszeit   Nach wie vielen Jahren hat sich das Kapital aus (Zinssatz ) verdoppelt?    Gesucht ist mit , also . Logarithmieren und das dritte Logarithmengesetz holen aus dem Exponenten: Nach knapp Jahren hat sich das Kapital verdoppelt — unabhängig vom Startkapital , das sich weggekürzt hat. Praktiker rechnen das mit einer Faustregel im Kopf, die wir in begründen.   "
},
{
  "id": "ex-anwendung-log-skala",
  "level": "2",
  "url": "sec-funktionen-stetigkeit.html#ex-anwendung-log-skala",
  "type": "Beispiel",
  "number": "3.1.31",
  "title": "Anwendungsbeispiel: Exponentielles Wachstum auf der Log-Skala.",
  "body": " Anwendungsbeispiel: Exponentielles Wachstum auf der Log-Skala   Eine neue App hat nach Monaten jeweils , , und Nutzer. Zeigen Sie, dass die Daten zu passen, und dass eine lineare Funktion von ist. Wann wird die App bei gleichbleibendem Wachstum Nutzer haben? (Verwenden Sie und .)    Die Quotienten aufeinanderfolgender Werte sind alle gleich, , also . Logarithmieren mit den Logarithmengesetzen liefert eine Gerade in mit Steigung . Für brauchen wir , also Nach gut elf Monaten, also knapp einem Jahr, wäre die Marke erreicht. Genau deshalb zeichnet man Wachstumsdaten gern mit logarithmischer -Achse: Exponentielles Wachstum erscheint dort als Gerade, und jede Abweichung von der Geraden — etwa ein Abflachen, weil der Markt gesättigt ist — fällt sofort ins Auge. Aus einem verwandten Grund — Logarithmieren macht Multiplikatives additiv — logarithmiert man in der Statistik oft Einkommen, Preise oder Fallzahlen, bevor man eine Gerade an die Daten anpasst.   "
},
{
  "id": "ex-anwendung-sigmoid-funktion",
  "level": "2",
  "url": "sec-funktionen-stetigkeit.html#ex-anwendung-sigmoid-funktion",
  "type": "Beispiel",
  "number": "3.1.32",
  "title": "Anwendungsbeispiel: Die Sigmoid-Funktion.",
  "body": " Anwendungsbeispiel: Die Sigmoid-Funktion   In der logistischen Regression und als Aktivierungsfunktion in neuronalen Netzen wird die Sigmoid-Funktion  verwendet, um einen beliebigen reellen Wert (z. B. eine gewichtete Summe von Merkmalen) auf eine Wahrscheinlichkeit im Intervall abzubilden. Berechnen Sie und zeigen Sie für alle .     — eine Eingabe von entspricht also maximaler Unsicherheit. Da für alle , ist der Nenner , also . Außerdem ist streng monoton wachsend: Wächst , so fällt , also fällt , also fällt der Nenner , und der Bruch wächst. Damit ist injektiv, also umkehrbar — ihre Umkehrfunktion ist die in der logistischen Regression verwendete Logit-Funktion  . Das Grenzverhalten von für untersuchen wir in .   "
},
{
  "id": "fig-sigmoid",
  "level": "2",
  "url": "sec-funktionen-stetigkeit.html#fig-sigmoid",
  "type": "Abbildung",
  "number": "3.1.33",
  "title": "",
  "body": " Die Sigmoid-Funktion : streng monoton wachsend, Werte in , punktsymmetrisch zu , und für große nahezu konstant ( Sättigung ).    Ein Koordinatensystem mit dem S-förmigen Graphen der Sigmoid-Funktion, der von links nahe kommt, bei den Wert hat und nach rechts gegen die gestrichelte Asymptote strebt.     "
},
{
  "id": "def-arkussinus-arkuskosinus",
  "level": "2",
  "url": "sec-funktionen-stetigkeit.html#def-arkussinus-arkuskosinus",
  "type": "Definition",
  "number": "3.1.34",
  "title": "Arkussinus und Arkuskosinus.",
  "body": " Arkussinus und Arkuskosinus   Der Arkussinus ist die Umkehrfunktion der Einschränkung des Sinus auf : Der Arkuskosinus ist die Umkehrfunktion der Einschränkung des Kosinus auf :    "
},
{
  "id": "ex-trigonometrische-gleichung",
  "level": "2",
  "url": "sec-funktionen-stetigkeit.html#ex-trigonometrische-gleichung",
  "type": "Beispiel",
  "number": "3.1.35",
  "title": "Trigonometrische Gleichung lösen.",
  "body": " Trigonometrische Gleichung lösen   Bestimmen Sie alle Lösungen der Gleichung .    Umformen liefert . Da , hat die Gleichung im Hauptbereich die Lösung . Wegen der Symmetrie des Sinus ( ) und der -Periodizität ergeben sich im Intervall die beiden Lösungen    "
},
{
  "id": "ssub-trigonometrische-funktionen-6",
  "level": "2",
  "url": "sec-funktionen-stetigkeit.html#ssub-trigonometrische-funktionen-6",
  "type": "Absatz (with a defined term)",
  "number": "",
  "title": "",
  "body": "Tangens Arkustangens Kotangens Arkuskotangens Additionstheoreme "
},
{
  "id": "def-allgemeine-kosinusfunktion",
  "level": "2",
  "url": "sec-funktionen-stetigkeit.html#def-allgemeine-kosinusfunktion",
  "type": "Definition",
  "number": "3.1.36",
  "title": "Allgemeine Kosinusfunktion.",
  "body": " Allgemeine Kosinusfunktion   Die allgemeine Kosinusfunktion hat die Form mit Amplitude  , Kreisfrequenz  und Phasenverschiebung  . Ihre primitive Periode ist .   "
},
{
  "id": "def-hyperbelfunktionen",
  "level": "2",
  "url": "sec-funktionen-stetigkeit.html#def-hyperbelfunktionen",
  "type": "Definition",
  "number": "3.1.37",
  "title": "Hyperbelfunktionen.",
  "body": " Hyperbelfunktionen   Die Hyperbelfunktionen sind definiert als     "
},
{
  "id": "ex-hyperbel-identitaet",
  "level": "2",
  "url": "sec-funktionen-stetigkeit.html#ex-hyperbel-identitaet",
  "type": "Beispiel",
  "number": "3.1.38",
  "title": "Eine Hyperbelidentität nachweisen.",
  "body": " Eine Hyperbelidentität nachweisen   Zeigen Sie für alle .    Einsetzen der Definitionen: Ausmultiplizieren beider Quadrate liefert und . Die Differenz der beiden Terme in Klammern ist also , so dass . Vergleichen Sie mit : Die Punkte liegen auf einem Kreis, die Punkte auf einer Hyperbel — daher der Name.   "
},
{
  "id": "ex-anwendung-kettenlinie",
  "level": "2",
  "url": "sec-funktionen-stetigkeit.html#ex-anwendung-kettenlinie",
  "type": "Beispiel",
  "number": "3.1.39",
  "title": "Anwendungsbeispiel: Die Kettenlinie (zur Vertiefung).",
  "body": " Anwendungsbeispiel: Die Kettenlinie (zur Vertiefung)   Eine frei zwischen zwei Aufhängepunkten hängende Kette (oder Freileitung) folgt der Kurve für eine Konstante , die von Kettenlänge und Eigengewicht abhängt. Für : Um wie viel liegt die Kette seitlich vom tiefsten Punkt höher als an diesem?    Der tiefste Punkt liegt bei mit . Bei ist Der Höhenunterschied beträgt also . Eine Parabel sieht ähnlich aus, ist aber nicht dasselbe: Wer eine Freileitung plant, rechnet mit . Stellt man die Kettenlinie auf den Kopf, erhält man übrigens die ideale Form eines Bogens, in dem nur Druck und keine Biegung auftritt. Der Architekt Antoni Gaudí hat deshalb seine Gewölbe mit Hängemodellen aus Schnüren und Gewichten entworfen, und der Gateway Arch in St. Louis folgt einer (leicht abgewandelten) umgedrehten Kettenlinie.   "
},
{
  "id": "def-grenzwert-funktion",
  "level": "2",
  "url": "sec-funktionen-stetigkeit.html#def-grenzwert-funktion",
  "type": "Definition",
  "number": "3.1.40",
  "title": "Grenzwert einer Funktion, links-\/rechtsseitiger Grenzwert.",
  "body": " Grenzwert einer Funktion, links-\/rechtsseitiger Grenzwert   Sei ein Intervall, , und sei eine Funktion.     hat den Grenzwert  an der Stelle , falls für jede Folge im Definitionsbereich von mit gilt: . Wir schreiben .   hat den linksseitigen (bzw. rechtsseitigen ) Grenzwert  an der Stelle , falls dies für jede Folge mit und (bzw. ) gilt. Wir schreiben bzw. .    Der beidseitige Grenzwert existiert genau dann, wenn beide einseitigen Grenzwerte existieren und übereinstimmen.   "
},
{
  "id": "ex-wertetabelle-luegt",
  "level": "2",
  "url": "sec-funktionen-stetigkeit.html#ex-wertetabelle-luegt",
  "type": "Beispiel",
  "number": "3.1.41",
  "title": "Wenn die Wertetabelle lügt.",
  "body": " Wenn die Wertetabelle lügt   Werten Sie an den Stellen aus. Was vermuten Sie über ? Untersuchen Sie dann die Folge .    Es ist , und . Allgemein ist für jedes — die Tabelle legt den Grenzwert nahe. Aber für ist für alle . Zwei Folgen, die beide gegen gehen, liefern verschiedene Grenzwerte der Funktionswerte. Also existiert nicht: Nahe schwingt die Funktion immer schneller zwischen und hin und her, und die Stützstellen haben zufällig immer die Nullstellen erwischt. Ein Computer, der ein paar Werte ausprobiert , wäre auf genau diese Falle hereingefallen.   "
},
{
  "id": "thm-rechenregeln-grenzwerte-funktionen",
  "level": "2",
  "url": "sec-funktionen-stetigkeit.html#thm-rechenregeln-grenzwerte-funktionen",
  "type": "Satz",
  "number": "3.1.42",
  "title": "Rechenregeln für Grenzwerte.",
  "body": " Rechenregeln für Grenzwerte   Es gelte und . Dann:       , falls   (Sandwich-Satz) Gilt und für alle in einer Umgebung von , so folgt .     "
},
{
  "id": "ex-grenzwert-faktorisieren",
  "level": "2",
  "url": "sec-funktionen-stetigkeit.html#ex-grenzwert-faktorisieren",
  "type": "Beispiel",
  "number": "3.1.43",
  "title": "Grenzwert durch Faktorisieren.",
  "body": " Grenzwert durch Faktorisieren   Bestimmen Sie .    Einsetzen von ergibt den unbestimmten Ausdruck ; wir faktorisieren den Zähler. Die Nullstellen von sind und , also . Für kann gekürzt werden: Damit .   "
},
{
  "id": "ex-grenzwert-rationalisieren",
  "level": "2",
  "url": "sec-funktionen-stetigkeit.html#ex-grenzwert-rationalisieren",
  "type": "Beispiel",
  "number": "3.1.44",
  "title": "Grenzwert durch Rationalisieren.",
  "body": " Grenzwert durch Rationalisieren   Bestimmen Sie .    Wir erweitern mit der dritten binomischen Formel, also mit : Für strebt dies gegen .   "
},
{
  "id": "ex-einseitige-grenzwerte-vorzeichen",
  "level": "2",
  "url": "sec-funktionen-stetigkeit.html#ex-einseitige-grenzwerte-vorzeichen",
  "type": "Beispiel",
  "number": "3.1.45",
  "title": "Einseitige Grenzwerte, die nicht übereinstimmen.",
  "body": " Einseitige Grenzwerte, die nicht übereinstimmen   Zeigen Sie, dass für keinen Grenzwert besitzt.    Für ist , also , somit . Für ist , also , somit . Da die beiden einseitigen Grenzwerte nicht übereinstimmen, existiert nicht.   "
},
{
  "id": "ex-sandwich-oszillation",
  "level": "2",
  "url": "sec-funktionen-stetigkeit.html#ex-sandwich-oszillation",
  "type": "Beispiel",
  "number": "3.1.46",
  "title": "Sandwich-Satz bei oszillierender Funktion.",
  "body": " Sandwich-Satz bei oszillierender Funktion   Bestimmen Sie .    Der Faktor oszilliert für und besitzt keinen Grenzwert, ist aber stets zwischen und beschränkt. Damit gilt für alle : Da , folgt mit dem Sandwich-Satz .   "
},
{
  "id": "ex-grenzwert-sinx-durch-x",
  "level": "2",
  "url": "sec-funktionen-stetigkeit.html#ex-grenzwert-sinx-durch-x",
  "type": "Beispiel",
  "number": "3.1.47",
  "title": "Der Grenzwert <span class=\"process-math\">\\(\\frac{\\sin(x)}{x}\\to1\\)<\/span>.",
  "body": " Der Grenzwert   Bestimmen Sie ( im Bogenmaß). Vergleichen Sie zuerst mit einigen Werten und begründen Sie das Ergebnis dann am Einheitskreis ( ).   Am Einheitskreis gilt für : kleines Dreieck Kreissektor großes Dreieck, also .    Ein Viertel des Einheitskreises im ersten Quadranten. Vom Ursprung geht ein Strahl unter dem Winkel aus, der den Kreis im Punkt schneidet und die senkrechte Tangente bei in der Höhe . Drei ineinanderliegende Flächen sind unterschiedlich stark eingefärbt: das dunkle kleine Dreieck aus Ursprung, und dem Kreispunkt, der mittlere Kreissektor und das helle große Dreieck aus Ursprung, und .        Einsetzen von ergibt . Werte: , — der Grenzwert ist vermutlich .  Zur Begründung sei . In liegen drei Flächen ineinander: das kleine Dreieck mit Höhe , der Kreissektor mit Winkel und das große Dreieck mit Höhe . Ihre Flächeninhalte sind , (der Sektor ist der Anteil der Kreisfläche ) und , also Teilen durch und Übergang zu den Kehrwerten ergibt Da (der Kosinus ist stetig, siehe ), liefert der Sandwich-Satz für . Für negative gilt dasselbe, weil . Also   Praktisch heißt das: Für kleine Winkel ist . Ingenieure nutzen diese Kleinwinkelnäherung ständig, etwa beim Fadenpendel oder in der Optik.   "
},
{
  "id": "ex-anwendung-stueckkosten-grenzwert",
  "level": "2",
  "url": "sec-funktionen-stetigkeit.html#ex-anwendung-stueckkosten-grenzwert",
  "type": "Beispiel",
  "number": "3.1.49",
  "title": "Anwendungsbeispiel: Stückkosten bei großer Produktion (zur Vertiefung).",
  "body": " Anwendungsbeispiel: Stückkosten bei großer Produktion (zur Vertiefung)   Ein Unternehmen hat Fixkosten von  € und variable Kosten von  € pro Stück. Durch Mengenrabatte beim Materialeinkauf sinken die variablen Kosten pro zusätzlichem Stück mit wachsender Stückzahl , sodass die Gesamtkosten betragen. Gegen welchen Wert streben die Stückkosten für ?    Wir teilen jeden Summanden durch : Für gilt und , also Die Fixkosten verteilen sich auf immer mehr Stück und verschwinden pro Stück ( Fixkostendegression ); übrig bleiben die variablen Kosten, durch den Rabatt auf  € pro Stück gesenkt. Die Technik ist dieselbe wie bei Folgen ( ): durch die höchste Potenz kürzen.   "
},
{
  "id": "ex-anwendung-sigmoid-grenzwert",
  "level": "2",
  "url": "sec-funktionen-stetigkeit.html#ex-anwendung-sigmoid-grenzwert",
  "type": "Beispiel",
  "number": "3.1.50",
  "title": "Anwendungsbeispiel: Sättigung der Sigmoid-Funktion.",
  "body": " Anwendungsbeispiel: Sättigung der Sigmoid-Funktion   Bestimmen Sie und für die Sigmoid-Funktion aus .    Für geht , also , und damit . Für geht , also , und damit . Die Sigmoid-Funktion nähert sich also für große den horizontalen Asymptoten bzw. an — sie sättigt . Diese Sättigung ist beim Training neuronaler Netze relevant: Für sehr große wird der Funktionswert nahezu konstant, was (wie in gezeigt wird) zu sehr kleinen Gradienten führt.   "
},
{
  "id": "def-stetigkeit",
  "level": "2",
  "url": "sec-funktionen-stetigkeit.html#def-stetigkeit",
  "type": "Definition",
  "number": "3.1.51",
  "title": "Stetigkeit.",
  "body": " Stetigkeit   Eine reelle Funktion ist stetig an der Stelle  , wenn Ist an jeder Stelle von stetig, so heißt  stetig .   "
},
{
  "id": "ex-anwendung-versandkosten-unstetig",
  "level": "2",
  "url": "sec-funktionen-stetigkeit.html#ex-anwendung-versandkosten-unstetig",
  "type": "Beispiel",
  "number": "3.1.52",
  "title": "Anwendungsbeispiel: Ein Versandtarif mit Sprung.",
  "body": " Anwendungsbeispiel: Ein Versandtarif mit Sprung   Ein Onlinehändler berechnet für Bestellungen mit Warenwert  € Versandkosten von  €, ab  € ist der Versand kostenlos. Der Rechnungsbetrag ist also Ist an der Stelle stetig?    Von links gilt , von rechts . Die einseitigen Grenzwerte stimmen nicht überein, der Grenzwert existiert nicht, und ist bei unstetig — der Graph springt um  € nach unten. Genau dieser Sprung ist gewollt: Wer für  € bestellt, zahlt  €; wer für  € mehr einkauft, zahlt nur  €. Unstetige Tarife setzen bewusst Anreize.   "
},
{
  "id": "ex-anwendung-stromtarif-stetig",
  "level": "2",
  "url": "sec-funktionen-stetigkeit.html#ex-anwendung-stromtarif-stetig",
  "type": "Beispiel",
  "number": "3.1.53",
  "title": "Anwendungsbeispiel: Einen Stromtarif stetig machen.",
  "body": " Anwendungsbeispiel: Einen Stromtarif stetig machen   Ein Energieversorger berechnet bis zu einem Jahresverbrauch von  kWh einen Preis von  € pro kWh. Wer mehr verbraucht, zahlt für den gesamten Verbrauch einen Grundpreis plus  € pro kWh: Wie muss gewählt werden, damit stetig ist? Was passiert bei  €?    Beide Teilstücke sind als lineare Funktionen stetig; kritisch ist nur die Nahtstelle . Dort ist Stetig ist genau dann, wenn , also  €. Bei  € dagegen springt die Rechnung an der Grenze um  € nach unten : Ein Haushalt mit  kWh zahlt  €, einer mit  kWh nur  €. Wer knapp unter der Grenze liegt, würde also Geld sparen, indem er mehr Strom verbraucht — ein klassischer Schwelleneffekt , den ein stetiger Tarif vermeidet.   "
},
{
  "id": "thm-kombination-stetiger-funktionen",
  "level": "2",
  "url": "sec-funktionen-stetigkeit.html#thm-kombination-stetiger-funktionen",
  "type": "Satz",
  "number": "3.1.54",
  "title": "Kombination und Verkettung stetiger Funktionen.",
  "body": " Kombination und Verkettung stetiger Funktionen   Sind und an der Stelle stetig, so sind auch , und (falls ) an der Stelle stetig. Ist an der Stelle und an der Stelle stetig, so ist auch die Verkettung an der Stelle stetig. Alle elementaren Funktionen ( ) sind auf ihrem gesamten Definitionsbereich stetig.   "
},
{
  "id": "ex-stetigkeit-verkettung-nachweisen",
  "level": "2",
  "url": "sec-funktionen-stetigkeit.html#ex-stetigkeit-verkettung-nachweisen",
  "type": "Beispiel",
  "number": "3.1.55",
  "title": "Stetigkeit einer zusammengesetzten Funktion (zur Vertiefung).",
  "body": " Stetigkeit einer zusammengesetzten Funktion (zur Vertiefung)   Begründen Sie, warum auf ganz stetig ist.     ist als Polynom stetig und stets positiv, die Wurzelfunktion ist auf stetig, also ist die Verkettung auf ganz stetig. Ebenso sind und als elementare Funktionen stetig, also auch ihre Verkettung . Als Produkt zweier auf stetiger Funktionen ist damit auch auf ganz stetig.   "
},
{
  "id": "ex-anwendung-relu-stetigkeit",
  "level": "2",
  "url": "sec-funktionen-stetigkeit.html#ex-anwendung-relu-stetigkeit",
  "type": "Beispiel",
  "number": "3.1.56",
  "title": "Anwendungsbeispiel: Die ReLU-Funktion ist stetig.",
  "body": " Anwendungsbeispiel: Die ReLU-Funktion ist stetig   Zeigen Sie, dass die ReLU-Funktion aus , an der Stelle stetig ist.    Der linksseitige Grenzwert ist , der rechtsseitige . Beide stimmen überein und mit dem Funktionswert , also ist : ist an der Stelle stetig — trotz des Knicks im Graphen. Stetigkeit verlangt nur übereinstimmende Grenzwerte, keine Glattheit ; ob die Funktion an dieser Stelle auch differenzierbar ist, untersuchen wir in .   "
},
{
  "id": "thm-zwischenwertsatz-nullstellensatz",
  "level": "2",
  "url": "sec-funktionen-stetigkeit.html#thm-zwischenwertsatz-nullstellensatz",
  "type": "Satz",
  "number": "3.1.57",
  "title": "Zwischenwertsatz, Nullstellensatz.",
  "body": " Zwischenwertsatz, Nullstellensatz   Sei eine auf stetige Funktion.    ( Zwischenwertsatz ) nimmt jeden Wert zwischen und mindestens einmal an.  ( Nullstellensatz ) Haben und unterschiedliche Vorzeichen, so besitzt mindestens eine Nullstelle in .     "
},
{
  "id": "ex-intervallhalbierung",
  "level": "2",
  "url": "sec-funktionen-stetigkeit.html#ex-intervallhalbierung",
  "type": "Beispiel",
  "number": "3.1.58",
  "title": "Rechenbeispiel: Nullstellen einkreisen durch Intervallhalbierung.",
  "body": " Rechenbeispiel: Nullstellen einkreisen durch Intervallhalbierung   Zeigen Sie, dass eine Nullstelle in hat, und schränken Sie sie durch viermaliges Halbieren des Intervalls ein.     ist als Polynom stetig, und , . Nach dem Nullstellensatz liegt in eine Nullstelle. Nun werten wir in der Intervallmitte aus und behalten die Hälfte, an deren Rändern das Vorzeichen wechselt: Die Nullstelle liegt also zwischen und (tatsächlich bei ). Jeder Schritt halbiert die Unsicherheit; nach Schritten ist das Intervall lang, nach Schritten also kürzer als ein Millionstel. Das Bisektionsverfahren ist langsamer als das Heron-Verfahren oder das später behandelte Newton-Verfahren ( ), funktioniert aber für jede stetige Funktion mit Vorzeichenwechsel.   "
},
{
  "id": "ex-bergwanderung-zwischenwertsatz",
  "level": "2",
  "url": "sec-funktionen-stetigkeit.html#ex-bergwanderung-zwischenwertsatz",
  "type": "Beispiel",
  "number": "3.1.59",
  "title": "Das Rätsel von der Bergwanderung.",
  "body": " Das Rätsel von der Bergwanderung   Eine Wanderin bricht um 6 Uhr morgens im Tal auf und erreicht um 18 Uhr die Berghütte. Am nächsten Morgen startet sie um 6 Uhr auf demselben Weg zum Abstieg und ist um 18 Uhr wieder im Tal. Unterwegs läuft sie an beiden Tagen ganz unterschiedlich schnell und macht Pausen, wo es ihr gefällt. Gibt es eine Stelle des Weges, an der sie an beiden Tagen zur selben Uhrzeit ist?    Die Antwort ist ja — und zwar ganz egal, wie sie läuft. Sei die Weglänge, ihre Position (Wegstrecke ab Tal) am ersten Tag und die am zweiten Tag, jeweils zur Uhrzeit . Beide Funktionen sind stetig, denn niemand springt. Die Differenz ist ebenfalls stetig, und Nach dem Nullstellensatz gibt es ein mit , also : Zur Uhrzeit ist sie an beiden Tagen an derselben Stelle.  Wer das nicht glaubt, stelle sich zwei Wanderinnen vor, die am selben Tag losgehen, eine von unten, eine von oben — sie müssen sich unterwegs begegnen. Bemerkenswert ist, was der Beweis nicht liefert: Wann und wo die Begegnung stattfindet, sagt er nicht. Der Nullstellensatz ist ein reiner Existenzsatz, genau wie der Fundamentalsatz der Algebra in .   "
},
{
  "id": "def-stetige-fortsetzung",
  "level": "2",
  "url": "sec-funktionen-stetigkeit.html#def-stetige-fortsetzung",
  "type": "Definition",
  "number": "3.1.60",
  "title": "Stetige Fortsetzung.",
  "body": " Stetige Fortsetzung   Seien ein Intervall, , und eine auf definierte Funktion. Existiert der Grenzwert , so heißt  stetig fortsetzbar durch    "
},
{
  "id": "sub-zusammenfassung-3-1-2",
  "level": "2",
  "url": "sec-funktionen-stetigkeit.html#sub-zusammenfassung-3-1-2",
  "type": "Absatz (with a defined term)",
  "number": "",
  "title": "",
  "body": "Abbildung Injektiv: Surjektiv: Bijektiv: Reelle Funktionen: Elementare Funktionen: Grenzwert Stetig Zwischenwertsatz: Stetige Fortsetzung Roter Faden: "
},
{
  "id": "exercise-buch-injektiv-surjektiv",
  "level": "2",
  "url": "sec-funktionen-stetigkeit.html#exercise-buch-injektiv-surjektiv",
  "type": "Übung",
  "number": "3.1.7.1",
  "title": "",
  "body": "  Untersuchen Sie , , und , , jeweils auf Injektivität und Surjektivität.     ist injektiv: Aus folgt . Sie ist aber nicht surjektiv, da z. B. kein Urbild besitzt (kein erfüllt ).   ist ebenfalls injektiv: Aus folgt . Sie ist nicht surjektiv, da kein Urbild besitzt ( für alle ).   "
},
{
  "id": "exercise-buch-gerade-ungerade-funktion",
  "level": "2",
  "url": "sec-funktionen-stetigkeit.html#exercise-buch-gerade-ungerade-funktion",
  "type": "Übung",
  "number": "3.1.7.2",
  "title": "",
  "body": "  Untersuchen Sie und auf Symmetrie (gerade, ungerade oder keines von beidem).    Es gilt , also ist gerade. Für : , also ist ungerade.   "
},
{
  "id": "exercise-buch-grenzwert-faktorisieren",
  "level": "2",
  "url": "sec-funktionen-stetigkeit.html#exercise-buch-grenzwert-faktorisieren",
  "type": "Übung",
  "number": "3.1.7.3",
  "title": "",
  "body": "  Bestimmen Sie .    Die Nullstellen von sind und , also . Für gilt Damit .   "
},
{
  "id": "exercise-buch-stetige-fortsetzung-kubisch",
  "level": "2",
  "url": "sec-funktionen-stetigkeit.html#exercise-buch-stetige-fortsetzung-kubisch",
  "type": "Übung",
  "number": "3.1.7.4",
  "title": "",
  "body": "  Untersuchen Sie, ob sich an der Stelle stetig fortsetzen lässt.    Mit der Faktorisierung (Formel für die Differenz dritter Potenzen, ) gilt für : Damit . Der Grenzwert existiert, also ist stetig fortsetzbar mit Funktionswert an der Stelle .   "
},
{
  "id": "exercise-buch-logarithmusgleichung",
  "level": "2",
  "url": "sec-funktionen-stetigkeit.html#exercise-buch-logarithmusgleichung",
  "type": "Übung",
  "number": "3.1.7.5",
  "title": "",
  "body": "  Lösen Sie die Gleichung nach auf.    Anwenden von auf beide Seiten liefert , also (Probe der Definitionsbedingung: ist erfüllt.)   "
},
{
  "id": "sec-differenzialrechnung",
  "level": "1",
  "url": "sec-differenzialrechnung.html",
  "type": "Abschnitt",
  "number": "3.2",
  "title": "Differenzialrechnung",
  "body": " Differenzialrechnung    Nach diesem Abschnitt können Sie    die Ableitung als Grenzwert des Differenzenquotienten erklären und für einfache Funktionen direkt aus der Definition berechnen;  Differenzierbarkeit von Stetigkeit unterscheiden — und am Knick der ReLU-Funktion zeigen, warum;  Tangenten aufstellen und Funktionswerte damit linear approximieren;  Ableitungen mit Produkt-, Quotienten-, Ketten- und Umkehrregel berechnen;  Monotonie, Extremstellen, Krümmung und Wendepunkte aus und ablesen und Extremwertaufgaben mit Nebenbedingung lösen;  Newton-Verfahren und Gradientenabstieg für wenige Schritte von Hand ausführen;  Grenzwerte mit der Regel von l'Hospital berechnen und den Mittelwertsatz für Abschätzungen nutzen.     Wie stark steigen die Kosten, wenn eine Einheit mehr produziert wird? Wie schnell entlädt sich ein Kondensator gerade jetzt ? In welche Richtung muss ein Lernalgorithmus seine Parameter verschieben, damit der Fehler sinkt? Alle drei Fragen fragen nach einer momentanen Änderungsrate — und die heißt Ableitung. Dieser Abschnitt führt sie über die Steigung von Sekanten und Tangenten ein, stellt die Rechenregeln bereit, mit denen man Ableitungen ohne Grenzwertbildung berechnet, und zeigt dann, was man mit Ableitungen anfangen kann: Kurven diskutieren, Optimierungsprobleme lösen, Nullstellen und Minima iterativ aufspüren, und knifflige Grenzwerte mit der Regel von l'Hospital knacken.  Auf dem Weg erfahren Sie, warum es für die Ableitung drei Schreibweisen gibt, warum Getränkedosen nicht so aussehen, wie es die Schulaufgabe verlangt, warum der antike Wurzelalgorithmus aus tatsächlich ein Newton-Verfahren ist — und wer die Regel von l'Hospital wirklich erfunden hat. Die Rechenregeln selbst kennen Sie zum Teil aus der Schule; nehmen Sie sich trotzdem Zeit für die Beispiele, denn in den Übungen müssen Sie sie deutlich häufiger kombinieren.    Definition und Bedeutung der Ableitung   Ein Auto legt auf der Autobahn  km in einer Stunde zurück. Die Durchschnittsgeschwindigkeit ist also  km\/h — aber der Tacho hat in dieser Stunde viele verschiedene Werte gezeigt. Was misst der Tacho eigentlich? Er misst eine momentane Änderungsrate: den Weg, der in einem sehr kurzen Zeitraum zurückgelegt wird, geteilt durch diesen Zeitraum. Genau diese Idee — Durchschnitt über ein immer kürzeres Intervall — führt zur Ableitung .  In haben wir gesehen, dass Stetigkeit nur verlangt, dass sich der Funktionsgraph ohne Absetzen des Stifts zeichnen lässt — Knicke sind dabei ausdrücklich erlaubt. Die Ableitung ist ein schärferer Begriff: Sie misst die lokale Steigung einer Funktion, und wo ein Graph einen Knick hat, gibt es keine eindeutige Steigung.    Von der Sekante zur Tangente  Eine Tangente an eine Funktion im Punkt ist eine Gerade, die den Graphen von in berührt, ohne ihn in unmittelbarer Nähe von zu schneiden. Um ihre Steigung zu bestimmen, nähern wir uns über Sekanten an: Geraden durch zwei Punkte des Graphen.   Sekante durch und (links); im Grenzfall wird daraus die Tangente in (rechts).    Zwei Koordinatensysteme mit derselben Parabel. Im linken sind zwei Punkte der Parabel markiert, verbunden durch eine Sekante. Im rechten ist nur noch ein Punkt markiert, durch den die Tangente an die Parabel verläuft.       Differenzenquotient   Die Steigung der Sekante durch die Punkte und ist Man nennt diesen Ausdruck den Differenzenquotienten von zwischen und .     Rechenbeispiel: Sekantensteigungen, die sich stabilisieren (zur Vertiefung)   Berechnen Sie für und die Sekantensteigungen zu , , und . Welche Tangentensteigung vermuten Sie?     Je näher an rückt, desto näher liegen die Sekantensteigungen bei . Die Tangente in sollte also die Steigung haben. Das ist noch eine Vermutung — die folgende Definition macht aus dem immer näher einen Grenzwert, und in bestätigen wir den Wert exakt.     Ableitung, Differenzierbarkeit   Sei und . Existiert der Grenzwert so heißt an der Stelle  differenzierbar , und heißt die Ableitung von an der Stelle . Sie ist die Steigung der Tangente an im Punkt . Gebräuchliche Schreibweisen sind , und . Ist an jeder Stelle von differenzierbar, so heißt (kurz) differenzierbar .    Die beiden Formen des Grenzwerts in sind äquivalent: Mit , also , geht genau dann, wenn . Die zweite Form ist für konkrete Rechnungen oft bequemer.  Dass es für die Ableitung mehrere Schreibweisen gibt, hat historische Gründe — und hängt mit dem wohl erbittertsten Prioritätsstreit der Wissenschaftsgeschichte zusammen. Der Engländer Isaac Newton und der Deutsche Gottfried Wilhelm Leibniz entwickelten die Differenzialrechnung in den 1660er- bis 1680er-Jahren unabhängig voneinander. Newton schrieb und dachte an Geschwindigkeiten; Leibniz schrieb und dachte an Quotienten winziger Differenzen. Wer zuerst da war, darüber stritten die beiden und ihre Anhänger jahrzehntelang; eine Kommission der Royal Society — deren Präsident Newton selbst war — entschied 1712 wenig überraschend zu seinen Gunsten. Durchgesetzt hat sich trotzdem vor allem die Leibnizsche Schreibweise, weil es sich mit ihr so gut rechnen lässt; in der Physik lebt Newtons Punkt für Ableitungen nach der Zeit weiter. Der Strich schließlich stammt von Joseph-Louis Lagrange (1797), kam also erst lange nach dem Streit hinzu, und ist die kürzeste Variante — wir verwenden sie meistens.   Ableitung von aus der Definition   Bestimmen Sie die Ableitung von an einer beliebigen Stelle direkt über den Differenzenquotienten — ohne Ableitungsregeln zu verwenden.    Wir setzen in die Definition ein: Ausmultiplizieren des Zählers liefert , also An der Stelle ist das , wie in vermutet. Der Faktor kürzt sich weg, bevor der Grenzwert gebildet wird — genau das macht den Grenzwert überhaupt berechenbar, da der Differenzenquotient selbst für nicht definiert ist (Nenner ).    Ganz ohne Grenzwertrechnung sieht man die Ableitung einer Geraden : Der Differenzenquotient ist für jedes , also — die Tangente an eine Gerade ist die Gerade selbst.    Differenzierbarkeit und Stetigkeit   Differenzierbarkeit impliziert Stetigkeit   Ist an der Stelle differenzierbar, so ist an der Stelle auch stetig.    Die Umkehrung gilt nicht : Stetigkeit an einer Stelle garantiert keine Differenzierbarkeit dort.   Die ReLU-Funktion ist stetig, aber nicht überall differenzierbar   In haben wir gezeigt, dass die ReLU-Funktion an der Stelle stetig ist. Untersuchen Sie, ob sie dort auch differenzierbar ist.    Wir betrachten den Differenzenquotienten für getrennt von links und rechts. Für ist , also Für ist , also Der rechtsseitige Grenzwert des Differenzenquotienten ist also , der linksseitige — sie stimmen nicht überein, der Grenzwert existiert nicht. ist an der Stelle also nicht differenzierbar, obwohl sie dort stetig ist: Der Knick im Graphen ist stetig, aber nicht glatt. (In der Praxis des maschinellen Lernens wird dieser Stelle beim Ableiten meist einfach ein Wert, oft oder , zugewiesen — ein sogenannter Subgradient .)      Ableitungsfunktion und lineare Approximation  Ist auf ihrem gesamten Definitionsbereich differenzierbar, so können wir die Ableitungsfunktion  betrachten, deren Funktionswert an der Stelle die Ableitung ist. Nach ist etwa die Ableitungsfunktion von gegeben durch .  Kennt man , so lässt sich die Tangente an im Punkt explizit angeben — und diese Tangente liefert eine gute lineare Approximation von in der Nähe von .   Tangente als lineare Approximation   Sei an der Stelle differenzierbar. Die Tangente an im Punkt hat die Geradengleichung Sie approximiert in einem präzisen Sinn besser als jede andere Gerade durch : d. h. die Differenz geht schneller gegen als .     Rechenbeispiel: Näherungsweise Wurzelberechnung von Hand   Die Ableitung von lautet . Nutzen Sie die Näherungsformel , um näherungsweise zu berechnen — nur mit und dem im Kopf berechenbaren Wert .    Wir wählen , da (denn ) bekannt ist, und liegt nahe an . Mit ergibt die Näherungsformel Der exakte Wert ist — die lineare Approximation trifft ihn bereits auf drei Nachkommastellen.     Anwendungsbeispiel: Momentane Änderungsrate beim Entladen eines Kondensators   Der Blitz einer Kamera speichert Ladung in einem Kondensator, die beim Auslösen freigesetzt wird. Die auf dem Kondensator verbleibende Ladung (in Mikrocoulomb) zum Zeitpunkt (in Sekunden) nach Auslösen folgt näherungsweise . Bestimmen Sie die momentane Änderungsrate von zum Zeitpunkt , indem Sie den Differenzenquotienten mit approximieren, und interpretieren Sie das Vorzeichen.    Es gilt und , also Die momentane Änderungsrate ist negativ — die Ladung nimmt zum Zeitpunkt mit ungefähr Mikrocoulomb pro Sekunde ab. Allgemein ist die Entladestromstärke (bis auf Vorzeichen): Die Ableitung einer Bestandsgröße nach der Zeit ist ihre momentane Änderungsrate, hier ein physikalischer Strom. Mit den Ableitungsregeln aus dem nächsten Unterabschnitt lässt sich der exakte Wert bestimmen ( ).       Rechenregeln für Ableitungen   Die Ableitung jeder Funktion direkt über den Grenzwert des Differenzenquotienten ( ) zu bestimmen, wäre mühsam: Schon für müsste man einen unübersichtlichen Grenzwert berechnen. Zum Glück ist das nur einmal nötig — für die Bausteine. Die folgenden Rechenregeln sagen, wie sich Ableitungen beim Addieren, Multiplizieren, Dividieren, Verketten und Umkehren von Funktionen verhalten. Mit ihnen und einer kleinen Tabelle der Grundableitungen lässt sich jede elementare Funktion ableiten, ganz ohne Grenzwerte.    Die Ableitungsregeln   Ableitungsregeln   Seien an der Stelle differenzierbar, . Dann sind auch , , und (falls ) an der Stelle differenzierbar, mit    ( Linearität ) und ,  ( Produktregel ) ,  ( Kehrwertregel ) (falls ),  ( Quotientenregel ) .    Ist außerdem an der Stelle und an der Stelle differenzierbar, so ist auch an der Stelle differenzierbar mit    ( Kettenregel ) .    Ist auf einem Intervall streng monoton und differenzierbar mit , so ist auch die Umkehrfunktion an der Stelle differenzierbar mit    ( Umkehrregel ) .       Herleitung der Produktregel (zur Vertiefung)   Leiten Sie die Produktregel mithilfe des Differenzenquotienten her.    Für den Differenzenquotienten von an der Stelle fügen wir geschickt eine Null ein, nämlich , und sortieren um: Für strebt der erste Bruch gegen , der Faktor gegen (Stetigkeit von , ), und der zweite Bruch gegen . Insgesamt      Ableitung von mit der Produktregel   Bestimmen Sie mithilfe der Produktregel die Ableitung von für , .    Wir schreiben . Ist die Formel für den Exponenten schon bekannt, also , so folgt mit der Produktregel Die Formel überträgt sich also von jedem Exponenten auf den nächsten. Da sie für gilt ( ), gilt sie Schritt für Schritt für , also für alle (und, wie man separat zeigen kann, allgemeiner für mit beliebigem reellen Exponenten ).    Mit der Produktregel kennen wir die Ableitung jeder Potenz , . Woher kommen aber die Ableitungen der anderen Grundbausteine? Für und zahlen sich jetzt zwei Vorbereitungen aus aus.   Woher die Ableitungen von und kommen   Leiten Sie und aus der Definition der Ableitung her. Verwenden Sie dabei, dass an der Stelle die Steigung hat ( ), das Additionstheorem des Sinus und den Grenzwert ( ).     Exponentialfunktion: Mit dem Potenzgesetz ist denn ist genau der Differenzenquotient an der Stelle , und die Steigung dort ist nach Definition von gleich . Die Exponentialfunktion ist also ihre eigene Ableitung — die Eigenschaft, die zur natürlichen Basis macht.   Sinus: Mit dem Additionstheorem wird Der zweite Bruch geht gegen . Für den ersten erweitern wir mit und nutzen : Insgesamt geht der Differenzenquotient gegen . Ganz ähnlich folgt . Hätten wir im Gradmaß gerechnet, ginge gegen statt gegen , und dieser Faktor stünde in jeder Ableitung — noch ein Grund für das Bogenmaß.     Ableitung des Tangens mit der Quotientenregel   Bestimmen Sie mithilfe der Quotientenregel die Ableitung von .    Mit und : wobei wir verwendet haben. Wegen erhält man äquivalent .    Die Kettenregel ist die wichtigste der Regeln, und man kann sie sich wie ein Getriebe aus Zahnrädern vorstellen. Dreht sich das mittlere Rad doppelt so schnell wie das erste und das letzte Rad dreimal so schnell wie das mittlere, dann dreht sich das letzte sechsmal so schnell wie das erste: Die Übersetzungsverhältnisse multiplizieren sich. In Leibniz' Schreibweise sieht das aus wie Bruchrechnen, — eine bequeme Merkhilfe. (Ein echter Bruch ist nicht; die Kettenregel muss man beweisen, und das Kürzen sieht nur so aus .)   Ableitung mit der Kettenregel   Bestimmen Sie mithilfe der Kettenregel die Ableitung von .    Wir schreiben mit äußerer Funktion und innerer Funktion . Es gilt und , also     Der häufigste Fehler bei der Kettenregel ist, die innere Ableitung  zu vergessen: ist nicht , sondern . In der Praxis treten meist mehrere Regeln zugleich auf.   Mehrere Regeln in einer Rechnung   Leiten Sie und ab.     ist ein Produkt, dessen zweiter Faktor eine Verkettung ist. Produktregel, darin Kettenregel mit innerer Ableitung : Das Ausklammern lohnt sich: In dieser Form liest man die Nullstellen und der Ableitung direkt ab — genau das braucht man in für die Suche nach Extremstellen.   ist eine Verkettung mit äußerer Funktion und innerer Funktion :      Anwendungsbeispiel: Der Entladestrom exakt   Bestimmen Sie für die Kondensatorladung aus die Ableitung und den exakten Wert .    Kettenregel mit innerer Ableitung : Der Differenzenquotient mit hatte geliefert — eine brauchbare, aber um knapp ungenaue Näherung. Außerdem sieht man jetzt: . Die Abnahmerate der Ladung ist in jedem Moment proportional zur noch vorhandenen Ladung. Diese Beobachtung ist der Ausgangspunkt der Differenzialgleichungen in .      Ableitungen elementarer Funktionen  Mit der Umkehrregel lassen sich auch die Ableitungen der Umkehrfunktionen gewinnen, etwa des Logarithmus.   Ableitung des natürlichen Logarithmus mit der Umkehrregel   Bestimmen Sie mithilfe der Umkehrregel die Ableitung von , der Umkehrfunktion von .    Mit und liefert die Umkehrregel     Damit ergibt sich die folgende Übersicht der Ableitungen der wichtigsten elementaren Funktionen.   Ableitungen elementarer Funktionen    Funktion  Ableitung   (konstant)  ,   ,            Mit der Tabelle und der Tangentenformel aus lassen sich jetzt auch alte Rätsel lösen.   Anwendungsbeispiel: Warum die 70er-Regel funktioniert   In haben wir die Verdopplungszeit eines Kapitals berechnet. Praktiker benutzen die Faustregel Verdopplungszeit geteilt durch den Zinssatz in Prozent . Stellen Sie die Tangente an im Punkt auf, und begründen Sie damit die Faustregel über die Näherung . Wie genau ist sie für und für ?    Mit und ist die Tangente Setzt man , erhält man für kleine — genau die gesuchte Näherung. Die Verdopplungszeit ist damit ungefähr , und mit in Prozent ungefähr . Die lässt sich nicht nur leichter teilen, sie ist sogar genauer: Wegen ( ) ist die exakte Verdopplungszeit etwas länger als (mit in Prozent: ) — bei sind es Jahre statt , die 70er-Regel liefert . Für ist , die Näherung also auf genau. Für ist gegenüber — schon daneben. Die Tangente ist eben nur in der Nähe von eine gute Näherung.      Ableitungen in Data Science und Wirtschaft  Zum Abschluss drei Anwendungen, in denen die Ableitung eine konkrete Bedeutung hat: als Gradient beim Training neuronaler Netze, als Grenzkosten und als Baustein der Preiselastizität.   Anwendungsbeispiel: Die Ableitung der Sigmoid-Funktion   Für die Sigmoid-Funktion aus wird beim Training neuronaler Netze wiederholt die Ableitung benötigt. Zeigen Sie, dass gilt.    Wir schreiben und wenden Ketten- und Kehrwertregel an (oder direkt die Kehrwertregel mit , ): Um dies durch selbst auszudrücken, schreiben wir den Zähler als : Diese Form ist in der Praxis wertvoll: Ist bereits berechnet (z. B. beim Vorwärtsdurchlauf eines neuronalen Netzes), lässt sich ohne erneute Auswertung der Exponentialfunktion bestimmen.  Die Formel verrät außerdem, wie klein diese Ableitung ist: Das Produkt ist für höchstens (bei , also ), und für große geht gegen oder und damit . Die Sättigung aus bedeutet also verschwindende Gradienten : In tiefen Netzen, in denen viele solcher Faktoren multipliziert werden, kommt beim Lernen kaum noch ein Signal an — einer der Gründe, warum heute meist die ReLU-Funktion bevorzugt wird, deren Ableitung rechts von konstant ist.     Anwendungsbeispiel: Grenzkosten   Ein Betrieb hat die Kostenfunktion (Gesamtkosten in EUR bei Produktion von Einheiten). Die Grenzkosten  geben näherungsweise an, um wie viel die Gesamtkosten bei Produktion einer zusätzlichen Einheit steigen. Bestimmen Sie die Grenzkosten bei einer Produktionsmenge von Einheiten.    Mit der Potenzregel gliedweise: Einsetzen von : Die -te Einheit kostet also näherungsweise EUR zusätzlich — deutlich weniger als die durchschnittlichen Kosten pro Einheit an dieser Stelle ( EUR), ein typisches Bild bei Skaleneffekten in mittlerer Produktionsmenge.     Anwendungsbeispiel: Preiselastizität der Nachfrage   Die Preiselastizität der Nachfrage misst, wie stark die nachgefragte Menge relativ auf eine relative Preisänderung reagiert: Für die Nachfragefunktion (nachgefragte Menge in Abhängigkeit vom Preis in EUR) bestimmen Sie und interpretieren Sie das Ergebnis.    Es ist (konstant) und , also Der Betrag bedeutet elastische Nachfrage bei : Eine Preiserhöhung um lässt die nachgefragte Menge um etwa sinken — die Menge reagiert überproportional auf Preisänderungen. Für den Umsatz heißt das: Eine Preiserhöhung senkt ihn, eine leichte Preissenkung erhöht ihn. Zur Probe: , aber .       Anwendungen der Differenzialrechnung   Die Ableitung ist nicht nur ein Rechenwerkzeug — ihr Vorzeichen und ihre Nullstellen verraten viel über das Verhalten einer Funktion: wo sie wächst oder fällt, wo sie ein lokales Maximum oder Minimum annimmt, und wie ihr Graph gekrümmt ist. Diese Zusammenhänge sind die Grundlage der Kurvendiskussion und vieler Optimierungsprobleme.  Optimieren ist eine Kernaufgabe in Wirtschaft und Data Science: den Gewinn maximieren, den Materialverbrauch minimieren, den Fehler eines Modells minimieren. Die Differenzialrechnung liefert dafür ein klares Rezept — Kandidaten über finden, dann prüfen — und, wo sich die Gleichungen nicht mehr von Hand lösen lassen, iterative Verfahren wie das Newton-Verfahren und den Gradientenabstieg.    Monotonie und Extremstellen   Erste Ableitung und Monotonie   Sei eine auf einem Intervall differenzierbare Funktion. Dann gilt:    für alle   streng monoton wachsend auf ,  für alle   monoton wachsend auf ,  für alle   konstant auf ,  für alle   monoton fallend auf ,  für alle   streng monoton fallend auf .      Diese Tatsache ist eine direkte Folgerung aus dem Mittelwertsatz , den wir in nachreichen — dort auch die Begründung ( ).  Wo eine differenzierbare Funktion vom Steigen ins Fallen übergeht, hat ihr Graph eine Bergkuppe , und dort ist die Tangente waagerecht. Diese Beobachtung machen wir jetzt präzise.   Lokales Extremum   Sei , . hat ein lokales Maximum (bzw. lokales Minimum ) in , wenn es ein gibt, sodass (bzw. ) für alle mit . In diesem Fall heißt  Extremstelle von .     Notwendiges Kriterium für eine Extremstelle   Sei eine Extremstelle von . Liegt in einem offenen Intervall und ist an der Stelle differenzierbar, so gilt Eine Stelle mit heißt kritischer Punkt von .    Das Kriterium ist notwendig, aber nicht hinreichend: Für gilt , aber ist bei streng monoton wachsend und hat dort kein lokales Extremum. Die folgenden beiden Kriterien schließen diese Lücke.   1. hinreichendes Kriterium für Extremstellen   Sei ein kritischer Punkt von , d. h. .    Hat bei einen Vorzeichenwechsel von nach , so hat bei ein lokales Maximum.  Hat bei einen Vorzeichenwechsel von nach , so hat bei ein lokales Minimum.       2. hinreichendes Kriterium für Extremstellen   Sei zweimal differenzierbar, ein kritischer Punkt von .    Ist , so hat bei ein lokales Maximum.  Ist , so hat bei ein lokales Minimum.  Ist , so liefert dieses Kriterium keine Aussage — es muss auf das erste Kriterium (oder höhere Ableitungen) zurückgegriffen werden.       Anwendungsbeispiel: Monotonie und Extremstellen einer Gewinnfunktion   Ein Unternehmen modelliert seinen Gewinn (in Tausend EUR) in Abhängigkeit von der Produktionsmenge (in Tausend Stück) durch Bestimmen Sie die kritischen Punkte von , untersuchen Sie das Monotonieverhalten, und klassifizieren Sie die kritischen Punkte mit dem 2. hinreichenden Kriterium.    Ableitung: . Kritische Punkte: und .  Vorzeichen von : Für sind und beide negativ, ihr Produkt also positiv, mit dem Faktor ist — fällt. Für ist und , das Produkt negativ, also — wächst. Für sind beide Faktoren positiv, also — fällt wieder.  Zweite Ableitung: . Es gilt , also lokales Minimum bei mit ; und , also lokales Maximum bei mit .  Ökonomisch: Bei kleiner Produktionsmenge überwiegen die Fixkosten und der Gewinn fällt zunächst bis zu einem Verlust von EUR bei produzierten Stück; danach lohnt sich weitere Produktion bis zu einem maximalen Gewinn von EUR bei Stück, ab der die Kosten wieder stärker als der Erlös wachsen.    Vorsicht: findet nur Extremstellen im Inneren des Definitionsbereichs. Ist eine Funktion auf einem abgeschlossenen Intervall gegeben, muss man für das globale Maximum oder Minimum zusätzlich die Randwerte und vergleichen. Kann das Unternehmen im Beispiel höchstens Stück herstellen, so ist , , und : Das globale Maximum auf ist das lokale Maximum bei , das globale Minimum liegt aber am Rand bei — nicht beim lokalen Minimum .    Konvexität, Konkavität und Wendepunkte  Die zweite Ableitung beschreibt, wie sich die Steigung ändert, und damit, in welche Richtung der Graph gekrümmt ist.   Konvexe und konkave Funktionen   Sei eine auf einem Intervall definierte Funktion. heißt konvex (linksgekrümmt), wenn ihr Graph unterhalb jeder Verbindungsstrecke zweier ihrer Punkte liegt, d. h. für alle , :  heißt konkav (rechtsgekrümmt), wenn konvex ist.     Konvexität und zweite Ableitung   Sei zweimal differenzierbar. Dann gilt:    für alle   konvex auf ,  für alle   konkav auf .    Ist konvex auf , so ist ein lokales Minimum von in zugleich das globale Minimum von auf — eine Eigenschaft, die z. B. Optimierungsverfahren wie den Gradientenabstieg ( ) für konvexe Funktionen besonders zuverlässig macht.     Wendepunkt   Sei zweimal differenzierbar. Ein Punkt heißt Wendepunkt , wenn sich das Krümmungsverhalten von bei von konvex auf konkav (oder umgekehrt) ändert. Ist ein Wendepunkt, so ist eine notwendige Bedingung dafür — hinreichend ist ein Vorzeichenwechsel von bei .     Anwendungsbeispiel: Krümmung und Wendepunkt der Gewinnfunktion   Untersuchen Sie die Gewinnfunktion aus auf Konvexität, Konkavität und Wendepunkte.    Aus folgt . Also ist auf konvex und auf konkav; bei wechselt das Vorzeichen (von nach ), also liegt dort ein Wendepunkt mit .  Der Wendepunkt liegt genau zwischen den beiden kritischen Punkten und aus — nicht zufällig, denn zwischen einem lokalen Minimum und einem lokalen Maximum einer zweimal differenzierbaren Funktion liegt stets mindestens ein Wendepunkt (dort wechselt die Steigung von wachsend auf fallend, also das Vorzeichen). Dass er hier sogar genau in der Mitte liegt, ist eine Besonderheit der Polynome dritten Grades: ist eine Parabel mit den Nullstellen und , und ihr Scheitel, die Nullstelle von , liegt symmetrisch dazwischen.     Anwendungsbeispiel: Extremwertaufgabe mit Nebenbedingung — die optimale Dose   Eine zylinderförmige Dose mit Radius und Höhe soll ein Volumen von Liter ( ) fassen. Bestimmen Sie und so, dass die Materialmenge — die Oberfläche der Dose — minimal wird.    Die Oberfläche besteht aus Deckel, Boden und Mantel: . Die Nebenbedingung liefert . Einsetzen macht zu einer Funktion einer Variablen:   Notwendiges Kriterium: , also Wegen für alle ist auf konvex, der kritische Punkt also ein (globales) Minimum.  Die zugehörige Höhe: Mit , also , vereinfacht sich dies zu . Die materialsparendste Dose bei vorgegebenem Volumen hat also stets Höhe gleich Durchmesser, — unabhängig vom konkreten Volumen.    Ein Realitätscheck lohnt sich: Nehmen Sie eine Getränkedose zur Hand. Eine übliche -Liter-Dose hat etwa  cm Durchmesser und  cm Höhe — sie ist also deutlich schlanker, als das Modell verlangt. Ist die Getränkeindustrie zu dumm zum Ableiten? Nein, das Modell ist zu schlicht. Deckel und Boden einer Dose müssen dem Innendruck standhalten und sind deshalb aus deutlich dickerem Blech als der Mantel. Kostet ein Quadratzentimeter Deckel -mal so viel Material wie ein Quadratzentimeter Mantel, so lautet die Zielfunktion für den Materialaufwand , und dieselbe Rechnung wie oben liefert Das Verhältnis einer echten Dose passt also zu Deckeln, die rund -mal so materialintensiv sind wie die Wand. Die Moral: Ein mathematisches Optimum ist immer nur so gut wie das Modell, das man optimiert.    Nullstellen approximieren: das Newton-Verfahren  Viele Gleichungen lassen sich nicht exakt auflösen. Das Newton-Verfahren nutzt die Ableitung, um Nullstellen iterativ zu approximieren: Es ersetzt an der aktuellen Näherung durch ihre Tangente und verwendet deren Nullstelle als nächste Näherung.   Newton-Verfahren   Sei auf zweimal stetig differenzierbar mit auf . Ausgehend von einem Startwert  berechnet man iterativ Näherungswerte  Unter geeigneten Voraussetzungen konvergiert die Folge gegen eine Nullstelle von in .     Rechenbeispiel: Newton-Verfahren von Hand für zwei Schritte   Approximieren Sie mit zwei Schritten des Newton-Verfahrens, angewandt auf mit Startwert .    Es ist . Erster Schritt:   Zweiter Schritt, mit : und , also Der exakte Wert ist — nach nur zwei Schritten stimmen bereits fünf Nachkommastellen. Diese sehr schnelle (quadratische) Konvergenz ist typisch für das Newton-Verfahren, sobald der Startwert nahe genug an der gesuchten Nullstelle liegt.  In hatten wir behauptet, das Heron-Verfahren sei ein Spezialfall des Newton-Verfahrens. Jetzt können wir es nachrechnen: Für lautet die Newton-Vorschrift — genau Herons Vorschrift. Heron von Alexandria hat also vor rund zweitausend Jahren, ohne etwas von Ableitungen zu wissen, bereits das Newton-Verfahren für Quadratwurzeln benutzt.    So schnell das Verfahren ist, wenn es funktioniert — eine Garantie gibt es nicht. Die Tangente ist nur nahe am Berührpunkt eine gute Näherung, und ein ungünstiger Startwert kann das Verfahren in die Irre schicken.   Wenn Newton im Kreis läuft (zur Vertiefung)   Wenden Sie das Newton-Verfahren auf mit Startwert an. Was beobachten Sie?    Es ist . Damit Das Verfahren springt für immer zwischen und hin und her und findet die Nullstelle nie. Dabei hat durchaus eine: Wegen und liegt nach dem Nullstellensatz eine Nullstelle in (sie ist ungefähr ). Mit einem Startwert in ihrer Nähe, etwa , konvergiert das Verfahren problemlos. (Zwischen und liegt dagegen gar keine Nullstelle, und verschwindet dort bei — die Voraussetzungen aus sind auf diesem Intervall nicht erfüllt.) In der Praxis kombiniert man deshalb gern: erst mit dem langsamen, aber sicheren Bisektionsverfahren ( ) in die Nähe der Nullstelle, dann mit Newton die letzten Stellen.     Anwendungsbeispiel: Gradientenabstieg von Hand   Der Gradientenabstieg ist das Arbeitspferd des maschinellen Lernens: Um das Minimum einer Verlustfunktion zu finden — also einen kritischen Punkt mit — startet man bei und geht wiederholt ein Stück gegen die Steigung: Führen Sie für mit Startwert und Lernrate zwei Schritte aus. Was passiert stattdessen bei und bei ?    Es ist , und das Minimum liegt bei (denn und ). Mit : Die Folge nähert sich , und zwar halbiert sich der Abstand in jedem Schritt: , für also Faktor — genau die geometrische Folge aus .  Für ist der Faktor : Bereits trifft das Minimum exakt. Für ist der Faktor : , , … — die Iteration springt mit wachsendem Ausschlag um das Minimum und divergiert. Die Lernrate muss also zur Krümmung passen: Das Newton-Verfahren, auf angewendet, wählt automatisch (hier ) und landet deshalb in einem Schritt — es ist ein Verfahren zweiter Ordnung , das aber die zweite Ableitung kennen muss, was bei Millionen von Parametern zu teuer ist. Deshalb begnügt man sich in der Praxis mit dem Gradientenabstieg und einer vorsichtig gewählten Lernrate.       Mittelwertsatz und die Regel von l'Hospital   Zum Abschluss dieses Abschnitts stellen wir zwei eng verwandte Werkzeuge vor: den Mittelwertsatz der Differenzialrechnung , der abstrakte Aussagen über eine Funktion aus punktuellem Wissen über ihre Ableitung gewinnt, und die Regel von l'Hospital , mit der sich viele Grenzwerte der Bauart oder berechnen lassen, die mit den Grenzwertregeln aus allein nicht zugänglich sind.    Der Mittelwertsatz   Mittelwertsatz der Differenzialrechnung   Sei stetig auf und differenzierbar auf . Dann existiert ein mit     Geometrisch besagt der Mittelwertsatz, dass es zwischen und mindestens eine Stelle gibt, an der die Tangente an parallel zur Sekante durch und verläuft.   Mittelwertsatz: Die Tangente an im Punkt ist parallel zur Sekante durch und .    Ein Koordinatensystem mit einer gekrümmten Kurve zwischen den Punkten a und b. Eine gestrichelte Sekante verbindet die Kurvenpunkte über a und b. An einer inneren Stelle c ist die Tangente an die Kurve eingezeichnet, parallel zur Sekante.       Anwendungsbeispiel: Abschnittskontrolle (zur Vertiefung)   Bei einer Abschnittskontrolle wird ein Fahrzeug an zwei Messpunkten im Abstand von  km erfasst; die erlaubte Höchstgeschwindigkeit ist  km\/h. Ein Fahrzeug braucht für die Strecke Minuten. Die Fahrerin versichert, der Tacho habe nie mehr als  km\/h angezeigt. Was sagt der Mittelwertsatz dazu?    Sei die zurückgelegte Strecke (in km) nach Stunden. Mit Minuten  h ist die Durchschnittsgeschwindigkeit Die Weg-Zeit-Funktion eines Autos ist differenzierbar (das Auto hat in jedem Moment eine Geschwindigkeit, und sein Ort springt nicht), und ihre Ableitung ist die Momentangeschwindigkeit. Nach dem Mittelwertsatz gibt es also einen Zeitpunkt mit  km\/h. Die Aussage der Fahrerin kann nicht stimmen — ohne dass irgendwo eine Momentangeschwindigkeit gemessen worden wäre.     Begründung des Monotoniekriteriums  Der Mittelwertsatz begründet das Monotoniekriterium aus : Gilt auf ganz , und sind beliebig aus , so liefert der Mittelwertsatz auf ein mit Da und , folgt , also : ist streng monoton wachsend. Die übrigen Fälle des Kriteriums folgen analog.    Eine Logarithmus-Ungleichung   Zeigen Sie mithilfe des Mittelwertsatzes: Für alle gilt .    Sei fest und auf ; ist dort stetig und auf differenzierbar mit . Der Mittelwertsatz liefert ein mit Da , ist , also (denn ). Damit für alle .      Die Regel von l'Hospital   Regel von l'Hospital   Seien auf einem Intervall um (ggf. mit Ausnahme von selbst) differenzierbar, in der Nähe von , und gelte einer der beiden Fälle Existiert dann , so gilt     Der Name der Regel ist eine kleine historische Ungerechtigkeit. Entdeckt hat sie der Schweizer Mathematiker Johann Bernoulli. Der französische Marquis de l'Hospital bezahlte Bernoulli in den 1690er-Jahren dafür, ihn in der neuen Differenzialrechnung zu unterrichten und ihm seine Ergebnisse zu überlassen, und nahm die Regel 1696 in sein Lehrbuch auf — das erste Lehrbuch der Differenzialrechnung überhaupt. Seither trägt sie seinen Namen.  Die Regel gilt sinngemäß auch für sowie für einseitige Grenzwerte. Führt erneut auf eine unbestimmte Form oder , so darf die Regel erneut angewendet werden.  Die Regel verlangt ausdrücklich eine unbestimmte Form. Wer sie blind anwendet, erhält Unsinn: Bei ergibt Einsetzen sofort ; getrenntes Ableiten von Zähler und Nenner lieferte dagegen fälschlich . Und: Abgeleitet werden Zähler und Nenner einzeln — nicht der Bruch mit der Quotientenregel.   Rechenbeispiel: Zweifache Anwendung der Regel von l'Hospital   Bestimmen Sie .    Für gehen sowohl Zähler ( ) als auch Nenner ( ) gegen : unbestimmte Form . Ableiten von Zähler und Nenner: Auch hier gehen Zähler und Nenner für wieder gegen — erneute Anwendung der Regel: Also .     Anwendungsbeispiel: Wachstumsvergleich — Logarithmus gegen Wurzelfunktion   Bestimmen Sie .    Für gehen Zähler und Nenner beide gegen : unbestimmte Form . Mit und :   Dieses Ergebnis ist ein Spezialfall einer allgemeinen Wachstumshierarchie, die in der Analyse von Algorithmen (Big-O- Notation) ständig verwendet wird: Für wächst langsamer als jede positive Potenz ( ), und jede Potenzfunktion wiederum langsamer als — kurz . Die Regel von l'Hospital ist das Standardwerkzeug, um solche Wachstumsvergleiche exakt zu belegen.       Zusammenfassung     Ableitung:  — Steigung der Tangente, momentane Änderungsrate. Differenzierbar stetig, aber nicht umgekehrt (ReLU bei ).   Tangente und lineare Näherung:  , und für nahe — etwa (70er-Regel).   Rechenregeln:  , , , , , ; dazu die Tabelle der elementaren Ableitungen ( , , , , , , , …); dabei ist und (im Bogenmaß). Kettenregel in Leibniz-Form: .   Kurvendiskussion:  wachsend, fallend. Extremstelle  (notwendig); hinreichend: Vorzeichenwechsel von oder ( Maximum, Minimum). konvex, konkav; Wendepunkt bei Vorzeichenwechsel von . Bei konvexem ist ein lokales Minimum global.   Extremwertaufgabe: Nebenbedingung nach einer Variablen auflösen, einsetzen, Funktion einer Variablen diskutieren. Auf für globale Extrema auch die Randwerte , vergleichen.   Iterative Verfahren: Newton für Nullstellen (sehr schnell nahe der Lösung, aber ohne Garantie bei schlechtem Startwert; für ist es das Heron-Verfahren); Gradientenabstieg für Minima (Lernrate entscheidet über Konvergenz).   Mittelwertsatz:  für ein — Grundlage des Monotoniekriteriums und vieler Abschätzungen. l'Hospital: bei oder ist , falls der rechte Grenzwert existiert; notfalls mehrfach anwenden.   Anwendungen: Grenzkosten , Elastizität , Entladestrom , Sigmoid-Ableitung (verschwindende Gradienten), Wachstumshierarchie .      Übungsaufgaben    Bestimmen Sie die Ableitung von (für ) direkt über den Differenzenquotienten — ohne Ableitungsregeln zu verwenden.           Bestimmen Sie mithilfe der Kettenregel die Ableitung von .    Mit äußerer Funktion und innerer Funktion :       Bestimmen Sie die Gleichung der Tangente an an der Stelle .    Es gilt und , also . Mit der Tangentenformel :       Bestimmen Sie alle lokalen Extremstellen von und klassifizieren Sie diese mit dem 2. hinreichenden Kriterium.     , kritische Punkte und . Mit : , also lokales Minimum bei mit ; und , also lokales Maximum bei mit .      Bestimmen Sie mit der Regel von l'Hospital .    Für gehen Zähler und Nenner beide gegen (unbestimmte Form ). Ableiten von Zähler und Nenner:      "
},
{
  "id": "sec-differenzialrechnung-2",
  "level": "2",
  "url": "sec-differenzialrechnung.html#sec-differenzialrechnung-2",
  "type": "Lernziele",
  "number": "3.2",
  "title": "",
  "body": "  Nach diesem Abschnitt können Sie    die Ableitung als Grenzwert des Differenzenquotienten erklären und für einfache Funktionen direkt aus der Definition berechnen;  Differenzierbarkeit von Stetigkeit unterscheiden — und am Knick der ReLU-Funktion zeigen, warum;  Tangenten aufstellen und Funktionswerte damit linear approximieren;  Ableitungen mit Produkt-, Quotienten-, Ketten- und Umkehrregel berechnen;  Monotonie, Extremstellen, Krümmung und Wendepunkte aus und ablesen und Extremwertaufgaben mit Nebenbedingung lösen;  Newton-Verfahren und Gradientenabstieg für wenige Schritte von Hand ausführen;  Grenzwerte mit der Regel von l'Hospital berechnen und den Mittelwertsatz für Abschätzungen nutzen.   "
},
{
  "id": "sub-ableitung-definition-2-1",
  "level": "2",
  "url": "sec-differenzialrechnung.html#sub-ableitung-definition-2-1",
  "type": "Absatz (with a defined term)",
  "number": "",
  "title": "",
  "body": "Ableitung "
},
{
  "id": "sub-tangente-sekante-2",
  "level": "2",
  "url": "sec-differenzialrechnung.html#sub-tangente-sekante-2",
  "type": "Absatz (with a defined term)",
  "number": "",
  "title": "",
  "body": "Tangente Sekanten "
},
{
  "id": "fig-sekante-tangente",
  "level": "2",
  "url": "sec-differenzialrechnung.html#fig-sekante-tangente",
  "type": "Abbildung",
  "number": "3.2.1",
  "title": "",
  "body": " Sekante durch und (links); im Grenzfall wird daraus die Tangente in (rechts).    Zwei Koordinatensysteme mit derselben Parabel. Im linken sind zwei Punkte der Parabel markiert, verbunden durch eine Sekante. Im rechten ist nur noch ein Punkt markiert, durch den die Tangente an die Parabel verläuft.     "
},
{
  "id": "def-differenzenquotient",
  "level": "2",
  "url": "sec-differenzialrechnung.html#def-differenzenquotient",
  "type": "Definition",
  "number": "3.2.2",
  "title": "Differenzenquotient.",
  "body": " Differenzenquotient   Die Steigung der Sekante durch die Punkte und ist Man nennt diesen Ausdruck den Differenzenquotienten von zwischen und .   "
},
{
  "id": "ex-sekantensteigungen-numerisch",
  "level": "2",
  "url": "sec-differenzialrechnung.html#ex-sekantensteigungen-numerisch",
  "type": "Beispiel",
  "number": "3.2.3",
  "title": "Rechenbeispiel: Sekantensteigungen, die sich stabilisieren (zur Vertiefung).",
  "body": " Rechenbeispiel: Sekantensteigungen, die sich stabilisieren (zur Vertiefung)   Berechnen Sie für und die Sekantensteigungen zu , , und . Welche Tangentensteigung vermuten Sie?     Je näher an rückt, desto näher liegen die Sekantensteigungen bei . Die Tangente in sollte also die Steigung haben. Das ist noch eine Vermutung — die folgende Definition macht aus dem immer näher einen Grenzwert, und in bestätigen wir den Wert exakt.   "
},
{
  "id": "def-ableitung",
  "level": "2",
  "url": "sec-differenzialrechnung.html#def-ableitung",
  "type": "Definition",
  "number": "3.2.4",
  "title": "Ableitung, Differenzierbarkeit.",
  "body": " Ableitung, Differenzierbarkeit   Sei und . Existiert der Grenzwert so heißt an der Stelle  differenzierbar , und heißt die Ableitung von an der Stelle . Sie ist die Steigung der Tangente an im Punkt . Gebräuchliche Schreibweisen sind , und . Ist an jeder Stelle von differenzierbar, so heißt (kurz) differenzierbar .   "
},
{
  "id": "ex-ableitung-x-quadrat-differenzenquotient",
  "level": "2",
  "url": "sec-differenzialrechnung.html#ex-ableitung-x-quadrat-differenzenquotient",
  "type": "Beispiel",
  "number": "3.2.5",
  "title": "Ableitung von <span class=\"process-math\">\\(f(x)=x^2\\)<\/span> aus der Definition.",
  "body": " Ableitung von aus der Definition   Bestimmen Sie die Ableitung von an einer beliebigen Stelle direkt über den Differenzenquotienten — ohne Ableitungsregeln zu verwenden.    Wir setzen in die Definition ein: Ausmultiplizieren des Zählers liefert , also An der Stelle ist das , wie in vermutet. Der Faktor kürzt sich weg, bevor der Grenzwert gebildet wird — genau das macht den Grenzwert überhaupt berechenbar, da der Differenzenquotient selbst für nicht definiert ist (Nenner ).   "
},
{
  "id": "thm-differenzierbar-impliziert-stetig",
  "level": "2",
  "url": "sec-differenzialrechnung.html#thm-differenzierbar-impliziert-stetig",
  "type": "Satz",
  "number": "3.2.6",
  "title": "Differenzierbarkeit impliziert Stetigkeit.",
  "body": " Differenzierbarkeit impliziert Stetigkeit   Ist an der Stelle differenzierbar, so ist an der Stelle auch stetig.   "
},
{
  "id": "ex-relu-nicht-differenzierbar",
  "level": "2",
  "url": "sec-differenzialrechnung.html#ex-relu-nicht-differenzierbar",
  "type": "Beispiel",
  "number": "3.2.7",
  "title": "Die ReLU-Funktion ist stetig, aber nicht überall differenzierbar.",
  "body": " Die ReLU-Funktion ist stetig, aber nicht überall differenzierbar   In haben wir gezeigt, dass die ReLU-Funktion an der Stelle stetig ist. Untersuchen Sie, ob sie dort auch differenzierbar ist.    Wir betrachten den Differenzenquotienten für getrennt von links und rechts. Für ist , also Für ist , also Der rechtsseitige Grenzwert des Differenzenquotienten ist also , der linksseitige — sie stimmen nicht überein, der Grenzwert existiert nicht. ist an der Stelle also nicht differenzierbar, obwohl sie dort stetig ist: Der Knick im Graphen ist stetig, aber nicht glatt. (In der Praxis des maschinellen Lernens wird dieser Stelle beim Ableiten meist einfach ein Wert, oft oder , zugewiesen — ein sogenannter Subgradient .)   "
},
{
  "id": "sub-tangente-lineare-approximation-2",
  "level": "2",
  "url": "sec-differenzialrechnung.html#sub-tangente-lineare-approximation-2",
  "type": "Absatz (with a defined term)",
  "number": "",
  "title": "",
  "body": "Ableitungsfunktion "
},
{
  "id": "sub-tangente-lineare-approximation-3",
  "level": "2",
  "url": "sec-differenzialrechnung.html#sub-tangente-lineare-approximation-3",
  "type": "Absatz (with a defined term)",
  "number": "",
  "title": "",
  "body": "lineare Approximation "
},
{
  "id": "thm-tangente-lineare-approximation",
  "level": "2",
  "url": "sec-differenzialrechnung.html#thm-tangente-lineare-approximation",
  "type": "Satz",
  "number": "3.2.8",
  "title": "Tangente als lineare Approximation.",
  "body": " Tangente als lineare Approximation   Sei an der Stelle differenzierbar. Die Tangente an im Punkt hat die Geradengleichung Sie approximiert in einem präzisen Sinn besser als jede andere Gerade durch : d. h. die Differenz geht schneller gegen als .   "
},
{
  "id": "ex-wurzel-naeherung",
  "level": "2",
  "url": "sec-differenzialrechnung.html#ex-wurzel-naeherung",
  "type": "Beispiel",
  "number": "3.2.9",
  "title": "Rechenbeispiel: Näherungsweise Wurzelberechnung von Hand.",
  "body": " Rechenbeispiel: Näherungsweise Wurzelberechnung von Hand   Die Ableitung von lautet . Nutzen Sie die Näherungsformel , um näherungsweise zu berechnen — nur mit und dem im Kopf berechenbaren Wert .    Wir wählen , da (denn ) bekannt ist, und liegt nahe an . Mit ergibt die Näherungsformel Der exakte Wert ist — die lineare Approximation trifft ihn bereits auf drei Nachkommastellen.   "
},
{
  "id": "ex-anwendung-kondensator-entladung",
  "level": "2",
  "url": "sec-differenzialrechnung.html#ex-anwendung-kondensator-entladung",
  "type": "Beispiel",
  "number": "3.2.10",
  "title": "Anwendungsbeispiel: Momentane Änderungsrate beim Entladen eines Kondensators.",
  "body": " Anwendungsbeispiel: Momentane Änderungsrate beim Entladen eines Kondensators   Der Blitz einer Kamera speichert Ladung in einem Kondensator, die beim Auslösen freigesetzt wird. Die auf dem Kondensator verbleibende Ladung (in Mikrocoulomb) zum Zeitpunkt (in Sekunden) nach Auslösen folgt näherungsweise . Bestimmen Sie die momentane Änderungsrate von zum Zeitpunkt , indem Sie den Differenzenquotienten mit approximieren, und interpretieren Sie das Vorzeichen.    Es gilt und , also Die momentane Änderungsrate ist negativ — die Ladung nimmt zum Zeitpunkt mit ungefähr Mikrocoulomb pro Sekunde ab. Allgemein ist die Entladestromstärke (bis auf Vorzeichen): Die Ableitung einer Bestandsgröße nach der Zeit ist ihre momentane Änderungsrate, hier ein physikalischer Strom. Mit den Ableitungsregeln aus dem nächsten Unterabschnitt lässt sich der exakte Wert bestimmen ( ).   "
},
{
  "id": "thm-ableitungsregeln",
  "level": "2",
  "url": "sec-differenzialrechnung.html#thm-ableitungsregeln",
  "type": "Satz",
  "number": "3.2.11",
  "title": "Ableitungsregeln.",
  "body": " Ableitungsregeln   Seien an der Stelle differenzierbar, . Dann sind auch , , und (falls ) an der Stelle differenzierbar, mit    ( Linearität ) und ,  ( Produktregel ) ,  ( Kehrwertregel ) (falls ),  ( Quotientenregel ) .    Ist außerdem an der Stelle und an der Stelle differenzierbar, so ist auch an der Stelle differenzierbar mit    ( Kettenregel ) .    Ist auf einem Intervall streng monoton und differenzierbar mit , so ist auch die Umkehrfunktion an der Stelle differenzierbar mit    ( Umkehrregel ) .     "
},
{
  "id": "ex-herleitung-produktregel",
  "level": "2",
  "url": "sec-differenzialrechnung.html#ex-herleitung-produktregel",
  "type": "Beispiel",
  "number": "3.2.12",
  "title": "Herleitung der Produktregel (zur Vertiefung).",
  "body": " Herleitung der Produktregel (zur Vertiefung)   Leiten Sie die Produktregel mithilfe des Differenzenquotienten her.    Für den Differenzenquotienten von an der Stelle fügen wir geschickt eine Null ein, nämlich , und sortieren um: Für strebt der erste Bruch gegen , der Faktor gegen (Stetigkeit von , ), und der zweite Bruch gegen . Insgesamt    "
},
{
  "id": "ex-ableitung-xn-produktregel",
  "level": "2",
  "url": "sec-differenzialrechnung.html#ex-ableitung-xn-produktregel",
  "type": "Beispiel",
  "number": "3.2.13",
  "title": "Ableitung von <span class=\"process-math\">\\(x^n\\)<\/span> mit der Produktregel.",
  "body": " Ableitung von mit der Produktregel   Bestimmen Sie mithilfe der Produktregel die Ableitung von für , .    Wir schreiben . Ist die Formel für den Exponenten schon bekannt, also , so folgt mit der Produktregel Die Formel überträgt sich also von jedem Exponenten auf den nächsten. Da sie für gilt ( ), gilt sie Schritt für Schritt für , also für alle (und, wie man separat zeigen kann, allgemeiner für mit beliebigem reellen Exponenten ).   "
},
{
  "id": "ex-ableitung-exp-sin-herleitung",
  "level": "2",
  "url": "sec-differenzialrechnung.html#ex-ableitung-exp-sin-herleitung",
  "type": "Beispiel",
  "number": "3.2.14",
  "title": "Woher die Ableitungen von <span class=\"process-math\">\\(\\euler^x\\)<\/span> und <span class=\"process-math\">\\(\\sin(x)\\)<\/span> kommen.",
  "body": " Woher die Ableitungen von und kommen   Leiten Sie und aus der Definition der Ableitung her. Verwenden Sie dabei, dass an der Stelle die Steigung hat ( ), das Additionstheorem des Sinus und den Grenzwert ( ).     Exponentialfunktion: Mit dem Potenzgesetz ist denn ist genau der Differenzenquotient an der Stelle , und die Steigung dort ist nach Definition von gleich . Die Exponentialfunktion ist also ihre eigene Ableitung — die Eigenschaft, die zur natürlichen Basis macht.   Sinus: Mit dem Additionstheorem wird Der zweite Bruch geht gegen . Für den ersten erweitern wir mit und nutzen : Insgesamt geht der Differenzenquotient gegen . Ganz ähnlich folgt . Hätten wir im Gradmaß gerechnet, ginge gegen statt gegen , und dieser Faktor stünde in jeder Ableitung — noch ein Grund für das Bogenmaß.   "
},
{
  "id": "ex-ableitung-tangens-quotientenregel",
  "level": "2",
  "url": "sec-differenzialrechnung.html#ex-ableitung-tangens-quotientenregel",
  "type": "Beispiel",
  "number": "3.2.15",
  "title": "Ableitung des Tangens mit der Quotientenregel.",
  "body": " Ableitung des Tangens mit der Quotientenregel   Bestimmen Sie mithilfe der Quotientenregel die Ableitung von .    Mit und : wobei wir verwendet haben. Wegen erhält man äquivalent .   "
},
{
  "id": "ex-ableitung-kettenregel-exp-sin",
  "level": "2",
  "url": "sec-differenzialrechnung.html#ex-ableitung-kettenregel-exp-sin",
  "type": "Beispiel",
  "number": "3.2.16",
  "title": "Ableitung mit der Kettenregel.",
  "body": " Ableitung mit der Kettenregel   Bestimmen Sie mithilfe der Kettenregel die Ableitung von .    Wir schreiben mit äußerer Funktion und innerer Funktion . Es gilt und , also    "
},
{
  "id": "ex-ableitung-regeln-kombiniert",
  "level": "2",
  "url": "sec-differenzialrechnung.html#ex-ableitung-regeln-kombiniert",
  "type": "Beispiel",
  "number": "3.2.17",
  "title": "Mehrere Regeln in einer Rechnung.",
  "body": " Mehrere Regeln in einer Rechnung   Leiten Sie und ab.     ist ein Produkt, dessen zweiter Faktor eine Verkettung ist. Produktregel, darin Kettenregel mit innerer Ableitung : Das Ausklammern lohnt sich: In dieser Form liest man die Nullstellen und der Ableitung direkt ab — genau das braucht man in für die Suche nach Extremstellen.   ist eine Verkettung mit äußerer Funktion und innerer Funktion :    "
},
{
  "id": "ex-anwendung-entladestrom-exakt",
  "level": "2",
  "url": "sec-differenzialrechnung.html#ex-anwendung-entladestrom-exakt",
  "type": "Beispiel",
  "number": "3.2.18",
  "title": "Anwendungsbeispiel: Der Entladestrom exakt.",
  "body": " Anwendungsbeispiel: Der Entladestrom exakt   Bestimmen Sie für die Kondensatorladung aus die Ableitung und den exakten Wert .    Kettenregel mit innerer Ableitung : Der Differenzenquotient mit hatte geliefert — eine brauchbare, aber um knapp ungenaue Näherung. Außerdem sieht man jetzt: . Die Abnahmerate der Ladung ist in jedem Moment proportional zur noch vorhandenen Ladung. Diese Beobachtung ist der Ausgangspunkt der Differenzialgleichungen in .   "
},
{
  "id": "ex-ableitung-ln-umkehrregel",
  "level": "2",
  "url": "sec-differenzialrechnung.html#ex-ableitung-ln-umkehrregel",
  "type": "Beispiel",
  "number": "3.2.19",
  "title": "Ableitung des natürlichen Logarithmus mit der Umkehrregel.",
  "body": " Ableitung des natürlichen Logarithmus mit der Umkehrregel   Bestimmen Sie mithilfe der Umkehrregel die Ableitung von , der Umkehrfunktion von .    Mit und liefert die Umkehrregel    "
},
{
  "id": "tab-ableitungen-elementarer-funktionen",
  "level": "2",
  "url": "sec-differenzialrechnung.html#tab-ableitungen-elementarer-funktionen",
  "type": "Tabelle",
  "number": "3.2.20",
  "title": "Ableitungen elementarer Funktionen",
  "body": " Ableitungen elementarer Funktionen    Funktion  Ableitung   (konstant)  ,   ,           "
},
{
  "id": "ex-anwendung-70er-regel-tangente",
  "level": "2",
  "url": "sec-differenzialrechnung.html#ex-anwendung-70er-regel-tangente",
  "type": "Beispiel",
  "number": "3.2.21",
  "title": "Anwendungsbeispiel: Warum die 70er-Regel funktioniert.",
  "body": " Anwendungsbeispiel: Warum die 70er-Regel funktioniert   In haben wir die Verdopplungszeit eines Kapitals berechnet. Praktiker benutzen die Faustregel Verdopplungszeit geteilt durch den Zinssatz in Prozent . Stellen Sie die Tangente an im Punkt auf, und begründen Sie damit die Faustregel über die Näherung . Wie genau ist sie für und für ?    Mit und ist die Tangente Setzt man , erhält man für kleine — genau die gesuchte Näherung. Die Verdopplungszeit ist damit ungefähr , und mit in Prozent ungefähr . Die lässt sich nicht nur leichter teilen, sie ist sogar genauer: Wegen ( ) ist die exakte Verdopplungszeit etwas länger als (mit in Prozent: ) — bei sind es Jahre statt , die 70er-Regel liefert . Für ist , die Näherung also auf genau. Für ist gegenüber — schon daneben. Die Tangente ist eben nur in der Nähe von eine gute Näherung.   "
},
{
  "id": "ex-anwendung-sigmoid-ableitung",
  "level": "2",
  "url": "sec-differenzialrechnung.html#ex-anwendung-sigmoid-ableitung",
  "type": "Beispiel",
  "number": "3.2.22",
  "title": "Anwendungsbeispiel: Die Ableitung der Sigmoid-Funktion.",
  "body": " Anwendungsbeispiel: Die Ableitung der Sigmoid-Funktion   Für die Sigmoid-Funktion aus wird beim Training neuronaler Netze wiederholt die Ableitung benötigt. Zeigen Sie, dass gilt.    Wir schreiben und wenden Ketten- und Kehrwertregel an (oder direkt die Kehrwertregel mit , ): Um dies durch selbst auszudrücken, schreiben wir den Zähler als : Diese Form ist in der Praxis wertvoll: Ist bereits berechnet (z. B. beim Vorwärtsdurchlauf eines neuronalen Netzes), lässt sich ohne erneute Auswertung der Exponentialfunktion bestimmen.  Die Formel verrät außerdem, wie klein diese Ableitung ist: Das Produkt ist für höchstens (bei , also ), und für große geht gegen oder und damit . Die Sättigung aus bedeutet also verschwindende Gradienten : In tiefen Netzen, in denen viele solcher Faktoren multipliziert werden, kommt beim Lernen kaum noch ein Signal an — einer der Gründe, warum heute meist die ReLU-Funktion bevorzugt wird, deren Ableitung rechts von konstant ist.   "
},
{
  "id": "ex-anwendung-grenzkosten",
  "level": "2",
  "url": "sec-differenzialrechnung.html#ex-anwendung-grenzkosten",
  "type": "Beispiel",
  "number": "3.2.23",
  "title": "Anwendungsbeispiel: Grenzkosten.",
  "body": " Anwendungsbeispiel: Grenzkosten   Ein Betrieb hat die Kostenfunktion (Gesamtkosten in EUR bei Produktion von Einheiten). Die Grenzkosten  geben näherungsweise an, um wie viel die Gesamtkosten bei Produktion einer zusätzlichen Einheit steigen. Bestimmen Sie die Grenzkosten bei einer Produktionsmenge von Einheiten.    Mit der Potenzregel gliedweise: Einsetzen von : Die -te Einheit kostet also näherungsweise EUR zusätzlich — deutlich weniger als die durchschnittlichen Kosten pro Einheit an dieser Stelle ( EUR), ein typisches Bild bei Skaleneffekten in mittlerer Produktionsmenge.   "
},
{
  "id": "ex-anwendung-elastizitaet",
  "level": "2",
  "url": "sec-differenzialrechnung.html#ex-anwendung-elastizitaet",
  "type": "Beispiel",
  "number": "3.2.24",
  "title": "Anwendungsbeispiel: Preiselastizität der Nachfrage.",
  "body": " Anwendungsbeispiel: Preiselastizität der Nachfrage   Die Preiselastizität der Nachfrage misst, wie stark die nachgefragte Menge relativ auf eine relative Preisänderung reagiert: Für die Nachfragefunktion (nachgefragte Menge in Abhängigkeit vom Preis in EUR) bestimmen Sie und interpretieren Sie das Ergebnis.    Es ist (konstant) und , also Der Betrag bedeutet elastische Nachfrage bei : Eine Preiserhöhung um lässt die nachgefragte Menge um etwa sinken — die Menge reagiert überproportional auf Preisänderungen. Für den Umsatz heißt das: Eine Preiserhöhung senkt ihn, eine leichte Preissenkung erhöht ihn. Zur Probe: , aber .   "
},
{
  "id": "sub-anwendungen-differenzialrechnung-2-1",
  "level": "2",
  "url": "sec-differenzialrechnung.html#sub-anwendungen-differenzialrechnung-2-1",
  "type": "Absatz (with a defined term)",
  "number": "",
  "title": "",
  "body": "Kurvendiskussion "
},
{
  "id": "thm-monotonie-ableitung",
  "level": "2",
  "url": "sec-differenzialrechnung.html#thm-monotonie-ableitung",
  "type": "Satz",
  "number": "3.2.25",
  "title": "Erste Ableitung und Monotonie.",
  "body": " Erste Ableitung und Monotonie   Sei eine auf einem Intervall differenzierbare Funktion. Dann gilt:    für alle   streng monoton wachsend auf ,  für alle   monoton wachsend auf ,  für alle   konstant auf ,  für alle   monoton fallend auf ,  für alle   streng monoton fallend auf .     "
},
{
  "id": "sub-monotonie-extremstellen-3",
  "level": "2",
  "url": "sec-differenzialrechnung.html#sub-monotonie-extremstellen-3",
  "type": "Absatz (with a defined term)",
  "number": "",
  "title": "",
  "body": "Mittelwertsatz "
},
{
  "id": "def-lokales-extremum",
  "level": "2",
  "url": "sec-differenzialrechnung.html#def-lokales-extremum",
  "type": "Definition",
  "number": "3.2.26",
  "title": "Lokales Extremum.",
  "body": " Lokales Extremum   Sei , . hat ein lokales Maximum (bzw. lokales Minimum ) in , wenn es ein gibt, sodass (bzw. ) für alle mit . In diesem Fall heißt  Extremstelle von .   "
},
{
  "id": "thm-notwendiges-extremalkriterium",
  "level": "2",
  "url": "sec-differenzialrechnung.html#thm-notwendiges-extremalkriterium",
  "type": "Satz",
  "number": "3.2.27",
  "title": "Notwendiges Kriterium für eine Extremstelle.",
  "body": " Notwendiges Kriterium für eine Extremstelle   Sei eine Extremstelle von . Liegt in einem offenen Intervall und ist an der Stelle differenzierbar, so gilt Eine Stelle mit heißt kritischer Punkt von .   "
},
{
  "id": "thm-erstes-hinreichendes-kriterium",
  "level": "2",
  "url": "sec-differenzialrechnung.html#thm-erstes-hinreichendes-kriterium",
  "type": "Satz",
  "number": "3.2.28",
  "title": "1. hinreichendes Kriterium für Extremstellen.",
  "body": " 1. hinreichendes Kriterium für Extremstellen   Sei ein kritischer Punkt von , d. h. .    Hat bei einen Vorzeichenwechsel von nach , so hat bei ein lokales Maximum.  Hat bei einen Vorzeichenwechsel von nach , so hat bei ein lokales Minimum.     "
},
{
  "id": "thm-zweites-hinreichendes-kriterium",
  "level": "2",
  "url": "sec-differenzialrechnung.html#thm-zweites-hinreichendes-kriterium",
  "type": "Satz",
  "number": "3.2.29",
  "title": "2. hinreichendes Kriterium für Extremstellen.",
  "body": " 2. hinreichendes Kriterium für Extremstellen   Sei zweimal differenzierbar, ein kritischer Punkt von .    Ist , so hat bei ein lokales Maximum.  Ist , so hat bei ein lokales Minimum.  Ist , so liefert dieses Kriterium keine Aussage — es muss auf das erste Kriterium (oder höhere Ableitungen) zurückgegriffen werden.     "
},
{
  "id": "ex-anwendung-gewinnfunktion-kurvendiskussion",
  "level": "2",
  "url": "sec-differenzialrechnung.html#ex-anwendung-gewinnfunktion-kurvendiskussion",
  "type": "Beispiel",
  "number": "3.2.30",
  "title": "Anwendungsbeispiel: Monotonie und Extremstellen einer Gewinnfunktion.",
  "body": " Anwendungsbeispiel: Monotonie und Extremstellen einer Gewinnfunktion   Ein Unternehmen modelliert seinen Gewinn (in Tausend EUR) in Abhängigkeit von der Produktionsmenge (in Tausend Stück) durch Bestimmen Sie die kritischen Punkte von , untersuchen Sie das Monotonieverhalten, und klassifizieren Sie die kritischen Punkte mit dem 2. hinreichenden Kriterium.    Ableitung: . Kritische Punkte: und .  Vorzeichen von : Für sind und beide negativ, ihr Produkt also positiv, mit dem Faktor ist — fällt. Für ist und , das Produkt negativ, also — wächst. Für sind beide Faktoren positiv, also — fällt wieder.  Zweite Ableitung: . Es gilt , also lokales Minimum bei mit ; und , also lokales Maximum bei mit .  Ökonomisch: Bei kleiner Produktionsmenge überwiegen die Fixkosten und der Gewinn fällt zunächst bis zu einem Verlust von EUR bei produzierten Stück; danach lohnt sich weitere Produktion bis zu einem maximalen Gewinn von EUR bei Stück, ab der die Kosten wieder stärker als der Erlös wachsen.   "
},
{
  "id": "def-konvex-konkav",
  "level": "2",
  "url": "sec-differenzialrechnung.html#def-konvex-konkav",
  "type": "Definition",
  "number": "3.2.31",
  "title": "Konvexe und konkave Funktionen.",
  "body": " Konvexe und konkave Funktionen   Sei eine auf einem Intervall definierte Funktion. heißt konvex (linksgekrümmt), wenn ihr Graph unterhalb jeder Verbindungsstrecke zweier ihrer Punkte liegt, d. h. für alle , :  heißt konkav (rechtsgekrümmt), wenn konvex ist.   "
},
{
  "id": "thm-konvexitaet-zweite-ableitung",
  "level": "2",
  "url": "sec-differenzialrechnung.html#thm-konvexitaet-zweite-ableitung",
  "type": "Satz",
  "number": "3.2.32",
  "title": "Konvexität und zweite Ableitung.",
  "body": " Konvexität und zweite Ableitung   Sei zweimal differenzierbar. Dann gilt:    für alle   konvex auf ,  für alle   konkav auf .    Ist konvex auf , so ist ein lokales Minimum von in zugleich das globale Minimum von auf — eine Eigenschaft, die z. B. Optimierungsverfahren wie den Gradientenabstieg ( ) für konvexe Funktionen besonders zuverlässig macht.   "
},
{
  "id": "def-wendepunkt",
  "level": "2",
  "url": "sec-differenzialrechnung.html#def-wendepunkt",
  "type": "Definition",
  "number": "3.2.33",
  "title": "Wendepunkt.",
  "body": " Wendepunkt   Sei zweimal differenzierbar. Ein Punkt heißt Wendepunkt , wenn sich das Krümmungsverhalten von bei von konvex auf konkav (oder umgekehrt) ändert. Ist ein Wendepunkt, so ist eine notwendige Bedingung dafür — hinreichend ist ein Vorzeichenwechsel von bei .   "
},
{
  "id": "ex-anwendung-gewinnfunktion-konvexitaet",
  "level": "2",
  "url": "sec-differenzialrechnung.html#ex-anwendung-gewinnfunktion-konvexitaet",
  "type": "Beispiel",
  "number": "3.2.34",
  "title": "Anwendungsbeispiel: Krümmung und Wendepunkt der Gewinnfunktion.",
  "body": " Anwendungsbeispiel: Krümmung und Wendepunkt der Gewinnfunktion   Untersuchen Sie die Gewinnfunktion aus auf Konvexität, Konkavität und Wendepunkte.    Aus folgt . Also ist auf konvex und auf konkav; bei wechselt das Vorzeichen (von nach ), also liegt dort ein Wendepunkt mit .  Der Wendepunkt liegt genau zwischen den beiden kritischen Punkten und aus — nicht zufällig, denn zwischen einem lokalen Minimum und einem lokalen Maximum einer zweimal differenzierbaren Funktion liegt stets mindestens ein Wendepunkt (dort wechselt die Steigung von wachsend auf fallend, also das Vorzeichen). Dass er hier sogar genau in der Mitte liegt, ist eine Besonderheit der Polynome dritten Grades: ist eine Parabel mit den Nullstellen und , und ihr Scheitel, die Nullstelle von , liegt symmetrisch dazwischen.   "
},
{
  "id": "ex-anwendung-optimale-dose",
  "level": "2",
  "url": "sec-differenzialrechnung.html#ex-anwendung-optimale-dose",
  "type": "Beispiel",
  "number": "3.2.35",
  "title": "Anwendungsbeispiel: Extremwertaufgabe mit Nebenbedingung — die optimale Dose.",
  "body": " Anwendungsbeispiel: Extremwertaufgabe mit Nebenbedingung — die optimale Dose   Eine zylinderförmige Dose mit Radius und Höhe soll ein Volumen von Liter ( ) fassen. Bestimmen Sie und so, dass die Materialmenge — die Oberfläche der Dose — minimal wird.    Die Oberfläche besteht aus Deckel, Boden und Mantel: . Die Nebenbedingung liefert . Einsetzen macht zu einer Funktion einer Variablen:   Notwendiges Kriterium: , also Wegen für alle ist auf konvex, der kritische Punkt also ein (globales) Minimum.  Die zugehörige Höhe: Mit , also , vereinfacht sich dies zu . Die materialsparendste Dose bei vorgegebenem Volumen hat also stets Höhe gleich Durchmesser, — unabhängig vom konkreten Volumen.   "
},
{
  "id": "sub-newton-verfahren-2",
  "level": "2",
  "url": "sec-differenzialrechnung.html#sub-newton-verfahren-2",
  "type": "Absatz (with a defined term)",
  "number": "",
  "title": "",
  "body": "Newton-Verfahren "
},
{
  "id": "def-newton-verfahren",
  "level": "2",
  "url": "sec-differenzialrechnung.html#def-newton-verfahren",
  "type": "Definition",
  "number": "3.2.36",
  "title": "Newton-Verfahren.",
  "body": " Newton-Verfahren   Sei auf zweimal stetig differenzierbar mit auf . Ausgehend von einem Startwert  berechnet man iterativ Näherungswerte  Unter geeigneten Voraussetzungen konvergiert die Folge gegen eine Nullstelle von in .   "
},
{
  "id": "ex-newton-wurzel-2",
  "level": "2",
  "url": "sec-differenzialrechnung.html#ex-newton-wurzel-2",
  "type": "Beispiel",
  "number": "3.2.37",
  "title": "Rechenbeispiel: Newton-Verfahren von Hand für zwei Schritte.",
  "body": " Rechenbeispiel: Newton-Verfahren von Hand für zwei Schritte   Approximieren Sie mit zwei Schritten des Newton-Verfahrens, angewandt auf mit Startwert .    Es ist . Erster Schritt:   Zweiter Schritt, mit : und , also Der exakte Wert ist — nach nur zwei Schritten stimmen bereits fünf Nachkommastellen. Diese sehr schnelle (quadratische) Konvergenz ist typisch für das Newton-Verfahren, sobald der Startwert nahe genug an der gesuchten Nullstelle liegt.  In hatten wir behauptet, das Heron-Verfahren sei ein Spezialfall des Newton-Verfahrens. Jetzt können wir es nachrechnen: Für lautet die Newton-Vorschrift — genau Herons Vorschrift. Heron von Alexandria hat also vor rund zweitausend Jahren, ohne etwas von Ableitungen zu wissen, bereits das Newton-Verfahren für Quadratwurzeln benutzt.   "
},
{
  "id": "ex-newton-zyklus",
  "level": "2",
  "url": "sec-differenzialrechnung.html#ex-newton-zyklus",
  "type": "Beispiel",
  "number": "3.2.38",
  "title": "Wenn Newton im Kreis läuft (zur Vertiefung).",
  "body": " Wenn Newton im Kreis läuft (zur Vertiefung)   Wenden Sie das Newton-Verfahren auf mit Startwert an. Was beobachten Sie?    Es ist . Damit Das Verfahren springt für immer zwischen und hin und her und findet die Nullstelle nie. Dabei hat durchaus eine: Wegen und liegt nach dem Nullstellensatz eine Nullstelle in (sie ist ungefähr ). Mit einem Startwert in ihrer Nähe, etwa , konvergiert das Verfahren problemlos. (Zwischen und liegt dagegen gar keine Nullstelle, und verschwindet dort bei — die Voraussetzungen aus sind auf diesem Intervall nicht erfüllt.) In der Praxis kombiniert man deshalb gern: erst mit dem langsamen, aber sicheren Bisektionsverfahren ( ) in die Nähe der Nullstelle, dann mit Newton die letzten Stellen.   "
},
{
  "id": "ex-anwendung-gradientenabstieg",
  "level": "2",
  "url": "sec-differenzialrechnung.html#ex-anwendung-gradientenabstieg",
  "type": "Beispiel",
  "number": "3.2.39",
  "title": "Anwendungsbeispiel: Gradientenabstieg von Hand.",
  "body": " Anwendungsbeispiel: Gradientenabstieg von Hand   Der Gradientenabstieg ist das Arbeitspferd des maschinellen Lernens: Um das Minimum einer Verlustfunktion zu finden — also einen kritischen Punkt mit — startet man bei und geht wiederholt ein Stück gegen die Steigung: Führen Sie für mit Startwert und Lernrate zwei Schritte aus. Was passiert stattdessen bei und bei ?    Es ist , und das Minimum liegt bei (denn und ). Mit : Die Folge nähert sich , und zwar halbiert sich der Abstand in jedem Schritt: , für also Faktor — genau die geometrische Folge aus .  Für ist der Faktor : Bereits trifft das Minimum exakt. Für ist der Faktor : , , … — die Iteration springt mit wachsendem Ausschlag um das Minimum und divergiert. Die Lernrate muss also zur Krümmung passen: Das Newton-Verfahren, auf angewendet, wählt automatisch (hier ) und landet deshalb in einem Schritt — es ist ein Verfahren zweiter Ordnung , das aber die zweite Ableitung kennen muss, was bei Millionen von Parametern zu teuer ist. Deshalb begnügt man sich in der Praxis mit dem Gradientenabstieg und einer vorsichtig gewählten Lernrate.   "
},
{
  "id": "sub-mittelwertsatz-2-1",
  "level": "2",
  "url": "sec-differenzialrechnung.html#sub-mittelwertsatz-2-1",
  "type": "Absatz (with a defined term)",
  "number": "",
  "title": "",
  "body": "Mittelwertsatz der Differenzialrechnung Regel von l'Hospital "
},
{
  "id": "thm-mittelwertsatz",
  "level": "2",
  "url": "sec-differenzialrechnung.html#thm-mittelwertsatz",
  "type": "Satz",
  "number": "3.2.40",
  "title": "Mittelwertsatz der Differenzialrechnung.",
  "body": " Mittelwertsatz der Differenzialrechnung   Sei stetig auf und differenzierbar auf . Dann existiert ein mit    "
},
{
  "id": "fig-mittelwertsatz",
  "level": "2",
  "url": "sec-differenzialrechnung.html#fig-mittelwertsatz",
  "type": "Abbildung",
  "number": "3.2.41",
  "title": "",
  "body": " Mittelwertsatz: Die Tangente an im Punkt ist parallel zur Sekante durch und .    Ein Koordinatensystem mit einer gekrümmten Kurve zwischen den Punkten a und b. Eine gestrichelte Sekante verbindet die Kurvenpunkte über a und b. An einer inneren Stelle c ist die Tangente an die Kurve eingezeichnet, parallel zur Sekante.     "
},
{
  "id": "ex-anwendung-abschnittskontrolle",
  "level": "2",
  "url": "sec-differenzialrechnung.html#ex-anwendung-abschnittskontrolle",
  "type": "Beispiel",
  "number": "3.2.42",
  "title": "Anwendungsbeispiel: Abschnittskontrolle (zur Vertiefung).",
  "body": " Anwendungsbeispiel: Abschnittskontrolle (zur Vertiefung)   Bei einer Abschnittskontrolle wird ein Fahrzeug an zwei Messpunkten im Abstand von  km erfasst; die erlaubte Höchstgeschwindigkeit ist  km\/h. Ein Fahrzeug braucht für die Strecke Minuten. Die Fahrerin versichert, der Tacho habe nie mehr als  km\/h angezeigt. Was sagt der Mittelwertsatz dazu?    Sei die zurückgelegte Strecke (in km) nach Stunden. Mit Minuten  h ist die Durchschnittsgeschwindigkeit Die Weg-Zeit-Funktion eines Autos ist differenzierbar (das Auto hat in jedem Moment eine Geschwindigkeit, und sein Ort springt nicht), und ihre Ableitung ist die Momentangeschwindigkeit. Nach dem Mittelwertsatz gibt es also einen Zeitpunkt mit  km\/h. Die Aussage der Fahrerin kann nicht stimmen — ohne dass irgendwo eine Momentangeschwindigkeit gemessen worden wäre.   "
},
{
  "id": "rem-monotoniekriterium-beweis",
  "level": "2",
  "url": "sec-differenzialrechnung.html#rem-monotoniekriterium-beweis",
  "type": "Bemerkung",
  "number": "3.2.43",
  "title": "Begründung des Monotoniekriteriums.",
  "body": " Begründung des Monotoniekriteriums  Der Mittelwertsatz begründet das Monotoniekriterium aus : Gilt auf ganz , und sind beliebig aus , so liefert der Mittelwertsatz auf ein mit Da und , folgt , also : ist streng monoton wachsend. Die übrigen Fälle des Kriteriums folgen analog.  "
},
{
  "id": "ex-mittelwertsatz-logarithmus-ungleichung",
  "level": "2",
  "url": "sec-differenzialrechnung.html#ex-mittelwertsatz-logarithmus-ungleichung",
  "type": "Beispiel",
  "number": "3.2.44",
  "title": "Eine Logarithmus-Ungleichung.",
  "body": " Eine Logarithmus-Ungleichung   Zeigen Sie mithilfe des Mittelwertsatzes: Für alle gilt .    Sei fest und auf ; ist dort stetig und auf differenzierbar mit . Der Mittelwertsatz liefert ein mit Da , ist , also (denn ). Damit für alle .   "
},
{
  "id": "thm-regel-hospital",
  "level": "2",
  "url": "sec-differenzialrechnung.html#thm-regel-hospital",
  "type": "Satz",
  "number": "3.2.45",
  "title": "Regel von l’Hospital.",
  "body": " Regel von l'Hospital   Seien auf einem Intervall um (ggf. mit Ausnahme von selbst) differenzierbar, in der Nähe von , und gelte einer der beiden Fälle Existiert dann , so gilt    "
},
{
  "id": "ex-hospital-e-hoch-x",
  "level": "2",
  "url": "sec-differenzialrechnung.html#ex-hospital-e-hoch-x",
  "type": "Beispiel",
  "number": "3.2.46",
  "title": "Rechenbeispiel: Zweifache Anwendung der Regel von l’Hospital.",
  "body": " Rechenbeispiel: Zweifache Anwendung der Regel von l'Hospital   Bestimmen Sie .    Für gehen sowohl Zähler ( ) als auch Nenner ( ) gegen : unbestimmte Form . Ableiten von Zähler und Nenner: Auch hier gehen Zähler und Nenner für wieder gegen — erneute Anwendung der Regel: Also .   "
},
{
  "id": "ex-hospital-log-wurzel",
  "level": "2",
  "url": "sec-differenzialrechnung.html#ex-hospital-log-wurzel",
  "type": "Beispiel",
  "number": "3.2.47",
  "title": "Anwendungsbeispiel: Wachstumsvergleich — Logarithmus gegen Wurzelfunktion.",
  "body": " Anwendungsbeispiel: Wachstumsvergleich — Logarithmus gegen Wurzelfunktion   Bestimmen Sie .    Für gehen Zähler und Nenner beide gegen : unbestimmte Form . Mit und :   Dieses Ergebnis ist ein Spezialfall einer allgemeinen Wachstumshierarchie, die in der Analyse von Algorithmen (Big-O- Notation) ständig verwendet wird: Für wächst langsamer als jede positive Potenz ( ), und jede Potenzfunktion wiederum langsamer als — kurz . Die Regel von l'Hospital ist das Standardwerkzeug, um solche Wachstumsvergleiche exakt zu belegen.   "
},
{
  "id": "sub-zusammenfassung-3-2-2",
  "level": "2",
  "url": "sec-differenzialrechnung.html#sub-zusammenfassung-3-2-2",
  "type": "Absatz (with a defined term)",
  "number": "",
  "title": "",
  "body": "Ableitung: Tangente und lineare Näherung: Rechenregeln: Kurvendiskussion: Extremwertaufgabe: Iterative Verfahren: Mittelwertsatz: l'Hospital: Anwendungen: "
},
{
  "id": "exercise-buch-ableitung-kehrwert-differenzenquotient",
  "level": "2",
  "url": "sec-differenzialrechnung.html#exercise-buch-ableitung-kehrwert-differenzenquotient",
  "type": "Übung",
  "number": "3.2.6.1",
  "title": "",
  "body": "  Bestimmen Sie die Ableitung von (für ) direkt über den Differenzenquotienten — ohne Ableitungsregeln zu verwenden.        "
},
{
  "id": "exercise-buch-kettenregel-logarithmus",
  "level": "2",
  "url": "sec-differenzialrechnung.html#exercise-buch-kettenregel-logarithmus",
  "type": "Übung",
  "number": "3.2.6.2",
  "title": "",
  "body": "  Bestimmen Sie mithilfe der Kettenregel die Ableitung von .    Mit äußerer Funktion und innerer Funktion :    "
},
{
  "id": "exercise-buch-tangente-kubisch",
  "level": "2",
  "url": "sec-differenzialrechnung.html#exercise-buch-tangente-kubisch",
  "type": "Übung",
  "number": "3.2.6.3",
  "title": "",
  "body": "  Bestimmen Sie die Gleichung der Tangente an an der Stelle .    Es gilt und , also . Mit der Tangentenformel :    "
},
{
  "id": "exercise-buch-extremstellen-kubisch",
  "level": "2",
  "url": "sec-differenzialrechnung.html#exercise-buch-extremstellen-kubisch",
  "type": "Übung",
  "number": "3.2.6.4",
  "title": "",
  "body": "  Bestimmen Sie alle lokalen Extremstellen von und klassifizieren Sie diese mit dem 2. hinreichenden Kriterium.     , kritische Punkte und . Mit : , also lokales Minimum bei mit ; und , also lokales Maximum bei mit .   "
},
{
  "id": "exercise-buch-hospital-quadrat-logarithmus",
  "level": "2",
  "url": "sec-differenzialrechnung.html#exercise-buch-hospital-quadrat-logarithmus",
  "type": "Übung",
  "number": "3.2.6.5",
  "title": "",
  "body": "  Bestimmen Sie mit der Regel von l'Hospital .    Für gehen Zähler und Nenner beide gegen (unbestimmte Form ). Ableiten von Zähler und Nenner:    "
},
{
  "id": "sec-riemannsches-integral",
  "level": "1",
  "url": "sec-riemannsches-integral.html",
  "type": "Abschnitt",
  "number": "4.1",
  "title": "Riemannsches Integral: Grundlagen",
  "body": " Riemannsches Integral: Grundlagen    Nach diesem Abschnitt können Sie    das bestimmte Integral als Grenzwert von Riemannsummen erklären und als signierte Fläche deuten;  bestimmte Integrale mit dem Hauptsatz der Differenzial- und Integralrechnung über eine Stammfunktion berechnen;  Integralfunktionen ableiten, auch wenn die obere Grenze eine Funktion von ist;  Stammfunktionen mit der Tabelle der Grundintegrale und der Regel für lineare Argumente bestimmen und die Integrationskonstante aus einem bekannten Funktionswert festlegen;  uneigentliche Integrale über unbeschränkte Bereiche oder mit unbeschränktem Integranden als Grenzwerte berechnen;  Konsumentenrente, Mittelwerte, Wahrscheinlichkeitsdichten und Barwerte als Integrale lesen und ausrechnen.     Wie groß ist die Wahrscheinlichkeit, dass ein Bauteil länger als tausend Stunden hält? Wie viel ist ein Zahlungsstrom heute wert, der unbegrenzt weiterfließt? Wie viel Vorteil ziehen Käufer aus einem Marktpreis, der unter ihrer Zahlungsbereitschaft liegt? Alle drei Fragen sind Flächenfragen : Gesucht ist die Fläche zwischen dem Graphen einer Funktion und der -Achse. Dieser Abschnitt definiert diese Fläche als Integral — zunächst ehrlich und mühsam als Grenzwert von Rechtecksummen, dann bequem über den Hauptsatz, der das Integral mit der Ableitung aus dem vorigen Kapitel verknüpft und die Berechnung auf das Auffinden einer Stammfunktion zurückführt. Zum Schluss erweitern wir den Integralbegriff auf unbeschränkte Bereiche, wie sie bei Wahrscheinlichkeitsdichten und Barwerten auftreten.  Nebenbei erfahren Sie, was Archimedes schon vor über zweitausend Jahren über Flächen wusste, warum das Integralzeichen wie ein langgezogenes S aussieht, dass ausgerechnet die Glockenkurve der Statistik keine Stammfunktion zum Hinschreiben hat und wie man mit einer harmlos aussehenden Rechnung ein negatives Integral einer positiven Funktion beweist .    Vom Flächenproblem zur Riemannsumme   In haben wir gefragt, wie man aus der zurückgelegten Strecke die Momentangeschwindigkeit gewinnt. Jetzt stellen wir die umgekehrte Frage: Ein Fahrtenschreiber hat den Verlauf der Geschwindigkeit aufgezeichnet — wie weit ist das Fahrzeug gefahren? Bei konstanter Geschwindigkeit ist das einfach Geschwindigkeit mal Zeit, also die Fläche eines Rechtecks im Geschwindigkeits-Zeit-Diagramm. Ändert sich die Geschwindigkeit, ist die Strecke die Fläche unter der Kurve.  Damit sind wir beim zweiten Grundproblem der Analysis, dem Flächenproblem : Wie groß ist die Fläche zwischen dem Graphen einer Funktion und der -Achse? Die Idee zur Antwort ist so einfach wie die Rechnung des Fahrtenschreibers: in schmale Streifen zerlegen, jeden Streifen als Rechteck behandeln, aufsummieren. Das Ergebnis — das Riemannsche Integral — hängt eng mit der Ableitung zusammen, wie der Hauptsatz in zeigen wird.    Das Flächenproblem  Sei stetig (vgl. ). Wir suchen die Fläche zwischen dem Graphen von und der -Achse auf , bezeichnet als Integral  wobei die Integrationsgrenzen und der Integrand heißen.   Die gesuchte Fläche zwischen dem Graphen von und der -Achse auf .    Ein Koordinatensystem mit einer nach oben geöffneten Parabel . Die Fläche zwischen dem Kurvenstück von bis und der -Achse ist eingefärbt.      Eine der ältesten Motivationen für das Flächenproblem kommt aus der Ökonomie: Betrachten wir einen Markt mit einer Angebotsfunktion und einer Nachfragefunktion , die jeweils den Preis in Abhängigkeit von der gehandelten Menge angeben.   Angebots- und Nachfragekurve mit Marktgleichgewicht .    Ein Koordinatensystem mit Menge auf der horizontalen und Preis auf der vertikalen Achse. Eine steigende Gerade (Angebot) und eine fallende Gerade (Nachfrage) schneiden sich in einem Punkt, dessen Koordinaten und durch gestrichelte Hilfslinien markiert sind.      Stellt sich am Markt der Gleichgewichtspreis bei der Menge ein, so profitieren Käufer, die auch zu einem höheren Preis gekauft hätten, und Verkäufer, die auch zu einem niedrigeren Preis verkauft hätten. Diese Vorteile heißen Konsumentenrente und Produzentenrente , und beide sind Flächen zwischen Angebots- bzw. Nachfragekurve und der Geraden — also genau vom Typ des Flächenproblems. Sobald wir Integrale berechnen können, greifen wir dieses Beispiel in wieder auf.    Riemannsummen und die Definition des Integrals  Die Idee, eine krummlinig begrenzte Fläche durch immer feinere Stücke mit geraden Kanten auszuschöpfen, ist über zweitausend Jahre alt. Archimedes von Syrakus bestimmte um 250 v. Chr. auf diese Weise die Fläche eines Parabelsegments — sie ist genau der Fläche des einbeschriebenen Dreiecks —, indem er die Fläche mit immer mehr, immer kleineren Dreiecken ausfüllte. Im Kern steckt darin die geometrische Reihe aus . Präzise gefasst wurde das Verfahren erst im 19. Jahrhundert — von Bernhard Riemann im Jahr 1854, nach Vorarbeiten von Augustin-Louis Cauchy; daher der Name.  Die Grundidee zur Berechnung der Fläche: Wir unterteilen in gleich lange Teilintervalle der Länge , wählen in jedem Teilintervall einen Punkt (z. B. den Mittelpunkt oder den rechten Randpunkt), und approximieren die gesuchte Fläche durch die Summe der Rechteckflächen .   Approximation der Fläche unter durch fünf Rechtecke (Riemannsumme mit Mittelpunkten).    Dieselbe nach oben geöffnete Parabel wie in , diesmal überdeckt von fünf gleich breiten Rechtecken, deren Höhe jeweils dem Funktionswert am Mittelpunkt des zugehörigen Teilintervalls entspricht.       Riemannsumme   Sei stetig, sei in gleich lange Teilintervalle der Länge zerlegt, und sei ein Punkt im -ten Teilintervall ( ). Dann heißt  Riemannsumme von zur gegebenen Zerlegung.     Anwendungsbeispiel: Energieverbrauch aus Messdaten (zur Vertiefung)   Die elektrische Leistung eines Serverraums wird über vier Stunden jeweils zur Mitte jeder Stunde gemessen: , , und  kW. Schätzen Sie die in diesen vier Stunden verbrauchte Energie.    Energie ist Leistung mal Zeit — bei schwankender Leistung also die Fläche unter der Leistungskurve . Mit der Zerlegung in vier Stunden (  h) und den gemessenen Mittelpunktswerten ergibt sich die Riemannsumme So rechnen z. B. Monitoring-Werkzeuge: Messwerte in festen Zeitabständen werden mit der Schrittweite multipliziert und aufsummiert. Je kürzer der Messabstand, desto genauer die Schätzung — die folgende Definition macht diesen Grenzübergang präzise.     Riemann-Integral   Sei stetig. Für immer feinere Zerlegungen ( ) konvergiert die Folge der Riemannsummen gegen einen von der konkreten Wahl der Zerlegung und der Punkte unabhängigen Grenzwert. Dieser Grenzwert heißt das bestimmte Integral von auf :     An dieser Formel sieht man, woher die Schreibweise kommt. Leibniz, der sie um 1675 einführte, dachte an eine Summe unendlich vieler, unendlich schmaler Rechtecke, und schrieb dafür ein langgezogenes S (für lateinisch summa ): das Integralzeichen , gewissermaßen der kontinuierliche Verwandte des Summenzeichens . Aus der endlichen Breite wird dabei das unendlich kleine  . Lesen Sie deshalb ruhig als Summe von Höhe mal Breite, von bis — diese Lesart hilft bei jeder Anwendung, ob Energie, Strecke oder Wahrscheinlichkeit.   Integral einer konstanten Funktion (zur Vertiefung)   Bestimmen Sie .    Für die konstante Funktion ist jede Riemannsumme unabhängig von der Zerlegung bereits exakt die gesuchte Fläche: Ein Rechteck der Breite und Höhe . Es gilt also bereits ohne Grenzübergang      Integral einer linearen Funktion (zur Vertiefung)   Bestimmen Sie .    Die Fläche zwischen der Geraden und der -Achse auf ist ein rechtwinkliges Dreieck mit Grundseite und Höhe , also Auch hier lässt sich das Ergebnis direkt geometrisch ablesen, ohne den Grenzwert der Riemannsummen explizit auszurechnen.     Rechenbeispiel: Konvergenz der Riemannsummen von   Betrachten Sie und die Riemannsummen (mit Mittelpunkten) für bei zunehmend feinerer Unterteilung. Die folgende Tabelle zeigt die Werte für Teilintervalle. Rechnen Sie den Wert für von Hand nach.    Für ist , die Teilintervalle sind und mit den Mittelpunkten und : Die übrigen Werte der Tabelle entstehen genauso, nur mit mehr Summanden — eine Aufgabe für den Computer.   Riemannsummen von auf    Teilintervalle  Schrittweite  Riemannsumme            Die Riemannsummen nähern sich erkennbar dem Wert an. Im nächsten Abschnitt werden wir mit dem Hauptsatz der Differenzial- und Integralrechnung bestätigen, dass tatsächlich gilt — ohne dass wir dafür jemals wieder eine Riemannsumme von Hand aufsummieren müssen.      Eigenschaften und Vorzeichenkonvention  Aus der Definition über Riemannsummen folgen unmittelbar einige Grundeigenschaften des Integrals. Sei stetig:    Flächenstücke oberhalb der -Achse liefern einen positiven Beitrag zum Integral, solche unterhalb der -Achse einen negativen Beitrag — denn dort ist , und jeder Summand der Riemannsumme ist entsprechend negativ.  Integrale über einen einzelnen Punkt sind null: (das Intervall hat Länge ).  Vertauschen der Integrationsgrenzen bewirkt einen Vorzeichenwechsel: .     Vorzeichen des Integrals einer negativen Funktion (zur Vertiefung)   Vergleichen Sie (siehe ) mit .    Die Funktion ist auf überall negativ, ihr Graph verläuft unterhalb der -Achse. Jeder Summand jeder Riemannsumme von ist das -fache des entsprechenden Summanden für , also gilt bereits für jede einzelne Riemannsumme , und damit auch im Grenzwert Das Integral ist negativ — kein Fehler, sondern genau die Vorzeichenkonvention: Es misst die signierte Fläche, bei der Flächen unterhalb der Achse negativ gezählt werden.     Integral der Sinusfunktion über eine komplette Periode   Bestimmen Sie , ohne eine Stammfunktion zu berechnen.    Der Graph von ist punktsymmetrisch zu : Auf ist er positiv, auf exakt spiegelbildlich negativ, mit betragsmäßig gleicher Fläche. Die positiven und negativen Beiträge zur Riemannsumme heben sich also vollständig auf, und Beachten Sie: Das bedeutet nicht , dass zwischen dem Graphen von und der -Achse auf keine Fläche liegt — der tatsächliche (unsignierte) Flächeninhalt ist positiv. Das Integral misst eben die signierte Fläche.       Hauptsatz der Differenzial- und Integralrechnung   Riemannsummen von Hand aufzusummieren, wie in , ist mühsam und liefert ohnehin nur eine Näherung. Der folgende Satz — das wichtigste Hilfsmittel dieses Kapitels — verbindet das Integral mit der aus bekannten Ableitung und macht die exakte Berechnung von Integralen praktikabel.  Dass Flächen und Steigungen zusammenhängen, ist keineswegs offensichtlich — Isaac Newton und Gottfried Wilhelm Leibniz haben es im 17. Jahrhundert unabhängig voneinander entdeckt, und damit begann die moderne Analysis. Die Idee lässt sich aber anschaulich erklären, und das tun wir direkt nach dem Satz.    Aussage und Anschauung   Hauptsatz der Differenzial- und Integralrechnung   Sei stetig.    Die Funktion mit ist eine Stammfunktion von , d. h. .  Ist irgendeine Stammfunktion zu , d. h. , dann ist     Da der Ausdruck so häufig vorkommt, schreibt man dafür kurz .    Warum ist die Ableitung der Flächenfunktion gerade ? Schiebt man die rechte Grenze von auf , kommt ein schmaler Streifen hinzu. Für kleines ist er fast ein Rechteck der Breite und der Höhe , also Links steht der Differenzenquotient von ; für wird aus der Näherung eine Gleichung: . Die Fläche wächst also an jeder Stelle genau mit der Rate .  Der Hauptsatz löst damit beide Grundprobleme der Analysis mit einem Werkzeug: Kennt man eine Stammfunktion von , so lässt sich jedes bestimmte Integral von ohne Grenzwertbildung einer Riemannsumme berechnen.  Den zweiten Teil des Satzes kann man auch als Bilanzprinzip lesen. Ist irgendeine Größe und ihre Änderungsrate, so sagt Wer alle kleinen Änderungen zwischen und aufsummiert, erhält die Gesamtänderung. Das kennen Sie vom Konto: Die Summe aller Ein- und Auszahlungen eines Monats ist der Kontostand am Monatsende minus dem am Monatsanfang. Genauso ergibt die aufsummierte Geschwindigkeit die zurückgelegte Strecke, die aufsummierte Zuflussrate die Wassermenge im Speicher und die aufsummierten Grenzkosten die zusätzlichen Kosten.   Rechenbeispiel: Kontrolle des Riemannsummen-Grenzwerts   Bestimmen Sie mit dem Hauptsatz, und vergleichen Sie mit .    Eine Stammfunktion von ist (denn ). Damit Das ist genau der Wert, dem sich die Riemannsummen in immer weiter angenähert haben — der Hauptsatz liefert ihn exakt und ohne Grenzwertbildung.     Integral einer Summe aus Exponentialfunktion und quadratischer Funktion (zur Vertiefung)   Bestimmen Sie .    Eine Stammfunktion ist . Damit      Anwendungsbeispiel: Vom Tacho zur Strecke (zur Vertiefung)   Ein Fahrzeug beschleunigt aus dem Stand; seine Geschwindigkeit ist (in m\/s, in Sekunden, ). Welche Strecke legt es in den ersten Sekunden zurück?    Die Strecke ist die Fläche unter der Geschwindigkeitskurve. Eine Stammfunktion von ist , also Die Stammfunktion hat hier eine anschauliche Bedeutung: ist die bis zum Zeitpunkt zurückgelegte Strecke, und ihre Ableitung ist — wie beim Tacho — die Geschwindigkeit.      Integralfunktionen und die Kettenregel  Der erste Teil des Hauptsatzes macht eine Aussage über die Integralfunktion  , bei der die obere Integrationsgrenze selbst die Variable ist. Ist die obere Grenze nicht selbst, sondern eine Funktion von , so muss beim Ableiten zusätzlich die Kettenregel angewendet werden.   Ableitung einer Integralfunktion (ohne Kettenregel) (zur Vertiefung)   Sei . Bestimmen Sie .    Nach dem Hauptsatz ist unmittelbar eine Stammfunktion des Integranden, also ohne dass wir selbst überhaupt explizit ausrechnen müssen.     Rechenbeispiel: Ableitung einer Integralfunktion mit Kettenregel   Sei . Bestimmen Sie .    Die obere Grenze ist , also keine reine Variable. Wir schreiben mit . Nach dem Hauptsatz ist , und mit der Kettenregel        Unbestimmtes Integral und Grundintegrale   Der Hauptsatz macht Stammfunktionen zum zentralen Werkzeug der Integralrechnung: Wer ein bestimmtes Integral berechnen will, muss eine Funktion finden, deren Ableitung der Integrand ist. Integrieren ist also Ableiten rückwärts . Das klingt einfach, ist aber schwieriger als Ableiten: Für das Ableiten gibt es für jede Verknüpfung eine Regel, für das Integrieren nicht. Wir beginnen mit den Grundintegralen, die man direkt aus der Ableitungstabelle abliest; weitere Techniken folgen in .    Stammfunktionen und Grundintegrale   Unbestimmtes Integral   Eine Stammfunktion einer Funktion wird auch als unbestimmtes Integral von bezeichnet. Man schreibt      Vorsicht: Stammfunktionen sind nicht eindeutig. Ist eine Stammfunktion von , so ist auch für jede Konstante eine Stammfunktion von — schließlich ändert eine additive Konstante die Ableitung nicht. Man schreibt deshalb meist und nennt die Integrationskonstante . Für ein bestimmtes Integral spielt die Wahl von keine Rolle, da sich in ohnehin heraushebt.   Grundintegrale    Funktion  Stammfunktion              Warum steht in der zweiten Zeile und nicht einfach ? Weil auch für negative definiert ist, aber nicht. Für ist (Kettenregel), und beide Fälle fasst zusammen. Wer den Betrag weglässt, bekommt bei Integralen wie Logarithmen negativer Zahlen — und damit Unsinn.  Diese Tabelle liest man am schnellsten rückwärts : Da gilt, ist eine Stammfunktion von — jede Zeile ist also eine Zeile der Ableitungstabelle aus , von rechts nach links gelesen. (Nur den letzten Eintrag, die Stammfunktion von , kann man so nicht ablesen; wir leiten ihn in her.) Zusammen mit der Summenregel (die Stammfunktion einer Summe ist die Summe der Stammfunktionen) und der Regel für Konstanten lassen sich damit bereits viele unbestimmte Integrale bilden.  Eine nützliche Erweiterung der Tabelle betrifft ein lineares Argument : Ist eine der Funktionen aus der Tabelle mit Stammfunktion , und ist , so ist eine Stammfunktion von — das folgt direkt aus der Kettenregel, denn . Insbesondere gilt für : Diese beiden Fälle tauchen im weiteren Verlauf dieses Kapitels wiederholt auf, etwa bei zeitlich abklingenden oder periodischen Vorgängen.   Rechenbeispiel: Stammfunktion einer Summe von Potenzfunktionen   Bestimmen Sie .    Wir schreiben zunächst alle Terme als Potenzen von : und . Gliedweises Integrieren mit der Potenzregel liefert Insgesamt      Rechenbeispiel: Stammfunktion mit Logarithmus- und Exponentialterm (zur Vertiefung)   Bestimmen Sie .    Der konstante Summand (die Eulersche Zahl, ein fester reeller Wert) integriert sich wie jede Konstante zu . Zusammen mit den anderen beiden Grundintegralen:      Rechenbeispiel: Stammfunktion einer Kombination von Sinus und Kosinus (zur Vertiefung)   Bestimmen Sie .          Rechenbeispiel: Lineare Argumente — und wo die Regel endet   Bestimmen Sie , und . Lässt sich genauso behandeln?    In allen drei Fällen ist das Argument linear, und wir teilen durch den Faktor vor : Probe durch Ableiten, etwa beim ersten: . Die Probe ist beim Integrieren immer möglich und sehr zu empfehlen.  Bei ist das Argument nicht linear. Der naheliegende Versuch scheitert an der Probe: Nach der Quotientenregel kommt nicht heraus. Tatsächlich hat gar keine Stammfunktion, die sich mit elementaren Funktionen aufschreiben lässt — ein Phänomen, das es beim Ableiten nicht gibt. Bewiesen hat solche Aussagen der französische Mathematiker Joseph Liouville im 19. Jahrhundert. Pikanterweise gilt dasselbe für , die Glockenkurve der Normalverteilung, also für die wohl wichtigste Funktion der Statistik: Ihre Integrale muss man numerisch berechnen, wie in gezeigt wird. Ableiten ist Handwerk, Integrieren manchmal Kunst — und manchmal unmöglich.      Anwendungsbeispiele  Weil Stammfunktionen nur bis auf eine Konstante festliegen, braucht man in Anwendungen eine Zusatzinformation, um die richtige auszuwählen — etwa einen bekannten Funktionswert. Die Konstante hat dann oft eine ganz konkrete Bedeutung.   Anwendungsbeispiel: Die Kostenfunktion aus den Grenzkosten   Die Controlling-Abteilung eines Betriebs kennt die Grenzkosten (in EUR pro Einheit bei einer Produktionsmenge von Einheiten) und die Fixkosten von  EUR. Bestimmen Sie die Kostenfunktion . Wie stark steigen die Kosten, wenn die Produktion von auf Einheiten erhöht wird?    Gliedweises Integrieren liefert alle Stammfunktionen Die Fixkosten sind die Kosten bei , also , und Das ist genau die Kostenfunktion aus — Ableiten und Integrieren heben sich auf, und die Integrationskonstante entpuppt sich als die Fixkosten. Für die Kostensteigerung braucht man die Konstante gar nicht: Nach dem Bilanzprinzip ist sie      Anwendungsbeispiel: Konsumentenrente im Marktgleichgewicht   Wir greifen die Motivation aus auf. In einem Markt seien Angebots- und Nachfragefunktion gegeben durch jeweils als Preis in Abhängigkeit von der Menge . Bestimmen Sie die Gleichgewichtsmenge , den Gleichgewichtspreis und die Konsumentenrente .    Gleichsetzen von Angebot und Nachfrage: Mit der Lösungsformel ergibt sich und ; die negative Lösung scheidet als Menge aus, also . Der Gleichgewichtspreis ist (Kontrolle: ✓).  Die Konsumentenrente ist die Fläche zwischen der Nachfragekurve und der Geraden :      Anwendungsbeispiel: Der Tagesertrag einer Solaranlage (zur Vertiefung)   Die Leistung einer Photovoltaikanlage an einem sonnigen Tag wird zwischen Sonnenaufgang (6 Uhr) und Sonnenuntergang (18 Uhr) durch modelliert ( in Stunden). Wie viel Energie liefert sie an diesem Tag?    Energie ist die Fläche unter der Leistungskurve — dieselbe Idee wie beim Serverraum in , nur jetzt exakt. Das Argument des Sinus ist linear in mit Faktor , also ist eine Stammfunktion: Plausibilitätscheck: Zwölf Stunden Spitzenleistung wären  kWh; die Sinuskurve füllt davon den Anteil . Mit knapp  kWh ließe sich ein durchschnittlicher Vierpersonenhaushalt etwa vier Tage lang versorgen.     Anwendungsbeispiel: Durchschnittstemperatur eines Tages   Für eine stetige Funktion ist der Durchschnittswert auf einem Intervall definiert als — man teilt die Fläche unter durch die Intervalllänge, analog dazu, wie man bei diskreten Daten die Summe der Werte durch ihre Anzahl teilt. Die Tagestemperatur (in °C) an einem Sommertag folge näherungsweise , wobei die Zeit in Stunden ab 9 Uhr morgens ist (das Maximum liegt dann um 15 Uhr, das Minimum um 3 Uhr nachts). Bestimmen Sie die Durchschnittstemperatur über den ganzen Tag.     Der konstante Anteil liefert . Für den Schwingungsanteil ist eine Stammfunktion, und da genau eine volle Periode der Funktion ist (Periode ), gilt , und der Term verschwindet: Damit — die Schwankung um den Mittelwert trägt im Tagesdurchschnitt nichts bei, die Durchschnittstemperatur ist genau der konstante Anteil .       Uneigentliches Integral   Der Hauptsatz setzt voraus, dass auf einem abgeschlossenen, endlichen Intervall stetig ist. In vielen Anwendungen — etwa wenn ein Vorgang zeitlich unbegrenzt andauert, oder wenn eine Dichtefunktion an einer Stelle unbeschränkt wird — möchte man aber über unbeschränkte Bereiche oder unbeschränkte Funktionen integrieren. Man behandelt beide Fälle über einen Grenzübergang.  Dabei begegnet Ihnen ein alter Bekannter aus in neuem Gewand: Eine Fläche, die sich unendlich weit erstreckt, kann trotzdem einen endlichen Inhalt haben — oder auch nicht, und wieder kommt es darauf an, wie schnell der Integrand gegen null geht. Und Sie sehen, warum man bei Integranden mit Polstellen genau hinschauen muss, bevor man den Hauptsatz anwendet.    Unbeschränkte Integrationsgrenzen   Uneigentliches Integral mit unbeschränkten Integrationsgrenzen   Sei auf dem jeweils passenden Bereich stetig. Falls die folgenden Grenzwerte existieren, definiert man Existiert der jeweilige Grenzwert, heißt das Integral konvergent , sonst divergent .     Rechenbeispiel: Uneigentliches Integral der Exponentialfunktion   Bestimmen Sie .     Da für , ist das Integral konvergent mit Wert Eine Fläche, die sich unendlich weit nach rechts erstreckt, hat also einen endlichen Inhalt — dasselbe Phänomen wie bei der geometrischen Reihe in .     Rechenbeispiel: gegen   Untersuchen Sie und auf Konvergenz.    Für ist eine Stammfunktion: Für ist eine Stammfunktion: Das erste Integral konvergiert, das zweite divergiert, obwohl beide Integranden gegen gehen. Erinnert Sie das an etwas? Die Reihe konvergiert, die harmonische Reihe divergiert ( ). Integral und Reihe verhalten sich hier gleich — fällt einfach zu langsam.      Unbeschränkter Integrand   Uneigentliches Integral mit unbeschränktem Integranden   Seien , und sei bzw. stetig, aber an der jeweils ausgeschlossenen Randstelle unbeschränkt. Falls die folgenden Grenzwerte existieren, definiert man      Rechenbeispiel: Uneigentliches Integral mit Singularität am Rand   Bestimmen Sie .    Der Integrand ist an der Stelle nicht definiert und unbeschränkt, das Integral ist also uneigentlich. Das Integral ist also konvergent mit Wert .    Uneigentliche Integrale erkennt man nicht immer an der Schreibweise. Liegt die problematische Stelle im Inneren des Intervalls, muss man das Integral dort aufteilen — sonst liefert der Hauptsatz Unsinn.   Vorsicht, Polstelle: Ein negatives Integral einer positiven Funktion?   Jemand rechnet Was ist hier schiefgegangen, und was ist richtig?    Das Ergebnis kann nicht stimmen: Der Integrand ist überall positiv, jede Riemannsumme also positiv. Der Fehler ist, dass bei — mitten im Intervall — nicht definiert und unbeschränkt ist. Der Hauptsatz verlangt aber eine auf dem ganzen Intervall stetige Funktion. Richtig ist, das Integral bei in zwei uneigentliche Integrale aufzuteilen. Schon das rechte divergiert: Das Integral ist also divergent; die Fläche unter dem Graphen ist unendlich groß.    Allgemein gilt: Hat an einer Stelle im Inneren von eine Singularität, so zerlegt man in zwei uneigentliche Integrale. Das Integral konvergiert nur, wenn beide Teilintegrale konvergieren. Und vor jedem Einsetzen in eine Stammfunktion lohnt ein kurzer Blick, ob der Integrand auf dem ganzen Intervall stetig ist.    Anwendungsbeispiele   Anwendungsbeispiel: Dichtefunktion der Exponentialverteilung   In der Data Science modelliert man Wartezeiten oder Lebensdauern häufig mit der Exponentialverteilung , deren Dichtefunktion für einen Parameter gegeben ist durch für . Eine grundlegende Eigenschaft jeder Wahrscheinlichkeitsdichte ist, dass die Gesamtfläche unter ihrem Graphen gleich ist — die Gesamtwahrscheinlichkeit. Zeigen Sie .  Die Wahrscheinlichkeit, dass die Lebensdauer mindestens beträgt, ist die Fläche unter der Dichte rechts von . Ein Bauteil habe eine exponentialverteilte Lebensdauer mit pro Stunde. Wie wahrscheinlich ist es, dass es länger als Stunden hält?     Da , gilt für , also wie behauptet. Diese Eigenschaft — die Fläche unter einer Dichte ist stets — ist der Grund, warum Integrale in der Wahrscheinlichkeitsrechnung und Statistik allgegenwärtig sind.  Für die Lebensdauer rechnen wir genauso, nur ab : Mit etwa Wahrscheinlichkeit hält das Bauteil länger als Stunden. Damit ist die erste Frage aus der Einleitung dieses Abschnitts beantwortet.     Anwendungsbeispiel: Barwert einer ewigen Rente   Eine Zahlung fließt kontinuierlich mit konstanter Rate pro Zeiteinheit und wird stetig mit Zinssatz diskontiert; der Wert einer zum Zeitpunkt fließenden Zahlung ist heute also wert. Leiten Sie eine allgemeine Formel für den Barwert einer unbegrenzt lange fließenden solchen Zahlung her, .     Da , gilt für , also Diese einfache Formel — Zahlungsrate durch Zinssatz — ist die stetige Version der ewigen Rente : In hatten wir für jährliche Zahlungen und Jahreszins über eine geometrische Reihe genau dasselbe Ergebnis erhalten. Reihe und Integral sind hier die diskrete und die kontinuierliche Fassung derselben Rechnung.       Zusammenfassung     Bestimmtes Integral:  — Grenzwert der Riemannsummen, geometrisch die signierte Fläche (unterhalb der Achse negativ). , . Lesart: Summe von Höhe mal Breite .   Hauptsatz: Die Integralfunktion ist eine Stammfunktion von ( ), und für jede Stammfunktion gilt . Bilanzprinzip:  — die aufsummierte Änderungsrate ist die Gesamtänderung. Ist die obere Grenze eine Funktion , kommt die Kettenregel dazu: .   Unbestimmtes Integral  : alle Stammfunktionen, eindeutig bis auf die Konstante . Grundintegrale = Ableitungstabelle rückwärts; lineares Argument: , etwa ; . Die Konstante wird durch einen bekannten Funktionswert festgelegt (Fixkosten ). Nicht jede elementare Funktion hat eine elementare Stammfunktion ( ).   Uneigentliche Integrale:  ; bei einer Singularität am Rand : . Konvergent, wenn der Grenzwert existiert. Bei einer Singularität im Inneren an dieser Stelle aufteilen — konvergent nur, wenn beide Teile konvergieren. Beispiele: , ; konvergiert, nicht. Vorsicht bei Polstellen im Inneren: dort aufteilen, sonst liefert der Hauptsatz Unsinn.   Anwendungen: Konsumentenrente ; Mittelwert ; Dichtefunktion mit ; Barwert .      Übungsaufgaben    Bestimmen Sie alle Stammfunktionen von .           Berechnen Sie .           Sei . Bestimmen Sie .    Nach dem Hauptsatz der Differenzial- und Integralrechnung ist eine Stammfunktion des Integranden, also unmittelbar       Berechnen Sie den Flächeninhalt zwischen dem Graphen von und der -Achse auf dem Intervall .    Auf gilt (Nullstellen genau an den Rändern), der Graph liegt also durchgehend auf oder unterhalb der -Achse. Der Flächeninhalt ist daher der Betrag des Integrals: also Flächeninhalt .      Untersuchen Sie auf Konvergenz und berechnen Sie im konvergenten Fall den Wert.     Das Integral ist konvergent mit Wert .     "
},
{
  "id": "sec-riemannsches-integral-2",
  "level": "2",
  "url": "sec-riemannsches-integral.html#sec-riemannsches-integral-2",
  "type": "Lernziele",
  "number": "4.1",
  "title": "",
  "body": "  Nach diesem Abschnitt können Sie    das bestimmte Integral als Grenzwert von Riemannsummen erklären und als signierte Fläche deuten;  bestimmte Integrale mit dem Hauptsatz der Differenzial- und Integralrechnung über eine Stammfunktion berechnen;  Integralfunktionen ableiten, auch wenn die obere Grenze eine Funktion von ist;  Stammfunktionen mit der Tabelle der Grundintegrale und der Regel für lineare Argumente bestimmen und die Integrationskonstante aus einem bekannten Funktionswert festlegen;  uneigentliche Integrale über unbeschränkte Bereiche oder mit unbeschränktem Integranden als Grenzwerte berechnen;  Konsumentenrente, Mittelwerte, Wahrscheinlichkeitsdichten und Barwerte als Integrale lesen und ausrechnen.   "
},
{
  "id": "sub-riemannsumme-integralbegriff-2-2",
  "level": "2",
  "url": "sec-riemannsches-integral.html#sub-riemannsumme-integralbegriff-2-2",
  "type": "Absatz (with a defined term)",
  "number": "",
  "title": "",
  "body": "Riemannsche Integral "
},
{
  "id": "sub-flaechenproblem-2",
  "level": "2",
  "url": "sec-riemannsches-integral.html#sub-flaechenproblem-2",
  "type": "Absatz (with a defined term)",
  "number": "",
  "title": "",
  "body": "Integral Integrationsgrenzen Integrand "
},
{
  "id": "fig-flaeche-unter-graph",
  "level": "2",
  "url": "sec-riemannsches-integral.html#fig-flaeche-unter-graph",
  "type": "Abbildung",
  "number": "4.1.1",
  "title": "",
  "body": " Die gesuchte Fläche zwischen dem Graphen von und der -Achse auf .    Ein Koordinatensystem mit einer nach oben geöffneten Parabel . Die Fläche zwischen dem Kurvenstück von bis und der -Achse ist eingefärbt.     "
},
{
  "id": "sub-flaechenproblem-4",
  "level": "2",
  "url": "sec-riemannsches-integral.html#sub-flaechenproblem-4",
  "type": "Absatz (with a defined term)",
  "number": "",
  "title": "",
  "body": "Angebotsfunktion Nachfragefunktion "
},
{
  "id": "fig-angebot-nachfrage",
  "level": "2",
  "url": "sec-riemannsches-integral.html#fig-angebot-nachfrage",
  "type": "Abbildung",
  "number": "4.1.2",
  "title": "",
  "body": " Angebots- und Nachfragekurve mit Marktgleichgewicht .    Ein Koordinatensystem mit Menge auf der horizontalen und Preis auf der vertikalen Achse. Eine steigende Gerade (Angebot) und eine fallende Gerade (Nachfrage) schneiden sich in einem Punkt, dessen Koordinaten und durch gestrichelte Hilfslinien markiert sind.     "
},
{
  "id": "sub-flaechenproblem-6",
  "level": "2",
  "url": "sec-riemannsches-integral.html#sub-flaechenproblem-6",
  "type": "Absatz (with a defined term)",
  "number": "",
  "title": "",
  "body": "Konsumentenrente Produzentenrente "
},
{
  "id": "fig-riemannsumme-rechtecke",
  "level": "2",
  "url": "sec-riemannsches-integral.html#fig-riemannsumme-rechtecke",
  "type": "Abbildung",
  "number": "4.1.3",
  "title": "",
  "body": " Approximation der Fläche unter durch fünf Rechtecke (Riemannsumme mit Mittelpunkten).    Dieselbe nach oben geöffnete Parabel wie in , diesmal überdeckt von fünf gleich breiten Rechtecken, deren Höhe jeweils dem Funktionswert am Mittelpunkt des zugehörigen Teilintervalls entspricht.     "
},
{
  "id": "def-riemannsumme",
  "level": "2",
  "url": "sec-riemannsches-integral.html#def-riemannsumme",
  "type": "Definition",
  "number": "4.1.4",
  "title": "Riemannsumme.",
  "body": " Riemannsumme   Sei stetig, sei in gleich lange Teilintervalle der Länge zerlegt, und sei ein Punkt im -ten Teilintervall ( ). Dann heißt  Riemannsumme von zur gegebenen Zerlegung.   "
},
{
  "id": "ex-anwendung-energie-aus-leistungsdaten",
  "level": "2",
  "url": "sec-riemannsches-integral.html#ex-anwendung-energie-aus-leistungsdaten",
  "type": "Beispiel",
  "number": "4.1.5",
  "title": "Anwendungsbeispiel: Energieverbrauch aus Messdaten (zur Vertiefung).",
  "body": " Anwendungsbeispiel: Energieverbrauch aus Messdaten (zur Vertiefung)   Die elektrische Leistung eines Serverraums wird über vier Stunden jeweils zur Mitte jeder Stunde gemessen: , , und  kW. Schätzen Sie die in diesen vier Stunden verbrauchte Energie.    Energie ist Leistung mal Zeit — bei schwankender Leistung also die Fläche unter der Leistungskurve . Mit der Zerlegung in vier Stunden (  h) und den gemessenen Mittelpunktswerten ergibt sich die Riemannsumme So rechnen z. B. Monitoring-Werkzeuge: Messwerte in festen Zeitabständen werden mit der Schrittweite multipliziert und aufsummiert. Je kürzer der Messabstand, desto genauer die Schätzung — die folgende Definition macht diesen Grenzübergang präzise.   "
},
{
  "id": "def-riemann-integral",
  "level": "2",
  "url": "sec-riemannsches-integral.html#def-riemann-integral",
  "type": "Definition",
  "number": "4.1.6",
  "title": "Riemann-Integral.",
  "body": " Riemann-Integral   Sei stetig. Für immer feinere Zerlegungen ( ) konvergiert die Folge der Riemannsummen gegen einen von der konkreten Wahl der Zerlegung und der Punkte unabhängigen Grenzwert. Dieser Grenzwert heißt das bestimmte Integral von auf :    "
},
{
  "id": "ex-integral-konstante-funktion",
  "level": "2",
  "url": "sec-riemannsches-integral.html#ex-integral-konstante-funktion",
  "type": "Beispiel",
  "number": "4.1.7",
  "title": "Integral einer konstanten Funktion (zur Vertiefung).",
  "body": " Integral einer konstanten Funktion (zur Vertiefung)   Bestimmen Sie .    Für die konstante Funktion ist jede Riemannsumme unabhängig von der Zerlegung bereits exakt die gesuchte Fläche: Ein Rechteck der Breite und Höhe . Es gilt also bereits ohne Grenzübergang    "
},
{
  "id": "ex-integral-lineare-funktion",
  "level": "2",
  "url": "sec-riemannsches-integral.html#ex-integral-lineare-funktion",
  "type": "Beispiel",
  "number": "4.1.8",
  "title": "Integral einer linearen Funktion (zur Vertiefung).",
  "body": " Integral einer linearen Funktion (zur Vertiefung)   Bestimmen Sie .    Die Fläche zwischen der Geraden und der -Achse auf ist ein rechtwinkliges Dreieck mit Grundseite und Höhe , also Auch hier lässt sich das Ergebnis direkt geometrisch ablesen, ohne den Grenzwert der Riemannsummen explizit auszurechnen.   "
},
{
  "id": "ex-riemannsumme-quadratfunktion-tabelle",
  "level": "2",
  "url": "sec-riemannsches-integral.html#ex-riemannsumme-quadratfunktion-tabelle",
  "type": "Beispiel",
  "number": "4.1.9",
  "title": "Rechenbeispiel: Konvergenz der Riemannsummen von <span class=\"process-math\">\\(f(x)=\\frac13x^2\\)<\/span>.",
  "body": " Rechenbeispiel: Konvergenz der Riemannsummen von   Betrachten Sie und die Riemannsummen (mit Mittelpunkten) für bei zunehmend feinerer Unterteilung. Die folgende Tabelle zeigt die Werte für Teilintervalle. Rechnen Sie den Wert für von Hand nach.    Für ist , die Teilintervalle sind und mit den Mittelpunkten und : Die übrigen Werte der Tabelle entstehen genauso, nur mit mehr Summanden — eine Aufgabe für den Computer.   Riemannsummen von auf    Teilintervalle  Schrittweite  Riemannsumme            Die Riemannsummen nähern sich erkennbar dem Wert an. Im nächsten Abschnitt werden wir mit dem Hauptsatz der Differenzial- und Integralrechnung bestätigen, dass tatsächlich gilt — ohne dass wir dafür jemals wieder eine Riemannsumme von Hand aufsummieren müssen.   "
},
{
  "id": "sub-eigenschaften-integral-3",
  "level": "2",
  "url": "sec-riemannsches-integral.html#sub-eigenschaften-integral-3",
  "type": "Absatz (with a defined term)",
  "number": "",
  "title": "",
  "body": "positiven negativen "
},
{
  "id": "ex-integral-negative-funktion",
  "level": "2",
  "url": "sec-riemannsches-integral.html#ex-integral-negative-funktion",
  "type": "Beispiel",
  "number": "4.1.11",
  "title": "Vorzeichen des Integrals einer negativen Funktion (zur Vertiefung).",
  "body": " Vorzeichen des Integrals einer negativen Funktion (zur Vertiefung)   Vergleichen Sie (siehe ) mit .    Die Funktion ist auf überall negativ, ihr Graph verläuft unterhalb der -Achse. Jeder Summand jeder Riemannsumme von ist das -fache des entsprechenden Summanden für , also gilt bereits für jede einzelne Riemannsumme , und damit auch im Grenzwert Das Integral ist negativ — kein Fehler, sondern genau die Vorzeichenkonvention: Es misst die signierte Fläche, bei der Flächen unterhalb der Achse negativ gezählt werden.   "
},
{
  "id": "ex-integral-sinus-periode",
  "level": "2",
  "url": "sec-riemannsches-integral.html#ex-integral-sinus-periode",
  "type": "Beispiel",
  "number": "4.1.12",
  "title": "Integral der Sinusfunktion über eine komplette Periode.",
  "body": " Integral der Sinusfunktion über eine komplette Periode   Bestimmen Sie , ohne eine Stammfunktion zu berechnen.    Der Graph von ist punktsymmetrisch zu : Auf ist er positiv, auf exakt spiegelbildlich negativ, mit betragsmäßig gleicher Fläche. Die positiven und negativen Beiträge zur Riemannsumme heben sich also vollständig auf, und Beachten Sie: Das bedeutet nicht , dass zwischen dem Graphen von und der -Achse auf keine Fläche liegt — der tatsächliche (unsignierte) Flächeninhalt ist positiv. Das Integral misst eben die signierte Fläche.   "
},
{
  "id": "thm-hauptsatz-integral",
  "level": "2",
  "url": "sec-riemannsches-integral.html#thm-hauptsatz-integral",
  "type": "Satz",
  "number": "4.1.13",
  "title": "Hauptsatz der Differenzial- und Integralrechnung.",
  "body": " Hauptsatz der Differenzial- und Integralrechnung   Sei stetig.    Die Funktion mit ist eine Stammfunktion von , d. h. .  Ist irgendeine Stammfunktion zu , d. h. , dann ist     Da der Ausdruck so häufig vorkommt, schreibt man dafür kurz .   "
},
{
  "id": "ex-hauptsatz-quadratische-funktion",
  "level": "2",
  "url": "sec-riemannsches-integral.html#ex-hauptsatz-quadratische-funktion",
  "type": "Beispiel",
  "number": "4.1.14",
  "title": "Rechenbeispiel: Kontrolle des Riemannsummen-Grenzwerts.",
  "body": " Rechenbeispiel: Kontrolle des Riemannsummen-Grenzwerts   Bestimmen Sie mit dem Hauptsatz, und vergleichen Sie mit .    Eine Stammfunktion von ist (denn ). Damit Das ist genau der Wert, dem sich die Riemannsummen in immer weiter angenähert haben — der Hauptsatz liefert ihn exakt und ohne Grenzwertbildung.   "
},
{
  "id": "ex-hauptsatz-summe-exp-quadrat",
  "level": "2",
  "url": "sec-riemannsches-integral.html#ex-hauptsatz-summe-exp-quadrat",
  "type": "Beispiel",
  "number": "4.1.15",
  "title": "Integral einer Summe aus Exponentialfunktion und quadratischer Funktion (zur Vertiefung).",
  "body": " Integral einer Summe aus Exponentialfunktion und quadratischer Funktion (zur Vertiefung)   Bestimmen Sie .    Eine Stammfunktion ist . Damit    "
},
{
  "id": "ex-anwendung-strecke-aus-geschwindigkeit",
  "level": "2",
  "url": "sec-riemannsches-integral.html#ex-anwendung-strecke-aus-geschwindigkeit",
  "type": "Beispiel",
  "number": "4.1.16",
  "title": "Anwendungsbeispiel: Vom Tacho zur Strecke (zur Vertiefung).",
  "body": " Anwendungsbeispiel: Vom Tacho zur Strecke (zur Vertiefung)   Ein Fahrzeug beschleunigt aus dem Stand; seine Geschwindigkeit ist (in m\/s, in Sekunden, ). Welche Strecke legt es in den ersten Sekunden zurück?    Die Strecke ist die Fläche unter der Geschwindigkeitskurve. Eine Stammfunktion von ist , also Die Stammfunktion hat hier eine anschauliche Bedeutung: ist die bis zum Zeitpunkt zurückgelegte Strecke, und ihre Ableitung ist — wie beim Tacho — die Geschwindigkeit.   "
},
{
  "id": "sub-integralfunktion-2",
  "level": "2",
  "url": "sec-riemannsches-integral.html#sub-integralfunktion-2",
  "type": "Absatz (with a defined term)",
  "number": "",
  "title": "",
  "body": "Integralfunktion "
},
{
  "id": "ex-integralfunktion-ableiten-einfach",
  "level": "2",
  "url": "sec-riemannsches-integral.html#ex-integralfunktion-ableiten-einfach",
  "type": "Beispiel",
  "number": "4.1.17",
  "title": "Ableitung einer Integralfunktion (ohne Kettenregel) (zur Vertiefung).",
  "body": " Ableitung einer Integralfunktion (ohne Kettenregel) (zur Vertiefung)   Sei . Bestimmen Sie .    Nach dem Hauptsatz ist unmittelbar eine Stammfunktion des Integranden, also ohne dass wir selbst überhaupt explizit ausrechnen müssen.   "
},
{
  "id": "ex-integralfunktion-kettenregel",
  "level": "2",
  "url": "sec-riemannsches-integral.html#ex-integralfunktion-kettenregel",
  "type": "Beispiel",
  "number": "4.1.18",
  "title": "Rechenbeispiel: Ableitung einer Integralfunktion mit Kettenregel.",
  "body": " Rechenbeispiel: Ableitung einer Integralfunktion mit Kettenregel   Sei . Bestimmen Sie .    Die obere Grenze ist , also keine reine Variable. Wir schreiben mit . Nach dem Hauptsatz ist , und mit der Kettenregel    "
},
{
  "id": "def-unbestimmtes-integral",
  "level": "2",
  "url": "sec-riemannsches-integral.html#def-unbestimmtes-integral",
  "type": "Definition",
  "number": "4.1.19",
  "title": "Unbestimmtes Integral.",
  "body": " Unbestimmtes Integral   Eine Stammfunktion einer Funktion wird auch als unbestimmtes Integral von bezeichnet. Man schreibt    "
},
{
  "id": "ssub-stammfunktionen-grundintegrale-3",
  "level": "2",
  "url": "sec-riemannsches-integral.html#ssub-stammfunktionen-grundintegrale-3",
  "type": "Absatz (with a defined term)",
  "number": "",
  "title": "",
  "body": "Vorsicht: Integrationskonstante "
},
{
  "id": "tab-grundintegrale",
  "level": "2",
  "url": "sec-riemannsches-integral.html#tab-grundintegrale",
  "type": "Tabelle",
  "number": "4.1.20",
  "title": "Grundintegrale",
  "body": " Grundintegrale    Funktion  Stammfunktion             "
},
{
  "id": "ex-stammfunktion-potenzfunktionen",
  "level": "2",
  "url": "sec-riemannsches-integral.html#ex-stammfunktion-potenzfunktionen",
  "type": "Beispiel",
  "number": "4.1.21",
  "title": "Rechenbeispiel: Stammfunktion einer Summe von Potenzfunktionen.",
  "body": " Rechenbeispiel: Stammfunktion einer Summe von Potenzfunktionen   Bestimmen Sie .    Wir schreiben zunächst alle Terme als Potenzen von : und . Gliedweises Integrieren mit der Potenzregel liefert Insgesamt    "
},
{
  "id": "ex-stammfunktion-exp-log",
  "level": "2",
  "url": "sec-riemannsches-integral.html#ex-stammfunktion-exp-log",
  "type": "Beispiel",
  "number": "4.1.22",
  "title": "Rechenbeispiel: Stammfunktion mit Logarithmus- und Exponentialterm (zur Vertiefung).",
  "body": " Rechenbeispiel: Stammfunktion mit Logarithmus- und Exponentialterm (zur Vertiefung)   Bestimmen Sie .    Der konstante Summand (die Eulersche Zahl, ein fester reeller Wert) integriert sich wie jede Konstante zu . Zusammen mit den anderen beiden Grundintegralen:    "
},
{
  "id": "ex-stammfunktion-trig",
  "level": "2",
  "url": "sec-riemannsches-integral.html#ex-stammfunktion-trig",
  "type": "Beispiel",
  "number": "4.1.23",
  "title": "Rechenbeispiel: Stammfunktion einer Kombination von Sinus und Kosinus (zur Vertiefung).",
  "body": " Rechenbeispiel: Stammfunktion einer Kombination von Sinus und Kosinus (zur Vertiefung)   Bestimmen Sie .        "
},
{
  "id": "ex-stammfunktion-lineares-argument",
  "level": "2",
  "url": "sec-riemannsches-integral.html#ex-stammfunktion-lineares-argument",
  "type": "Beispiel",
  "number": "4.1.24",
  "title": "Rechenbeispiel: Lineare Argumente — und wo die Regel endet.",
  "body": " Rechenbeispiel: Lineare Argumente — und wo die Regel endet   Bestimmen Sie , und . Lässt sich genauso behandeln?    In allen drei Fällen ist das Argument linear, und wir teilen durch den Faktor vor : Probe durch Ableiten, etwa beim ersten: . Die Probe ist beim Integrieren immer möglich und sehr zu empfehlen.  Bei ist das Argument nicht linear. Der naheliegende Versuch scheitert an der Probe: Nach der Quotientenregel kommt nicht heraus. Tatsächlich hat gar keine Stammfunktion, die sich mit elementaren Funktionen aufschreiben lässt — ein Phänomen, das es beim Ableiten nicht gibt. Bewiesen hat solche Aussagen der französische Mathematiker Joseph Liouville im 19. Jahrhundert. Pikanterweise gilt dasselbe für , die Glockenkurve der Normalverteilung, also für die wohl wichtigste Funktion der Statistik: Ihre Integrale muss man numerisch berechnen, wie in gezeigt wird. Ableiten ist Handwerk, Integrieren manchmal Kunst — und manchmal unmöglich.   "
},
{
  "id": "ex-anwendung-kosten-aus-grenzkosten",
  "level": "2",
  "url": "sec-riemannsches-integral.html#ex-anwendung-kosten-aus-grenzkosten",
  "type": "Beispiel",
  "number": "4.1.25",
  "title": "Anwendungsbeispiel: Die Kostenfunktion aus den Grenzkosten.",
  "body": " Anwendungsbeispiel: Die Kostenfunktion aus den Grenzkosten   Die Controlling-Abteilung eines Betriebs kennt die Grenzkosten (in EUR pro Einheit bei einer Produktionsmenge von Einheiten) und die Fixkosten von  EUR. Bestimmen Sie die Kostenfunktion . Wie stark steigen die Kosten, wenn die Produktion von auf Einheiten erhöht wird?    Gliedweises Integrieren liefert alle Stammfunktionen Die Fixkosten sind die Kosten bei , also , und Das ist genau die Kostenfunktion aus — Ableiten und Integrieren heben sich auf, und die Integrationskonstante entpuppt sich als die Fixkosten. Für die Kostensteigerung braucht man die Konstante gar nicht: Nach dem Bilanzprinzip ist sie    "
},
{
  "id": "ex-anwendung-konsumentenrente",
  "level": "2",
  "url": "sec-riemannsches-integral.html#ex-anwendung-konsumentenrente",
  "type": "Beispiel",
  "number": "4.1.26",
  "title": "Anwendungsbeispiel: Konsumentenrente im Marktgleichgewicht.",
  "body": " Anwendungsbeispiel: Konsumentenrente im Marktgleichgewicht   Wir greifen die Motivation aus auf. In einem Markt seien Angebots- und Nachfragefunktion gegeben durch jeweils als Preis in Abhängigkeit von der Menge . Bestimmen Sie die Gleichgewichtsmenge , den Gleichgewichtspreis und die Konsumentenrente .    Gleichsetzen von Angebot und Nachfrage: Mit der Lösungsformel ergibt sich und ; die negative Lösung scheidet als Menge aus, also . Der Gleichgewichtspreis ist (Kontrolle: ✓).  Die Konsumentenrente ist die Fläche zwischen der Nachfragekurve und der Geraden :    "
},
{
  "id": "ex-anwendung-solarertrag",
  "level": "2",
  "url": "sec-riemannsches-integral.html#ex-anwendung-solarertrag",
  "type": "Beispiel",
  "number": "4.1.27",
  "title": "Anwendungsbeispiel: Der Tagesertrag einer Solaranlage (zur Vertiefung).",
  "body": " Anwendungsbeispiel: Der Tagesertrag einer Solaranlage (zur Vertiefung)   Die Leistung einer Photovoltaikanlage an einem sonnigen Tag wird zwischen Sonnenaufgang (6 Uhr) und Sonnenuntergang (18 Uhr) durch modelliert ( in Stunden). Wie viel Energie liefert sie an diesem Tag?    Energie ist die Fläche unter der Leistungskurve — dieselbe Idee wie beim Serverraum in , nur jetzt exakt. Das Argument des Sinus ist linear in mit Faktor , also ist eine Stammfunktion: Plausibilitätscheck: Zwölf Stunden Spitzenleistung wären  kWh; die Sinuskurve füllt davon den Anteil . Mit knapp  kWh ließe sich ein durchschnittlicher Vierpersonenhaushalt etwa vier Tage lang versorgen.   "
},
{
  "id": "ex-anwendung-mittelwert-temperatur",
  "level": "2",
  "url": "sec-riemannsches-integral.html#ex-anwendung-mittelwert-temperatur",
  "type": "Beispiel",
  "number": "4.1.28",
  "title": "Anwendungsbeispiel: Durchschnittstemperatur eines Tages.",
  "body": " Anwendungsbeispiel: Durchschnittstemperatur eines Tages   Für eine stetige Funktion ist der Durchschnittswert auf einem Intervall definiert als — man teilt die Fläche unter durch die Intervalllänge, analog dazu, wie man bei diskreten Daten die Summe der Werte durch ihre Anzahl teilt. Die Tagestemperatur (in °C) an einem Sommertag folge näherungsweise , wobei die Zeit in Stunden ab 9 Uhr morgens ist (das Maximum liegt dann um 15 Uhr, das Minimum um 3 Uhr nachts). Bestimmen Sie die Durchschnittstemperatur über den ganzen Tag.     Der konstante Anteil liefert . Für den Schwingungsanteil ist eine Stammfunktion, und da genau eine volle Periode der Funktion ist (Periode ), gilt , und der Term verschwindet: Damit — die Schwankung um den Mittelwert trägt im Tagesdurchschnitt nichts bei, die Durchschnittstemperatur ist genau der konstante Anteil .   "
},
{
  "id": "def-uneigentlich-grenzen",
  "level": "2",
  "url": "sec-riemannsches-integral.html#def-uneigentlich-grenzen",
  "type": "Definition",
  "number": "4.1.29",
  "title": "Uneigentliches Integral mit unbeschränkten Integrationsgrenzen.",
  "body": " Uneigentliches Integral mit unbeschränkten Integrationsgrenzen   Sei auf dem jeweils passenden Bereich stetig. Falls die folgenden Grenzwerte existieren, definiert man Existiert der jeweilige Grenzwert, heißt das Integral konvergent , sonst divergent .   "
},
{
  "id": "ex-uneigentlich-exponentiell",
  "level": "2",
  "url": "sec-riemannsches-integral.html#ex-uneigentlich-exponentiell",
  "type": "Beispiel",
  "number": "4.1.30",
  "title": "Rechenbeispiel: Uneigentliches Integral der Exponentialfunktion.",
  "body": " Rechenbeispiel: Uneigentliches Integral der Exponentialfunktion   Bestimmen Sie .     Da für , ist das Integral konvergent mit Wert Eine Fläche, die sich unendlich weit nach rechts erstreckt, hat also einen endlichen Inhalt — dasselbe Phänomen wie bei der geometrischen Reihe in .   "
},
{
  "id": "ex-uneigentlich-potenzen-vergleich",
  "level": "2",
  "url": "sec-riemannsches-integral.html#ex-uneigentlich-potenzen-vergleich",
  "type": "Beispiel",
  "number": "4.1.31",
  "title": "Rechenbeispiel: <span class=\"process-math\">\\(\\frac1x\\)<\/span> gegen <span class=\"process-math\">\\(\\frac1{x^2}\\)<\/span>.",
  "body": " Rechenbeispiel: gegen   Untersuchen Sie und auf Konvergenz.    Für ist eine Stammfunktion: Für ist eine Stammfunktion: Das erste Integral konvergiert, das zweite divergiert, obwohl beide Integranden gegen gehen. Erinnert Sie das an etwas? Die Reihe konvergiert, die harmonische Reihe divergiert ( ). Integral und Reihe verhalten sich hier gleich — fällt einfach zu langsam.   "
},
{
  "id": "def-uneigentlich-integrand",
  "level": "2",
  "url": "sec-riemannsches-integral.html#def-uneigentlich-integrand",
  "type": "Definition",
  "number": "4.1.32",
  "title": "Uneigentliches Integral mit unbeschränktem Integranden.",
  "body": " Uneigentliches Integral mit unbeschränktem Integranden   Seien , und sei bzw. stetig, aber an der jeweils ausgeschlossenen Randstelle unbeschränkt. Falls die folgenden Grenzwerte existieren, definiert man    "
},
{
  "id": "ex-uneigentlich-wurzel-integrand",
  "level": "2",
  "url": "sec-riemannsches-integral.html#ex-uneigentlich-wurzel-integrand",
  "type": "Beispiel",
  "number": "4.1.33",
  "title": "Rechenbeispiel: Uneigentliches Integral mit Singularität am Rand.",
  "body": " Rechenbeispiel: Uneigentliches Integral mit Singularität am Rand   Bestimmen Sie .    Der Integrand ist an der Stelle nicht definiert und unbeschränkt, das Integral ist also uneigentlich. Das Integral ist also konvergent mit Wert .   "
},
{
  "id": "ex-uneigentlich-falle-polstelle",
  "level": "2",
  "url": "sec-riemannsches-integral.html#ex-uneigentlich-falle-polstelle",
  "type": "Beispiel",
  "number": "4.1.34",
  "title": "Vorsicht, Polstelle: Ein negatives Integral einer positiven Funktion?",
  "body": " Vorsicht, Polstelle: Ein negatives Integral einer positiven Funktion?   Jemand rechnet Was ist hier schiefgegangen, und was ist richtig?    Das Ergebnis kann nicht stimmen: Der Integrand ist überall positiv, jede Riemannsumme also positiv. Der Fehler ist, dass bei — mitten im Intervall — nicht definiert und unbeschränkt ist. Der Hauptsatz verlangt aber eine auf dem ganzen Intervall stetige Funktion. Richtig ist, das Integral bei in zwei uneigentliche Integrale aufzuteilen. Schon das rechte divergiert: Das Integral ist also divergent; die Fläche unter dem Graphen ist unendlich groß.   "
},
{
  "id": "ex-anwendung-dichtefunktion-exponentialverteilung",
  "level": "2",
  "url": "sec-riemannsches-integral.html#ex-anwendung-dichtefunktion-exponentialverteilung",
  "type": "Beispiel",
  "number": "4.1.35",
  "title": "Anwendungsbeispiel: Dichtefunktion der Exponentialverteilung.",
  "body": " Anwendungsbeispiel: Dichtefunktion der Exponentialverteilung   In der Data Science modelliert man Wartezeiten oder Lebensdauern häufig mit der Exponentialverteilung , deren Dichtefunktion für einen Parameter gegeben ist durch für . Eine grundlegende Eigenschaft jeder Wahrscheinlichkeitsdichte ist, dass die Gesamtfläche unter ihrem Graphen gleich ist — die Gesamtwahrscheinlichkeit. Zeigen Sie .  Die Wahrscheinlichkeit, dass die Lebensdauer mindestens beträgt, ist die Fläche unter der Dichte rechts von . Ein Bauteil habe eine exponentialverteilte Lebensdauer mit pro Stunde. Wie wahrscheinlich ist es, dass es länger als Stunden hält?     Da , gilt für , also wie behauptet. Diese Eigenschaft — die Fläche unter einer Dichte ist stets — ist der Grund, warum Integrale in der Wahrscheinlichkeitsrechnung und Statistik allgegenwärtig sind.  Für die Lebensdauer rechnen wir genauso, nur ab : Mit etwa Wahrscheinlichkeit hält das Bauteil länger als Stunden. Damit ist die erste Frage aus der Einleitung dieses Abschnitts beantwortet.   "
},
{
  "id": "ex-anwendung-barwert-herleitung",
  "level": "2",
  "url": "sec-riemannsches-integral.html#ex-anwendung-barwert-herleitung",
  "type": "Beispiel",
  "number": "4.1.36",
  "title": "Anwendungsbeispiel: Barwert einer ewigen Rente.",
  "body": " Anwendungsbeispiel: Barwert einer ewigen Rente   Eine Zahlung fließt kontinuierlich mit konstanter Rate pro Zeiteinheit und wird stetig mit Zinssatz diskontiert; der Wert einer zum Zeitpunkt fließenden Zahlung ist heute also wert. Leiten Sie eine allgemeine Formel für den Barwert einer unbegrenzt lange fließenden solchen Zahlung her, .     Da , gilt für , also Diese einfache Formel — Zahlungsrate durch Zinssatz — ist die stetige Version der ewigen Rente : In hatten wir für jährliche Zahlungen und Jahreszins über eine geometrische Reihe genau dasselbe Ergebnis erhalten. Reihe und Integral sind hier die diskrete und die kontinuierliche Fassung derselben Rechnung.   "
},
{
  "id": "sub-zusammenfassung-4-1-2",
  "level": "2",
  "url": "sec-riemannsches-integral.html#sub-zusammenfassung-4-1-2",
  "type": "Absatz (with a defined term)",
  "number": "",
  "title": "",
  "body": "Bestimmtes Integral: Hauptsatz: Unbestimmtes Integral Uneigentliche Integrale: Anwendungen: "
},
{
  "id": "exercise-buch-stammfunktion-polynom",
  "level": "2",
  "url": "sec-riemannsches-integral.html#exercise-buch-stammfunktion-polynom",
  "type": "Übung",
  "number": "4.1.6.1",
  "title": "",
  "body": "  Bestimmen Sie alle Stammfunktionen von .        "
},
{
  "id": "exercise-buch-bestimmtes-integral-polynom",
  "level": "2",
  "url": "sec-riemannsches-integral.html#exercise-buch-bestimmtes-integral-polynom",
  "type": "Übung",
  "number": "4.1.6.2",
  "title": "",
  "body": "  Berechnen Sie .        "
},
{
  "id": "exercise-buch-integralfunktion-einfach",
  "level": "2",
  "url": "sec-riemannsches-integral.html#exercise-buch-integralfunktion-einfach",
  "type": "Übung",
  "number": "4.1.6.3",
  "title": "",
  "body": "  Sei . Bestimmen Sie .    Nach dem Hauptsatz der Differenzial- und Integralrechnung ist eine Stammfunktion des Integranden, also unmittelbar    "
},
{
  "id": "exercise-buch-flaeche-parabel-negativ",
  "level": "2",
  "url": "sec-riemannsches-integral.html#exercise-buch-flaeche-parabel-negativ",
  "type": "Übung",
  "number": "4.1.6.4",
  "title": "",
  "body": "  Berechnen Sie den Flächeninhalt zwischen dem Graphen von und der -Achse auf dem Intervall .    Auf gilt (Nullstellen genau an den Rändern), der Graph liegt also durchgehend auf oder unterhalb der -Achse. Der Flächeninhalt ist daher der Betrag des Integrals: also Flächeninhalt .   "
},
{
  "id": "exercise-buch-uneigentliches-integral-potenz",
  "level": "2",
  "url": "sec-riemannsches-integral.html#exercise-buch-uneigentliches-integral-potenz",
  "type": "Übung",
  "number": "4.1.6.5",
  "title": "",
  "body": "  Untersuchen Sie auf Konvergenz und berechnen Sie im konvergenten Fall den Wert.     Das Integral ist konvergent mit Wert .   "
},
{
  "id": "sec-integrationstechniken-anwendungen",
  "level": "1",
  "url": "sec-integrationstechniken-anwendungen.html",
  "type": "Abschnitt",
  "number": "4.2",
  "title": "Integrationstechniken und Anwendungen",
  "body": " Integrationstechniken und Anwendungen    Nach diesem Abschnitt können Sie    Linearität und Intervalladditivität des Integrals anwenden;  Produkte mit partieller Integration integrieren, einschließlich des Logarithmus-Tricks und der Rückschluss-Technik;  Integrale durch Substitution lösen, bei bestimmten Integralen die Grenzen mittransformieren und logarithmische Integration erkennen;  Effektivwert, Bogenlänge, Rotationsvolumen und Mantelfläche als Integrale aufstellen und berechnen;  Integrale numerisch mit Trapez- und Simpsonregel approximieren und einschätzen, wann das nötig ist;  Erwartungswerte und Normierungskonstanten von Dichtefunktionen sowie Barwerte wachsender Zahlungsströme berechnen.     Im vorigen Abschnitt haben wir das Riemann-Integral eingeführt und über den Hauptsatz mit der Stammfunktion verbunden — doch damit ist die Frage, wie man eine Stammfunktion tatsächlich findet, erst teilweise beantwortet: Unsere Grundintegrale-Tabelle deckt nur einzelne elementare Funktionen ab, nicht ihre Produkte oder Verkettungen. In diesem Abschnitt lernen wir mit partieller Integration und Substitution die beiden Techniken kennen, die genau diese Lücke schließen — jeweils eine Ableitungsregel rückwärts gelesen. Danach wenden wir das Integral auf Effektivwerte, Bogenlängen und Rotationskörper an und lernen schließlich numerische Verfahren für die Fälle kennen, in denen keine elementare Stammfunktion existiert — und das sind, wie die Normalverteilung zeigt, keineswegs exotische Fälle.  Unterwegs sehen Sie, was die  Volt auf dem Typenschild eigentlich bedeuten, wie lang eine durchhängende Leitung ist, warum man eine bestimmte Trompete mit Farbe füllen, aber nicht anstreichen kann, und wie ein Weinkauf Johannes Kepler zur numerischen Integration brachte. Und die Sigmoid-Funktion aus bekommt eine Stammfunktion, die aussieht wie eine geglättete ReLU.    Grundregeln: Linearität und Intervalladditivität  Für das Integrieren gibt es kein Rezept, das immer funktioniert — wohl aber eine Handvoll Techniken, die in den allermeisten praktisch wichtigen Fällen zum Ziel führen, und für den Rest numerische Verfahren. Bevor wir mit partieller Integration und Substitution die beiden wichtigsten Techniken kennenlernen, halten wir zwei einfache, aber ständig benutzte Rechenregeln fest, die direkt aus der Definition des Integrals als Grenzwert von Riemannsummen folgen.   Linearität des Integrals   Seien stetige Funktionen und . Dann gilt Dieselben Regeln gelten auch für unbestimmte Integrale.     Intervalladditivität   Sei stetig und . Dann gilt Man kann das Integrationsintervall also an jeder Stelle aufteilen — anschaulich zerlegt man einfach die Fläche unter in zwei Teilflächen.     Rechenbeispiel: Linearität und Intervalladditivität kombiniert   Für eine stetige Funktion gelte und . Bestimmen Sie .    Mit Intervalladditivität (Aufteilen bei ) und anschließender Linearität:     Die Intervalladditivität ist vor allem dann unverzichtbar, wenn nicht das (signierte) Integral, sondern der tatsächliche Flächeninhalt gefragt ist. Dann teilt man an den Nullstellen des Integranden auf und addiert die Beträge der Teilintegrale.   Rechenbeispiel: Flächeninhalt statt signierter Fläche   In hatten wir gesehen, dass sich beim Integral positive und negative Anteile aufheben können. Berechnen Sie für das Integral und den Flächeninhalt zwischen dem Graphen von und der -Achse auf .    Eine Stammfunktion ist . Über das ganze Intervall: Eine Fläche von kann aber nicht stimmen — der Graph weicht ja deutlich von der Achse ab. Die Nullstellen von sind und ; auf ist negativ, auf positiv. Wir teilen bei auf: Der Flächeninhalt ist die Summe der Beträge, . Die beiden Teilflächen sind zufällig gleich groß und heben sich im Integral genau auf. Wer einfach über integriert, erhält deshalb — ein klassischer Fehler, wenn nach einer Fläche gefragt ist.      Partielle Integration   Die bisherigen Grundintegrale reichen nicht aus, um ein Produkt wie zu integrieren — keine der bekannten Regeln greift direkt. Die partielle Integration entsteht durch Umkehren der Produktregel der Differenzialrechnung und ist das Werkzeug für genau solche Produkte.  Solche Produkte sind in den Anwendungen häufiger, als man denkt: Der Erwartungswert einer Wartezeit führt auf , der Barwert eines linear wachsenden Zahlungsstroms auf . Beide Male steht eine Potenzfunktion mal eine Exponentialfunktion im Integranden.    Die Regel und typische Fälle   Partielle Integration   Seien stetig differenzierbare Funktionen. Dann gilt Dieselbe Regel gilt auch für unbestimmte Integrale: .    Nach der Produktregel ist , also ist eine Stammfunktion von . Mit dem Hauptsatz folgt , und Umstellen liefert die Formel.    Die Kunst besteht darin, im Integranden eine Zerlegung in einen Faktor (der abgeleitet wird) und einen Faktor (der aufgeleitet wird) so zu wählen, dass das neu entstehende Integral  einfacher ist als das ursprüngliche. Eine bewährte Merkregel stammt aus dem Englischen: In der Reihenfolge L ogarithmus, I nverse Winkelfunktion, A lgebraische Funktion (Potenzen, Polynome), T rigonometrische Funktion, E xponentialfunktion — kurz LIATE — wählt man den Faktor, der weiter vorne steht, als (zum Ableiten). Bei Produkten mit einer Potenzfunktion heißt das meist: Die Potenz wird abgeleitet (sie wird dadurch einfacher), der andere Faktor ( , , …) aufgeleitet. Eine Garantie ist das nicht, aber ein guter erster Versuch.   Rechenbeispiel: Potenzfunktion mal Exponentialfunktion (zur Vertiefung)   Bestimmen Sie .    Wir wählen (wird abgeleitet) und (wird aufgeleitet), also und . Mit der Formel: Probe durch Ableiten: ✓.  Und wenn man die Rollen vertauscht? Mit und , also , entstünde das neue Integral — schwieriger als das ursprüngliche. Führt eine Wahl in die falsche Richtung, probiert man die andere.     Rechenbeispiel: Bestimmtes Integral mit Kosinus (zur Vertiefung)   Bestimmen Sie .    Mit , , also , :      Rechenbeispiel: Der Logarithmus-Trick   Bestimmen Sie .    Hier steht scheinbar kein Produkt — der Trick ist, als zu lesen und den konstanten Faktor aufzuleiten: , , also , . Damit Dies bestätigt den Eintrag für in der Grundintegrale-Tabelle aus . Derselbe Trick — einen Faktor einführen und aufleiten — funktioniert für und ganz analog.     Rechenbeispiel: Zweifache partielle Integration mit Rückschluss   Bestimmen Sie .    Mit , : Das neue Integral integrieren wir nochmals partiell, diesmal mit , : Setzen wir das ein, taucht rechts wieder das ursprüngliche Integral auf: Addieren wir auf beiden Seiten und teilen durch : Diese Rückschluss -Technik — das gesuchte Integral taucht nach zweimaliger partieller Integration wieder auf und wird wie eine Unbekannte in einer Gleichung behandelt — funktioniert immer dann, wenn sich die Faktoren beim Ableiten reproduzieren, wie mit und .      Anwendungsbeispiele   Anwendungsbeispiel: Erwartungswert der Exponentialverteilung   In hatten wir gezeigt, dass die Dichtefunktion der Exponentialverteilung (Parameter ) die Gesamtwahrscheinlichkeit liefert. Der Erwartungswert dieser Verteilung ist definiert als Bestimmen Sie .    Zunächst die unbestimmte Stammfunktion mit partieller Integration, , , also , : Da die obere Grenze unendlich ist, betrachten wir den Grenzwert für : Für geht (die Exponentialfunktion gewinnt gegen das Polynom ) und ebenso . Damit Je größer die Rate (je schneller die Verteilung abklingt ), desto kleiner der erwartete Wert — ein Ergebnis, das in der Warteschlangentheorie und bei Ausfallzeitmodellen ständig verwendet wird. Für das Bauteil aus mit pro Stunde heißt das: Im Mittel hält es Stunden.     Anwendungsbeispiel: Barwert eines wachsenden Zahlungsstroms   Ein Softwareunternehmen erwartet aus einem Abonnementprodukt kontinuierliche Einnahmen mit der Rate (in Tausend EUR pro Jahr, in Jahren) — die Einnahmen wachsen also linear. Wie in wird stetig diskontiert, hier mit . Bestimmen Sie den Barwert der Einnahmen der ersten fünf Jahre, , sowie den Barwert bei unbegrenzter Laufzeit.    Der konstante Anteil ist ein Grundintegral: . Für den wachsenden Anteil integrieren wir partiell mit , , also : Zusammen: Die Einnahmen der ersten fünf Jahre (nominal Tausend EUR) sind heute also knapp Tausend EUR wert. Bei unbegrenzter Laufzeit gehen alle Terme mit für gegen — auch , denn die Exponentialfunktion gewinnt gegen jede Potenz —, und es bleibt der Barwert Tausend EUR. Allgemein ergibt dieselbe Rechnung für den Barwert Das Wachstum wird durch geteilt und fällt bei niedrigen Zinsen besonders ins Gewicht.       Integration durch Substitution   Die zweite grundlegende Integrationstechnik entsteht durch Umkehren der Kettenregel. Sie ist das richtige Werkzeug, wenn der Integrand die Ableitung einer inneren Funktion als Faktor enthält.  In haben wir gesehen, dass sich nicht elementar integrieren lässt. Überraschenderweise ist ganz einfach zu integrieren: Der zusätzliche Faktor ist — bis auf den Faktor — genau die Ableitung der inneren Funktion . Genau diese Situation erkennt und nutzt die Substitutionsregel.    Die Regel und typische Fälle   Substitutionsregel   Sei stetig und stetig differenzierbar. Dann gilt Dieselbe Regel gilt für unbestimmte Integrale — dort wird am Ende wieder in zurücksubstituiert.    Ist eine Stammfunktion von , so ist nach der Kettenregel . Mit dem Hauptsatz sind daher beide Seiten gleich .    Praktisch geht man in drei Schritten vor: Man wählt eine Substitution , drückt mithilfe von durch aus, und integriert das entstehende (hoffentlich einfachere) Integral in der Variablen . Bei einem bestimmten Integral gibt es zwei gleichwertige Möglichkeiten, mit den Grenzen umzugehen: entweder man rechnet zunächst das unbestimmte Integral in aus und setzt am Ende die ursprünglichen Grenzen ein, oder man transformiert die Grenzen direkt mit — dann muss man am Ende nicht zurücksubstituieren. nutzt die zweite Variante.   Rechenbeispiel: Die innere Ableitung steht schon da   Bestimmen Sie .    Wir substituieren , also bzw. : Probe: ✓.     Rechenbeispiel: Logarithmische Integration   Bestimmen Sie .    Der Zähler ist genau die Ableitung des Nenners: mit ist . Also wobei der Betrag entfällt, da für alle (Diskriminante negativ). Allgemein gilt für jede differenzierbare Funktion mit : — man erkennt diese Form daran, dass der Zähler (bis auf einen konstanten Faktor) die Ableitung des Nenners ist.     Rechenbeispiel: Bestimmtes Integral mit transformierten Grenzen   Bestimmen Sie .    Substitution , . Die Grenzen transformieren sich mit: bei ist , bei ist . Damit Da wir die Grenzen mit substituiert haben, müssen wir am Ende nicht mehr zu zurückkehren.      Anwendungsbeispiele   Anwendungsbeispiel: Normierungskonstante einer Dichtefunktion   Eine stetige Zufallsvariable habe die Dichtefunktion wobei eine Konstante ist. Wie in muss für eine Wahrscheinlichkeitsdichte gelten. Bestimmen Sie .    Mit Substitution , : Die Normierungsbedingung liefert Diese Dichte — mit — ist als Rayleigh-Verteilung (Spezialfall) bekannt und beschreibt z. B. die Verteilung von Betragsfehlern bei zweidimensional normalverteilten Messgrößen.     Anwendungsbeispiel: Softplus — die Stammfunktion der Sigmoid-Funktion   Bestimmen Sie eine Stammfunktion der Sigmoid-Funktion aus . Wie verhält sich diese Stammfunktion für große positive und für große negative ?    In der gegebenen Form sieht man keine innere Ableitung. Erweitern mit hilft: . Jetzt ist der Zähler die Ableitung des Nenners, und mit , , wird Die Funktion ist im maschinellen Lernen als Softplus bekannt. Für große ist , also ; für stark negative ist , also . Softplus verhält sich also wie die ReLU-Funktion aus — nur ohne Knick, überall differenzierbar. Damit schließt sich ein Kreis: Die Ableitung dieser geglätteten ReLU ist genau die Sigmoid-Funktion.       Anwendung: Effektivwert einer Wechselspannung  Die Steckdose liefert Volt — sagt man. Tatsächlich schwankt die Netzspannung fünfzigmal pro Sekunde zwischen etwa und Volt, und ihr zeitlicher Mittelwert ist . Was also bedeutet die ?  In hatten wir den Mittelwert einer Funktion kennengelernt. Für eine periodisch schwingende Größe wie eine Wechselspannung ist dieser Mittelwert über eine volle Periode meist — er sagt also nichts über die tatsächlich umgesetzte Leistung aus. Man braucht ein anderes Mittel, das negative und positive Werte nicht gegeneinander aufheben lässt. Die Idee: erst quadrieren (dann ist alles positiv), dann mitteln, dann die Wurzel ziehen, um wieder in Volt zu landen.   Effektivwert   Der Effektivwert einer periodischen Funktion mit Periode ist also die Wurzel aus dem Mittelwert des Quadrats der Funktion ( root mean square , RMS). Physikalisch ist der Effektivwert einer Wechselspannung gerade der Wert einer Gleichspannung , die an einem Ohmschen Widerstand im Periodenzeitraum dieselbe Leistung umsetzt wie .     Anwendungsbeispiel: Effektivwert einer sinusförmigen Wechselspannung   Eine Wechselspannung sei gegeben durch mit Amplitude und Kreisfrequenz ; die Periode ist . Bestimmen Sie den Effektivwert .    Wir brauchen zunächst den Mittelwert von . Mit der Identität (nach dem Additionstheorem ist ): Der konstante Anteil liefert . Für den Schwingungsanteil ist eine Stammfunktion, und da genau zwei volle Perioden von umfasst (Periode ), verschwindet dieser Term beim Einsetzen der Grenzen (wie schon beim Mittelwert der Tagestemperatur in ): Damit und der Effektivwert ist Dies ist die bekannte Faustregel der Elektrotechnik: Die Effektivspannung des europäischen Haushaltsnetzes von  V entspricht einer Amplitude von . Die  V auf dem Typenschild sind also genau der Effektivwert: Ein Heizlüfter wird an der Wechselspannung genauso warm wie an einer Gleichspannung von  V.    Der Faktor gilt nur für sinusförmige Signale. Bei anderen Kurvenformen muss man neu rechnen.   Anwendungsbeispiel: Effektivwert einer Sägezahnspannung (zur Vertiefung)   Eine Sägezahnspannung steigt in jeder Periode linear von auf an und fällt dann schlagartig auf zurück: für . Bestimmen Sie den Effektivwert.     Bei gleicher Spitzenspannung setzt die Sägezahnspannung also weniger Leistung um als die Sinusspannung ( ). Dieselbe Konstruktion Wurzel aus dem Mittelwert der Quadrate kennen Sie vielleicht aus der Statistik: Der RMSE (root mean squared error) misst die typische Abweichung eines Prognosemodells, ohne dass sich positive und negative Fehler gegenseitig aufheben.      Bogenlänge einer ebenen Kurve   Neben Flächen lassen sich auch Längen von gekrümmten Kurven mithilfe von Integralen berechnen. Dazu beschreiben wir eine Kurve zunächst als Parametrisierung .  Wie lang ist ein Kabel, das in einem Bogen durchhängt? Wie weit legt ein Punkt am Rand eines rollenden Rades zurück? Für Strecken genügt der Satz des Pythagoras; für gekrümmte Kurven zerlegt man — wie beim Integral selbst — in viele kleine, fast gerade Stücke.    Kurven und ihre Länge   Ebene Kurve   Eine auf einem Intervall parametrisierte ebene Kurve ist eine Funktion wobei stückweise stetig differenzierbare Funktionen sind.     Bogenlänge   Für eine ebene Kurve , , ist die Bogenlänge gegeben durch Insbesondere ist die Bogenlänge des Graphen einer Funktion (aufgefasst als Kurve ) gegeben durch     Anschaulich approximiert man die Kurve durch einen Streckenzug: Ein kleines Kurvenstück zwischen und hat näherungsweise die Länge einer Strecke mit Höhen- und Seitenlänge bzw. , also Länge nach Pythagoras; Aufsummieren und Grenzübergang liefert obige Integralformel — dieselbe Idee wie bei der Herleitung des Riemann-Integrals selbst.   Rechenbeispiel: Kontrolle an einer Geraden (zur Vertiefung)   Bestimmen Sie die Bogenlänge des Graphen von auf mit der Integralformel, und vergleichen Sie mit dem Ergebnis, das der Satz des Pythagoras direkt liefert.    Es ist , also Kontrolle: Die Strecke verläuft von nach , Pythagoras liefert direkt — dieselbe Länge ✓. Für eine Gerade ist konstant, das Integral wird also zu einer einfachen Multiplikation.     Rechenbeispiel: Bogenlänge eines Funktionsgraphen   Bestimmen Sie die Bogenlänge des Graphen von auf dem Intervall .    Es ist , also und Substitution , , Grenzen , :       Anwendungsbeispiele   Anwendungsbeispiel: Bogenlänge des Zykloidenbogens   Rollt ein Kreis mit Radius ohne zu rutschen auf einer Geraden ab, so beschreibt ein fester Punkt auf dem Kreisrand eine Zykloide — diese Bahn beschreibt z. B. ein Steinchen, das im Profil eines rollenden Reifens steckt. Ein Bogen dieser Kurve ist Bestimmen Sie die Bogenlänge dieses einen Zykloidenbogens.    Es ist und , also Mit der Halbwinkel-Identität (nach dem Additionstheorem ist ) wird daraus , und für ist , also Damit Ein Zykloidenbogen ist also genau -mal so lang wie der Radius des erzeugenden Kreises — ein bemerkenswert einfaches Ergebnis für eine auf den ersten Blick komplizierte Kurve. Entdeckt hat es 1658 der englische Astronom und Mathematiker Christopher Wren — später berühmt als Architekt der St. Paul's Cathedral in London.    Wurzeln unter dem Integral sind der Grund, warum sich Bogenlängen nur selten exakt berechnen lassen. Umso schöner ist es, wenn eine Identität die Wurzel verschwinden lässt — wie bei der Zykloide oder beim folgenden Beispiel, das die Kettenlinie aus wieder aufgreift.   Anwendungsbeispiel: Wie lang ist eine durchhängende Leitung?   Eine Leitung hängt zwischen zwei gleich hohen Masten im Abstand von  m in Form der Kettenlinie , (in Metern). Wie lang ist die Leitung?    Aus den Definitionen und folgt sofort und . Also ist , und mit aus wird die Wurzel ganz einfach: Damit Die Leitung ist also gut länger als der Mastabstand. Allgemein hat die Kettenlinie auf nach derselben Rechnung die Länge . Genau solche Rechnungen braucht man, wenn man Freileitungen plant: Zu wenig Länge bedeutet zu viel Zugspannung, zu viel Länge zu viel Durchhang.       Volumen eines Rotationskörpers   Lässt man den Graphen einer Funktion um die -Achse rotieren, so entsteht ein dreidimensionaler Körper, dessen Volumen und Oberfläche sich ebenfalls durch Integrale ausdrücken lassen. Vasen, Flaschen, Gläser, Kolben und Drehteile aus der Werkstatt sind solche Rotationskörper — und am Ende dieses Unterabschnitts wartet ein Körper, den man mit Farbe füllen, aber nicht anstreichen kann.    Volumen und Mantelfläche   Rotationskörper   Zu einer stetigen Funktion heißt das dreidimensionale Volumen, das von der Fläche eingeschlossen wird, die durch Rotation des Graphen von um die -Achse entsteht, der Rotationskörper zu .    Zerlegt man wie beim Riemann-Integral in schmale Streifen der Breite , so ist der zugehörige Teil des Rotationskörpers näherungsweise ein Kreiszylinder mit Radius und Höhe , also mit Volumen . Aufsummieren und Grenzübergang liefert den ersten Teil des folgenden Satzes; die Mantelfläche ergibt sich analog aus der Bogenlängenformel des vorigen Unterabschnitts, angewendet auf die Kreisumfänge der Streifen.   Volumen und Mantelfläche eines Rotationskörpers   Sei stetig differenzierbar. Dann gilt für das Volumen des Rotationskörpers zu : und für die Mantelfläche des Rotationskörpers zu :      Rechenbeispiel: Kontrolle am Kegel   Ein Kegel mit Grundradius und Höhe entsteht durch Rotation der Geraden auf um die -Achse. Bestimmen Sie Volumen und Mantelfläche mit den obigen Formeln, und vergleichen Sie mit den aus der Schule bekannten Kegelformeln und (mit Mantellinie ).     Für die Mantelfläche ist konstant, also : Beide Integralformeln reproduzieren also genau die aus der Elementargeometrie bekannten Kegelformeln — ein gutes Zeichen, dass die allgemeinen Formeln korrekt sind, bevor man sie auf Körper ohne elementare Vergleichsformel anwendet.      Anwendungsbeispiele   Anwendungsbeispiel: Volumen eines Sektglases   Ein Sektglas wird näherungsweise als Rotationskörper zur Parabel (mit ) in den Grenzen von bis modelliert. Bestimmen Sie das Volumen des Sektglases.     Verdoppelt man die Höhe des Glases bei gleicher Form (also gleichem ), so wächst das Volumen um den Faktor — ein Effekt der starken Krümmung der Parabel, den man dem schmalen unteren Teil eines Sektglases nicht sofort ansieht. Die Mantelfläche des Sektglases ließe sich zwar grundsätzlich mit derselben Formel bestimmen, doch hat keine Stammfunktion unter den in diesem Kurs behandelten Grundintegralen — hier stößt die analytische Integration an ihre Grenzen, und man ist auf numerische Methoden angewiesen ( ).     Torricellis Trompete: endliches Volumen, unendliche Oberfläche   Lässt man den Graphen von für um die -Achse rotieren, entsteht ein unendlich langer, trompetenförmiger Körper, den der italienische Physiker und Mathematiker Evangelista Torricelli 1643 untersuchte. Bestimmen Sie sein Volumen, und zeigen Sie, dass seine Mantelfläche unendlich groß ist.    Das Volumen ist ein uneigentliches Integral, und das kennen wir aus : Für die Mantelfläche schätzen wir den Integranden nach unten ab: Wegen ist (größerer Integrand, größeres Integral) denn das rechte Integral divergiert, ebenfalls nach .  Schon dass ein unendlich langer Körper ein endliches Volumen haben kann, hat Torricellis Zeitgenossen ziemlich beunruhigt. Später hat man das Paradox noch zugespitzt: Man könnte die Trompete mit Volumeneinheiten Farbe füllen, aber keine Farbmenge der Welt würde reichen, um ihre Innenwand anzustreichen. Die Auflösung: Eine mathematische Farbschicht darf beliebig dünn werden, eine echte nicht. Mathematisch steckt dahinter wieder der Unterschied zwischen und , der uns schon bei den Reihen begegnet ist.       Numerische Integration   Partielle Integration und Substitution lösen viele, aber längst nicht alle Integrale. Manche wichtigen Funktionen besitzen nachweislich keine analytisch bestimmbare Stammfunktion aus den bekannten elementaren Funktionen — zum Beispiel (zentral in der Wahrscheinlichkeitstheorie, siehe die Dichtefunktion der Normalverteilung) oder (taucht beim Berechnen von Ellipsenumfängen auf). Wie in am Sektglas gesehen, kann sogar ein an sich harmlos wirkendes Integral diese Form annehmen. In solchen Fällen approximiert man das Integral numerisch.  Das allgemeine Vorgehen: Man teilt in Teilintervalle der Länge , approximiert auf jedem Teilintervall durch eine einfach integrierbare Funktion, integriert diese lokal, und summiert die Teilintegrale auf.    Trapezregel  Die einfachste Wahl approximiert auf jedem Teilintervall durch die Sekante durch und — geometrisch entsteht dabei ein Trapez.   Trapezregel   Sei stetig, mit für . Dann gilt näherungsweise      Trapezregel mit Teilintervallen: Auf jedem Teilintervall wird durch die Sekante ersetzt; die Näherung ist die Summe der vier Trapezflächen. Bei einer konvexen Funktion liegen die Sekanten über dem Graphen, die Trapezregel überschätzt dann das Integral.    Dieselbe nach oben geöffnete Parabel wie bei den Riemannsummen, diesmal über vier gleich breite Trapeze gelegt, deren obere Kanten die Kurvenpunkte an den fünf Stützstellen bis geradlinig verbinden.        Simpsonsche Regel (Keplersche Fassregel)  Der zweite Name dieser Regel erzählt eine hübsche Geschichte. Als Johannes Kepler 1613 für seine Hochzeit Wein kaufte, maß der Händler den Inhalt der Fässer, indem er einen Stab schräg durch das Spundloch bis zur gegenüberliegenden Bodenkante steckte und an einer Skala ablas, wie weit er reichte — ganz egal, wie bauchig das Fass war. Kepler fand das mathematisch fragwürdig und schrieb kurzerhand ein Buch über die Volumenberechnung von Weinfässern (1615). Nach ihm heißt die Näherungsformel, die ein Fassvolumen aus nur drei Querschnittsflächen (unten, Mitte, oben) schätzt, die Keplersche Fassregel — sie ist genau die folgende Regel mit zwei Teilintervallen. Als allgemeines Verfahren für beliebig viele Teilintervalle ist sie nach dem Engländer Thomas Simpson benannt, der sie 1743 veröffentlichte.  Approximiert man auf je zwei benachbarten Teilintervallen statt durch eine Gerade durch ein Parabelstück durch die drei Punkte , und , erhält man eine deutlich genauere Approximation.   Simpsonsche Regel   Sei stetig, gerade, mit . Dann gilt näherungsweise      Rechenbeispiel: Trapez- und Simpsonregel im Vergleich   Approximieren Sie mit Teilintervallen sowohl mit der Trapezregel als auch mit der Simpsonregel, und vergleichen Sie mit dem exakten Wert.    Mit sind die Stützstellen mit Funktionswerten .   Trapezregel:     Simpsonregel ( mit Gewicht , mit Gewicht ):   Der exakte Wert ist . Die Trapezregel überschätzt hier leicht (die Sekante liegt bei einer konvexen Funktion wie stets über dem Graphen), die Simpsonregel trifft den exakten Wert sogar genau — kein Zufall: Simpsons Parabelstücke integrieren jedes Polynom bis Grad exakt, und hat Grad .      Anwendungsbeispiele   Anwendungsbeispiel: Näherung eines Wahrscheinlichkeitsintegrals (zur Vertiefung)   Die Dichtefunktion der Standardnormalverteilung ist (bis auf einen konstanten Vorfaktor) . Wie in der Einleitung erwähnt, besitzt diese Funktion keine elementare Stammfunktion. Approximieren Sie mit der Trapezregel und Teilintervallen, und vergleichen Sie mit der Simpsonregel; die benötigten Funktionswerte sind gerundet in der Tabelle angegeben.                      Mit : Multipliziert man dieses Ergebnis noch mit dem üblichen Vorfaktor der Dichtefunktion, erhält man für eine standardnormalverteilte Zufallsvariable . Der Tabellenwert ist ; schon vier Trapeze liefern also zwei korrekte Nachkommastellen. Genau so werden die Werte in Standardnormalverteilungs-Tabellen in der Statistik tatsächlich erzeugt: durch numerische Integration, nicht durch eine geschlossene Stammfunktion.  Mit denselben fünf Funktionswerten liefert die Simpsonregel und damit — auf vier Stellen der Tabellenwert. Bei gleichem Rechenaufwand (fünf Funktionswerte) ist Simpson hier also viel genauer als die Trapezregel: Verglichen mit dem exakten Wert beträgt der Fehler der Trapezregel rund , der der Simpsonregel (mit exakten Funktionswerten) rund — gut hundertmal weniger.       Zusammenfassung     Grundregeln: Linearität , ; Intervalladditivität .   Partielle Integration (Produktregel rückwärts): . Faustregel: Potenz ableiten, , , aufleiten. Merkregel LIATE für die Wahl von . Logarithmus-Trick: . Rückschluss: taucht das Ausgangsintegral wieder auf, nach ihm auflösen.   Substitution (Kettenregel rückwärts): mit , wird . Bei bestimmten Integralen Grenzen mittransformieren oder am Ende zurücksubstituieren. Spezialfall .   Effektivwert einer -periodischen Größe: ; für ist (  V Effektivwert   V Amplitude).   Geometrie: Bogenlänge , für Graphen ; Rotationskörper um die -Achse: , Mantelfläche . Torricellis Trompete ( , ): Volumen , Mantelfläche unendlich.   Numerische Integration: Trapezregel (Sekanten, Randwerte halb gewichtet), Simpsonregel (Parabeln, gerade, Gewichte mit Faktor , exakt bis Grad ). Nötig, wenn keine elementare Stammfunktion existiert — etwa für .   Anwendungen:  als Erwartungswert der Exponentialverteilung (partiell); Barwert von bei unbegrenzter Laufzeit ; Normierung einer Dichte (Substitution); Softplus als Stammfunktion der Sigmoid-Funktion; Kettenlinie der Länge auf ; Zykloidenbogen der Länge ; Sektglas .      Übungsaufgaben    Bestimmen Sie .    Mit , , also , :       Bestimmen Sie .    Substitution , :       Bestimmen Sie die Bogenlänge des Graphen von auf dem Intervall .    Es ist , also       Bestimmen Sie das Volumen des Rotationskörpers, der durch Rotation des Graphen von auf um die -Achse entsteht.    Wegen ist       Approximieren Sie mit der Trapezregel und Teilintervallen. Vergleichen Sie mit dem exakten Wert und erklären Sie den Unterschied.    Mit : Stützstellen , Funktionswerte : Der exakte Wert ist — Trapezregel und exakter Wert stimmen genau überein, denn für eine lineare Funktion approximiert die Sekante der Trapezregel den Graphen exakt, es entsteht kein Approximationsfehler.     "
},
{
  "id": "sec-integrationstechniken-anwendungen-2",
  "level": "2",
  "url": "sec-integrationstechniken-anwendungen.html#sec-integrationstechniken-anwendungen-2",
  "type": "Lernziele",
  "number": "4.2",
  "title": "",
  "body": "  Nach diesem Abschnitt können Sie    Linearität und Intervalladditivität des Integrals anwenden;  Produkte mit partieller Integration integrieren, einschließlich des Logarithmus-Tricks und der Rückschluss-Technik;  Integrale durch Substitution lösen, bei bestimmten Integralen die Grenzen mittransformieren und logarithmische Integration erkennen;  Effektivwert, Bogenlänge, Rotationsvolumen und Mantelfläche als Integrale aufstellen und berechnen;  Integrale numerisch mit Trapez- und Simpsonregel approximieren und einschätzen, wann das nötig ist;  Erwartungswerte und Normierungskonstanten von Dichtefunktionen sowie Barwerte wachsender Zahlungsströme berechnen.   "
},
{
  "id": "thm-linearitaet-integral",
  "level": "2",
  "url": "sec-integrationstechniken-anwendungen.html#thm-linearitaet-integral",
  "type": "Satz",
  "number": "4.2.1",
  "title": "Linearität des Integrals.",
  "body": " Linearität des Integrals   Seien stetige Funktionen und . Dann gilt Dieselben Regeln gelten auch für unbestimmte Integrale.   "
},
{
  "id": "thm-intervalladditivitaet",
  "level": "2",
  "url": "sec-integrationstechniken-anwendungen.html#thm-intervalladditivitaet",
  "type": "Satz",
  "number": "4.2.2",
  "title": "Intervalladditivität.",
  "body": " Intervalladditivität   Sei stetig und . Dann gilt Man kann das Integrationsintervall also an jeder Stelle aufteilen — anschaulich zerlegt man einfach die Fläche unter in zwei Teilflächen.   "
},
{
  "id": "ex-linearitaet-intervalladditivitaet-kombiniert",
  "level": "2",
  "url": "sec-integrationstechniken-anwendungen.html#ex-linearitaet-intervalladditivitaet-kombiniert",
  "type": "Beispiel",
  "number": "4.2.3",
  "title": "Rechenbeispiel: Linearität und Intervalladditivität kombiniert.",
  "body": " Rechenbeispiel: Linearität und Intervalladditivität kombiniert   Für eine stetige Funktion gelte und . Bestimmen Sie .    Mit Intervalladditivität (Aufteilen bei ) und anschließender Linearität:    "
},
{
  "id": "ex-flaecheninhalt-aufteilen",
  "level": "2",
  "url": "sec-integrationstechniken-anwendungen.html#ex-flaecheninhalt-aufteilen",
  "type": "Beispiel",
  "number": "4.2.4",
  "title": "Rechenbeispiel: Flächeninhalt statt signierter Fläche.",
  "body": " Rechenbeispiel: Flächeninhalt statt signierter Fläche   In hatten wir gesehen, dass sich beim Integral positive und negative Anteile aufheben können. Berechnen Sie für das Integral und den Flächeninhalt zwischen dem Graphen von und der -Achse auf .    Eine Stammfunktion ist . Über das ganze Intervall: Eine Fläche von kann aber nicht stimmen — der Graph weicht ja deutlich von der Achse ab. Die Nullstellen von sind und ; auf ist negativ, auf positiv. Wir teilen bei auf: Der Flächeninhalt ist die Summe der Beträge, . Die beiden Teilflächen sind zufällig gleich groß und heben sich im Integral genau auf. Wer einfach über integriert, erhält deshalb — ein klassischer Fehler, wenn nach einer Fläche gefragt ist.   "
},
{
  "id": "sub-partielle-integration-2-1",
  "level": "2",
  "url": "sec-integrationstechniken-anwendungen.html#sub-partielle-integration-2-1",
  "type": "Absatz (with a defined term)",
  "number": "",
  "title": "",
  "body": "partielle Integration "
},
{
  "id": "thm-partielle-integration",
  "level": "2",
  "url": "sec-integrationstechniken-anwendungen.html#thm-partielle-integration",
  "type": "Satz",
  "number": "4.2.5",
  "title": "Partielle Integration.",
  "body": " Partielle Integration   Seien stetig differenzierbare Funktionen. Dann gilt Dieselbe Regel gilt auch für unbestimmte Integrale: .    Nach der Produktregel ist , also ist eine Stammfunktion von . Mit dem Hauptsatz folgt , und Umstellen liefert die Formel.   "
},
{
  "id": "ssub-partielle-integration-regel-3",
  "level": "2",
  "url": "sec-integrationstechniken-anwendungen.html#ssub-partielle-integration-regel-3",
  "type": "Absatz (with a defined term)",
  "number": "",
  "title": "",
  "body": "LIATE "
},
{
  "id": "ex-partielle-integration-potenz-exponential",
  "level": "2",
  "url": "sec-integrationstechniken-anwendungen.html#ex-partielle-integration-potenz-exponential",
  "type": "Beispiel",
  "number": "4.2.6",
  "title": "Rechenbeispiel: Potenzfunktion mal Exponentialfunktion (zur Vertiefung).",
  "body": " Rechenbeispiel: Potenzfunktion mal Exponentialfunktion (zur Vertiefung)   Bestimmen Sie .    Wir wählen (wird abgeleitet) und (wird aufgeleitet), also und . Mit der Formel: Probe durch Ableiten: ✓.  Und wenn man die Rollen vertauscht? Mit und , also , entstünde das neue Integral — schwieriger als das ursprüngliche. Führt eine Wahl in die falsche Richtung, probiert man die andere.   "
},
{
  "id": "ex-partielle-integration-potenz-trig",
  "level": "2",
  "url": "sec-integrationstechniken-anwendungen.html#ex-partielle-integration-potenz-trig",
  "type": "Beispiel",
  "number": "4.2.7",
  "title": "Rechenbeispiel: Bestimmtes Integral mit Kosinus (zur Vertiefung).",
  "body": " Rechenbeispiel: Bestimmtes Integral mit Kosinus (zur Vertiefung)   Bestimmen Sie .    Mit , , also , :    "
},
{
  "id": "ex-partielle-integration-logarithmus-trick",
  "level": "2",
  "url": "sec-integrationstechniken-anwendungen.html#ex-partielle-integration-logarithmus-trick",
  "type": "Beispiel",
  "number": "4.2.8",
  "title": "Rechenbeispiel: Der Logarithmus-Trick.",
  "body": " Rechenbeispiel: Der Logarithmus-Trick   Bestimmen Sie .    Hier steht scheinbar kein Produkt — der Trick ist, als zu lesen und den konstanten Faktor aufzuleiten: , , also , . Damit Dies bestätigt den Eintrag für in der Grundintegrale-Tabelle aus . Derselbe Trick — einen Faktor einführen und aufleiten — funktioniert für und ganz analog.   "
},
{
  "id": "ex-partielle-integration-doppelt-selbstbezueglich",
  "level": "2",
  "url": "sec-integrationstechniken-anwendungen.html#ex-partielle-integration-doppelt-selbstbezueglich",
  "type": "Beispiel",
  "number": "4.2.9",
  "title": "Rechenbeispiel: Zweifache partielle Integration mit Rückschluss.",
  "body": " Rechenbeispiel: Zweifache partielle Integration mit Rückschluss   Bestimmen Sie .    Mit , : Das neue Integral integrieren wir nochmals partiell, diesmal mit , : Setzen wir das ein, taucht rechts wieder das ursprüngliche Integral auf: Addieren wir auf beiden Seiten und teilen durch : Diese Rückschluss -Technik — das gesuchte Integral taucht nach zweimaliger partieller Integration wieder auf und wird wie eine Unbekannte in einer Gleichung behandelt — funktioniert immer dann, wenn sich die Faktoren beim Ableiten reproduzieren, wie mit und .   "
},
{
  "id": "ex-anwendung-erwartungswert-exponentialverteilung",
  "level": "2",
  "url": "sec-integrationstechniken-anwendungen.html#ex-anwendung-erwartungswert-exponentialverteilung",
  "type": "Beispiel",
  "number": "4.2.10",
  "title": "Anwendungsbeispiel: Erwartungswert der Exponentialverteilung.",
  "body": " Anwendungsbeispiel: Erwartungswert der Exponentialverteilung   In hatten wir gezeigt, dass die Dichtefunktion der Exponentialverteilung (Parameter ) die Gesamtwahrscheinlichkeit liefert. Der Erwartungswert dieser Verteilung ist definiert als Bestimmen Sie .    Zunächst die unbestimmte Stammfunktion mit partieller Integration, , , also , : Da die obere Grenze unendlich ist, betrachten wir den Grenzwert für : Für geht (die Exponentialfunktion gewinnt gegen das Polynom ) und ebenso . Damit Je größer die Rate (je schneller die Verteilung abklingt ), desto kleiner der erwartete Wert — ein Ergebnis, das in der Warteschlangentheorie und bei Ausfallzeitmodellen ständig verwendet wird. Für das Bauteil aus mit pro Stunde heißt das: Im Mittel hält es Stunden.   "
},
{
  "id": "ex-anwendung-barwert-wachsender-zahlungsstrom",
  "level": "2",
  "url": "sec-integrationstechniken-anwendungen.html#ex-anwendung-barwert-wachsender-zahlungsstrom",
  "type": "Beispiel",
  "number": "4.2.11",
  "title": "Anwendungsbeispiel: Barwert eines wachsenden Zahlungsstroms.",
  "body": " Anwendungsbeispiel: Barwert eines wachsenden Zahlungsstroms   Ein Softwareunternehmen erwartet aus einem Abonnementprodukt kontinuierliche Einnahmen mit der Rate (in Tausend EUR pro Jahr, in Jahren) — die Einnahmen wachsen also linear. Wie in wird stetig diskontiert, hier mit . Bestimmen Sie den Barwert der Einnahmen der ersten fünf Jahre, , sowie den Barwert bei unbegrenzter Laufzeit.    Der konstante Anteil ist ein Grundintegral: . Für den wachsenden Anteil integrieren wir partiell mit , , also : Zusammen: Die Einnahmen der ersten fünf Jahre (nominal Tausend EUR) sind heute also knapp Tausend EUR wert. Bei unbegrenzter Laufzeit gehen alle Terme mit für gegen — auch , denn die Exponentialfunktion gewinnt gegen jede Potenz —, und es bleibt der Barwert Tausend EUR. Allgemein ergibt dieselbe Rechnung für den Barwert Das Wachstum wird durch geteilt und fällt bei niedrigen Zinsen besonders ins Gewicht.   "
},
{
  "id": "thm-substitutionsregel",
  "level": "2",
  "url": "sec-integrationstechniken-anwendungen.html#thm-substitutionsregel",
  "type": "Satz",
  "number": "4.2.12",
  "title": "Substitutionsregel.",
  "body": " Substitutionsregel   Sei stetig und stetig differenzierbar. Dann gilt Dieselbe Regel gilt für unbestimmte Integrale — dort wird am Ende wieder in zurücksubstituiert.    Ist eine Stammfunktion von , so ist nach der Kettenregel . Mit dem Hauptsatz sind daher beide Seiten gleich .   "
},
{
  "id": "ex-substitution-kettenregel-exponential",
  "level": "2",
  "url": "sec-integrationstechniken-anwendungen.html#ex-substitution-kettenregel-exponential",
  "type": "Beispiel",
  "number": "4.2.13",
  "title": "Rechenbeispiel: Die innere Ableitung steht schon da.",
  "body": " Rechenbeispiel: Die innere Ableitung steht schon da   Bestimmen Sie .    Wir substituieren , also bzw. : Probe: ✓.   "
},
{
  "id": "ex-substitution-logarithmisch",
  "level": "2",
  "url": "sec-integrationstechniken-anwendungen.html#ex-substitution-logarithmisch",
  "type": "Beispiel",
  "number": "4.2.14",
  "title": "Rechenbeispiel: Logarithmische Integration.",
  "body": " Rechenbeispiel: Logarithmische Integration   Bestimmen Sie .    Der Zähler ist genau die Ableitung des Nenners: mit ist . Also wobei der Betrag entfällt, da für alle (Diskriminante negativ). Allgemein gilt für jede differenzierbare Funktion mit : — man erkennt diese Form daran, dass der Zähler (bis auf einen konstanten Faktor) die Ableitung des Nenners ist.   "
},
{
  "id": "ex-substitution-grenzen-transformiert",
  "level": "2",
  "url": "sec-integrationstechniken-anwendungen.html#ex-substitution-grenzen-transformiert",
  "type": "Beispiel",
  "number": "4.2.15",
  "title": "Rechenbeispiel: Bestimmtes Integral mit transformierten Grenzen.",
  "body": " Rechenbeispiel: Bestimmtes Integral mit transformierten Grenzen   Bestimmen Sie .    Substitution , . Die Grenzen transformieren sich mit: bei ist , bei ist . Damit Da wir die Grenzen mit substituiert haben, müssen wir am Ende nicht mehr zu zurückkehren.   "
},
{
  "id": "ex-anwendung-normierung-dichte-substitution",
  "level": "2",
  "url": "sec-integrationstechniken-anwendungen.html#ex-anwendung-normierung-dichte-substitution",
  "type": "Beispiel",
  "number": "4.2.16",
  "title": "Anwendungsbeispiel: Normierungskonstante einer Dichtefunktion.",
  "body": " Anwendungsbeispiel: Normierungskonstante einer Dichtefunktion   Eine stetige Zufallsvariable habe die Dichtefunktion wobei eine Konstante ist. Wie in muss für eine Wahrscheinlichkeitsdichte gelten. Bestimmen Sie .    Mit Substitution , : Die Normierungsbedingung liefert Diese Dichte — mit — ist als Rayleigh-Verteilung (Spezialfall) bekannt und beschreibt z. B. die Verteilung von Betragsfehlern bei zweidimensional normalverteilten Messgrößen.   "
},
{
  "id": "ex-anwendung-softplus",
  "level": "2",
  "url": "sec-integrationstechniken-anwendungen.html#ex-anwendung-softplus",
  "type": "Beispiel",
  "number": "4.2.17",
  "title": "Anwendungsbeispiel: Softplus — die Stammfunktion der Sigmoid-Funktion.",
  "body": " Anwendungsbeispiel: Softplus — die Stammfunktion der Sigmoid-Funktion   Bestimmen Sie eine Stammfunktion der Sigmoid-Funktion aus . Wie verhält sich diese Stammfunktion für große positive und für große negative ?    In der gegebenen Form sieht man keine innere Ableitung. Erweitern mit hilft: . Jetzt ist der Zähler die Ableitung des Nenners, und mit , , wird Die Funktion ist im maschinellen Lernen als Softplus bekannt. Für große ist , also ; für stark negative ist , also . Softplus verhält sich also wie die ReLU-Funktion aus — nur ohne Knick, überall differenzierbar. Damit schließt sich ein Kreis: Die Ableitung dieser geglätteten ReLU ist genau die Sigmoid-Funktion.   "
},
{
  "id": "def-effektivwert",
  "level": "2",
  "url": "sec-integrationstechniken-anwendungen.html#def-effektivwert",
  "type": "Definition",
  "number": "4.2.18",
  "title": "Effektivwert.",
  "body": " Effektivwert   Der Effektivwert einer periodischen Funktion mit Periode ist also die Wurzel aus dem Mittelwert des Quadrats der Funktion ( root mean square , RMS). Physikalisch ist der Effektivwert einer Wechselspannung gerade der Wert einer Gleichspannung , die an einem Ohmschen Widerstand im Periodenzeitraum dieselbe Leistung umsetzt wie .   "
},
{
  "id": "ex-anwendung-effektivwert-sinusspannung",
  "level": "2",
  "url": "sec-integrationstechniken-anwendungen.html#ex-anwendung-effektivwert-sinusspannung",
  "type": "Beispiel",
  "number": "4.2.19",
  "title": "Anwendungsbeispiel: Effektivwert einer sinusförmigen Wechselspannung.",
  "body": " Anwendungsbeispiel: Effektivwert einer sinusförmigen Wechselspannung   Eine Wechselspannung sei gegeben durch mit Amplitude und Kreisfrequenz ; die Periode ist . Bestimmen Sie den Effektivwert .    Wir brauchen zunächst den Mittelwert von . Mit der Identität (nach dem Additionstheorem ist ): Der konstante Anteil liefert . Für den Schwingungsanteil ist eine Stammfunktion, und da genau zwei volle Perioden von umfasst (Periode ), verschwindet dieser Term beim Einsetzen der Grenzen (wie schon beim Mittelwert der Tagestemperatur in ): Damit und der Effektivwert ist Dies ist die bekannte Faustregel der Elektrotechnik: Die Effektivspannung des europäischen Haushaltsnetzes von  V entspricht einer Amplitude von . Die  V auf dem Typenschild sind also genau der Effektivwert: Ein Heizlüfter wird an der Wechselspannung genauso warm wie an einer Gleichspannung von  V.   "
},
{
  "id": "ex-anwendung-effektivwert-saegezahn",
  "level": "2",
  "url": "sec-integrationstechniken-anwendungen.html#ex-anwendung-effektivwert-saegezahn",
  "type": "Beispiel",
  "number": "4.2.20",
  "title": "Anwendungsbeispiel: Effektivwert einer Sägezahnspannung (zur Vertiefung).",
  "body": " Anwendungsbeispiel: Effektivwert einer Sägezahnspannung (zur Vertiefung)   Eine Sägezahnspannung steigt in jeder Periode linear von auf an und fällt dann schlagartig auf zurück: für . Bestimmen Sie den Effektivwert.     Bei gleicher Spitzenspannung setzt die Sägezahnspannung also weniger Leistung um als die Sinusspannung ( ). Dieselbe Konstruktion Wurzel aus dem Mittelwert der Quadrate kennen Sie vielleicht aus der Statistik: Der RMSE (root mean squared error) misst die typische Abweichung eines Prognosemodells, ohne dass sich positive und negative Fehler gegenseitig aufheben.   "
},
{
  "id": "sub-bogenlaenge-2-1",
  "level": "2",
  "url": "sec-integrationstechniken-anwendungen.html#sub-bogenlaenge-2-1",
  "type": "Absatz (with a defined term)",
  "number": "",
  "title": "",
  "body": "Parametrisierung "
},
{
  "id": "def-ebene-kurve",
  "level": "2",
  "url": "sec-integrationstechniken-anwendungen.html#def-ebene-kurve",
  "type": "Definition",
  "number": "4.2.21",
  "title": "Ebene Kurve.",
  "body": " Ebene Kurve   Eine auf einem Intervall parametrisierte ebene Kurve ist eine Funktion wobei stückweise stetig differenzierbare Funktionen sind.   "
},
{
  "id": "thm-bogenlaenge",
  "level": "2",
  "url": "sec-integrationstechniken-anwendungen.html#thm-bogenlaenge",
  "type": "Satz",
  "number": "4.2.22",
  "title": "Bogenlänge.",
  "body": " Bogenlänge   Für eine ebene Kurve , , ist die Bogenlänge gegeben durch Insbesondere ist die Bogenlänge des Graphen einer Funktion (aufgefasst als Kurve ) gegeben durch    "
},
{
  "id": "ex-bogenlaenge-gerade-kontrolle",
  "level": "2",
  "url": "sec-integrationstechniken-anwendungen.html#ex-bogenlaenge-gerade-kontrolle",
  "type": "Beispiel",
  "number": "4.2.23",
  "title": "Rechenbeispiel: Kontrolle an einer Geraden (zur Vertiefung).",
  "body": " Rechenbeispiel: Kontrolle an einer Geraden (zur Vertiefung)   Bestimmen Sie die Bogenlänge des Graphen von auf mit der Integralformel, und vergleichen Sie mit dem Ergebnis, das der Satz des Pythagoras direkt liefert.    Es ist , also Kontrolle: Die Strecke verläuft von nach , Pythagoras liefert direkt — dieselbe Länge ✓. Für eine Gerade ist konstant, das Integral wird also zu einer einfachen Multiplikation.   "
},
{
  "id": "ex-bogenlaenge-funktionsgraph-potenz",
  "level": "2",
  "url": "sec-integrationstechniken-anwendungen.html#ex-bogenlaenge-funktionsgraph-potenz",
  "type": "Beispiel",
  "number": "4.2.24",
  "title": "Rechenbeispiel: Bogenlänge eines Funktionsgraphen.",
  "body": " Rechenbeispiel: Bogenlänge eines Funktionsgraphen   Bestimmen Sie die Bogenlänge des Graphen von auf dem Intervall .    Es ist , also und Substitution , , Grenzen , :    "
},
{
  "id": "ex-anwendung-zykloide-bogenlaenge",
  "level": "2",
  "url": "sec-integrationstechniken-anwendungen.html#ex-anwendung-zykloide-bogenlaenge",
  "type": "Beispiel",
  "number": "4.2.25",
  "title": "Anwendungsbeispiel: Bogenlänge des Zykloidenbogens.",
  "body": " Anwendungsbeispiel: Bogenlänge des Zykloidenbogens   Rollt ein Kreis mit Radius ohne zu rutschen auf einer Geraden ab, so beschreibt ein fester Punkt auf dem Kreisrand eine Zykloide — diese Bahn beschreibt z. B. ein Steinchen, das im Profil eines rollenden Reifens steckt. Ein Bogen dieser Kurve ist Bestimmen Sie die Bogenlänge dieses einen Zykloidenbogens.    Es ist und , also Mit der Halbwinkel-Identität (nach dem Additionstheorem ist ) wird daraus , und für ist , also Damit Ein Zykloidenbogen ist also genau -mal so lang wie der Radius des erzeugenden Kreises — ein bemerkenswert einfaches Ergebnis für eine auf den ersten Blick komplizierte Kurve. Entdeckt hat es 1658 der englische Astronom und Mathematiker Christopher Wren — später berühmt als Architekt der St. Paul's Cathedral in London.   "
},
{
  "id": "ex-anwendung-laenge-kettenlinie",
  "level": "2",
  "url": "sec-integrationstechniken-anwendungen.html#ex-anwendung-laenge-kettenlinie",
  "type": "Beispiel",
  "number": "4.2.26",
  "title": "Anwendungsbeispiel: Wie lang ist eine durchhängende Leitung?",
  "body": " Anwendungsbeispiel: Wie lang ist eine durchhängende Leitung?   Eine Leitung hängt zwischen zwei gleich hohen Masten im Abstand von  m in Form der Kettenlinie , (in Metern). Wie lang ist die Leitung?    Aus den Definitionen und folgt sofort und . Also ist , und mit aus wird die Wurzel ganz einfach: Damit Die Leitung ist also gut länger als der Mastabstand. Allgemein hat die Kettenlinie auf nach derselben Rechnung die Länge . Genau solche Rechnungen braucht man, wenn man Freileitungen plant: Zu wenig Länge bedeutet zu viel Zugspannung, zu viel Länge zu viel Durchhang.   "
},
{
  "id": "def-rotationskoerper",
  "level": "2",
  "url": "sec-integrationstechniken-anwendungen.html#def-rotationskoerper",
  "type": "Definition",
  "number": "4.2.27",
  "title": "Rotationskörper.",
  "body": " Rotationskörper   Zu einer stetigen Funktion heißt das dreidimensionale Volumen, das von der Fläche eingeschlossen wird, die durch Rotation des Graphen von um die -Achse entsteht, der Rotationskörper zu .   "
},
{
  "id": "thm-volumen-mantelflaeche-rotationskoerper",
  "level": "2",
  "url": "sec-integrationstechniken-anwendungen.html#thm-volumen-mantelflaeche-rotationskoerper",
  "type": "Satz",
  "number": "4.2.28",
  "title": "Volumen und Mantelfläche eines Rotationskörpers.",
  "body": " Volumen und Mantelfläche eines Rotationskörpers   Sei stetig differenzierbar. Dann gilt für das Volumen des Rotationskörpers zu : und für die Mantelfläche des Rotationskörpers zu :    "
},
{
  "id": "ex-rotationskoerper-kegel-kontrolle",
  "level": "2",
  "url": "sec-integrationstechniken-anwendungen.html#ex-rotationskoerper-kegel-kontrolle",
  "type": "Beispiel",
  "number": "4.2.29",
  "title": "Rechenbeispiel: Kontrolle am Kegel.",
  "body": " Rechenbeispiel: Kontrolle am Kegel   Ein Kegel mit Grundradius und Höhe entsteht durch Rotation der Geraden auf um die -Achse. Bestimmen Sie Volumen und Mantelfläche mit den obigen Formeln, und vergleichen Sie mit den aus der Schule bekannten Kegelformeln und (mit Mantellinie ).     Für die Mantelfläche ist konstant, also : Beide Integralformeln reproduzieren also genau die aus der Elementargeometrie bekannten Kegelformeln — ein gutes Zeichen, dass die allgemeinen Formeln korrekt sind, bevor man sie auf Körper ohne elementare Vergleichsformel anwendet.   "
},
{
  "id": "ex-anwendung-sektglas-volumen",
  "level": "2",
  "url": "sec-integrationstechniken-anwendungen.html#ex-anwendung-sektglas-volumen",
  "type": "Beispiel",
  "number": "4.2.30",
  "title": "Anwendungsbeispiel: Volumen eines Sektglases.",
  "body": " Anwendungsbeispiel: Volumen eines Sektglases   Ein Sektglas wird näherungsweise als Rotationskörper zur Parabel (mit ) in den Grenzen von bis modelliert. Bestimmen Sie das Volumen des Sektglases.     Verdoppelt man die Höhe des Glases bei gleicher Form (also gleichem ), so wächst das Volumen um den Faktor — ein Effekt der starken Krümmung der Parabel, den man dem schmalen unteren Teil eines Sektglases nicht sofort ansieht. Die Mantelfläche des Sektglases ließe sich zwar grundsätzlich mit derselben Formel bestimmen, doch hat keine Stammfunktion unter den in diesem Kurs behandelten Grundintegralen — hier stößt die analytische Integration an ihre Grenzen, und man ist auf numerische Methoden angewiesen ( ).   "
},
{
  "id": "ex-torricellis-trompete",
  "level": "2",
  "url": "sec-integrationstechniken-anwendungen.html#ex-torricellis-trompete",
  "type": "Beispiel",
  "number": "4.2.31",
  "title": "Torricellis Trompete: endliches Volumen, unendliche Oberfläche.",
  "body": " Torricellis Trompete: endliches Volumen, unendliche Oberfläche   Lässt man den Graphen von für um die -Achse rotieren, entsteht ein unendlich langer, trompetenförmiger Körper, den der italienische Physiker und Mathematiker Evangelista Torricelli 1643 untersuchte. Bestimmen Sie sein Volumen, und zeigen Sie, dass seine Mantelfläche unendlich groß ist.    Das Volumen ist ein uneigentliches Integral, und das kennen wir aus : Für die Mantelfläche schätzen wir den Integranden nach unten ab: Wegen ist (größerer Integrand, größeres Integral) denn das rechte Integral divergiert, ebenfalls nach .  Schon dass ein unendlich langer Körper ein endliches Volumen haben kann, hat Torricellis Zeitgenossen ziemlich beunruhigt. Später hat man das Paradox noch zugespitzt: Man könnte die Trompete mit Volumeneinheiten Farbe füllen, aber keine Farbmenge der Welt würde reichen, um ihre Innenwand anzustreichen. Die Auflösung: Eine mathematische Farbschicht darf beliebig dünn werden, eine echte nicht. Mathematisch steckt dahinter wieder der Unterschied zwischen und , der uns schon bei den Reihen begegnet ist.   "
},
{
  "id": "thm-trapezregel",
  "level": "2",
  "url": "sec-integrationstechniken-anwendungen.html#thm-trapezregel",
  "type": "Satz",
  "number": "4.2.32",
  "title": "Trapezregel.",
  "body": " Trapezregel   Sei stetig, mit für . Dann gilt näherungsweise    "
},
{
  "id": "fig-trapezregel",
  "level": "2",
  "url": "sec-integrationstechniken-anwendungen.html#fig-trapezregel",
  "type": "Abbildung",
  "number": "4.2.33",
  "title": "",
  "body": " Trapezregel mit Teilintervallen: Auf jedem Teilintervall wird durch die Sekante ersetzt; die Näherung ist die Summe der vier Trapezflächen. Bei einer konvexen Funktion liegen die Sekanten über dem Graphen, die Trapezregel überschätzt dann das Integral.    Dieselbe nach oben geöffnete Parabel wie bei den Riemannsummen, diesmal über vier gleich breite Trapeze gelegt, deren obere Kanten die Kurvenpunkte an den fünf Stützstellen bis geradlinig verbinden.     "
},
{
  "id": "sub-simpsonregel-2",
  "level": "2",
  "url": "sec-integrationstechniken-anwendungen.html#sub-simpsonregel-2",
  "type": "Absatz (with a defined term)",
  "number": "",
  "title": "",
  "body": "Keplersche Fassregel "
},
{
  "id": "thm-simpsonregel",
  "level": "2",
  "url": "sec-integrationstechniken-anwendungen.html#thm-simpsonregel",
  "type": "Satz",
  "number": "4.2.34",
  "title": "Simpsonsche Regel.",
  "body": " Simpsonsche Regel   Sei stetig, gerade, mit . Dann gilt näherungsweise    "
},
{
  "id": "ex-trapez-simpson-vergleich",
  "level": "2",
  "url": "sec-integrationstechniken-anwendungen.html#ex-trapez-simpson-vergleich",
  "type": "Beispiel",
  "number": "4.2.35",
  "title": "Rechenbeispiel: Trapez- und Simpsonregel im Vergleich.",
  "body": " Rechenbeispiel: Trapez- und Simpsonregel im Vergleich   Approximieren Sie mit Teilintervallen sowohl mit der Trapezregel als auch mit der Simpsonregel, und vergleichen Sie mit dem exakten Wert.    Mit sind die Stützstellen mit Funktionswerten .   Trapezregel:     Simpsonregel ( mit Gewicht , mit Gewicht ):   Der exakte Wert ist . Die Trapezregel überschätzt hier leicht (die Sekante liegt bei einer konvexen Funktion wie stets über dem Graphen), die Simpsonregel trifft den exakten Wert sogar genau — kein Zufall: Simpsons Parabelstücke integrieren jedes Polynom bis Grad exakt, und hat Grad .   "
},
{
  "id": "ex-anwendung-numerik-normalverteilung",
  "level": "2",
  "url": "sec-integrationstechniken-anwendungen.html#ex-anwendung-numerik-normalverteilung",
  "type": "Beispiel",
  "number": "4.2.36",
  "title": "Anwendungsbeispiel: Näherung eines Wahrscheinlichkeitsintegrals (zur Vertiefung).",
  "body": " Anwendungsbeispiel: Näherung eines Wahrscheinlichkeitsintegrals (zur Vertiefung)   Die Dichtefunktion der Standardnormalverteilung ist (bis auf einen konstanten Vorfaktor) . Wie in der Einleitung erwähnt, besitzt diese Funktion keine elementare Stammfunktion. Approximieren Sie mit der Trapezregel und Teilintervallen, und vergleichen Sie mit der Simpsonregel; die benötigten Funktionswerte sind gerundet in der Tabelle angegeben.                      Mit : Multipliziert man dieses Ergebnis noch mit dem üblichen Vorfaktor der Dichtefunktion, erhält man für eine standardnormalverteilte Zufallsvariable . Der Tabellenwert ist ; schon vier Trapeze liefern also zwei korrekte Nachkommastellen. Genau so werden die Werte in Standardnormalverteilungs-Tabellen in der Statistik tatsächlich erzeugt: durch numerische Integration, nicht durch eine geschlossene Stammfunktion.  Mit denselben fünf Funktionswerten liefert die Simpsonregel und damit — auf vier Stellen der Tabellenwert. Bei gleichem Rechenaufwand (fünf Funktionswerte) ist Simpson hier also viel genauer als die Trapezregel: Verglichen mit dem exakten Wert beträgt der Fehler der Trapezregel rund , der der Simpsonregel (mit exakten Funktionswerten) rund — gut hundertmal weniger.   "
},
{
  "id": "sub-zusammenfassung-4-2-2",
  "level": "2",
  "url": "sec-integrationstechniken-anwendungen.html#sub-zusammenfassung-4-2-2",
  "type": "Absatz (with a defined term)",
  "number": "",
  "title": "",
  "body": "Grundregeln: Partielle Integration Substitution Effektivwert Geometrie: Numerische Integration: Anwendungen: "
},
{
  "id": "exercise-buch-partielle-integration-linear-exponential",
  "level": "2",
  "url": "sec-integrationstechniken-anwendungen.html#exercise-buch-partielle-integration-linear-exponential",
  "type": "Übung",
  "number": "4.2.9.1",
  "title": "",
  "body": "  Bestimmen Sie .    Mit , , also , :    "
},
{
  "id": "exercise-buch-substitution-potenz-cosinus",
  "level": "2",
  "url": "sec-integrationstechniken-anwendungen.html#exercise-buch-substitution-potenz-cosinus",
  "type": "Übung",
  "number": "4.2.9.2",
  "title": "",
  "body": "  Bestimmen Sie .    Substitution , :    "
},
{
  "id": "exercise-buch-bogenlaenge-gerade",
  "level": "2",
  "url": "sec-integrationstechniken-anwendungen.html#exercise-buch-bogenlaenge-gerade",
  "type": "Übung",
  "number": "4.2.9.3",
  "title": "",
  "body": "  Bestimmen Sie die Bogenlänge des Graphen von auf dem Intervall .    Es ist , also    "
},
{
  "id": "exercise-buch-rotationskoerper-exponential-einfach",
  "level": "2",
  "url": "sec-integrationstechniken-anwendungen.html#exercise-buch-rotationskoerper-exponential-einfach",
  "type": "Übung",
  "number": "4.2.9.4",
  "title": "",
  "body": "  Bestimmen Sie das Volumen des Rotationskörpers, der durch Rotation des Graphen von auf um die -Achse entsteht.    Wegen ist    "
},
{
  "id": "exercise-buch-trapezregel-linear-exakt",
  "level": "2",
  "url": "sec-integrationstechniken-anwendungen.html#exercise-buch-trapezregel-linear-exakt",
  "type": "Übung",
  "number": "4.2.9.5",
  "title": "",
  "body": "  Approximieren Sie mit der Trapezregel und Teilintervallen. Vergleichen Sie mit dem exakten Wert und erklären Sie den Unterschied.    Mit : Stützstellen , Funktionswerte : Der exakte Wert ist — Trapezregel und exakter Wert stimmen genau überein, denn für eine lineare Funktion approximiert die Sekante der Trapezregel den Graphen exakt, es entsteht kein Approximationsfehler.   "
},
{
  "id": "sec-dgl-erster-ordnung",
  "level": "1",
  "url": "sec-dgl-erster-ordnung.html",
  "type": "Abschnitt",
  "number": "5.1",
  "title": "Begriffsbildung und Differenzialgleichungen erster Ordnung",
  "body": " Begriffsbildung und Differenzialgleichungen erster Ordnung    Nach diesem Abschnitt können Sie    die Ordnung einer Differenzialgleichung bestimmen, eine vorgelegte Funktion durch Einsetzen als Lösung verifizieren und allgemeine von partikulären Lösungen unterscheiden;  Anfangswertprobleme lösen, indem Sie die Integrationskonstanten aus den Anfangsbedingungen bestimmen;  ein Richtungsfeld lesen und Gleichgewichtslösungen erkennen;  trennbare Differenzialgleichungen erkennen und mit Trennung der Variablen lösen;  lineare Differenzialgleichungen erster Ordnung erkennen und im homogenen Fall direkt, im inhomogenen Fall mit Variation der Konstanten lösen;  Wachstums-, Zerfalls-, Abkühlungs-, Lade- und Sparvorgänge als Differenzialgleichung aufstellen und ihre Lösungen interpretieren;  eine DGL erster Ordnung mit einigen Schritten des Euler-Verfahrens von Hand näherungsweise lösen.     Im Oktober 1676 schickte Isaac Newton über einen Mittelsmann einen Brief an Leibniz, in dem er seine wichtigste Entdeckung versteckte — als Buchstabensalat: 6accdae13eff7i3l9n4o4qrr4s8t12ux . Die Zahlen geben an, wie oft jeder Buchstabe in einem lateinischen Satz vorkommt, dessen Inhalt Newton sich so sichern wollte, ohne ihn preiszugeben. Der russische Mathematiker Wladimir Arnold hat die Botschaft einmal frei mit einem einzigen Satz übersetzt: Es ist nützlich, Differenzialgleichungen zu lösen.   Nützlich ist es tatsächlich. Bisher war die Funktion, mit der wir gerechnet haben, immer gegeben. In vielen Anwendungen kennt man aber nur eine Regel für ihre Änderung : Eine Population wächst proportional zu ihrer Größe, ein Körper kühlt proportional zur Temperaturdifferenz ab, ein Kondensator lädt sich umso langsamer, je voller er ist. Aus einer solchen Regel die Funktion selbst zu rekonstruieren, ist die Aufgabe einer Differenzialgleichung . Wir klären zunächst die Grundbegriffe — was ist eine Lösung, und wie viele gibt es? —, verschaffen uns dann mit dem Richtungsfeld einen qualitativen Eindruck vom Lösungsverhalten (und sehen, wie ein Computer eine DGL näherungsweise löst) und lernen schließlich zwei Lösungsverfahren für Gleichungen erster Ordnung: die Trennung der Variablen für trennbare Gleichungen und die Variation der Konstanten für lineare Gleichungen. Die Anwendungen reichen vom Kaffee, der abkühlt, über die Altersbestimmung einer Gletschermumie bis zum Sparplan.    Begriffsbildung: Differenzialgleichungen und ihre Lösungen   In haben wir beim Entladen eines Kondensators eine bemerkenswerte Beobachtung gemacht: Die Ladung erfüllt . Ihre Änderungsrate ist in jedem Moment proportional zur noch vorhandenen Ladung. Umgekehrt gefragt: Wenn man nur dieses Änderungsgesetz kennt — kann man daraus auf die Funktion selbst schließen? Gleichungen dieser Art, in denen eine unbekannte Funktion zusammen mit ihren Ableitungen auftritt, heißen Differenzialgleichungen . Sie sind die Sprache, in der Naturgesetze, technische Systeme und viele Wirtschaftsmodelle formuliert werden.  Die einfachste Differenzialgleichung ist uns bereits aus begegnet, ohne dass wir sie so genannt haben: Ist eine stetige Funktion und eine Stammfunktion, so bedeutet das genau, dass die unbekannte Funktion die Gleichung erfüllt — eine Gleichung, in der nicht selbst, sondern seine Ableitung explizit vorgegeben ist. Eine Differenzialgleichung verallgemeinert diese Idee: Statt nur die erste Ableitung dürfen beliebige Ableitungen der gesuchten Funktion auftreten, und die rechte Seite darf auch von der gesuchten Funktion selbst abhängen.    Differenzialgleichungen, Ordnung und Lösungen   Gewöhnliche Differenzialgleichung -ter Ordnung   Eine gewöhnliche Differenzialgleichung (DGL) -ter Ordnung ist eine Gleichung für eine unbekannte Funktion einer Variablen , in der und dessen Ableitungen bis zur Ordnung auftreten: Die Ordnung der DGL ist die höchste auftretende Ableitungsordnung .    Genau genommen ist das die Definition einer expliziten DGL -ter Ordnung, da die Gleichung bereits nach aufgelöst ist. In diesem Kurs treten ausschließlich solche expliziten DGL auf, sodass wir keine allgemeinere Definition benötigen.   Rechenbeispiel: Ordnung und allgemeine Lösung einer DGL   Die Bewegung eines Körpers unter konstanter Beschleunigung (z. B. der freie Fall) genügt der DGL . Bestimmen Sie die Ordnung dieser DGL und zeigen Sie, dass für beliebige eine Lösung ist.    Die höchste auftretende Ableitung ist , die DGL hat also Ordnung . Einsetzen bestätigt die Lösung: Aus folgt und damit — unabhängig von der Wahl von und . Die Funktionenschar erfüllt die DGL also für jede Wahl der beiden Parameter.     Lösung einer DGL   Eine Lösung einer DGL ist eine -mal differenzierbare Funktion , die die Differenzialgleichung erfüllt.    Eine Lösung heißt allgemein , wenn sie von Parametern (Integrationskonstanten) abhängt.  Eine Lösung heißt partikulär , wenn sie keine freien Parameter mehr enthält. Man erhält eine partikuläre Lösung typischerweise aus der allgemeinen Lösung, indem man  Anfangsbedingungen stellt — man spricht dann von einem Anfangswertproblem (AWP) — oder  Randbedingungen (Randwertproblem).      Beachten Sie: Die Lösung einer Differenzialgleichung ist keine Zahl, sondern eine Funktion . Ob eine vorgelegte Funktion eine Lösung ist, prüft man immer auf dieselbe Weise: ableiten, einsetzen, vergleichen.   Rechenbeispiel: Eine Lösung durch Einsetzen prüfen   Zeigen Sie, dass die DGL löst. Ist auch eine Lösung?    Für ist — die DGL ist für alle erfüllt. Ebenso löst die DGL für jede Konstante . Für ist die Ableitung dieselbe, , aber . Die beiden Seiten unterscheiden sich um , also ist diese Funktion keine Lösung. Eine additive Konstante ist bei Stammfunktionen harmlos, bei Differenzialgleichungen im Allgemeinen nicht.    In ist die allgemeine Lösung: Sie hängt von genau Parametern ab, passend zur Ordnung der DGL. Ein Anfangswertproblem legt beide Parameter fest, wie das folgende Beispiel zeigt.   Rechenbeispiel: Anfangswertproblem zum freien Fall (zur Vertiefung)   Bestimmen Sie die partikuläre Lösung des Anfangswertproblems , , .    Wir setzen die Anfangsbedingungen in die allgemeine Lösung aus und ihre Ableitung ein: Die partikuläre Lösung des AWP ist also Da eine DGL zweiter Ordnung zwei Integrationskonstanten besitzt, werden auch genau zwei Anfangsbedingungen benötigt, um sie eindeutig festzulegen — je eine für und für .    Nicht jede Differenzialgleichung besitzt überhaupt eine Lösung, und der in der Mathematik zentrale Satz von Picard-Lindelöf gibt Bedingungen an, unter denen ein Anfangswertproblem eine eindeutige Lösung besitzt. Für diesen Kurs ist die mathematische Existenztheorie aber von untergeordneter Bedeutung: Wir gehen typischerweise davon aus, dass eine DGL aus einer Anwendung stammt, bei der bereits klar ist, dass eine Lösung existiert, und konzentrieren uns auf die Frage, wie man diese Lösung findet.    Anwendungsbeispiele   Anwendungsbeispiel: Populationswachstum modellieren   Wir möchten die Größe einer Population (z. B. einer Bakterienkultur) als Funktion der Zeit modellieren.    Im einfachsten Fall ist das Wachstum der Population proportional zur aktuell vorhandenen Population. Wie lässt sich das als DGL formulieren?  Realistischer ist die Annahme, dass die Population nur bis zu einer maximalen Kapazität wachsen kann, und dass das Wachstum sowohl zur Populationsgröße als auch zur noch verbleibenden (relativen) Kapazität proportional ist. Wie lautet die entsprechende DGL?         Proportional zur vorhandenen Population bedeutet, dass es eine Konstante gibt (die Wachstumsrate), sodass die Änderungsrate das -fache des aktuellen Bestands ist: Das ist die DGL des exponentiellen Wachstums .  Die verbleibende relative Kapazität bei Bestand ist — sie ist nahe , solange klein gegenüber ist, und nahe , wenn sich annähert. Proportionalität zu Bestand und verbleibender Kapazität ergibt Das ist die DGL des logistischen Wachstums . Für nahe verhält sie sich fast wie die DGL aus (a), für nahe bremst der Faktor das Wachstum ab.    Beide Gleichungen lösen wir in mit der Methode der Trennung der Variablen.       Qualitatives Verständnis: das Richtungsfeld  Bevor wir Differenzialgleichungen erster Ordnung tatsächlich lösen, lohnt sich ein Blick auf ein einfaches Werkzeug, das einen qualitativen Eindruck vom Verlauf der Lösungen vermittelt, ohne dass man die DGL überhaupt lösen muss.  Die Idee ist die eines Navigationsgeräts, das an jedem Ort nur die Fahrtrichtung anzeigt: Wer den Pfeilen folgt, findet den Weg, ohne die Karte je gesehen zu haben. Eine DGL erster Ordnung tut genau das — sie schreibt an jedem Punkt vor, welche Steigung eine Lösung dort haben muss.   Richtungsfeld   Zu einer DGL ordnet das Richtungsfeld jedem Punkt der Ebene den Richtungsvektor zu. Jede Lösung der DGL verläuft an jeder Stelle tangential zu diesem Vektor — das Richtungsfeld zeigt also an jedem Punkt die Steigung, die eine dort verlaufende Lösung haben müsste.    Zeichnet man an vielen Gitterpunkten ein kurzes Linienelement mit Steigung , entsteht ein Bild, aus dem sich der Verlauf einer Lösung zu einem gegebenen Startwert grob skizzieren lässt: Man folgt einfach den Linienelementen.   Richtungsfeld der DGL . Entlang der Linie ist die Steigung überall — das ist die Gleichgewichtslösung . Für nimmt die Steigung mit und zu.    Ein Gitter von kurzen Linienelementen im Bereich , die die Steigung der DGL an jedem Gitterpunkt anzeigen. Entlang der horizontalen Achse sind alle Linienelemente waagerecht. Mit zunehmendem Abstand vom Ursprung werden die Linienelemente steiler; im ersten und dritten Quadranten (wo ) zeigen sie nach oben rechts, im zweiten und vierten Quadranten (wo ) nach unten rechts.       Rechenbeispiel: Gleichgewichtslösung aus dem Richtungsfeld ablesen   Begründen Sie anhand der DGL (ohne sie zu lösen), warum eine Lösung ist, und erklären Sie, warum eine Lösung mit für alle positiv bleiben muss.    Setzt man ein, so ist die linke Seite und die rechte Seite — die DGL ist für alle erfüllt, ist also eine (konstante) Lösung, eine sogenannte Gleichgewichtslösung . Eine Lösung mit kann die Achse nicht überqueren: Träfe sie bei einem Wert auf , so wären an dieser Stelle sowohl als auch mit der Gleichgewichtslösung identisch, und nach dem Satz von Picard-Lindelöf wäre die Lösung durch diesen Punkt eindeutig bestimmt — sie müsste also mit übereinstimmen, im Widerspruch zu . Eine Lösung bleibt daher stets auf einer Seite der Gleichgewichtslösung.     Anwendungsbeispiel: Wie kühlt ein Kaffee ab?   Die Temperatur (in °C) einer Tasse Kaffee in einem  °C warmen Raum genüge der DGL , in Minuten ( ). Lesen Sie aus der DGL ab: Wo liegt die Gleichgewichtslösung? Wie verhalten sich Lösungen oberhalb und unterhalb davon? Wie schnell kühlt ein  °C heißer Kaffee zu Beginn ab?   Richtungsfeld von mit zwei Lösungskurven: Start bei  °C (heißer Kaffee) und bei  °C (kaltes Getränk). Beide nähern sich der Gleichgewichtslösung (gestrichelt).    Ein Koordinatensystem mit der Zeit von bis Minuten auf der horizontalen und der Temperatur von bis  °C auf der vertikalen Achse. Kurze Linienelemente zeigen oberhalb von nach rechts unten, unterhalb nach rechts oben, und werden zur gestrichelten Linie hin flacher. Eine Kurve fällt von aus und nähert sich von oben, eine zweite steigt von aus und nähert sich von unten.        Die rechte Seite hängt nicht von ab, nur von ; alle Linienelemente auf einer waagerechten Linie sind also parallel. Die Steigung ist null für : ist die Gleichgewichtslösung — Kaffee, der schon Raumtemperatur hat, bleibt so. Für ist die Steigung negativ, die Lösungen fallen; für ist sie positiv, die Lösungen steigen (ein kaltes Getränk erwärmt sich). In beiden Fällen werden die Linienelemente flacher, je näher man der kommt: Alle Lösungen nähern sich der Raumtemperatur immer langsamer an. Für ist : Anfangs verliert der Kaffee  °C pro Minute. All das haben wir abgelesen, ohne die DGL zu lösen; die Lösungsformel folgt in .    Das Bild vom Navigationsgerät lässt sich wörtlich nehmen: Man startet im Punkt , liest dort die Steigung ab, folgt dieser Richtung um einen kleinen Zeitschritt , liest die neue Steigung ab, und so fort: Das ist das Euler-Verfahren , das Leonhard Euler 1768 beschrieb — der einfachste Algorithmus, mit dem Computer Differenzialgleichungen näherungsweise lösen. Moderne Löser, etwa scipy.integrate.solve_ivp , arbeiten nach demselben Prinzip, nur mit geschickteren Schritten.   Rechenbeispiel: Das Euler-Verfahren von Hand   Berechnen Sie für den Kaffee aus , mit , zwei Schritte des Euler-Verfahrens mit der Schrittweite Minuten. Die exakten Werte (siehe ) sind und .     Die Näherung unterschätzt die Temperatur: Das Verfahren fährt fünf Minuten lang mit der anfänglichen, steilen Abkühlrate weiter, obwohl sich die Abkühlung in Wahrheit von Anfang an verlangsamt. Mit kleinerer Schrittweite wird die Näherung besser (mit erhält man nach zehn Schritten statt exakt , mit nur ), kostet aber mehr Schritte.    Vorsicht, beliebte Falle: Größere Schritte sind nicht einfach nur ungenauer — ab einer gewissen Größe liefert das Verfahren Unsinn. Beim Kaffee ist , der Abstand zur Raumtemperatur wird also in jedem Schritt mit multipliziert. Mit ist dieser Faktor : Die Näherung springt endlos zwischen  °C und  °C hin und her. Mit ist er , und die Temperatur schaukelt sich unbegrenzt auf — obwohl die exakte Lösung friedlich gegen  °C strebt. Nur für konvergiert die Näherung überhaupt, denn heißt   Das Phänomen kennen Sie schon, unter anderem Namen. Der Gradientenabstieg aus , für eine Verlustfunktion (dort hieß sie ), ist nichts anderes als das Euler-Verfahren mit Schrittweite für die DGL . Die exakte Lösung dieser DGL läuft stets bergab , auf ein Minimum zu; das Euler-Verfahren folgt ihr in diskreten Schritten. Eine zu große Lernrate ist schlicht eine zu große Schrittweite — und das Springen und Explodieren, das wir beim Gradientenabstieg mit zu großem gesehen haben, ist dasselbe wie beim Kaffee mit .    Lösung durch Trennung der Variablen   Für eine große Klasse von Differenzialgleichungen erster Ordnung lässt sich eine Lösung tatsächlich explizit berechnen, indem man die Gleichung auf Integrale zurückführt.  Die Idee ist verblüffend einfach: Man bringt alles, was mit zu tun hat, auf die eine Seite der Gleichung und alles, was mit zu tun hat, auf die andere — und integriert dann beide Seiten. Damit das geht, muss die rechte Seite der DGL in einen -Teil und einen -Teil zerfallen.    Trennbare Gleichungen und das Verfahren   Trennbare DGL   Eine Differenzialgleichung erster Ordnung heißt trennbar (oder separierbar ), wenn sie sich in der Form für Funktionen und schreiben lässt — die rechte Seite zerfällt also in ein Produkt eines reinen -Anteils und eines reinen -Anteils.     Rechenbeispiel: Trennbarkeit erkennen   Welche der folgenden Differenzialgleichungen sind trennbar?             Für lässt sich nach auflösen: . Das ist ein Produkt aus und — trennbar .   lässt sich für und gemeinsam im Argument nicht als Produkt einer reinen Funktion von mit einer reinen Funktion von schreiben — nicht trennbar .  Mit den Rechenregeln für Exponenten ist , also und — trennbar .       Lösungsverfahren: Trennung der Variablen   Gegeben sei eine trennbare DGL . Man geht wie folgt vor:     Trennung der Variablen: Alle -Terme nach links, alle reinen -Terme nach rechts (für ):    Beidseitige Integration nach , wobei man auf der linken Seite mit substituiert:    Auflösen der entstandenen Gleichung nach .   Gleichgewichtslösungen ergänzen: Jede konstante Lösung mit löst die DGL ebenfalls, wurde aber durch die Division in Schritt 1 ausgeschlossen und muss deshalb separat zur Lösung hinzugefügt werden.       Rechenbeispiel: Trennung der Variablen   Bestimmen Sie die allgemeine Lösung der DGL aus durch Trennung der Variablen sowie die partikuläre Lösung des Anfangswertproblems .     Allgemeine Lösung: Für trennen wir die Variablen: Beidseitige Integration mit auf der linken Seite: Auflösen nach : wobei je nach Vorzeichen von . Die Gleichgewichtslösung (aus ) ist genau der Fall , den wir in Schritt 1 ausgeschlossen hatten. Die allgemeine Lösung lautet also  Partikuläre Lösung: Die Anfangsbedingung liefert , also Das passt zum Richtungsfeld aus : Die Lösung startet bei oberhalb der Gleichgewichtslösung und wächst für immer steiler — passend zu den mit zunehmend steilen Linienelementen.      Anwendungsbeispiele   Anwendungsbeispiel: Logistisches Wachstum   Lösen Sie die DGL des logistischen Wachstums aus , durch Trennung der Variablen, und bestimmen Sie die partikuläre Lösung zum Anfangswert mit .    Trennung der Variablen liefert (mit ): Für das linke Integral nutzen wir die Partialbruchzerlegung . Die Technik dahinter wird in diesem Kurs weder vorausgesetzt noch behandelt; die Zerlegung ist hier angegeben und leicht zu prüfen (gemeinsamer Nenner ergibt ✓). Damit erhalten wir wobei die Beträge wegen entfallen. Also Auflösen nach : Das ist die logistische Funktion . Aus folgt , also , und damit die partikuläre Lösung Für geht , also — die Population nähert sich der Kapazitätsgrenze an, unabhängig vom Startwert .  Die logistische Funktion ist eine alte Bekannte: Für , , ist sie genau die Sigmoid-Funktion aus . Die logistische Regression trägt ihren Namen von dieser Differenzialgleichung — und die Ableitungsformel aus ist nichts anderes als die logistische DGL selbst mit .     Anwendungsbeispiel: Newtonsches Abkühlungsgesetz   Das Newtonsche Abkühlungsgesetz besagt, dass sich ein Körper mit Temperatur in einer Umgebung mit konstanter Temperatur mit einer Rate abkühlt (bzw. erwärmt), die proportional zur Temperaturdifferenz ist. Stellen Sie die DGL auf und lösen Sie das Anfangswertproblem .     Proportional zur Temperaturdifferenz bedeutet, dass es eine Konstante gibt (die Abkühlkonstante) mit Das Minuszeichen sorgt dafür, dass sich immer in Richtung bewegt: Ist , so ist die rechte Seite negativ, fällt; ist , so ist sie positiv, steigt. Diese DGL ist trennbar mit , : Auflösen liefert die allgemeine Lösung , . Aus folgt , also die partikuläre Lösung Für strebt — der Körper gleicht sich unabhängig vom Vorzeichen von langfristig an die Umgebungstemperatur an. Für den Kaffee aus ist , genau die blaue Kurve in .    In der Praxis kennt man die Abkühlkonstante meist nicht, sondern bestimmt sie aus einer Messung.   Anwendungsbeispiel: Die Abkühlkonstante aus Messdaten (zur Vertiefung)   Ein Kaffee hat anfangs  °C, der Raum  °C. Nach Minuten misst man  °C. Bestimmen Sie . Wann ist der Kaffee auf  °C abgekühlt?    Mit und ist . Die Messung liefert Für brauchen wir , also Die ersten  °C Abkühlung dauern Minuten, die nächsten  °C noch einmal gut zwölf — je näher der Kaffee der Raumtemperatur kommt, desto langsamer kühlt er ab. Dieses Vorgehen — Modell aufstellen, Parameter aus Messdaten schätzen, Prognose rechnen — ist das Grundmuster jeder datengetriebenen Modellierung.    Dieselbe Mathematik funktioniert auch rückwärts in der Zeit: Kennt man die Zerfallsrate eines Stoffes und misst, wie viel noch da ist, kann man ausrechnen, wie lange der Zerfall schon läuft.   Anwendungsbeispiel: Wie alt ist Ötzi?   Lebende Organismen enthalten einen festen Anteil des radioaktiven Kohlenstoffisotops C-14. Nach dem Tod wird kein neues aufgenommen, und die vorhandene Menge zerfällt nach der DGL ; die Halbwertszeit von C-14 beträgt Jahre. Bestimmen Sie . Eine Gewebeprobe enthält noch des ursprünglichen C-14-Anteils. Wie alt ist sie? (Verwenden Sie und .)    Die DGL ist trennbar mit der Lösung . Nach einer Halbwertszeit ist , also , und Aus folgt , also In dieser Größenordnung liegt das Alter der 1991 in den Ötztaler Alpen gefundenen Gletschermumie Ötzi , deren Alter mit der Radiokarbonmethode auf rund Jahre bestimmt wurde (die Zahlen hier sind vereinfacht; in der Praxis wird das Messergebnis noch kalibriert). Die Methode trug dem Chemiker Willard Libby, der sie Ende der 1940er-Jahre entwickelte, 1960 den Nobelpreis für Chemie ein — und sie beruht auf nichts anderem als der einfachsten Differenzialgleichung dieses Abschnitts.       Lineare Differenzialgleichungen erster Ordnung  Beim Auf- und Entladen eines Kondensators und beim Abkühlen treten und nur linear auf: nicht quadriert, nicht unter einer Wurzel, nicht im Exponenten. Solche linearen Differenzialgleichungen sind in der Technik die wichtigste Klasse überhaupt. Für sie gibt es eine geschlossene Lösungsformel — sie erspart das wiederholte Durchlaufen aller vier Schritte der Trennung der Variablen und funktioniert, mit der Variation der Konstanten in , auch dann, wenn die Trennung der Variablen versagt.   Lineare Differenzialgleichung   Eine Differenzialgleichung erster Ordnung heißt linear , wenn sie sich in der Form für Funktionen und schreiben lässt.    Ist , so heißt die lineare DGL homogen . In diesem Fall ist sie trennbar: hat die Form mit und .  Ist , so heißt die DGL inhomogen — in diesem Fall ist sie im Allgemeinen nicht mehr trennbar, da und auf der rechten Seite additiv statt multiplikativ verknüpft sind, sobald man hinzuzieht.       Rechenbeispiel: Linearität erkennen   Welche der folgenden DGL erster Ordnung sind linear? Welche davon sind homogen bzw. inhomogen?             Umgestellt: . Das ist linear mit , — also homogen .  Das Argument von enthält das Produkt , sodass sich die Gleichung nicht in der Form schreiben lässt — nicht linear .  Für durch teilen: . Das ist linear mit , — also inhomogen .      Wir lösen zunächst den homogenen Fall durch Trennung der Variablen: Mit , liefert das Verfahren aus  wobei eine Stammfunktion von ist. Auflösen nach liefert die folgende geschlossene Formel.   Allgemeine Lösung einer homogenen linearen DGL erster Ordnung   Sei eine homogene lineare DGL erster Ordnung, und sei eine Stammfunktion von . Dann ist die allgemeine Lösung der DGL.    Probe: Mit und der Kettenregel ist , also . Die Formel lässt sich also jederzeit durch Ableiten kontrollieren.   Rechenbeispiel: Homogene lineare DGL mit nichtkonstantem Koeffizienten   Bestimmen Sie die allgemeine Lösung der DGL sowie die partikuläre Lösung des AWP .    Hier ist , also (Integrationskonstante gewählt, wie bei diesem Verfahren üblich — sie würde nur in der freien Konstante aufgehen). Nach ist die allgemeine Lösung Die Anfangsbedingung liefert , also die partikuläre Lösung Die Lösung ist eine Glockenkurve — dieselbe Form wie die Dichte der Normalverteilung aus .    Ist der Koeffizient konstant, , so ist und die Lösungsformel reduziert sich auf — genau die Exponentialfunktionen, die wir beim exponentiellen Wachstum und beim Entladen des Kondensators ( ) gesehen haben. Homogene lineare DGL mit konstantem Koeffizienten sind also nichts Neues, sondern ein Spezialfall, den wir bereits über die Trennung der Variablen gelöst hatten; die Formel aus verallgemeinert dies auf beliebige (nichtkonstante) Koeffizienten .    Variation der Konstanten   Es bleibt der inhomogene Fall mit . Die Idee, um aus der bekannten Lösung des homogenen Falls eine Lösung des inhomogenen Falls zu gewinnen, heißt Variation der Konstanten : Man lässt die Konstante in der homogenen Lösung von abhängen, setzt also den Ansatz in die inhomogene DGL ein und bestimmt, welche Funktion die Gleichung erfüllt.    Die Methode  Die Rechnung ist kurz. Mit dem Ansatz und der Produktregel ist also Der zweite Summand hebt sich genau weg — das ist kein Zufall, denn löst ja die homogene Gleichung. Die inhomogene DGL verlangt also nur noch , d. h. , und ist eine Stammfunktion davon. Das ergibt die folgende Lösungsformel.   Lösung einer inhomogenen linearen DGL erster Ordnung   Sei eine inhomogene lineare DGL erster Ordnung. Ist eine Stammfunktion von und eine Stammfunktion von , so ist die allgemeine Lösung der DGL.    Diese allgemeine Lösung hat eine bemerkenswerte Struktur: Mit (der allgemeinen Lösung der zugehörigen homogenen DGL, ) und (einer partikulären Lösung der inhomogenen DGL, dem Fall ) gilt die allgemeine Lösung der inhomogenen DGL ist also stets die Summe aus der allgemeinen Lösung der homogenen DGL und einer beliebigen partikulären Lösung der inhomogenen DGL.   Rechenbeispiel: Variation der Konstanten   Bestimmen Sie mit Variation der Konstanten die allgemeine Lösung der DGL sowie die partikuläre Lösung des AWP .    Hier ist und . Zunächst Damit bestimmen wir als Stammfunktion von . Mit der Substitution , : Nach ist die allgemeine Lösung Die Anfangsbedingung liefert , also und die partikuläre Lösung Probe: , und ✓.      Anwendungsbeispiele   Anwendungsbeispiel: Aufladen eines Kondensators   Ein Kondensator der Kapazität ist in Reihe mit einem Ohmschen Widerstand geschaltet. Zum Zeitpunkt ist der Kondensator entladen, , und es wird eine konstante Spannung angelegt. Für die Kondensatorspannung gilt dann die DGL Bestimmen Sie den zeitlichen Verlauf von .    Hier ist und , beide konstant. Damit , und ist eine Stammfunktion von : Die allgemeine Lösung ist also Aus folgt , also die partikuläre Lösung Für strebt : Der Kondensator lädt sich exponentiell auf die angelegte Spannung auf. Die Größe heißt Zeitkonstante : Nach der Zeit ist , nach schon mehr als der Endspannung erreicht. Bei  kΩ und  µF ist  s — nach etwa fünf Sekunden gilt der Kondensator in der Praxis als voll.    Der zugehörige homogene Fall entspricht dem Entladen eines zuvor aufgeladenen Kondensators ( , kein angelegtes ): Aus folgt direkt , die Spannung klingt exponentiell ab. Auf- und Entladen desselben -Glieds sind also genau der inhomogene bzw. der homogene Fall derselben linearen DGL.   Anwendungsbeispiel: Ein Sparplan mit stetiger Verzinsung   Auf ein Konto mit stetiger Verzinsung von pro Jahr wird kontinuierlich eingezahlt, insgesamt  € pro Jahr. In einem kurzen Zeitraum wächst der Kontostand (in €, in Jahren) also um die Zinsen und die Einzahlung . Teilt man durch und lässt gehen, erhält man Bestimmen Sie und den Kontostand nach Jahren.    In der Standardform ist , also , , . Eine Stammfunktion von ist . Damit Aus folgt , also Nach Jahren ist und  €. Eingezahlt wurden  €, der Rest sind Zinsen und Zinseszinsen. (Dass auch in der Lösung steht, ist Zufall: Die Laufzeit von Jahren ist gerade .)  Die Konstante ist der Gleichgewichtswert der DGL: ein Kontostand im Minus, bei dem die Schuldzinsen die Einzahlungen gerade auffressen würden. Von diesem Punkt entfernt sich jede andere Lösung exponentiell — ein abstoßender Fixpunkt wie beim Kredit aus , dessen Fixpunkt wir in untersucht haben.    Dieselbe Rechnung liefert allgemein für einen Sparplan mit stetigem Zinssatz und Einzahlungsrate , also mit , die Lösung Sie ist das kontinuierliche Gegenstück zur Restschuldformel aus : Dort ergibt sich mit und einer Einzahlung statt einer Rate ( ) der Kontostand — geometrisches statt exponentielles Wachstum, sonst dieselbe Struktur.     Zusammenfassung     DGL -ter Ordnung:  . Die allgemeine Lösung enthält freie Konstanten; Anfangsbedingungen ( , , …) legen eine partikuläre Lösung fest (Anfangswertproblem). Lösung prüfen: einsetzen.   Richtungsfeld zu : an jedem Punkt ein Linienelement mit Steigung ; Lösungen folgen den Linienelementen. Wo für alle , ist eine Gleichgewichtslösung, die andere Lösungen nicht kreuzen. Euler-Verfahren : folgt dem Richtungsfeld in Zeitschritten ; zu große Schritte machen die Näherung unbrauchbar. Gradientenabstieg für eine Verlustfunktion ist das Euler-Verfahren für , die Lernrate die Schrittweite.   Trennung der Variablen für : , nach auflösen, Gleichgewichtslösungen ( ) ergänzen.   Lineare DGL  mit : homogen ( ) ; inhomogen mit (Variation der Konstanten). Allgemeine Lösung = homogene Lösung + eine partikuläre Lösung.   Modelle: exponentielles Wachstum ( ); logistisches Wachstum (logistische Funktion, Sigmoid); Newtonsche Abkühlung ( ); -Glied ( ); radioaktiver Zerfall mit ; Sparplan ( für ).      Übungsaufgaben    Zeigen Sie, dass eine Lösung der DGL ist. Welche Ordnung hat diese DGL, und ist die angegebene Lösung allgemein oder partikulär?    Aus folgt — die DGL ist für alle erfüllt. Die DGL hat Ordnung (höchste auftretende Ableitung ist ). Da keinen freien Parameter enthält, ist es eine partikuläre Lösung; die allgemeine Lösung wäre , .      Bestimmen Sie die allgemeine Lösung der DGL durch Trennung der Variablen.    Für : . Integration liefert , also . Die Gleichgewichtslösung entspricht , die allgemeine Lösung lautet damit       Lösen Sie das Anfangswertproblem , ( ).    Mit ist , also . Aus folgt die partikuläre Lösung       Bestimmen Sie mit Variation der Konstanten die Lösung des Anfangswertproblems , .    Mit ist . Für integrieren wir : . Die allgemeine Lösung ist Aus folgt und die partikuläre Lösung       Gegeben ist das Anfangswertproblem , . Berechnen Sie mit dem Euler-Verfahren und der Schrittweite eine Näherung für . Zeigen Sie durch Einsetzen, dass die exakte Lösung ist, und vergleichen Sie ( ).    Mit , , : Für ist und , außerdem . Exakt ist also . Die Näherung liegt zu tief: Die Lösung wird immer steiler, das Verfahren rechnet in jedem Schritt aber mit der Steigung vom Anfang des Schritts.     "
},
{
  "id": "sec-dgl-erster-ordnung-2",
  "level": "2",
  "url": "sec-dgl-erster-ordnung.html#sec-dgl-erster-ordnung-2",
  "type": "Lernziele",
  "number": "5.1",
  "title": "",
  "body": "  Nach diesem Abschnitt können Sie    die Ordnung einer Differenzialgleichung bestimmen, eine vorgelegte Funktion durch Einsetzen als Lösung verifizieren und allgemeine von partikulären Lösungen unterscheiden;  Anfangswertprobleme lösen, indem Sie die Integrationskonstanten aus den Anfangsbedingungen bestimmen;  ein Richtungsfeld lesen und Gleichgewichtslösungen erkennen;  trennbare Differenzialgleichungen erkennen und mit Trennung der Variablen lösen;  lineare Differenzialgleichungen erster Ordnung erkennen und im homogenen Fall direkt, im inhomogenen Fall mit Variation der Konstanten lösen;  Wachstums-, Zerfalls-, Abkühlungs-, Lade- und Sparvorgänge als Differenzialgleichung aufstellen und ihre Lösungen interpretieren;  eine DGL erster Ordnung mit einigen Schritten des Euler-Verfahrens von Hand näherungsweise lösen.   "
},
{
  "id": "sub-begriffsbildung-dgl-2-1",
  "level": "2",
  "url": "sec-dgl-erster-ordnung.html#sub-begriffsbildung-dgl-2-1",
  "type": "Absatz (with a defined term)",
  "number": "",
  "title": "",
  "body": "Differenzialgleichungen "
},
{
  "id": "def-gewoehnliche-dgl",
  "level": "2",
  "url": "sec-dgl-erster-ordnung.html#def-gewoehnliche-dgl",
  "type": "Definition",
  "number": "5.1.1",
  "title": "Gewöhnliche Differenzialgleichung <span class=\"process-math\">\\(n\\)<\/span>-ter Ordnung.",
  "body": " Gewöhnliche Differenzialgleichung -ter Ordnung   Eine gewöhnliche Differenzialgleichung (DGL) -ter Ordnung ist eine Gleichung für eine unbekannte Funktion einer Variablen , in der und dessen Ableitungen bis zur Ordnung auftreten: Die Ordnung der DGL ist die höchste auftretende Ableitungsordnung .   "
},
{
  "id": "ssub-dgl-ordnung-loesung-3",
  "level": "2",
  "url": "sec-dgl-erster-ordnung.html#ssub-dgl-ordnung-loesung-3",
  "type": "Absatz (with a defined term)",
  "number": "",
  "title": "",
  "body": "expliziten "
},
{
  "id": "ex-dgl-freier-fall-ordnung",
  "level": "2",
  "url": "sec-dgl-erster-ordnung.html#ex-dgl-freier-fall-ordnung",
  "type": "Beispiel",
  "number": "5.1.2",
  "title": "Rechenbeispiel: Ordnung und allgemeine Lösung einer DGL.",
  "body": " Rechenbeispiel: Ordnung und allgemeine Lösung einer DGL   Die Bewegung eines Körpers unter konstanter Beschleunigung (z. B. der freie Fall) genügt der DGL . Bestimmen Sie die Ordnung dieser DGL und zeigen Sie, dass für beliebige eine Lösung ist.    Die höchste auftretende Ableitung ist , die DGL hat also Ordnung . Einsetzen bestätigt die Lösung: Aus folgt und damit — unabhängig von der Wahl von und . Die Funktionenschar erfüllt die DGL also für jede Wahl der beiden Parameter.   "
},
{
  "id": "def-loesung-dgl",
  "level": "2",
  "url": "sec-dgl-erster-ordnung.html#def-loesung-dgl",
  "type": "Definition",
  "number": "5.1.3",
  "title": "Lösung einer DGL.",
  "body": " Lösung einer DGL   Eine Lösung einer DGL ist eine -mal differenzierbare Funktion , die die Differenzialgleichung erfüllt.    Eine Lösung heißt allgemein , wenn sie von Parametern (Integrationskonstanten) abhängt.  Eine Lösung heißt partikulär , wenn sie keine freien Parameter mehr enthält. Man erhält eine partikuläre Lösung typischerweise aus der allgemeinen Lösung, indem man  Anfangsbedingungen stellt — man spricht dann von einem Anfangswertproblem (AWP) — oder  Randbedingungen (Randwertproblem).     "
},
{
  "id": "ex-dgl-loesung-verifizieren",
  "level": "2",
  "url": "sec-dgl-erster-ordnung.html#ex-dgl-loesung-verifizieren",
  "type": "Beispiel",
  "number": "5.1.4",
  "title": "Rechenbeispiel: Eine Lösung durch Einsetzen prüfen.",
  "body": " Rechenbeispiel: Eine Lösung durch Einsetzen prüfen   Zeigen Sie, dass die DGL löst. Ist auch eine Lösung?    Für ist — die DGL ist für alle erfüllt. Ebenso löst die DGL für jede Konstante . Für ist die Ableitung dieselbe, , aber . Die beiden Seiten unterscheiden sich um , also ist diese Funktion keine Lösung. Eine additive Konstante ist bei Stammfunktionen harmlos, bei Differenzialgleichungen im Allgemeinen nicht.   "
},
{
  "id": "ex-dgl-freier-fall-awp",
  "level": "2",
  "url": "sec-dgl-erster-ordnung.html#ex-dgl-freier-fall-awp",
  "type": "Beispiel",
  "number": "5.1.5",
  "title": "Rechenbeispiel: Anfangswertproblem zum freien Fall (zur Vertiefung).",
  "body": " Rechenbeispiel: Anfangswertproblem zum freien Fall (zur Vertiefung)   Bestimmen Sie die partikuläre Lösung des Anfangswertproblems , , .    Wir setzen die Anfangsbedingungen in die allgemeine Lösung aus und ihre Ableitung ein: Die partikuläre Lösung des AWP ist also Da eine DGL zweiter Ordnung zwei Integrationskonstanten besitzt, werden auch genau zwei Anfangsbedingungen benötigt, um sie eindeutig festzulegen — je eine für und für .   "
},
{
  "id": "ssub-dgl-ordnung-loesung-10",
  "level": "2",
  "url": "sec-dgl-erster-ordnung.html#ssub-dgl-ordnung-loesung-10",
  "type": "Absatz (with a defined term)",
  "number": "",
  "title": "",
  "body": "Satz von Picard-Lindelöf "
},
{
  "id": "ex-anwendung-populationswachstum-modellierung",
  "level": "2",
  "url": "sec-dgl-erster-ordnung.html#ex-anwendung-populationswachstum-modellierung",
  "type": "Beispiel",
  "number": "5.1.6",
  "title": "Anwendungsbeispiel: Populationswachstum modellieren.",
  "body": " Anwendungsbeispiel: Populationswachstum modellieren   Wir möchten die Größe einer Population (z. B. einer Bakterienkultur) als Funktion der Zeit modellieren.    Im einfachsten Fall ist das Wachstum der Population proportional zur aktuell vorhandenen Population. Wie lässt sich das als DGL formulieren?  Realistischer ist die Annahme, dass die Population nur bis zu einer maximalen Kapazität wachsen kann, und dass das Wachstum sowohl zur Populationsgröße als auch zur noch verbleibenden (relativen) Kapazität proportional ist. Wie lautet die entsprechende DGL?         Proportional zur vorhandenen Population bedeutet, dass es eine Konstante gibt (die Wachstumsrate), sodass die Änderungsrate das -fache des aktuellen Bestands ist: Das ist die DGL des exponentiellen Wachstums .  Die verbleibende relative Kapazität bei Bestand ist — sie ist nahe , solange klein gegenüber ist, und nahe , wenn sich annähert. Proportionalität zu Bestand und verbleibender Kapazität ergibt Das ist die DGL des logistischen Wachstums . Für nahe verhält sie sich fast wie die DGL aus (a), für nahe bremst der Faktor das Wachstum ab.    Beide Gleichungen lösen wir in mit der Methode der Trennung der Variablen.   "
},
{
  "id": "def-richtungsfeld",
  "level": "2",
  "url": "sec-dgl-erster-ordnung.html#def-richtungsfeld",
  "type": "Definition",
  "number": "5.1.7",
  "title": "Richtungsfeld.",
  "body": " Richtungsfeld   Zu einer DGL ordnet das Richtungsfeld jedem Punkt der Ebene den Richtungsvektor zu. Jede Lösung der DGL verläuft an jeder Stelle tangential zu diesem Vektor — das Richtungsfeld zeigt also an jedem Punkt die Steigung, die eine dort verlaufende Lösung haben müsste.   "
},
{
  "id": "fig-richtungsfeld-beispiel",
  "level": "2",
  "url": "sec-dgl-erster-ordnung.html#fig-richtungsfeld-beispiel",
  "type": "Abbildung",
  "number": "5.1.8",
  "title": "",
  "body": " Richtungsfeld der DGL . Entlang der Linie ist die Steigung überall — das ist die Gleichgewichtslösung . Für nimmt die Steigung mit und zu.    Ein Gitter von kurzen Linienelementen im Bereich , die die Steigung der DGL an jedem Gitterpunkt anzeigen. Entlang der horizontalen Achse sind alle Linienelemente waagerecht. Mit zunehmendem Abstand vom Ursprung werden die Linienelemente steiler; im ersten und dritten Quadranten (wo ) zeigen sie nach oben rechts, im zweiten und vierten Quadranten (wo ) nach unten rechts.     "
},
{
  "id": "ex-richtungsfeld-gleichgewichtsloesung",
  "level": "2",
  "url": "sec-dgl-erster-ordnung.html#ex-richtungsfeld-gleichgewichtsloesung",
  "type": "Beispiel",
  "number": "5.1.9",
  "title": "Rechenbeispiel: Gleichgewichtslösung aus dem Richtungsfeld ablesen.",
  "body": " Rechenbeispiel: Gleichgewichtslösung aus dem Richtungsfeld ablesen   Begründen Sie anhand der DGL (ohne sie zu lösen), warum eine Lösung ist, und erklären Sie, warum eine Lösung mit für alle positiv bleiben muss.    Setzt man ein, so ist die linke Seite und die rechte Seite — die DGL ist für alle erfüllt, ist also eine (konstante) Lösung, eine sogenannte Gleichgewichtslösung . Eine Lösung mit kann die Achse nicht überqueren: Träfe sie bei einem Wert auf , so wären an dieser Stelle sowohl als auch mit der Gleichgewichtslösung identisch, und nach dem Satz von Picard-Lindelöf wäre die Lösung durch diesen Punkt eindeutig bestimmt — sie müsste also mit übereinstimmen, im Widerspruch zu . Eine Lösung bleibt daher stets auf einer Seite der Gleichgewichtslösung.   "
},
{
  "id": "ex-anwendung-richtungsfeld-abkuehlung",
  "level": "2",
  "url": "sec-dgl-erster-ordnung.html#ex-anwendung-richtungsfeld-abkuehlung",
  "type": "Beispiel",
  "number": "5.1.10",
  "title": "Anwendungsbeispiel: Wie kühlt ein Kaffee ab?",
  "body": " Anwendungsbeispiel: Wie kühlt ein Kaffee ab?   Die Temperatur (in °C) einer Tasse Kaffee in einem  °C warmen Raum genüge der DGL , in Minuten ( ). Lesen Sie aus der DGL ab: Wo liegt die Gleichgewichtslösung? Wie verhalten sich Lösungen oberhalb und unterhalb davon? Wie schnell kühlt ein  °C heißer Kaffee zu Beginn ab?   Richtungsfeld von mit zwei Lösungskurven: Start bei  °C (heißer Kaffee) und bei  °C (kaltes Getränk). Beide nähern sich der Gleichgewichtslösung (gestrichelt).    Ein Koordinatensystem mit der Zeit von bis Minuten auf der horizontalen und der Temperatur von bis  °C auf der vertikalen Achse. Kurze Linienelemente zeigen oberhalb von nach rechts unten, unterhalb nach rechts oben, und werden zur gestrichelten Linie hin flacher. Eine Kurve fällt von aus und nähert sich von oben, eine zweite steigt von aus und nähert sich von unten.        Die rechte Seite hängt nicht von ab, nur von ; alle Linienelemente auf einer waagerechten Linie sind also parallel. Die Steigung ist null für : ist die Gleichgewichtslösung — Kaffee, der schon Raumtemperatur hat, bleibt so. Für ist die Steigung negativ, die Lösungen fallen; für ist sie positiv, die Lösungen steigen (ein kaltes Getränk erwärmt sich). In beiden Fällen werden die Linienelemente flacher, je näher man der kommt: Alle Lösungen nähern sich der Raumtemperatur immer langsamer an. Für ist : Anfangs verliert der Kaffee  °C pro Minute. All das haben wir abgelesen, ohne die DGL zu lösen; die Lösungsformel folgt in .   "
},
{
  "id": "sub-richtungsfeld-9",
  "level": "2",
  "url": "sec-dgl-erster-ordnung.html#sub-richtungsfeld-9",
  "type": "Absatz (with a defined term)",
  "number": "",
  "title": "",
  "body": "Euler-Verfahren "
},
{
  "id": "ex-euler-verfahren-kaffee",
  "level": "2",
  "url": "sec-dgl-erster-ordnung.html#ex-euler-verfahren-kaffee",
  "type": "Beispiel",
  "number": "5.1.12",
  "title": "Rechenbeispiel: Das Euler-Verfahren von Hand.",
  "body": " Rechenbeispiel: Das Euler-Verfahren von Hand   Berechnen Sie für den Kaffee aus , mit , zwei Schritte des Euler-Verfahrens mit der Schrittweite Minuten. Die exakten Werte (siehe ) sind und .     Die Näherung unterschätzt die Temperatur: Das Verfahren fährt fünf Minuten lang mit der anfänglichen, steilen Abkühlrate weiter, obwohl sich die Abkühlung in Wahrheit von Anfang an verlangsamt. Mit kleinerer Schrittweite wird die Näherung besser (mit erhält man nach zehn Schritten statt exakt , mit nur ), kostet aber mehr Schritte.   "
},
{
  "id": "def-trennbare-dgl",
  "level": "2",
  "url": "sec-dgl-erster-ordnung.html#def-trennbare-dgl",
  "type": "Definition",
  "number": "5.1.13",
  "title": "Trennbare DGL.",
  "body": " Trennbare DGL   Eine Differenzialgleichung erster Ordnung heißt trennbar (oder separierbar ), wenn sie sich in der Form für Funktionen und schreiben lässt — die rechte Seite zerfällt also in ein Produkt eines reinen -Anteils und eines reinen -Anteils.   "
},
{
  "id": "ex-trennbarkeit-erkennen",
  "level": "2",
  "url": "sec-dgl-erster-ordnung.html#ex-trennbarkeit-erkennen",
  "type": "Beispiel",
  "number": "5.1.14",
  "title": "Rechenbeispiel: Trennbarkeit erkennen.",
  "body": " Rechenbeispiel: Trennbarkeit erkennen   Welche der folgenden Differenzialgleichungen sind trennbar?             Für lässt sich nach auflösen: . Das ist ein Produkt aus und — trennbar .   lässt sich für und gemeinsam im Argument nicht als Produkt einer reinen Funktion von mit einer reinen Funktion von schreiben — nicht trennbar .  Mit den Rechenregeln für Exponenten ist , also und — trennbar .     "
},
{
  "id": "thm-loesungsverfahren-trennung-der-variablen",
  "level": "2",
  "url": "sec-dgl-erster-ordnung.html#thm-loesungsverfahren-trennung-der-variablen",
  "type": "Satz",
  "number": "5.1.15",
  "title": "Lösungsverfahren: Trennung der Variablen.",
  "body": " Lösungsverfahren: Trennung der Variablen   Gegeben sei eine trennbare DGL . Man geht wie folgt vor:     Trennung der Variablen: Alle -Terme nach links, alle reinen -Terme nach rechts (für ):    Beidseitige Integration nach , wobei man auf der linken Seite mit substituiert:    Auflösen der entstandenen Gleichung nach .   Gleichgewichtslösungen ergänzen: Jede konstante Lösung mit löst die DGL ebenfalls, wurde aber durch die Division in Schritt 1 ausgeschlossen und muss deshalb separat zur Lösung hinzugefügt werden.     "
},
{
  "id": "ex-trennung-der-variablen-grundbeispiel",
  "level": "2",
  "url": "sec-dgl-erster-ordnung.html#ex-trennung-der-variablen-grundbeispiel",
  "type": "Beispiel",
  "number": "5.1.16",
  "title": "Rechenbeispiel: Trennung der Variablen.",
  "body": " Rechenbeispiel: Trennung der Variablen   Bestimmen Sie die allgemeine Lösung der DGL aus durch Trennung der Variablen sowie die partikuläre Lösung des Anfangswertproblems .     Allgemeine Lösung: Für trennen wir die Variablen: Beidseitige Integration mit auf der linken Seite: Auflösen nach : wobei je nach Vorzeichen von . Die Gleichgewichtslösung (aus ) ist genau der Fall , den wir in Schritt 1 ausgeschlossen hatten. Die allgemeine Lösung lautet also  Partikuläre Lösung: Die Anfangsbedingung liefert , also Das passt zum Richtungsfeld aus : Die Lösung startet bei oberhalb der Gleichgewichtslösung und wächst für immer steiler — passend zu den mit zunehmend steilen Linienelementen.   "
},
{
  "id": "ex-anwendung-logistisches-wachstum",
  "level": "2",
  "url": "sec-dgl-erster-ordnung.html#ex-anwendung-logistisches-wachstum",
  "type": "Beispiel",
  "number": "5.1.17",
  "title": "Anwendungsbeispiel: Logistisches Wachstum.",
  "body": " Anwendungsbeispiel: Logistisches Wachstum   Lösen Sie die DGL des logistischen Wachstums aus , durch Trennung der Variablen, und bestimmen Sie die partikuläre Lösung zum Anfangswert mit .    Trennung der Variablen liefert (mit ): Für das linke Integral nutzen wir die Partialbruchzerlegung . Die Technik dahinter wird in diesem Kurs weder vorausgesetzt noch behandelt; die Zerlegung ist hier angegeben und leicht zu prüfen (gemeinsamer Nenner ergibt ✓). Damit erhalten wir wobei die Beträge wegen entfallen. Also Auflösen nach : Das ist die logistische Funktion . Aus folgt , also , und damit die partikuläre Lösung Für geht , also — die Population nähert sich der Kapazitätsgrenze an, unabhängig vom Startwert .  Die logistische Funktion ist eine alte Bekannte: Für , , ist sie genau die Sigmoid-Funktion aus . Die logistische Regression trägt ihren Namen von dieser Differenzialgleichung — und die Ableitungsformel aus ist nichts anderes als die logistische DGL selbst mit .   "
},
{
  "id": "ex-anwendung-newtonsche-abkuehlung",
  "level": "2",
  "url": "sec-dgl-erster-ordnung.html#ex-anwendung-newtonsche-abkuehlung",
  "type": "Beispiel",
  "number": "5.1.18",
  "title": "Anwendungsbeispiel: Newtonsches Abkühlungsgesetz.",
  "body": " Anwendungsbeispiel: Newtonsches Abkühlungsgesetz   Das Newtonsche Abkühlungsgesetz besagt, dass sich ein Körper mit Temperatur in einer Umgebung mit konstanter Temperatur mit einer Rate abkühlt (bzw. erwärmt), die proportional zur Temperaturdifferenz ist. Stellen Sie die DGL auf und lösen Sie das Anfangswertproblem .     Proportional zur Temperaturdifferenz bedeutet, dass es eine Konstante gibt (die Abkühlkonstante) mit Das Minuszeichen sorgt dafür, dass sich immer in Richtung bewegt: Ist , so ist die rechte Seite negativ, fällt; ist , so ist sie positiv, steigt. Diese DGL ist trennbar mit , : Auflösen liefert die allgemeine Lösung , . Aus folgt , also die partikuläre Lösung Für strebt — der Körper gleicht sich unabhängig vom Vorzeichen von langfristig an die Umgebungstemperatur an. Für den Kaffee aus ist , genau die blaue Kurve in .   "
},
{
  "id": "ex-anwendung-abkuehlkonstante-bestimmen",
  "level": "2",
  "url": "sec-dgl-erster-ordnung.html#ex-anwendung-abkuehlkonstante-bestimmen",
  "type": "Beispiel",
  "number": "5.1.19",
  "title": "Anwendungsbeispiel: Die Abkühlkonstante aus Messdaten (zur Vertiefung).",
  "body": " Anwendungsbeispiel: Die Abkühlkonstante aus Messdaten (zur Vertiefung)   Ein Kaffee hat anfangs  °C, der Raum  °C. Nach Minuten misst man  °C. Bestimmen Sie . Wann ist der Kaffee auf  °C abgekühlt?    Mit und ist . Die Messung liefert Für brauchen wir , also Die ersten  °C Abkühlung dauern Minuten, die nächsten  °C noch einmal gut zwölf — je näher der Kaffee der Raumtemperatur kommt, desto langsamer kühlt er ab. Dieses Vorgehen — Modell aufstellen, Parameter aus Messdaten schätzen, Prognose rechnen — ist das Grundmuster jeder datengetriebenen Modellierung.   "
},
{
  "id": "ex-anwendung-radiokarbon",
  "level": "2",
  "url": "sec-dgl-erster-ordnung.html#ex-anwendung-radiokarbon",
  "type": "Beispiel",
  "number": "5.1.20",
  "title": "Anwendungsbeispiel: Wie alt ist Ötzi?",
  "body": " Anwendungsbeispiel: Wie alt ist Ötzi?   Lebende Organismen enthalten einen festen Anteil des radioaktiven Kohlenstoffisotops C-14. Nach dem Tod wird kein neues aufgenommen, und die vorhandene Menge zerfällt nach der DGL ; die Halbwertszeit von C-14 beträgt Jahre. Bestimmen Sie . Eine Gewebeprobe enthält noch des ursprünglichen C-14-Anteils. Wie alt ist sie? (Verwenden Sie und .)    Die DGL ist trennbar mit der Lösung . Nach einer Halbwertszeit ist , also , und Aus folgt , also In dieser Größenordnung liegt das Alter der 1991 in den Ötztaler Alpen gefundenen Gletschermumie Ötzi , deren Alter mit der Radiokarbonmethode auf rund Jahre bestimmt wurde (die Zahlen hier sind vereinfacht; in der Praxis wird das Messergebnis noch kalibriert). Die Methode trug dem Chemiker Willard Libby, der sie Ende der 1940er-Jahre entwickelte, 1960 den Nobelpreis für Chemie ein — und sie beruht auf nichts anderem als der einfachsten Differenzialgleichung dieses Abschnitts.   "
},
{
  "id": "def-lineare-dgl-erster-ordnung",
  "level": "2",
  "url": "sec-dgl-erster-ordnung.html#def-lineare-dgl-erster-ordnung",
  "type": "Definition",
  "number": "5.1.21",
  "title": "Lineare Differenzialgleichung.",
  "body": " Lineare Differenzialgleichung   Eine Differenzialgleichung erster Ordnung heißt linear , wenn sie sich in der Form für Funktionen und schreiben lässt.    Ist , so heißt die lineare DGL homogen . In diesem Fall ist sie trennbar: hat die Form mit und .  Ist , so heißt die DGL inhomogen — in diesem Fall ist sie im Allgemeinen nicht mehr trennbar, da und auf der rechten Seite additiv statt multiplikativ verknüpft sind, sobald man hinzuzieht.     "
},
{
  "id": "ex-linearitaet-erkennen",
  "level": "2",
  "url": "sec-dgl-erster-ordnung.html#ex-linearitaet-erkennen",
  "type": "Beispiel",
  "number": "5.1.22",
  "title": "Rechenbeispiel: Linearität erkennen.",
  "body": " Rechenbeispiel: Linearität erkennen   Welche der folgenden DGL erster Ordnung sind linear? Welche davon sind homogen bzw. inhomogen?             Umgestellt: . Das ist linear mit , — also homogen .  Das Argument von enthält das Produkt , sodass sich die Gleichung nicht in der Form schreiben lässt — nicht linear .  Für durch teilen: . Das ist linear mit , — also inhomogen .     "
},
{
  "id": "thm-loesung-homogene-lineare-dgl",
  "level": "2",
  "url": "sec-dgl-erster-ordnung.html#thm-loesung-homogene-lineare-dgl",
  "type": "Satz",
  "number": "5.1.23",
  "title": "Allgemeine Lösung einer homogenen linearen DGL erster Ordnung.",
  "body": " Allgemeine Lösung einer homogenen linearen DGL erster Ordnung   Sei eine homogene lineare DGL erster Ordnung, und sei eine Stammfunktion von . Dann ist die allgemeine Lösung der DGL.   "
},
{
  "id": "ex-lineare-dgl-homogen-nichtkonstant",
  "level": "2",
  "url": "sec-dgl-erster-ordnung.html#ex-lineare-dgl-homogen-nichtkonstant",
  "type": "Beispiel",
  "number": "5.1.24",
  "title": "Rechenbeispiel: Homogene lineare DGL mit nichtkonstantem Koeffizienten.",
  "body": " Rechenbeispiel: Homogene lineare DGL mit nichtkonstantem Koeffizienten   Bestimmen Sie die allgemeine Lösung der DGL sowie die partikuläre Lösung des AWP .    Hier ist , also (Integrationskonstante gewählt, wie bei diesem Verfahren üblich — sie würde nur in der freien Konstante aufgehen). Nach ist die allgemeine Lösung Die Anfangsbedingung liefert , also die partikuläre Lösung Die Lösung ist eine Glockenkurve — dieselbe Form wie die Dichte der Normalverteilung aus .   "
},
{
  "id": "sub-variation-der-konstanten-2-1",
  "level": "2",
  "url": "sec-dgl-erster-ordnung.html#sub-variation-der-konstanten-2-1",
  "type": "Absatz (with a defined term)",
  "number": "",
  "title": "",
  "body": "Variation der Konstanten "
},
{
  "id": "thm-variation-der-konstanten",
  "level": "2",
  "url": "sec-dgl-erster-ordnung.html#thm-variation-der-konstanten",
  "type": "Satz",
  "number": "5.1.25",
  "title": "Lösung einer inhomogenen linearen DGL erster Ordnung.",
  "body": " Lösung einer inhomogenen linearen DGL erster Ordnung   Sei eine inhomogene lineare DGL erster Ordnung. Ist eine Stammfunktion von und eine Stammfunktion von , so ist die allgemeine Lösung der DGL.   "
},
{
  "id": "ssub-variation-methode-4",
  "level": "2",
  "url": "sec-dgl-erster-ordnung.html#ssub-variation-methode-4",
  "type": "Absatz (with a defined term)",
  "number": "",
  "title": "",
  "body": "partikulären Lösung Summe "
},
{
  "id": "ex-variation-der-konstanten-grundbeispiel",
  "level": "2",
  "url": "sec-dgl-erster-ordnung.html#ex-variation-der-konstanten-grundbeispiel",
  "type": "Beispiel",
  "number": "5.1.26",
  "title": "Rechenbeispiel: Variation der Konstanten.",
  "body": " Rechenbeispiel: Variation der Konstanten   Bestimmen Sie mit Variation der Konstanten die allgemeine Lösung der DGL sowie die partikuläre Lösung des AWP .    Hier ist und . Zunächst Damit bestimmen wir als Stammfunktion von . Mit der Substitution , : Nach ist die allgemeine Lösung Die Anfangsbedingung liefert , also und die partikuläre Lösung Probe: , und ✓.   "
},
{
  "id": "ex-anwendung-rc-glied-aufladung",
  "level": "2",
  "url": "sec-dgl-erster-ordnung.html#ex-anwendung-rc-glied-aufladung",
  "type": "Beispiel",
  "number": "5.1.27",
  "title": "Anwendungsbeispiel: Aufladen eines Kondensators.",
  "body": " Anwendungsbeispiel: Aufladen eines Kondensators   Ein Kondensator der Kapazität ist in Reihe mit einem Ohmschen Widerstand geschaltet. Zum Zeitpunkt ist der Kondensator entladen, , und es wird eine konstante Spannung angelegt. Für die Kondensatorspannung gilt dann die DGL Bestimmen Sie den zeitlichen Verlauf von .    Hier ist und , beide konstant. Damit , und ist eine Stammfunktion von : Die allgemeine Lösung ist also Aus folgt , also die partikuläre Lösung Für strebt : Der Kondensator lädt sich exponentiell auf die angelegte Spannung auf. Die Größe heißt Zeitkonstante : Nach der Zeit ist , nach schon mehr als der Endspannung erreicht. Bei  kΩ und  µF ist  s — nach etwa fünf Sekunden gilt der Kondensator in der Praxis als voll.   "
},
{
  "id": "sub-anwendungen-variation-der-konstanten-3",
  "level": "2",
  "url": "sec-dgl-erster-ordnung.html#sub-anwendungen-variation-der-konstanten-3",
  "type": "Absatz (with a defined term)",
  "number": "",
  "title": "",
  "body": "Entladen "
},
{
  "id": "ex-anwendung-sparplan-stetig",
  "level": "2",
  "url": "sec-dgl-erster-ordnung.html#ex-anwendung-sparplan-stetig",
  "type": "Beispiel",
  "number": "5.1.28",
  "title": "Anwendungsbeispiel: Ein Sparplan mit stetiger Verzinsung.",
  "body": " Anwendungsbeispiel: Ein Sparplan mit stetiger Verzinsung   Auf ein Konto mit stetiger Verzinsung von pro Jahr wird kontinuierlich eingezahlt, insgesamt  € pro Jahr. In einem kurzen Zeitraum wächst der Kontostand (in €, in Jahren) also um die Zinsen und die Einzahlung . Teilt man durch und lässt gehen, erhält man Bestimmen Sie und den Kontostand nach Jahren.    In der Standardform ist , also , , . Eine Stammfunktion von ist . Damit Aus folgt , also Nach Jahren ist und  €. Eingezahlt wurden  €, der Rest sind Zinsen und Zinseszinsen. (Dass auch in der Lösung steht, ist Zufall: Die Laufzeit von Jahren ist gerade .)  Die Konstante ist der Gleichgewichtswert der DGL: ein Kontostand im Minus, bei dem die Schuldzinsen die Einzahlungen gerade auffressen würden. Von diesem Punkt entfernt sich jede andere Lösung exponentiell — ein abstoßender Fixpunkt wie beim Kredit aus , dessen Fixpunkt wir in untersucht haben.   "
},
{
  "id": "sub-zusammenfassung-5-1-2",
  "level": "2",
  "url": "sec-dgl-erster-ordnung.html#sub-zusammenfassung-5-1-2",
  "type": "Absatz (with a defined term)",
  "number": "",
  "title": "",
  "body": "DGL -ter Ordnung: Richtungsfeld Euler-Verfahren Trennung der Variablen Lineare DGL Modelle: "
},
{
  "id": "exercise-buch-loesung-verifizieren",
  "level": "2",
  "url": "sec-dgl-erster-ordnung.html#exercise-buch-loesung-verifizieren",
  "type": "Übung",
  "number": "5.1.7.1",
  "title": "",
  "body": "  Zeigen Sie, dass eine Lösung der DGL ist. Welche Ordnung hat diese DGL, und ist die angegebene Lösung allgemein oder partikulär?    Aus folgt — die DGL ist für alle erfüllt. Die DGL hat Ordnung (höchste auftretende Ableitung ist ). Da keinen freien Parameter enthält, ist es eine partikuläre Lösung; die allgemeine Lösung wäre , .   "
},
{
  "id": "exercise-buch-trennung-der-variablen-einfach",
  "level": "2",
  "url": "sec-dgl-erster-ordnung.html#exercise-buch-trennung-der-variablen-einfach",
  "type": "Übung",
  "number": "5.1.7.2",
  "title": "",
  "body": "  Bestimmen Sie die allgemeine Lösung der DGL durch Trennung der Variablen.    Für : . Integration liefert , also . Die Gleichgewichtslösung entspricht , die allgemeine Lösung lautet damit    "
},
{
  "id": "exercise-buch-lineare-dgl-homogen-einfach",
  "level": "2",
  "url": "sec-dgl-erster-ordnung.html#exercise-buch-lineare-dgl-homogen-einfach",
  "type": "Übung",
  "number": "5.1.7.3",
  "title": "",
  "body": "  Lösen Sie das Anfangswertproblem , ( ).    Mit ist , also . Aus folgt die partikuläre Lösung    "
},
{
  "id": "exercise-buch-variation-der-konstanten-einfach",
  "level": "2",
  "url": "sec-dgl-erster-ordnung.html#exercise-buch-variation-der-konstanten-einfach",
  "type": "Übung",
  "number": "5.1.7.4",
  "title": "",
  "body": "  Bestimmen Sie mit Variation der Konstanten die Lösung des Anfangswertproblems , .    Mit ist . Für integrieren wir : . Die allgemeine Lösung ist Aus folgt und die partikuläre Lösung    "
},
{
  "id": "exercise-buch-euler-verfahren",
  "level": "2",
  "url": "sec-dgl-erster-ordnung.html#exercise-buch-euler-verfahren",
  "type": "Übung",
  "number": "5.1.7.5",
  "title": "",
  "body": "  Gegeben ist das Anfangswertproblem , . Berechnen Sie mit dem Euler-Verfahren und der Schrittweite eine Näherung für . Zeigen Sie durch Einsetzen, dass die exakte Lösung ist, und vergleichen Sie ( ).    Mit , , : Für ist und , außerdem . Exakt ist also . Die Näherung liegt zu tief: Die Lösung wird immer steiler, das Verfahren rechnet in jedem Schritt aber mit der Steigung vom Anfang des Schritts.   "
},
{
  "id": "sec-lineare-dgl-hoeherer-ordnung",
  "level": "1",
  "url": "sec-lineare-dgl-hoeherer-ordnung.html",
  "type": "Abschnitt",
  "number": "5.2",
  "title": "Lineare Differenzialgleichungen höherer Ordnung",
  "body": " Lineare Differenzialgleichungen höherer Ordnung    Nach diesem Abschnitt können Sie    lineare Differenzialgleichungen höherer Ordnung erkennen und nach Homogenität und konstanten Koeffizienten klassifizieren;  das charakteristische Polynom aufstellen und aus seinen Nullstellen — reell, komplex oder mehrfach — die allgemeine Lösung der homogenen Gleichung ablesen;  Anfangswertprobleme zweiter Ordnung lösen und umgekehrt aus einer gegebenen Lösung die Differenzialgleichung rekonstruieren;  partikuläre Lösungen inhomogener Gleichungen mit dem Ansatz vom Typ rechte Seite bestimmen, auch im Resonanzfall;  die Dämpfungsfälle des harmonischen Oszillators unterscheiden und auf Federpendel, RLC-Schwingkreis und Momentum-Optimierer übertragen.     Viele Schwingungsprobleme — vom Federpendel bis zum RLC-Schwingkreis — führen auf Differenzialgleichungen, in denen die gesuchte Funktion bis zur zweiten oder höheren Ableitung auftritt. In diesem Abschnitt entwickeln wir ein systematisches Lösungsverfahren für lineare Differenzialgleichungen beliebiger Ordnung mit konstanten Koeffizienten: Zunächst lösen wir den homogenen Fall über die Nullstellen eines charakteristischen Polynoms — hier zahlt sich die Arbeit aus aus, denn diese Nullstellen sind oft komplex —, dann den inhomogenen Fall über einen Ansatz vom Typ rechte Seite. Als durchgehendes Anwendungsbeispiel dient der harmonische Oszillator, an dem sich alle Lösungsfälle konkret interpretieren lassen: Schwingt das System, kriecht es in die Ruhelage, oder schaukelt es sich bei Anregung gefährlich auf?  Sie werden sehen, wie man einen Stoßdämpfer auslegt, warum Soldaten auf Brücken nicht im Gleichschritt marschieren sollen, wie man aus einem gemessenen Schwingungssignal auf Federkonstante und Dämpfung zurückschließt und was der Momentum-Optimierer beim Training neuronaler Netze mit einem Federpendel gemeinsam hat. Und ganz nebenbei liefert dieselbe Methode eine geschlossene Formel für die Fibonacci-Zahlen aus . Dieser Abschnitt ist zugleich eine Wiederholung: komplexe Zahlen, Polynome, Ableitungen und Gleichungssysteme greifen hier ineinander.    Lineare Differenzialgleichungen höherer Ordnung  Fährt ein Auto über eine Bodenwelle, federt die Karosserie ein — und soll danach rasch und ohne langes Nachwippen wieder zur Ruhe kommen. Ob das gelingt, entscheidet das Zusammenspiel von Feder und Stoßdämpfer, und beschrieben wird es durch eine Differenzialgleichung, in der die Beschleunigung , also die zweite Ableitung der Auslenkung, vorkommt. Newtons Gesetz Kraft gleich Masse mal Beschleunigung macht Gleichungen zweiter Ordnung zum Normalfall der Mechanik.  Die Differenzialgleichungen erster Ordnung aus reichen deshalb für viele, aber nicht für alle Anwendungen aus. Der harmonische Oszillator (ein schwingendes Federpendel oder ein RLC-Schwingkreis) etwa wird durch eine Gleichung der Form beschrieben, in der die gesuchte Funktion bis zur zweiten Ableitung auftritt. Auch die Durchbiegung eines belasteten Balkens genügt einer Gleichung vierter Ordnung, . Wir widmen uns deshalb im Folgenden Lösungsverfahren für lineare Differenzialgleichungen höherer Ordnung mit konstanten Koeffizienten .   Lineare DGL der Ordnung   Eine Differenzialgleichung der Ordnung heißt linear , wenn sie sich in der Form schreiben lässt, wobei die Koeffizienten Funktionen sind.    Sind alle  konstant , so hat die DGL konstante Koeffizienten .  Ist , so heißt die DGL homogen , andernfalls inhomogen .       Rechenbeispiel: Linearität, Homogenität und konstante Koeffizienten erkennen   Welche der folgenden DGL sind linear? Welche davon sind homogen bzw. inhomogen, und welche haben konstante Koeffizienten?             Der Term tritt nicht in erster Potenz auf — nicht linear .  Alle Koeffizienten ( ) sind Zahlen, also konstant, und die rechte Seite ist von verschieden — linear , inhomogen , konstante Koeffizienten .  Der Koeffizient von ist nicht konstant, aber die Gleichung ist in jeweils von erster Potenz und die rechte Seite ist — linear , homogen , aber nicht mit konstanten Koeffizienten.      Im Rest dieses Abschnitts beschränken wir uns auf lineare DGL mit konstanten Koeffizienten — genau die Klasse, die beim harmonischen Oszillator und vielen anderen technischen Schwingungsproblemen auftritt. Wie schon bei den DGL erster Ordnung gehen wir in zwei Schritten vor: Zunächst lösen wir den homogenen Fall, anschließend den inhomogenen.    Lösung homogener linearer DGL höherer Ordnung  Wir betrachten eine homogene lineare DGL der Ordnung mit konstanten Koeffizienten Der Lösungsweg führt über ein Hilfspolynom, das nur von den Koeffizienten der DGL abhängt.   Charakteristisches Polynom   Das charakteristische Polynom der obigen DGL ist     Woher kommt dieses Polynom? Der Ansatz hat die Ableitungen ; setzt man ihn in die DGL ein und klammert aus, bleibt genau die Bedingung übrig. Nach dem Fundamentalsatz der Algebra ( ) besitzt , Vielfachheit gezählt, genau (möglicherweise komplexe) Nullstellen. Jede Nullstelle liefert eine oder mehrere Fundamentallösungen der DGL — je nachdem, ob sie reell oder komplex und ob sie einfach oder mehrfach ist. Wir unterscheiden drei Fälle.   Fall 1: Einfache reelle Nullstelle   Ist eine einfache Nullstelle von , so ist eine Lösung der DGL.     Rechenbeispiel: Zwei verschiedene reelle Nullstellen (Fall 1) (zur Vertiefung)   Bestimmen Sie die allgemeine Lösung von und die Lösung zu , .     hat die einfachen Nullstellen und . Beide liefern nach Fall 1 eine Lösung, und die allgemeine Lösung ist (vorgreifend auf ) Probe für : ✓. Die Anfangswerte liefern das Gleichungssystem Doppelte erste Gleichung zur zweiten addiert: , also , und . Zwei Anfangsbedingungen für zwei Konstanten — wie beim freien Fall in .    Ist eine Nullstelle komplex, , so ist eine komplexwertige Funktion. Mit der Eulerschen Formel ( ) lässt sie sich aber sofort in reelle Bestandteile zerlegen: Der Realteil bestimmt also das Wachsen oder Abklingen, der Imaginärteil die Frequenz der Schwingung. Hier zahlen sich die komplexen Zahlen aus unmittelbar aus.   Fall 2: Einfaches Paar komplex konjugierter Nullstellen   Ist (mit ) eine einfache Nullstelle von , so ist auch die konjugiert komplexe Zahl eine einfache Nullstelle (da die Koeffizienten von reell sind). Real- und Imaginärteil der komplexen Lösung liefern dann zwei unabhängige, reelle Lösungen      Fall 3: Mehrfache Nullstelle der Ordnung    (a) Ist eine -fache reelle Nullstelle von , so bilden  unabhängige Lösungen der DGL.   (b) Ist (mit ) eine -fache komplexe Nullstelle, so liefern Real- und Imaginärteil von , , die unabhängigen, reellen Lösungen      Allgemeine Lösung der homogenen DGL   Sind die nach obigen Fällen aus den Nullstellen des charakteristischen Polynoms bestimmten Fundamentallösungen, so lautet die allgemeine Lösung  Die freien Parameter lassen sich durch gegebene Anfangswerte zu einer partikulären Lösung festlegen.     Rechenbeispiel: Doppelte reelle Nullstelle (Fall 3a) (zur Vertiefung)   Bestimmen Sie die allgemeine Lösung von .    Das charakteristische Polynom lässt sich mit der zweiten binomischen Formel faktorisieren: . Es gibt also nur die eine doppelte Nullstelle . Nach Fall 3a gehören dazu die Fundamentallösungen und , und die allgemeine Lösung ist Dass der merkwürdige Faktor tatsächlich funktioniert, zeigt die Probe: Für ist und , also ✓. Der Ansatz allein hätte bei einer doppelten Nullstelle nur eine Lösung geliefert, eine DGL zweiter Ordnung braucht aber zwei.     Rechenbeispiel: Einfaches komplexes Nullstellenpaar (Fall 2) (zur Vertiefung)   Bestimmen Sie die allgemeine Lösung von .    Die Lösungsformel für quadratische Gleichungen liefert für die Nullstellen Mit , liefert Fall 2 die Fundamentallösungen und , also      Rechenbeispiel: Kombination von Fall 1 und Fall 2   Bestimmen Sie die allgemeine Lösung von . ( Hinweis : Eine Nullstelle ist .)    Für bestätigt Einsetzen . Polynomdivision liefert (Probe: ), und hat die Nullstellen (Fall 2 mit , ). Zusammen mit der einfachen reellen Nullstelle (Fall 1) ergibt sich die allgemeine Lösung      Rechenbeispiel: Doppeltes komplexes Nullstellenpaar (Fall 3b) (zur Vertiefung)   Bestimmen Sie die allgemeine Lösung von .    Die erste binomische Formel (in ) liefert , also hat das doppelte komplex konjugierte Nullstellenpaar ( , , ). Nach Fall 3b gehören dazu die vier Fundamentallösungen , , , , und die allgemeine Lösung ist Das Polynom ist übrigens ein alter Bekannter: In hatten wir festgestellt, dass es in gar keine Nullstelle hat, in aber zwei doppelte. Genau diese Vielfachheiten entscheiden jetzt über die Faktoren in der Lösung.    Die Methode Exponentialansatz, charakteristisches Polynom, Nullstellen ist so mächtig, dass sie weit über Differenzialgleichungen hinaus funktioniert. Ein kleiner Seitenblick zum Schluss dieses Unterabschnitts zeigt sie bei einer Folge, die Ihnen in begegnet ist.   Seitenblick: Eine Formel für die Fibonacci-Zahlen   Die Fibonacci-Zahlen erfüllen die Rekursion mit , . (In haben wir mit begonnen; der Startwert passt dazu, denn dann ist .) Übertragen Sie den Exponentialansatz auf Folgen, indem Sie einsetzen, und bestimmen Sie eine explizite Formel für .    Einsetzen ergibt , und Division durch liefert das charakteristische Polynom der Rekursion, also (der Goldene Schnitt) und . Wie bei einer DGL ist jede Kombination eine Lösung der Rekursion, und die Anfangswerte legen die Konstanten fest: und , also . Das ergibt die Formel von Binet  Erstaunlich: Obwohl lauter Wurzeln aus vorkommen, kommt immer eine ganze Zahl heraus. Und weil ist, wird der zweite Summand schnell winzig; für etwa ist , und tatsächlich ist . Die Fibonacci-Zahlen wachsen also im Wesentlichen geometrisch mit dem Faktor .    Benannt ist die Formel nach Jacques Binet, der sie 1843 veröffentlichte. Abraham de Moivre und Daniel Bernoulli kannten sie allerdings schon rund ein Jahrhundert früher — in der Mathematik trägt eine Formel nicht selten den Namen eines späteren Entdeckers.    Lösung inhomogener linearer DGL höherer Ordnung  Wir betrachten nun eine inhomogene lineare DGL mit konstanten Koeffizienten Das Vorgehen ist analog zu den linearen DGL erster Ordnung aus :    Bestimmen Sie die allgemeine Lösung der zugehörigen homogenen DGL ( ).  Finden Sie über einen Ansatz vom Typ rechte Seite eine partikuläre Lösung  der inhomogenen DGL.  Die allgemeine Lösung der inhomogenen DGL ist dann .    Schritt 3 ist kein Zufall: Ist eine weitere Lösung der inhomogenen DGL, so löst die Differenz die homogene DGL (da sich die rechte Seite beim Subtrahieren weghebt), lässt sich also als schreiben.  Welchen Ansatz man für wählt, hängt von der Störfunktion ab — und davon, ob der zu gehörende Exponent zufällig mit einer Nullstelle des charakteristischen Polynoms zusammenfällt ( Resonanzfall ). In diesem Fall wird der Standardansatz mit dem Faktor versehen, wobei die Vielfachheit der Nullstelle ist.   Ansatz vom Typ rechte Seite ( = Vielfachheit der Nullstelle im Resonanzfall)      Störfunktion  Ansatz für    Polynom vom Grad  , falls keine Nullstelle von ist; sonst     , falls keine Nullstelle von ist; sonst     , falls keine Nullstelle von ist; sonst     , falls keine Nullstelle von ist; sonst mit Faktor     Die Koeffizienten des Ansatzes bestimmt man, indem man den Ansatz in die DGL einsetzt und die Koeffizienten beider Seiten vergleicht — bei Polynomen die Koeffizienten der Potenzen , bei trigonometrischen Termen die von und . Das führt auf ein kleines lineares Gleichungssystem.  Die Idee hinter der Tabelle: Ableiten führt Polynome, Exponential- und trigonometrische Funktionen in Funktionen derselben Bauart über. Setzt man einen Ansatz dieser Bauart in die linke Seite ein, kommt wieder eine Funktion dieser Bauart heraus, und man muss nur noch die Koeffizienten passend wählen. Bei exponentiellen und trigonometrischen Störfunktionen löst der Standardansatz im Resonanzfall bereits die homogene Gleichung und liefert links (bei Polynomen verliert er an Grad); erst der Faktor hilft.   Rechenbeispiel: Ansatz vom Typ rechte Seite ohne Resonanz   Bestimmen Sie die allgemeine Lösung von .    Das charakteristische Polynom hat die doppelte Nullstelle , also . Da  keine Nullstelle von ist, machen wir den Ansatz . Mit , liefert Einsetzen also nach Koeffizientenvergleich (aus ), (aus ), und (aus ). Also , und die allgemeine Lösung ist      Rechenbeispiel: Exponentielle Störfunktion im Resonanzfall   Bestimmen Sie die allgemeine Lösung von .    Das charakteristische Polynom hat die doppelte Nullstelle , also . Die Störfunktion gehört zu — Resonanz mit Vielfachheit . Ansatz: mit den Ableitungen (Produktregel) Einsetzen in die DGL: Alle -Terme heben sich weg — das ist typisch für den Resonanzfall. Aus folgt . Die allgemeine Lösung ist      Rechenbeispiel: Gedämpft-trigonometrische Störfunktion (zur Vertiefung)   Bestimmen Sie eine partikuläre Lösung von .    Das charakteristische Polynom hat die Nullstellen . Die Störfunktion gehört zu ; das ist keine Nullstelle von — kein Resonanzfall. Ansatz: . Zweimaliges Ableiten (Produkt- und Kettenregel) und Einsetzen ergibt nach dem Sortieren nach und  Das soll gleich sein, also und . Aus der ersten Gleichung folgt , eingesetzt in die zweite , also , und       Anwendung: Der harmonische Oszillator  Als durchgehendes Anwendungsbeispiel betrachten wir ein Federpendel : eine Masse , die an einer Feder mit Federkonstante hängt und deren Bewegung durch Reibung mit Koeffizient gedämpft wird. Für die Auslenkung aus der Ruhelage gilt (ohne äußere Krafteinwirkung) und unter Einwirkung einer äußeren Kraft  Mit der Abkürzung (Dämpfung wächst proportional zur Geschwindigkeit) und (Rückstellkraft wächst proportional zur Auslenkung) erhält die DGL die Normalform die auch für andere schwingende Systeme gilt — etwa für die Kondensatorladung eines RLC-Schwingkreises (siehe unten). Wir lösen zunächst den homogenen Fall ( , freie Schwingung), dann den inhomogenen Fall (erzwungene Schwingung).  Das charakteristische Polynom hat die Nullstellen . Je nach Vorzeichen von unterscheiden wir vier Fälle.   Fall 1a: Freie ungedämpfte Schwingung ( )  Ohne Dämpfung wird die DGL zu mit rein imaginären Nullstellen . Die allgemeine Lösung ist eine ungedämpfte Schwingung mit konstanter Amplitude.    Fall 1b: Freie gedämpfte Schwingung ( )  Für unterscheiden wir nach dem Vorzeichen von drei Unterfälle: schwache Dämpfung ( ), den aperiodischen Grenzfall ( ) und den Kriechfall ( ).    Rechenbeispiel: Schwache Dämpfung   Lösen Sie mit , .    Hier ist , ; wegen liegt schwache Dämpfung vor. Die Nullstellen liefern Mit der Produktregel ist Aus und folgt Das System schwingt oszillierend um die Ruhelage, mit einer Amplitude, die exponentiell gegen abklingt.     Rechenbeispiel: Aperiodischer Grenzfall   Lösen Sie mit , .    Hier ist , : der aperiodische Grenzfall. Das charakteristische Polynom hat die doppelte Nullstelle , also und (Produktregel) . Aus und folgt Das System kehrt möglichst schnell in die Ruhelage zurück, ohne zu schwingen — der Grenzfall zwischen Schwingung und reinem Abklingen.     Anwendungsbeispiel: Einen Stoßdämpfer auslegen (zur Vertiefung)   Auf ein Rad eines Autos entfällt eine Masse von  kg, die Feder hat die Federkonstante  N\/m. Welche Dämpfungskonstante (in Ns\/m) muss der Stoßdämpfer haben, damit die Karosserie nach einer Bodenwelle im aperiodischen Grenzfall zur Ruhe kommt?    Es ist , also pro Sekunde. Der aperiodische Grenzfall verlangt , und mit folgt Ein schwächerer Dämpfer lässt das Auto nachwippen (schwache Dämpfung), ein stärkerer macht die Federung hart und träge (Kriechfall). In der Praxis wählt man deutlich weniger, etwa bis der Grenzfall-Dämpfung, weil ein leichtes Nachschwingen als komfortabler empfunden wird — aber der Grenzfall ist der Bezugspunkt der Auslegung.     Rechenbeispiel: Kriechfall   Lösen Sie mit , .    Hier ist , ; wegen liegt der Kriechfall vor. Die Nullstellen sind reell und verschieden: , , also . Aus und folgt (Einsetzen von ) , , also Beide Anteile fallen monoton und ohne zu schwingen ab, wobei deutlich schneller abklingt als .     Die vier Fälle der freien Schwingung (also ) mit denselben Anfangswerten , : ungedämpft ( ), schwache Dämpfung ( ), aperiodischer Grenzfall ( ) und Kriechfall ( ). Der aperiodische Grenzfall erreicht die Ruhelage am schnellsten ohne Überschwingen.    Vier Kurven über der Zeitachse, alle starten bei mit waagerechter Tangente. Die ungedämpfte Kurve ist eine reine Kosinusschwingung mit konstanter Amplitude. Die schwach gedämpfte Kurve schwingt um null mit exponentiell abnehmender Amplitude. Die Kurve des aperiodischen Grenzfalls fällt monoton und schnell gegen null, ohne die Achse zu kreuzen. Die Kriechfall-Kurve fällt ebenfalls monoton gegen null, aber deutlich langsamer.      In der Praxis stellt sich oft die umgekehrte Frage: Man beobachtet ein schwingendes System, kennt aber seine Parameter nicht. Dann liest man die Nullstellen des charakteristischen Polynoms aus der gemessenen Lösung ab und baut das Polynom daraus zusammen — genau wie in , nur mit einer DGL am Ende.   Anwendungsbeispiel: Vom Messsignal zurück zur Differenzialgleichung   Ein Wegsensor an einer federnd aufgehängten Versuchsmasse (  kg) zeichnet nach einem Stoß die Auslenkung auf ( in mm, in Sekunden). Welche Differenzialgleichung beschreibt das System? Wie groß sind Federkonstante (in N\/m) und Dämpfungskonstante (in Ns\/m)?    Die Lösung besteht aus und , gehört also nach zum komplexen Nullstellenpaar . Das charakteristische Polynom ist daher und die DGL lautet . Probe: Mit der Produktregel ist also . Damit ist und , und mit , folgt Die Messung verrät die Parameter sehr direkt: Die Abklingrate liefert den Realteil , die Schwingungsdauer  s den Imaginärteil . Aus beiden zusammen ergibt sich . Dieses Rückwärtsrechnen vom Signal zum Modell heißt Systemidentifikation und ist in der Zustandsüberwachung von Maschinen Alltag: Ändert sich die gemessene Eigenfrequenz, hat sich meist an der Mechanik etwas verändert — etwa ein Riss oder eine gelockerte Schraube.     Fall 2: Erzwungene Schwingung und Resonanz  Wirkt eine sinusförmige äußere Kraft mit Anregungsfrequenz , so liefert der Ansatz vom Typ rechte Seite eine partikuläre Lösung der Form , solange keine Nullstelle des charakteristischen Polynoms ist — das System übernimmt (nach einer Einschwingzeit) die Frequenz der Anregung. Ist das System jedoch ungedämpft und wird genau mit seiner Eigenfrequenz angeregt, so ist eine Nullstelle von , und es tritt Resonanz ein.    Rechenbeispiel: Resonanzkatastrophe   Bestimmen Sie die allgemeine Lösung des ungedämpften, angeregten Systems .    Das charakteristische Polynom hat die Nullstellen . Die Anregungsfrequenz trifft also genau die Eigenfrequenz — Resonanzfall. Ansatz: . Zweimaliges Ableiten mit der Produktregel liefert und beim Einsetzen in hebt sich der -Anteil gegen weg: Koeffizientenvergleich ergibt , , also Der Term wächst unbeschränkt: Die Amplitude der Schwingung nimmt linear mit der Zeit zu — eine Resonanzkatastrophe .    Das ist ein Idealfall: In der Praxis (mit ) bleibt die Amplitude einer erzwungenen Schwingung endlich, kann aber bei kleiner Dämpfung und Anregung nahe sehr groß werden. Deshalb brechen Soldaten auf Brücken den Gleichschritt: 1831 stürzte bei Manchester die Broughton Suspension Bridge ein, als eine Kompanie im Gleichschritt darüber marschierte (ein schadhafter Bolzen spielte vermutlich mit). Und als in London im Jahr 2000 die Millennium Bridge eröffnet wurde, begann sie seitlich zu schwingen, weil die Fußgänger ihre Schritte unbewusst an das Schwanken anpassten und es so immer weiter anfachten; die Brücke wurde nach zwei Tagen gesperrt und erst mit zusätzlichen Dämpfern wieder freigegeben. (Der berühmte Einsturz der Tacoma-Narrows-Brücke 1940 im Wind beruht dagegen auf einem verwandten, aber anderen Mechanismus, dem selbsterregten Flattern.)  Wie groß die Ausschläge bei gedämpften Systemen werden, lässt sich mit einem Trick aus elegant ausrechnen. Statt der reellen Anregung betrachtet man die komplexe Anregung , deren Realteil sie ist. Weil die DGL reelle Koeffizienten hat, ist der Realteil einer komplexen Lösung dann eine Lösung der reellen Gleichung — und der Exponentialansatz spart die ganze Rechnerei mit Sinus und Kosinus.   Anwendungsbeispiel: Die Resonanzkurve mit komplexen Zahlen   Ein gedämpftes System habe , und . Bestimmen Sie mit dem komplexen Ansatz für die Amplitude der erzwungenen Schwingung in Abhängigkeit von der Anregungsfrequenz , und werten Sie sie für , und aus.    Mit und wird aus der DGL eine einzige komplexe Gleichung für , und damit Dabei half die Quotientenregel für Beträge aus . Warum ist die Amplitude? Schreibt man , so ist : eine Schwingung mit Amplitude und Phasenverschiebung . Mit den Zahlenwerten ist , also Langsames Rütteln ( ) verschiebt das System einfach mit; bei der Eigenfrequenz ist der Ausschlag viermal so groß; sehr schnelles Rütteln kommt kaum noch an, das System ist zu träge. Wer schon eine Waschmaschine beim Hochdrehen zum Schleudern beobachtet hat, kennt diese Resonanzkurve : Beim Durchfahren einer bestimmten Drehzahl wackelt sie heftig, danach läuft sie wieder ruhig. Der Nenner ist übrigens genau das charakteristische Polynom , ausgewertet bei . Beim Tiefpassfilter in steht mit ebenso das charakteristische Polynom seiner DGL erster Ordnung bei im Nenner — Schwingkreise und Filter sind mathematisch Geschwister.     Anwendungsbeispiel: RLC-Schwingkreis  Dieselbe Mathematik beschreibt einen elektrischen RLC-Reihenschwingkreis aus Induktivität , Widerstand und Kapazität : Für die Kondensatorladung gilt (ohne äußere Spannungsquelle) also genau die Form des freien Federpendels mit und . Ein großer Widerstand entspricht dabei starker Dämpfung: Die Ladung baut sich ab, ohne die Polarität zu wechseln (Kriechfall bzw. aperiodischer Grenzfall), während ein kleiner Widerstand zu einer gedämpft oszillierenden Entladung führt (schwache Dämpfung) — exakt dieselbe Fallunterscheidung wie beim mechanischen Pendel. Für  H und  µF ist ; der aperiodische Grenzfall liegt bei . Mit kleinerem Widerstand schwingt der Kreis.    Anwendungsbeispiel: Momentum im Gradientenabstieg  Die Fallunterscheidung des gedämpften Oszillators taucht auch beim Training neuronaler Netze wieder auf. Optimierer mit Momentum (der klassische Heavy-Ball -Ansatz) aktualisieren den Parametervektor nicht nur anhand des aktuellen Gradienten, sondern addieren einen Trägheitsterm, der die letzte Bewegungsrichtung fortsetzt. Im zeitkontinuierlichen Grenzfall lässt sich der Fehler (Abstand vom Optimum) einer solchen Trajektorie in der Nähe eines Minimums näherungsweise durch genau unsere Oszillator-DGL beschreiben, wobei von der Krümmung der Kostenfunktion und vom Momentum-Parameter abhängt. Zu schwache Dämpfung ( ) lässt die Optimierung um das Minimum überschwingen und oszillieren, zu starke Dämpfung ( ) macht die Konvergenz unnötig langsam. Der aperiodische Grenzfall markiert damit — genau wie beim Federpendel — die schnellstmögliche Annäherung ohne Überschwingen, ein Kriterium, das bei der Wahl von Lernrate und Momentum-Parameter in der Praxis eine Rolle spielt.     Zusammenfassung     Lineare DGL mit konstanten Koeffizienten:  ; homogen für .   Charakteristisches Polynom  (aus dem Ansatz ). Jede Nullstelle liefert Fundamentallösungen: reell einfach ; einfach , ; -fach zusätzlich Faktoren .   Allgemeine Lösung homogen:  ; die aus Anfangsbedingungen. Rückwärts: Aus den Fundamentallösungen die Nullstellen ablesen, als Produkt der Linearfaktoren ausmultiplizieren, DGL ablesen (Systemidentifikation). Derselbe Exponentialansatz liefert für die Fibonacci-Rekursion die Binet-Formel.   Inhomogen:  . Partikuläre Lösung per Ansatz vom Typ rechte Seite (Polynom, , , Produkte davon), Koeffizienten durch Einsetzen und Vergleich. Resonanz: Fällt der Exponent der Störfunktion mit einer -fachen Nullstelle von zusammen, Ansatz mit multiplizieren.   Harmonischer Oszillator  , Nullstellen : ungedämpfte Schwingung; abklingende Schwingung; aperiodischer Grenzfall ( ); Kriechfall. Anregung mit ohne Dämpfung: Resonanzkatastrophe (Amplitude wächst wie ). Mit Dämpfung bleibt die Amplitude endlich, , wird aber bei kleinem und sehr groß — der Grund, warum man auf Brücken den Gleichschritt bricht.   Dieselbe Gleichung beschreibt Federpendel ( , ), RLC-Schwingkreis ( , ) und die Fehlerdynamik eines Optimierers mit Momentum.      Übungsaufgaben    Welche Ordnung hat die DGL ? Ist sie linear? Ist sie homogen oder inhomogen? Hat sie konstante Koeffizienten?    Die höchste auftretende Ableitung ist , die DGL hat also Ordnung . Sie ist linear, da jeweils nur in erster Potenz auftreten. Wegen der rechten Seite ist sie inhomogen . Der Koeffizient von ist nicht konstant, also hat die DGL keine konstanten Koeffizienten.      Bestimmen Sie die allgemeine Lösung der DGL .    Das charakteristische Polynom hat die Nullstellen und . Die allgemeine Lösung lautet       Bestimmen Sie die allgemeine Lösung der DGL .    Das charakteristische Polynom hat die Nullstellen , also . Da keine Nullstelle von ist, machen wir für die konstante Störfunktion den Ansatz . Einsetzen liefert . Die allgemeine Lösung ist       Ein gedämpftes Federpendel genügt der DGL . Welcher Dämpfungsfall liegt vor, und wie lautet die allgemeine Lösung?    In der Normalform ist , . Wegen liegt der Kriechfall vor. Die Nullstellen des charakteristischen Polynoms sind , also , . Die allgemeine Lösung lautet      "
},
{
  "id": "sec-lineare-dgl-hoeherer-ordnung-2",
  "level": "2",
  "url": "sec-lineare-dgl-hoeherer-ordnung.html#sec-lineare-dgl-hoeherer-ordnung-2",
  "type": "Lernziele",
  "number": "5.2",
  "title": "",
  "body": "  Nach diesem Abschnitt können Sie    lineare Differenzialgleichungen höherer Ordnung erkennen und nach Homogenität und konstanten Koeffizienten klassifizieren;  das charakteristische Polynom aufstellen und aus seinen Nullstellen — reell, komplex oder mehrfach — die allgemeine Lösung der homogenen Gleichung ablesen;  Anfangswertprobleme zweiter Ordnung lösen und umgekehrt aus einer gegebenen Lösung die Differenzialgleichung rekonstruieren;  partikuläre Lösungen inhomogener Gleichungen mit dem Ansatz vom Typ rechte Seite bestimmen, auch im Resonanzfall;  die Dämpfungsfälle des harmonischen Oszillators unterscheiden und auf Federpendel, RLC-Schwingkreis und Momentum-Optimierer übertragen.   "
},
{
  "id": "sub-lineare-dgl-hoeherer-ordnung-definition-3",
  "level": "2",
  "url": "sec-lineare-dgl-hoeherer-ordnung.html#sub-lineare-dgl-hoeherer-ordnung-definition-3",
  "type": "Absatz (with a defined term)",
  "number": "",
  "title": "",
  "body": "lineare Differenzialgleichungen höherer Ordnung mit konstanten Koeffizienten "
},
{
  "id": "def-lineare-dgl-hoeherer-ordnung",
  "level": "2",
  "url": "sec-lineare-dgl-hoeherer-ordnung.html#def-lineare-dgl-hoeherer-ordnung",
  "type": "Definition",
  "number": "5.2.1",
  "title": "Lineare DGL der Ordnung <span class=\"process-math\">\\(n\\)<\/span>.",
  "body": " Lineare DGL der Ordnung   Eine Differenzialgleichung der Ordnung heißt linear , wenn sie sich in der Form schreiben lässt, wobei die Koeffizienten Funktionen sind.    Sind alle  konstant , so hat die DGL konstante Koeffizienten .  Ist , so heißt die DGL homogen , andernfalls inhomogen .     "
},
{
  "id": "ex-linearitaet-hoeherer-ordnung-erkennen",
  "level": "2",
  "url": "sec-lineare-dgl-hoeherer-ordnung.html#ex-linearitaet-hoeherer-ordnung-erkennen",
  "type": "Beispiel",
  "number": "5.2.2",
  "title": "Rechenbeispiel: Linearität, Homogenität und konstante Koeffizienten erkennen.",
  "body": " Rechenbeispiel: Linearität, Homogenität und konstante Koeffizienten erkennen   Welche der folgenden DGL sind linear? Welche davon sind homogen bzw. inhomogen, und welche haben konstante Koeffizienten?             Der Term tritt nicht in erster Potenz auf — nicht linear .  Alle Koeffizienten ( ) sind Zahlen, also konstant, und die rechte Seite ist von verschieden — linear , inhomogen , konstante Koeffizienten .  Der Koeffizient von ist nicht konstant, aber die Gleichung ist in jeweils von erster Potenz und die rechte Seite ist — linear , homogen , aber nicht mit konstanten Koeffizienten.     "
},
{
  "id": "def-charakteristisches-polynom",
  "level": "2",
  "url": "sec-lineare-dgl-hoeherer-ordnung.html#def-charakteristisches-polynom",
  "type": "Definition",
  "number": "5.2.3",
  "title": "Charakteristisches Polynom.",
  "body": " Charakteristisches Polynom   Das charakteristische Polynom der obigen DGL ist    "
},
{
  "id": "thm-nullstelle-einfach-reell",
  "level": "2",
  "url": "sec-lineare-dgl-hoeherer-ordnung.html#thm-nullstelle-einfach-reell",
  "type": "Satz",
  "number": "5.2.4",
  "title": "Fall 1: Einfache reelle Nullstelle.",
  "body": " Fall 1: Einfache reelle Nullstelle   Ist eine einfache Nullstelle von , so ist eine Lösung der DGL.   "
},
{
  "id": "ex-charakteristisches-polynom-zwei-reelle-nullstellen",
  "level": "2",
  "url": "sec-lineare-dgl-hoeherer-ordnung.html#ex-charakteristisches-polynom-zwei-reelle-nullstellen",
  "type": "Beispiel",
  "number": "5.2.5",
  "title": "Rechenbeispiel: Zwei verschiedene reelle Nullstellen (Fall 1) (zur Vertiefung).",
  "body": " Rechenbeispiel: Zwei verschiedene reelle Nullstellen (Fall 1) (zur Vertiefung)   Bestimmen Sie die allgemeine Lösung von und die Lösung zu , .     hat die einfachen Nullstellen und . Beide liefern nach Fall 1 eine Lösung, und die allgemeine Lösung ist (vorgreifend auf ) Probe für : ✓. Die Anfangswerte liefern das Gleichungssystem Doppelte erste Gleichung zur zweiten addiert: , also , und . Zwei Anfangsbedingungen für zwei Konstanten — wie beim freien Fall in .   "
},
{
  "id": "thm-nullstelle-komplex-einfach",
  "level": "2",
  "url": "sec-lineare-dgl-hoeherer-ordnung.html#thm-nullstelle-komplex-einfach",
  "type": "Satz",
  "number": "5.2.6",
  "title": "Fall 2: Einfaches Paar komplex konjugierter Nullstellen.",
  "body": " Fall 2: Einfaches Paar komplex konjugierter Nullstellen   Ist (mit ) eine einfache Nullstelle von , so ist auch die konjugiert komplexe Zahl eine einfache Nullstelle (da die Koeffizienten von reell sind). Real- und Imaginärteil der komplexen Lösung liefern dann zwei unabhängige, reelle Lösungen    "
},
{
  "id": "thm-nullstelle-mehrfach",
  "level": "2",
  "url": "sec-lineare-dgl-hoeherer-ordnung.html#thm-nullstelle-mehrfach",
  "type": "Satz",
  "number": "5.2.7",
  "title": "Fall 3: Mehrfache Nullstelle der Ordnung <span class=\"process-math\">\\(k\\)<\/span>.",
  "body": " Fall 3: Mehrfache Nullstelle der Ordnung    (a) Ist eine -fache reelle Nullstelle von , so bilden  unabhängige Lösungen der DGL.   (b) Ist (mit ) eine -fache komplexe Nullstelle, so liefern Real- und Imaginärteil von , , die unabhängigen, reellen Lösungen    "
},
{
  "id": "thm-allgemeine-loesung-homogen-hoehere-ordnung",
  "level": "2",
  "url": "sec-lineare-dgl-hoeherer-ordnung.html#thm-allgemeine-loesung-homogen-hoehere-ordnung",
  "type": "Satz",
  "number": "5.2.8",
  "title": "Allgemeine Lösung der homogenen DGL.",
  "body": " Allgemeine Lösung der homogenen DGL   Sind die nach obigen Fällen aus den Nullstellen des charakteristischen Polynoms bestimmten Fundamentallösungen, so lautet die allgemeine Lösung  Die freien Parameter lassen sich durch gegebene Anfangswerte zu einer partikulären Lösung festlegen.   "
},
{
  "id": "ex-charakteristisches-polynom-doppelte-nullstelle",
  "level": "2",
  "url": "sec-lineare-dgl-hoeherer-ordnung.html#ex-charakteristisches-polynom-doppelte-nullstelle",
  "type": "Beispiel",
  "number": "5.2.9",
  "title": "Rechenbeispiel: Doppelte reelle Nullstelle (Fall 3a) (zur Vertiefung).",
  "body": " Rechenbeispiel: Doppelte reelle Nullstelle (Fall 3a) (zur Vertiefung)   Bestimmen Sie die allgemeine Lösung von .    Das charakteristische Polynom lässt sich mit der zweiten binomischen Formel faktorisieren: . Es gibt also nur die eine doppelte Nullstelle . Nach Fall 3a gehören dazu die Fundamentallösungen und , und die allgemeine Lösung ist Dass der merkwürdige Faktor tatsächlich funktioniert, zeigt die Probe: Für ist und , also ✓. Der Ansatz allein hätte bei einer doppelten Nullstelle nur eine Lösung geliefert, eine DGL zweiter Ordnung braucht aber zwei.   "
},
{
  "id": "ex-charakteristisches-polynom-komplexe-nullstelle",
  "level": "2",
  "url": "sec-lineare-dgl-hoeherer-ordnung.html#ex-charakteristisches-polynom-komplexe-nullstelle",
  "type": "Beispiel",
  "number": "5.2.10",
  "title": "Rechenbeispiel: Einfaches komplexes Nullstellenpaar (Fall 2) (zur Vertiefung).",
  "body": " Rechenbeispiel: Einfaches komplexes Nullstellenpaar (Fall 2) (zur Vertiefung)   Bestimmen Sie die allgemeine Lösung von .    Die Lösungsformel für quadratische Gleichungen liefert für die Nullstellen Mit , liefert Fall 2 die Fundamentallösungen und , also    "
},
{
  "id": "ex-charakteristisches-polynom-kombiniert",
  "level": "2",
  "url": "sec-lineare-dgl-hoeherer-ordnung.html#ex-charakteristisches-polynom-kombiniert",
  "type": "Beispiel",
  "number": "5.2.11",
  "title": "Rechenbeispiel: Kombination von Fall 1 und Fall 2.",
  "body": " Rechenbeispiel: Kombination von Fall 1 und Fall 2   Bestimmen Sie die allgemeine Lösung von . ( Hinweis : Eine Nullstelle ist .)    Für bestätigt Einsetzen . Polynomdivision liefert (Probe: ), und hat die Nullstellen (Fall 2 mit , ). Zusammen mit der einfachen reellen Nullstelle (Fall 1) ergibt sich die allgemeine Lösung    "
},
{
  "id": "ex-charakteristisches-polynom-doppelt-komplex",
  "level": "2",
  "url": "sec-lineare-dgl-hoeherer-ordnung.html#ex-charakteristisches-polynom-doppelt-komplex",
  "type": "Beispiel",
  "number": "5.2.12",
  "title": "Rechenbeispiel: Doppeltes komplexes Nullstellenpaar (Fall 3b) (zur Vertiefung).",
  "body": " Rechenbeispiel: Doppeltes komplexes Nullstellenpaar (Fall 3b) (zur Vertiefung)   Bestimmen Sie die allgemeine Lösung von .    Die erste binomische Formel (in ) liefert , also hat das doppelte komplex konjugierte Nullstellenpaar ( , , ). Nach Fall 3b gehören dazu die vier Fundamentallösungen , , , , und die allgemeine Lösung ist Das Polynom ist übrigens ein alter Bekannter: In hatten wir festgestellt, dass es in gar keine Nullstelle hat, in aber zwei doppelte. Genau diese Vielfachheiten entscheiden jetzt über die Faktoren in der Lösung.   "
},
{
  "id": "ex-binet-fibonacci",
  "level": "2",
  "url": "sec-lineare-dgl-hoeherer-ordnung.html#ex-binet-fibonacci",
  "type": "Beispiel",
  "number": "5.2.13",
  "title": "Seitenblick: Eine Formel für die Fibonacci-Zahlen.",
  "body": " Seitenblick: Eine Formel für die Fibonacci-Zahlen   Die Fibonacci-Zahlen erfüllen die Rekursion mit , . (In haben wir mit begonnen; der Startwert passt dazu, denn dann ist .) Übertragen Sie den Exponentialansatz auf Folgen, indem Sie einsetzen, und bestimmen Sie eine explizite Formel für .    Einsetzen ergibt , und Division durch liefert das charakteristische Polynom der Rekursion, also (der Goldene Schnitt) und . Wie bei einer DGL ist jede Kombination eine Lösung der Rekursion, und die Anfangswerte legen die Konstanten fest: und , also . Das ergibt die Formel von Binet  Erstaunlich: Obwohl lauter Wurzeln aus vorkommen, kommt immer eine ganze Zahl heraus. Und weil ist, wird der zweite Summand schnell winzig; für etwa ist , und tatsächlich ist . Die Fibonacci-Zahlen wachsen also im Wesentlichen geometrisch mit dem Faktor .   "
},
{
  "id": "sub-loesung-inhomogene-lineare-dgl-hoeherer-ordnung-3",
  "level": "2",
  "url": "sec-lineare-dgl-hoeherer-ordnung.html#sub-loesung-inhomogene-lineare-dgl-hoeherer-ordnung-3",
  "type": "Absatz (with a defined term)",
  "number": "",
  "title": "",
  "body": "Ansatz vom Typ rechte Seite partikuläre Lösung "
},
{
  "id": "sub-loesung-inhomogene-lineare-dgl-hoeherer-ordnung-5",
  "level": "2",
  "url": "sec-lineare-dgl-hoeherer-ordnung.html#sub-loesung-inhomogene-lineare-dgl-hoeherer-ordnung-5",
  "type": "Absatz (with a defined term)",
  "number": "",
  "title": "",
  "body": "Resonanzfall "
},
{
  "id": "tab-ansatz-typ-rechte-seite",
  "level": "2",
  "url": "sec-lineare-dgl-hoeherer-ordnung.html#tab-ansatz-typ-rechte-seite",
  "type": "Tabelle",
  "number": "5.2.14",
  "title": "Ansatz vom Typ rechte Seite (<span class=\"process-math\">\\(k\\)<\/span> = Vielfachheit der Nullstelle im Resonanzfall)",
  "body": " Ansatz vom Typ rechte Seite ( = Vielfachheit der Nullstelle im Resonanzfall)      Störfunktion  Ansatz für    Polynom vom Grad  , falls keine Nullstelle von ist; sonst     , falls keine Nullstelle von ist; sonst     , falls keine Nullstelle von ist; sonst     , falls keine Nullstelle von ist; sonst mit Faktor    "
},
{
  "id": "ex-ansatz-rechte-seite-polynom",
  "level": "2",
  "url": "sec-lineare-dgl-hoeherer-ordnung.html#ex-ansatz-rechte-seite-polynom",
  "type": "Beispiel",
  "number": "5.2.15",
  "title": "Rechenbeispiel: Ansatz vom Typ rechte Seite ohne Resonanz.",
  "body": " Rechenbeispiel: Ansatz vom Typ rechte Seite ohne Resonanz   Bestimmen Sie die allgemeine Lösung von .    Das charakteristische Polynom hat die doppelte Nullstelle , also . Da  keine Nullstelle von ist, machen wir den Ansatz . Mit , liefert Einsetzen also nach Koeffizientenvergleich (aus ), (aus ), und (aus ). Also , und die allgemeine Lösung ist    "
},
{
  "id": "ex-ansatz-rechte-seite-exponentiell-resonanz",
  "level": "2",
  "url": "sec-lineare-dgl-hoeherer-ordnung.html#ex-ansatz-rechte-seite-exponentiell-resonanz",
  "type": "Beispiel",
  "number": "5.2.16",
  "title": "Rechenbeispiel: Exponentielle Störfunktion im Resonanzfall.",
  "body": " Rechenbeispiel: Exponentielle Störfunktion im Resonanzfall   Bestimmen Sie die allgemeine Lösung von .    Das charakteristische Polynom hat die doppelte Nullstelle , also . Die Störfunktion gehört zu — Resonanz mit Vielfachheit . Ansatz: mit den Ableitungen (Produktregel) Einsetzen in die DGL: Alle -Terme heben sich weg — das ist typisch für den Resonanzfall. Aus folgt . Die allgemeine Lösung ist    "
},
{
  "id": "ex-ansatz-rechte-seite-gedaempft-trigonometrisch",
  "level": "2",
  "url": "sec-lineare-dgl-hoeherer-ordnung.html#ex-ansatz-rechte-seite-gedaempft-trigonometrisch",
  "type": "Beispiel",
  "number": "5.2.17",
  "title": "Rechenbeispiel: Gedämpft-trigonometrische Störfunktion (zur Vertiefung).",
  "body": " Rechenbeispiel: Gedämpft-trigonometrische Störfunktion (zur Vertiefung)   Bestimmen Sie eine partikuläre Lösung von .    Das charakteristische Polynom hat die Nullstellen . Die Störfunktion gehört zu ; das ist keine Nullstelle von — kein Resonanzfall. Ansatz: . Zweimaliges Ableiten (Produkt- und Kettenregel) und Einsetzen ergibt nach dem Sortieren nach und  Das soll gleich sein, also und . Aus der ersten Gleichung folgt , eingesetzt in die zweite , also , und    "
},
{
  "id": "sub-harmonischer-oszillator-2",
  "level": "2",
  "url": "sec-lineare-dgl-hoeherer-ordnung.html#sub-harmonischer-oszillator-2",
  "type": "Absatz (with a defined term)",
  "number": "",
  "title": "",
  "body": "Federpendel "
},
{
  "id": "rem-schwingung-ungedaempft",
  "level": "2",
  "url": "sec-lineare-dgl-hoeherer-ordnung.html#rem-schwingung-ungedaempft",
  "type": "Bemerkung",
  "number": "5.2.18",
  "title": "Fall 1a: Freie ungedämpfte Schwingung (<span class=\"process-math\">\\(\\beta=0\\)<\/span>).",
  "body": " Fall 1a: Freie ungedämpfte Schwingung ( )  Ohne Dämpfung wird die DGL zu mit rein imaginären Nullstellen . Die allgemeine Lösung ist eine ungedämpfte Schwingung mit konstanter Amplitude.  "
},
{
  "id": "rem-schwingung-gedaempft-uebersicht",
  "level": "2",
  "url": "sec-lineare-dgl-hoeherer-ordnung.html#rem-schwingung-gedaempft-uebersicht",
  "type": "Bemerkung",
  "number": "5.2.19",
  "title": "Fall 1b: Freie gedämpfte Schwingung (<span class=\"process-math\">\\(\\beta&gt;0\\)<\/span>).",
  "body": " Fall 1b: Freie gedämpfte Schwingung ( )  Für unterscheiden wir nach dem Vorzeichen von drei Unterfälle: schwache Dämpfung ( ), den aperiodischen Grenzfall ( ) und den Kriechfall ( ).  "
},
{
  "id": "ex-freie-schwingung-schwache-daempfung",
  "level": "2",
  "url": "sec-lineare-dgl-hoeherer-ordnung.html#ex-freie-schwingung-schwache-daempfung",
  "type": "Beispiel",
  "number": "5.2.20",
  "title": "Rechenbeispiel: Schwache Dämpfung.",
  "body": " Rechenbeispiel: Schwache Dämpfung   Lösen Sie mit , .    Hier ist , ; wegen liegt schwache Dämpfung vor. Die Nullstellen liefern Mit der Produktregel ist Aus und folgt Das System schwingt oszillierend um die Ruhelage, mit einer Amplitude, die exponentiell gegen abklingt.   "
},
{
  "id": "ex-freie-schwingung-aperiodischer-grenzfall",
  "level": "2",
  "url": "sec-lineare-dgl-hoeherer-ordnung.html#ex-freie-schwingung-aperiodischer-grenzfall",
  "type": "Beispiel",
  "number": "5.2.21",
  "title": "Rechenbeispiel: Aperiodischer Grenzfall.",
  "body": " Rechenbeispiel: Aperiodischer Grenzfall   Lösen Sie mit , .    Hier ist , : der aperiodische Grenzfall. Das charakteristische Polynom hat die doppelte Nullstelle , also und (Produktregel) . Aus und folgt Das System kehrt möglichst schnell in die Ruhelage zurück, ohne zu schwingen — der Grenzfall zwischen Schwingung und reinem Abklingen.   "
},
{
  "id": "ex-anwendung-stossdaempfer-auslegen",
  "level": "2",
  "url": "sec-lineare-dgl-hoeherer-ordnung.html#ex-anwendung-stossdaempfer-auslegen",
  "type": "Beispiel",
  "number": "5.2.22",
  "title": "Anwendungsbeispiel: Einen Stoßdämpfer auslegen (zur Vertiefung).",
  "body": " Anwendungsbeispiel: Einen Stoßdämpfer auslegen (zur Vertiefung)   Auf ein Rad eines Autos entfällt eine Masse von  kg, die Feder hat die Federkonstante  N\/m. Welche Dämpfungskonstante (in Ns\/m) muss der Stoßdämpfer haben, damit die Karosserie nach einer Bodenwelle im aperiodischen Grenzfall zur Ruhe kommt?    Es ist , also pro Sekunde. Der aperiodische Grenzfall verlangt , und mit folgt Ein schwächerer Dämpfer lässt das Auto nachwippen (schwache Dämpfung), ein stärkerer macht die Federung hart und träge (Kriechfall). In der Praxis wählt man deutlich weniger, etwa bis der Grenzfall-Dämpfung, weil ein leichtes Nachschwingen als komfortabler empfunden wird — aber der Grenzfall ist der Bezugspunkt der Auslegung.   "
},
{
  "id": "ex-freie-schwingung-kriechfall",
  "level": "2",
  "url": "sec-lineare-dgl-hoeherer-ordnung.html#ex-freie-schwingung-kriechfall",
  "type": "Beispiel",
  "number": "5.2.23",
  "title": "Rechenbeispiel: Kriechfall.",
  "body": " Rechenbeispiel: Kriechfall   Lösen Sie mit , .    Hier ist , ; wegen liegt der Kriechfall vor. Die Nullstellen sind reell und verschieden: , , also . Aus und folgt (Einsetzen von ) , , also Beide Anteile fallen monoton und ohne zu schwingen ab, wobei deutlich schneller abklingt als .   "
},
{
  "id": "fig-daempfungsfaelle",
  "level": "2",
  "url": "sec-lineare-dgl-hoeherer-ordnung.html#fig-daempfungsfaelle",
  "type": "Abbildung",
  "number": "5.2.24",
  "title": "",
  "body": " Die vier Fälle der freien Schwingung (also ) mit denselben Anfangswerten , : ungedämpft ( ), schwache Dämpfung ( ), aperiodischer Grenzfall ( ) und Kriechfall ( ). Der aperiodische Grenzfall erreicht die Ruhelage am schnellsten ohne Überschwingen.    Vier Kurven über der Zeitachse, alle starten bei mit waagerechter Tangente. Die ungedämpfte Kurve ist eine reine Kosinusschwingung mit konstanter Amplitude. Die schwach gedämpfte Kurve schwingt um null mit exponentiell abnehmender Amplitude. Die Kurve des aperiodischen Grenzfalls fällt monoton und schnell gegen null, ohne die Achse zu kreuzen. Die Kriechfall-Kurve fällt ebenfalls monoton gegen null, aber deutlich langsamer.     "
},
{
  "id": "ex-anwendung-systemidentifikation",
  "level": "2",
  "url": "sec-lineare-dgl-hoeherer-ordnung.html#ex-anwendung-systemidentifikation",
  "type": "Beispiel",
  "number": "5.2.25",
  "title": "Anwendungsbeispiel: Vom Messsignal zurück zur Differenzialgleichung.",
  "body": " Anwendungsbeispiel: Vom Messsignal zurück zur Differenzialgleichung   Ein Wegsensor an einer federnd aufgehängten Versuchsmasse (  kg) zeichnet nach einem Stoß die Auslenkung auf ( in mm, in Sekunden). Welche Differenzialgleichung beschreibt das System? Wie groß sind Federkonstante (in N\/m) und Dämpfungskonstante (in Ns\/m)?    Die Lösung besteht aus und , gehört also nach zum komplexen Nullstellenpaar . Das charakteristische Polynom ist daher und die DGL lautet . Probe: Mit der Produktregel ist also . Damit ist und , und mit , folgt Die Messung verrät die Parameter sehr direkt: Die Abklingrate liefert den Realteil , die Schwingungsdauer  s den Imaginärteil . Aus beiden zusammen ergibt sich . Dieses Rückwärtsrechnen vom Signal zum Modell heißt Systemidentifikation und ist in der Zustandsüberwachung von Maschinen Alltag: Ändert sich die gemessene Eigenfrequenz, hat sich meist an der Mechanik etwas verändert — etwa ein Riss oder eine gelockerte Schraube.   "
},
{
  "id": "rem-schwingung-erzwungen",
  "level": "2",
  "url": "sec-lineare-dgl-hoeherer-ordnung.html#rem-schwingung-erzwungen",
  "type": "Bemerkung",
  "number": "5.2.26",
  "title": "Fall 2: Erzwungene Schwingung und Resonanz.",
  "body": " Fall 2: Erzwungene Schwingung und Resonanz  Wirkt eine sinusförmige äußere Kraft mit Anregungsfrequenz , so liefert der Ansatz vom Typ rechte Seite eine partikuläre Lösung der Form , solange keine Nullstelle des charakteristischen Polynoms ist — das System übernimmt (nach einer Einschwingzeit) die Frequenz der Anregung. Ist das System jedoch ungedämpft und wird genau mit seiner Eigenfrequenz angeregt, so ist eine Nullstelle von , und es tritt Resonanz ein.  "
},
{
  "id": "ex-erzwungene-schwingung-resonanzkatastrophe",
  "level": "2",
  "url": "sec-lineare-dgl-hoeherer-ordnung.html#ex-erzwungene-schwingung-resonanzkatastrophe",
  "type": "Beispiel",
  "number": "5.2.27",
  "title": "Rechenbeispiel: Resonanzkatastrophe.",
  "body": " Rechenbeispiel: Resonanzkatastrophe   Bestimmen Sie die allgemeine Lösung des ungedämpften, angeregten Systems .    Das charakteristische Polynom hat die Nullstellen . Die Anregungsfrequenz trifft also genau die Eigenfrequenz — Resonanzfall. Ansatz: . Zweimaliges Ableiten mit der Produktregel liefert und beim Einsetzen in hebt sich der -Anteil gegen weg: Koeffizientenvergleich ergibt , , also Der Term wächst unbeschränkt: Die Amplitude der Schwingung nimmt linear mit der Zeit zu — eine Resonanzkatastrophe .   "
},
{
  "id": "ex-anwendung-resonanzkurve-komplex",
  "level": "2",
  "url": "sec-lineare-dgl-hoeherer-ordnung.html#ex-anwendung-resonanzkurve-komplex",
  "type": "Beispiel",
  "number": "5.2.28",
  "title": "Anwendungsbeispiel: Die Resonanzkurve mit komplexen Zahlen.",
  "body": " Anwendungsbeispiel: Die Resonanzkurve mit komplexen Zahlen   Ein gedämpftes System habe , und . Bestimmen Sie mit dem komplexen Ansatz für die Amplitude der erzwungenen Schwingung in Abhängigkeit von der Anregungsfrequenz , und werten Sie sie für , und aus.    Mit und wird aus der DGL eine einzige komplexe Gleichung für , und damit Dabei half die Quotientenregel für Beträge aus . Warum ist die Amplitude? Schreibt man , so ist : eine Schwingung mit Amplitude und Phasenverschiebung . Mit den Zahlenwerten ist , also Langsames Rütteln ( ) verschiebt das System einfach mit; bei der Eigenfrequenz ist der Ausschlag viermal so groß; sehr schnelles Rütteln kommt kaum noch an, das System ist zu träge. Wer schon eine Waschmaschine beim Hochdrehen zum Schleudern beobachtet hat, kennt diese Resonanzkurve : Beim Durchfahren einer bestimmten Drehzahl wackelt sie heftig, danach läuft sie wieder ruhig. Der Nenner ist übrigens genau das charakteristische Polynom , ausgewertet bei . Beim Tiefpassfilter in steht mit ebenso das charakteristische Polynom seiner DGL erster Ordnung bei im Nenner — Schwingkreise und Filter sind mathematisch Geschwister.   "
},
{
  "id": "rem-rlc-schwingkreis",
  "level": "2",
  "url": "sec-lineare-dgl-hoeherer-ordnung.html#rem-rlc-schwingkreis",
  "type": "Bemerkung",
  "number": "5.2.29",
  "title": "Anwendungsbeispiel: RLC-Schwingkreis.",
  "body": " Anwendungsbeispiel: RLC-Schwingkreis  Dieselbe Mathematik beschreibt einen elektrischen RLC-Reihenschwingkreis aus Induktivität , Widerstand und Kapazität : Für die Kondensatorladung gilt (ohne äußere Spannungsquelle) also genau die Form des freien Federpendels mit und . Ein großer Widerstand entspricht dabei starker Dämpfung: Die Ladung baut sich ab, ohne die Polarität zu wechseln (Kriechfall bzw. aperiodischer Grenzfall), während ein kleiner Widerstand zu einer gedämpft oszillierenden Entladung führt (schwache Dämpfung) — exakt dieselbe Fallunterscheidung wie beim mechanischen Pendel. Für  H und  µF ist ; der aperiodische Grenzfall liegt bei . Mit kleinerem Widerstand schwingt der Kreis.  "
},
{
  "id": "rem-daempfung-gradientenabstieg",
  "level": "2",
  "url": "sec-lineare-dgl-hoeherer-ordnung.html#rem-daempfung-gradientenabstieg",
  "type": "Bemerkung",
  "number": "5.2.30",
  "title": "Anwendungsbeispiel: Momentum im Gradientenabstieg.",
  "body": " Anwendungsbeispiel: Momentum im Gradientenabstieg  Die Fallunterscheidung des gedämpften Oszillators taucht auch beim Training neuronaler Netze wieder auf. Optimierer mit Momentum (der klassische Heavy-Ball -Ansatz) aktualisieren den Parametervektor nicht nur anhand des aktuellen Gradienten, sondern addieren einen Trägheitsterm, der die letzte Bewegungsrichtung fortsetzt. Im zeitkontinuierlichen Grenzfall lässt sich der Fehler (Abstand vom Optimum) einer solchen Trajektorie in der Nähe eines Minimums näherungsweise durch genau unsere Oszillator-DGL beschreiben, wobei von der Krümmung der Kostenfunktion und vom Momentum-Parameter abhängt. Zu schwache Dämpfung ( ) lässt die Optimierung um das Minimum überschwingen und oszillieren, zu starke Dämpfung ( ) macht die Konvergenz unnötig langsam. Der aperiodische Grenzfall markiert damit — genau wie beim Federpendel — die schnellstmögliche Annäherung ohne Überschwingen, ein Kriterium, das bei der Wahl von Lernrate und Momentum-Parameter in der Praxis eine Rolle spielt.  "
},
{
  "id": "sub-zusammenfassung-5-2-2",
  "level": "2",
  "url": "sec-lineare-dgl-hoeherer-ordnung.html#sub-zusammenfassung-5-2-2",
  "type": "Absatz (with a defined term)",
  "number": "",
  "title": "",
  "body": "Lineare DGL mit konstanten Koeffizienten: Charakteristisches Polynom Allgemeine Lösung homogen: Inhomogen: Resonanz: Harmonischer Oszillator Dieselbe Gleichung "
},
{
  "id": "exercise-buch-dgl-ordnung-linearitaet-bestimmen",
  "level": "2",
  "url": "sec-lineare-dgl-hoeherer-ordnung.html#exercise-buch-dgl-ordnung-linearitaet-bestimmen",
  "type": "Übung",
  "number": "5.2.6.1",
  "title": "",
  "body": "  Welche Ordnung hat die DGL ? Ist sie linear? Ist sie homogen oder inhomogen? Hat sie konstante Koeffizienten?    Die höchste auftretende Ableitung ist , die DGL hat also Ordnung . Sie ist linear, da jeweils nur in erster Potenz auftreten. Wegen der rechten Seite ist sie inhomogen . Der Koeffizient von ist nicht konstant, also hat die DGL keine konstanten Koeffizienten.   "
},
{
  "id": "exercise-buch-charakteristisches-polynom-einfach",
  "level": "2",
  "url": "sec-lineare-dgl-hoeherer-ordnung.html#exercise-buch-charakteristisches-polynom-einfach",
  "type": "Übung",
  "number": "5.2.6.2",
  "title": "",
  "body": "  Bestimmen Sie die allgemeine Lösung der DGL .    Das charakteristische Polynom hat die Nullstellen und . Die allgemeine Lösung lautet    "
},
{
  "id": "exercise-buch-inhomogene-dgl-einfach",
  "level": "2",
  "url": "sec-lineare-dgl-hoeherer-ordnung.html#exercise-buch-inhomogene-dgl-einfach",
  "type": "Übung",
  "number": "5.2.6.3",
  "title": "",
  "body": "  Bestimmen Sie die allgemeine Lösung der DGL .    Das charakteristische Polynom hat die Nullstellen , also . Da keine Nullstelle von ist, machen wir für die konstante Störfunktion den Ansatz . Einsetzen liefert . Die allgemeine Lösung ist    "
},
{
  "id": "exercise-buch-schwingfall-klassifizieren",
  "level": "2",
  "url": "sec-lineare-dgl-hoeherer-ordnung.html#exercise-buch-schwingfall-klassifizieren",
  "type": "Übung",
  "number": "5.2.6.4",
  "title": "",
  "body": "  Ein gedämpftes Federpendel genügt der DGL . Welcher Dämpfungsfall liegt vor, und wie lautet die allgemeine Lösung?    In der Normalform ist , . Wegen liegt der Kriechfall vor. Die Nullstellen des charakteristischen Polynoms sind , also , . Die allgemeine Lösung lautet    "
},
{
  "id": "backmatter-2",
  "level": "1",
  "url": "backmatter-2.html",
  "type": "Register",
  "number": "",
  "title": "Stichwortverzeichnis",
  "body": " Stichwortverzeichnis   "
}
]

var ptx_lunr_idx = lunr(function () {
  this.ref('id')
  this.field('title')
  this.field('body')
  this.metadataWhitelist = ['position']

  ptx_lunr_docs.forEach(function (doc) {
    this.add(doc)
  }, this)
})
