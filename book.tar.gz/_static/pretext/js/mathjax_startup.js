/***************************************************************
 * Implements startup of MathJax v4
 ***************************************************************/

// Base config options. Will be supplemented by optional parts later
let mathJaxOpts = {
  "tex": {
    "inlineMath": [
      [
        "\\(",
        "\\)"
      ]
    ],
    "tags": "none",
    "tagSide": "right",
    "tagIndent": ".8em",
    "packages": {
      "[+]": [
        "amscd",
        "color",
        "knowl"
      ]
    }
  },
  "options": {
    "ignoreHtmlClass": "tex2jax_ignore|ignore-math",
    "processHtmlClass": "process-math",
  },
  "chtml": {
    "scale": 0.98,
    "mtextInheritFont": true
  },
  "loader": {
    "load": [
      "input/asciimath",
      "[tex]/amscd",
      "[tex]/color",
    ]
  }
};


export function startMathJax(opts) {
  // window.runestoneMathReady is the promise that Runestone uses to know when
  // MathJax is ready. It is deliberately fulfilled, never rejected, with
  // a value of either MathJax or null.
  let resolveRunestoneMathReady;
  const runestoneMathReady = new Promise((resolve) => {
    resolveRunestoneMathReady = resolve;
  });
  window.runestoneMathReady = runestoneMathReady;

  if(opts.hasWebworkReps || opts.hasSage) {
    mathJaxOpts['renderActions'] = {
      "findScript": [
        10,
        function (doc) {
          document.querySelectorAll('script[type^="math/tex"]').forEach(function (node) {
            var display = !!node.type.match(/; *mode=display/);
            var math = new doc.options.MathItem(node.textContent, doc.inputJax[0], display);
            var text = document.createTextNode('');
            node.parentNode.replaceChild(text, node);
            math.start = { node: text, delim: '', n: 0 };
            math.end = { node: text, delim: '', n: 0 };
            doc.math.push(math);
          });
        },
        ""
      ]
    }
  }

  if(opts.isReact) {
    mathJaxOpts['startup'] = {
      typeset: false,
    }
  } else {
    mathJaxOpts['startup'] = {
      ready() {
        window.PTX_MACROS = document.getElementById('latex-macros').textContent;
        const { Configuration } = MathJax._.input.tex.Configuration;
        const configuration = Configuration.create("knowl", {
          handler: {
            macro: ["knowl"]
          }
        });

        const NodeUtil = MathJax._.input.tex.NodeUtil.default;

        function GetArgumentMML(parser, name) {
          const arg = parser.ParseArg(name);
          if (!NodeUtil.isInferred(arg)) {
            return arg;
          }
          const children = NodeUtil.getChildren(arg);
          if (children.length === 1) {
            return children[0];
          }
          const mrow = parser.create("node", "mrow");
          NodeUtil.copyChildren(arg, mrow);
          NodeUtil.copyAttributes(arg, mrow);
          return mrow;
        };

        const CommandMap = MathJax._.input.tex.TokenMap.CommandMap;
        new CommandMap(
          "knowl",
          {
            knowl(parser, name) {
              const url = parser.GetArgument(name);
              const arg = GetArgumentMML(parser, name);
              const mrow = parser.create("node", "mrow", [arg], { tabindex: '0', "data-knowl": url });
              parser.Push(mrow);
            }
          }
        );

        MathJax.startup.defaultReady();
      },
      pageReady() {
        // Let MathJax keep reporting a genuine initial-typesetting failure,
        // but still release Runestone's queue. It will determine whether a
        // usable typesetPromise remains and otherwise treat MathJax as absent.
        return MathJax.startup.defaultPageReady().then(
          () => resolveRunestoneMathReady(MathJax),
          (error) => {
            resolveRunestoneMathReady(null);
            throw error;
          },
        );
      },
    }
  }

  if(opts.htmlPresentation) {
    mathJaxOpts['options']['menuOptions'] = {
      "settings": {
        "zoom": "Click",
        "zscale": "300%"
      }
    }
  }

  // Speech generation.  MathJax's Speech Rule Engine produces the spoken
  // form of every expression and attaches it as an aria-label; screen
  // readers use it, and so does the read-aloud feature, which hands off to
  // it rather than trying to voice the visual output.  This is on by
  // default in v4's combined components, but assert it explicitly so a
  // future change of default cannot silently break either consumer.
  mathJaxOpts['options']['enableSpeech'] = true;

  // Match the speech locale to the document language when SRE supports it,
  // otherwise leave SRE's own default in place (graceful degradation).
  const sreLocales = ['en', 'fr', 'es', 'de', 'it'];
  const primaryTag = (opts.lang || '').split('-')[0].toLowerCase();
  if(sreLocales.includes(primaryTag)) {
    mathJaxOpts['options']['sre'] = { "locale": primaryTag };
  }

  // Apply the options
  window.MathJax = mathJaxOpts;

  // The MathJax CDN request may fail before this module runs. The generated
  // script records that failure on itself; inspect it after installing the
  // resolver so either execution order fulfils the same null result.
  const mathJaxScript = document.querySelector('script[data-pretext-mathjax]');
  if (mathJaxScript) {
    mathJaxScript.addEventListener(
      'error',
      () => resolveRunestoneMathReady(null),
      { once: true },
    );
    if (mathJaxScript.dataset.loadFailed === 'true') {
      resolveRunestoneMathReady(null);
    }
  }
}

